import { serve } from "https://deno.land/std@0.168.0/http/server.ts"
import { createClient } from 'https://esm.sh/@supabase/supabase-js@2'

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
}

interface AssignDeliveryRequest {
  order_id: string;
  motoboy_id: string;
  notes?: string;
}

serve(async (req) => {
  // Handle CORS preflight requests
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  if (req.method !== 'POST') {
    return new Response(
      JSON.stringify({ error: 'Method not allowed' }),
      { status: 405, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );
  }

  try {
    const supabase = createClient(
      Deno.env.get('SUPABASE_URL') ?? '',
      Deno.env.get('SUPABASE_SERVICE_ROLE_KEY') ?? ''
    );

    const authHeader = req.headers.get('Authorization')!;
    const token = authHeader.replace('Bearer ', '');
    
    // Set auth context for RLS
    const { data: { user }, error: authError } = await supabase.auth.getUser(token);
    if (authError || !user) {
      console.error('Erro de autenticação:', authError);
      return new Response(
        JSON.stringify({ error: 'Unauthorized' }),
        { status: 401, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    const { order_id, motoboy_id, notes }: AssignDeliveryRequest = await req.json();

    console.log('🚚 Iniciando atribuição de entrega:', { 
      order_id, 
      motoboy_id, 
      user_id: user.id,
      notes 
    });

    // Validar que o pedido pertence ao usuário e está em preparo
    const { data: order, error: orderError } = await supabase
      .from('user_orders')
      .select('id, status, order_number, customer_name, customer_phone, delivery_address, items, total, payment_method')
      .eq('id', order_id)
      .eq('user_id', user.id)
      .eq('status', 'preparing')
      .single();

    if (orderError || !order) {
      console.error('❌ Pedido não encontrado ou não está em preparo:', orderError);
      return new Response(
        JSON.stringify({ 
          error: 'Pedido não encontrado ou não está em status de preparo',
          details: orderError?.message 
        }),
        { status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    // Validar que o motoboy está ativo e pertence ao usuário
    const { data: motoboy, error: motoboyError } = await supabase
      .from('motoboys')
      .select('id, name, phone_e164, active')
      .eq('id', motoboy_id)
      .eq('user_id', user.id)
      .eq('active', true)
      .single();

    if (motoboyError || !motoboy) {
      console.error('❌ Motoboy não encontrado ou inativo:', motoboyError);
      return new Response(
        JSON.stringify({ 
          error: 'Motoboy não encontrado ou inativo',
          details: motoboyError?.message 
        }),
        { status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    console.log('✅ Validações ok:', { order: order.order_number, motoboy: motoboy.name });

    // Iniciar transação
    const { data: delivery, error: deliveryError } = await supabase
      .from('deliveries')
      .insert({
        user_id: user.id,
        order_id: order_id,
        motoboy_id: motoboy_id,
        status: 'assigned',
        assigned_by: user.id,
        notes: notes || null
      })
      .select('*')
      .single();

    if (deliveryError) {
      console.error('❌ Erro ao criar entrega:', deliveryError);
      return new Response(
        JSON.stringify({ 
          error: 'Erro ao criar registro de entrega',
          details: deliveryError.message 
        }),
        { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    // Atualizar status do pedido para "delivery" (Em Entrega)
    const { error: updateError } = await supabase
      .from('user_orders')
      .update({ 
        status: 'delivery',
        out_for_delivery_at: new Date().toISOString()
      })
      .eq('id', order_id);

    if (updateError) {
      console.error('❌ Erro ao atualizar pedido:', updateError);
      
      // Rollback: remover entrega criada
      await supabase
        .from('deliveries')
        .delete()
        .eq('id', delivery.id);

      return new Response(
        JSON.stringify({ 
          error: 'Erro ao atualizar status do pedido',
          details: updateError.message 
        }),
        { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    console.log('✅ Entrega atribuída com sucesso:', delivery.id);

    // Buscar instância WhatsApp ativa para envio de mensagens
    const { data: whatsappInstance } = await supabase
      .from('whatsapp_instances')
      .select('instance_id, token_instance, status')
      .eq('user_id', user.id)
      .eq('status', 'connected')
      .order('updated_at', { ascending: false })
      .limit(1)
      .maybeSingle();

    // Enviar mensagens WhatsApp (não bloquear a resposta)
    if (whatsappInstance && whatsappInstance.instance_id && whatsappInstance.token_instance) {
      console.log('📱 Enviando mensagens WhatsApp...');
      
      // Mensagem para o motoboy
      const motoboyMessage = `🚚 *NOVA ENTREGA* 🚚

📋 *Pedido:* ${order.order_number}
👤 *Cliente:* ${order.customer_name}
📱 *Telefone:* ${order.customer_phone}

📍 *Endereço de Entrega:*
${order.delivery_address || 'Não informado'}

📦 *Itens:*
${order.items ? JSON.parse(order.items as string).map((item: any) => 
  `• ${item.quantity}x ${item.name} - R$ ${item.price.toFixed(2)}`
).join('\n') : 'Não especificado'}

💰 *Total:* R$ ${order.total}
💳 *Pagamento:* ${order.payment_method || 'Não especificado'}

${notes ? `📝 *Observações:* ${notes}` : ''}

🗺️ *Ver rota:* https://maps.google.com/maps?q=${encodeURIComponent(order.delivery_address || '')}`;

      // Mensagem para o cliente
      const customerMessage = `🚚 *Seu pedido saiu para entrega!*

📋 *Pedido:* ${order.order_number}
🚴 *Entregador:* ${motoboy.name}
📱 *Contato do entregador:* ${motoboy.phone_e164}

Seu pedido está a caminho! 🍔✨`;

      // Enviar mensagens (sem awaitar para não bloquear a resposta)
      Promise.all([
        // Mensagem para motoboy
        fetch('https://mzhyxympbmjjergvbwfa.supabase.co/functions/v1/wa-send-text', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            'Authorization': authHeader
          },
          body: JSON.stringify({
            instance_id: whatsappInstance.instance_id,
            token_instance: whatsappInstance.token_instance,
            phone: motoboy.phone_e164,
            message: motoboyMessage
          })
        }),
        // Mensagem para cliente
        order.customer_phone ? fetch('https://mzhyxympbmjjergvbwfa.supabase.co/functions/v1/wa-send-text', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            'Authorization': authHeader
          },
          body: JSON.stringify({
            instance_id: whatsappInstance.instance_id,
            token_instance: whatsappInstance.token_instance,
            phone: order.customer_phone,
            message: customerMessage
          })
        }) : Promise.resolve()
      ]).then(() => {
        console.log('✅ Mensagens WhatsApp enviadas');
      }).catch((error) => {
        console.error('❌ Erro ao enviar mensagens WhatsApp:', error);
      });
    } else {
      console.log('⚠️ WhatsApp não configurado - mensagens não enviadas');
    }

    // Retornar sucesso
    return new Response(
      JSON.stringify({
        success: true,
        delivery_id: delivery.id,
        order_id: order_id,
        motoboy: {
          id: motoboy.id,
          name: motoboy.name,
          phone_e164: motoboy.phone_e164
        },
        message: `Entrega atribuída para ${motoboy.name}`
      }),
      {
        status: 200,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' }
      }
    );

  } catch (error) {
    console.error('❌ Erro geral na atribuição de entrega:', error);
    return new Response(
      JSON.stringify({ 
        error: 'Erro interno do servidor',
        details: error.message 
      }),
      { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );
  }
});