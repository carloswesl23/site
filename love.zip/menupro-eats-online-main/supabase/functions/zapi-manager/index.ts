import { serve } from "https://deno.land/std@0.190.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

const supabase = createClient(
  Deno.env.get('SUPABASE_URL') ?? '',
  Deno.env.get('SUPABASE_SERVICE_ROLE_KEY') ?? ''
);

interface CreateInstanceRequest {
  instanceName: string;
  userId: string;
}

interface UpdateStatusRequest {
  instanceId: string;
  userId: string;
}

interface DisconnectInstanceRequest {
  instanceId: string;
  userId: string;
}

interface ConnectPhoneRequest {
  instanceId: string;
  userId: string;
  phone: string;
}

// Função para sanitizar o nome da instância
const sanitizeInstanceName = (name: string): string => {
  return name
    .toLowerCase()
    .normalize('NFD')
    .replace(/[\u0300-\u036f]/g, '') // Remove acentos
    .replace(/[^a-z0-9-]/g, '-') // Substitui caracteres especiais por hífen
    .replace(/-+/g, '-') // Remove hífens duplicados
    .replace(/^-|-$/g, '') // Remove hífens do início e fim
    .substring(0, 50); // Limita a 50 caracteres
};

const handler = async (req: Request): Promise<Response> => {
  // Handle CORS preflight requests
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const url = new URL(req.url);
    const action = url.searchParams.get('action');
    const partnerToken = Deno.env.get('ZAPI_PARTNER_TOKEN');
    
    console.log('=== Z-API Manager Debug ===');
    console.log('Action:', action);
    console.log('Partner token configured:', partnerToken ? 'YES' : 'NO');
    console.log('Partner token length:', partnerToken?.length || 0);
    console.log('Partner token starts with:', partnerToken?.substring(0, 10) || 'N/A');

    if (!partnerToken || partnerToken.trim() === '') {
      console.error('ZAPI_PARTNER_TOKEN not found or empty');
      return new Response(
        JSON.stringify({ error: 'Partner token not configured properly' }),
        { status: 500, headers: { 'Content-Type': 'application/json', ...corsHeaders } }
      );
    }

    switch (action) {
      case 'qrcode': {
        const { instanceId, userId }: UpdateStatusRequest = await req.json();
        console.log('=== QR CODE GENERATION START ===');
        console.log('Instance ID:', instanceId);
        console.log('User ID:', userId);
        
        // Get instance from database
        const { data: instance, error: getError } = await supabase
          .from('whatsapp_instances')
          .select('*')
          .eq('user_id', userId)
          .eq('instance_id', instanceId)
          .single();

        if (getError || !instance) {
          console.error('Instance not found in database:', getError);
          return new Response(
            JSON.stringify({ error: 'Instance not found in database' }),
            { status: 404, headers: { 'Content-Type': 'application/json', ...corsHeaders } }
          );
        }

        console.log('Instance found, token starts with:', instance.token_instance?.substring(0, 10));
        
        try {
          // Primeiro, reinicializar a instância para garantir que esteja pronta
          console.log('Reinicializando instância antes de gerar QR code...');
          
          const restartUrl = `https://api.z-api.io/instances/${instanceId}/token/${instance.token_instance}/restart`;
          
          try {
            const restartResponse = await fetch(restartUrl, {
              method: 'GET',
              headers: {
                'Client-Token': 'F25f061eefa514271aac2c1b3dafc9acdS',
                'Authorization': `Bearer ${partnerToken}`,
              },
            });
            
            console.log('Restart response status:', restartResponse.status);
            
            if (restartResponse.ok) {
              console.log('Instance restarted successfully, waiting 5 seconds...');
              // Aguardar mais tempo após reiniciar
              await new Promise(resolve => setTimeout(resolve, 5000));
            }
          } catch (restartError) {
            console.log('Restart failed, continuing anyway:', restartError.message);
          }
          
          // Usar o endpoint correto da Z-API para obter QR code como JSON
          const qrCodeUrl = `https://api.z-api.io/instances/${instanceId}/token/${instance.token_instance}/qr-code`;
          console.log('QR Code URL:', qrCodeUrl);
          
          const qrResponse = await fetch(qrCodeUrl, {
            method: 'GET',
            headers: {
              'Client-Token': 'F25f061eefa514271aac2c1b3dafc9acdS',
              'Authorization': `Bearer ${partnerToken}`,
            },
          });

          console.log('QR Code API response status:', qrResponse.status);
          
          if (!qrResponse.ok) {
            const errorText = await qrResponse.text();
            console.error('QR Code API error response:', errorText);
            
            // Se der erro 404, tentar gerar QR code primeiro
            if (qrResponse.status === 404) {
              console.log('QR Code not found, trying to generate new QR code...');
              
              // Tentar endpoint para gerar novo QR code
              const generateUrl = `https://api.z-api.io/instances/${instanceId}/token/${instance.token_instance}/generate-qr-code`;
              
              try {
                const generateResponse = await fetch(generateUrl, {
                  method: 'POST',
                  headers: {
                    'Client-Token': 'F25f061eefa514271aac2c1b3dafc9acdS',
                    'Authorization': `Bearer ${partnerToken}`,
                    'Content-Type': 'application/json'
                  },
                });
                
                if (generateResponse.ok) {
                  console.log('QR code generation requested, waiting 2 seconds...');
                  await new Promise(resolve => setTimeout(resolve, 2000));
                  
                  // Tentar obter o QR code novamente
                  const retryResponse = await fetch(qrCodeUrl, {
                    method: 'GET',
                    headers: {
                      'Client-Token': 'F25f061eefa514271aac2c1b3dafc9acdS',
                      'Authorization': 'Bearer eyJhbGciOiJIUzI1NiJ9.eyJpYXQiOjQ5MDg0MzU0NTUsInN1YiI6ImNhcmxvc3dlc2xsZW5ob3RtYXJ0QGdtYWlsLmNvbSIsImlzcyI6ImVtRmhjQzF6WldOMWNtbDBlUzFoY0drPSIsImF1ZCI6ImVtRmhjQzFoY0drPSIsImV4cCI6NDkwODQzNTQ1NSwib25EZW1hbmQiOnRydWUsInJvbGUiOiJFTlRFUlBSSVNFIiwiaW50ZWdyYXRvciI6dHJ1ZSwidGVuYW50T3duZXIiOiJaVzFoYVd4QVptOTFjbkpwZUdWc0xtbDAifQ.OmtaNR3G-fQWVVzYmfl8Vbgl1Np009zKmpBTNK8C8Vo',
                      'Content-Type': 'application/json'
                    },
                  });
                  
                  if (retryResponse.ok) {
                    const retryData = await retryResponse.json();
                    if (retryData.qrcode) {
                      const qrCodeFormatted = retryData.qrcode.startsWith('data:') 
                        ? retryData.qrcode 
                        : `data:image/png;base64,${retryData.qrcode}`;
                      
                      // Atualizar no banco de dados
                      const { error: updateError } = await supabase
                        .from('whatsapp_instances')
                        .update({ 
                          qr_code: qrCodeFormatted,
                          status: 'qrcode'
                        })
                        .eq('instance_id', instanceId)
                        .eq('user_id', userId);

                      if (updateError) {
                        console.error('Error updating QR code in database:', updateError);
                      }

                      console.log('=== QR CODE GENERATION SUCCESS (RETRY) ===');
                      return new Response(
                        JSON.stringify({ 
                          success: true, 
                          qrCode: qrCodeFormatted,
                          status: 'qrcode',
                          message: 'QR Code gerado com sucesso'
                        }),
                        { headers: { 'Content-Type': 'application/json', ...corsHeaders } }
                      );
                    }
                  }
                }
              } catch (generateError) {
                console.log('Failed to generate QR code:', generateError.message);
              }
              
              return new Response(
                JSON.stringify({ 
                  error: 'QR Code not available',
                  message: 'A instância ainda não está pronta. Aguarde alguns segundos e tente novamente.',
                  status: 'initializing'
                }),
                { status: 400, headers: { 'Content-Type': 'application/json', ...corsHeaders } }
              );
            }
            
            return new Response(
              JSON.stringify({ 
                error: 'Failed to get QR Code',
                message: `Erro ao obter QR Code da Z-API: ${qrResponse.status}`,
                details: errorText,
                url: qrCodeUrl
              }),
              { status: 400, headers: { 'Content-Type': 'application/json', ...corsHeaders } }
            );
          }

          // Parse da resposta JSON
          const qrData = await qrResponse.json();
          console.log('QR Code data received:', qrData);
          
          // Verificar se temos o QR code na resposta
          if (!qrData || (!qrData.qrcode && !qrData.value)) {
            console.error('No QR code in response:', qrData);
            return new Response(
              JSON.stringify({ 
                error: 'QR Code not found',
                message: 'QR Code não encontrado na resposta da API. Tente novamente em alguns segundos.',
                details: qrData
              }),
              { status: 400, headers: { 'Content-Type': 'application/json', ...corsHeaders } }
            );
          }

          // Garantir que esteja no formato data URL correto
          const qrCodeRaw = qrData.qrcode || qrData.value;
          const qrCodeFormatted = qrCodeRaw.startsWith('data:') 
            ? qrCodeRaw 
            : `data:image/png;base64,${qrCodeRaw}`;
          
          console.log('QR Code formatted successfully');
          
          // Atualizar no banco de dados
          const { error: updateError } = await supabase
            .from('whatsapp_instances')
            .update({ 
              qr_code: qrCodeFormatted,
              status: 'qrcode'
            })
            .eq('instance_id', instanceId)
            .eq('user_id', userId);

          if (updateError) {
            console.error('Error updating QR code in database:', updateError);
          }

          console.log('=== QR CODE GENERATION SUCCESS ===');
          return new Response(
            JSON.stringify({ 
              success: true, 
              qrCode: qrCodeFormatted,
              status: 'qrcode',
              message: 'QR Code gerado com sucesso'
            }),
            { headers: { 'Content-Type': 'application/json', ...corsHeaders } }
          );

        } catch (error) {
          console.error('=== QR CODE GENERATION ERROR ===');
          console.error('Error details:', error);
          return new Response(
            JSON.stringify({ 
              error: 'Internal server error',
              message: 'Erro interno ao gerar QR Code',
              details: error.message
            }),
            { status: 500, headers: { 'Content-Type': 'application/json', ...corsHeaders } }
          );
        }
      }

      case 'create': {
        const { instanceName, userId }: CreateInstanceRequest = await req.json();
        
        // Sanitizar o nome da instância
        const sanitizedName = sanitizeInstanceName(instanceName);
        const uniqueInstanceName = `lovezap-${sanitizedName}-${Date.now()}`;
        
        console.log('=== Creating Z-API Instance ===');
        console.log('Original instance name:', instanceName);
        console.log('Sanitized instance name:', uniqueInstanceName);
        console.log('User ID:', userId);

        const requestBody = {
          instanceName: uniqueInstanceName,
          name: instanceName,
          email: `${userId}@temp.com`, // Email temporário baseado no userId
          webhookReceiveMessage: `https://mzhyxympbmjjergvbwfa.supabase.co/functions/v1/zapi-webhook?userId=${userId}&type=message`,
          webhookReceiveStatus: `https://mzhyxympbmjjergvbwfa.supabase.co/functions/v1/zapi-webhook?userId=${userId}&type=status`,
          webhookConnect: `https://mzhyxympbmjjergvbwfa.supabase.co/functions/v1/zapi-webhook?userId=${userId}&type=connect`,
          webhookDisconnect: `https://mzhyxympbmjjergvbwfa.supabase.co/functions/v1/zapi-webhook?userId=${userId}&type=disconnect`,
          webhookDeliveryReceipt: `https://mzhyxympbmjjergvbwfa.supabase.co/functions/v1/zapi-webhook?userId=${userId}&type=delivery`,
          webhookNotifyMessage: `https://mzhyxympbmjjergvbwfa.supabase.co/functions/v1/zapi-webhook?userId=${userId}&type=message`
        };

        console.log('Request body:', JSON.stringify(requestBody, null, 2));
        console.log('Z-API URL:', 'https://api.z-api.io/instances/integrator/on-demand');
        console.log('Authorization header:', `Bearer ${partnerToken.substring(0, 20)}...`);

        // Create instance on Z-API using on-demand endpoint
        const zapiResponse = await fetch('https://api.z-api.io/instances/integrator/on-demand', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            'Client-Token': 'F25f061eefa514271aac2c1b3dafc9acdS',
            'Authorization': 'Bearer eyJhbGciOiJIUzI1NiJ9.eyJpYXQiOjQ5MDg0MzU0NTUsInN1YiI6ImNhcmxvc3dlc2xsZW5ob3RtYXJ0QGdtYWlsLmNvbSIsImlzcyI6ImVtRmhjQzF6WldOMWNtbDBlUzFoY0drPSIsImF1ZCI6ImVtRmhjQzFoY0drPSIsImV4cCI6NDkwODQzNTQ1NSwib25EZW1hbmQiOnRydWUsInJvbGUiOiJFTlRFUlBSSVNFIiwiaW50ZWdyYXRvciI6dHJ1ZSwidGVuYW50T3duZXIiOiJaVzFoYVd4QVptOTFjbkpwZUdWc0xtbDAifQ.OmtaNR3G-fQWVVzYmfl8Vbgl1Np009zKmpBTNK8C8Vo'
          },
          body: JSON.stringify(requestBody),
        });

        console.log('=== Z-API Response ===');
        console.log('Status:', zapiResponse.status);
        console.log('Status Text:', zapiResponse.statusText);
        console.log('Headers:', Object.fromEntries(zapiResponse.headers.entries()));

        if (!zapiResponse.ok) {
          const errorText = await zapiResponse.text();
          console.error('=== Z-API ERROR ===');
          console.error('Status:', zapiResponse.status);
          console.error('Status Text:', zapiResponse.statusText);
          console.error('Response body:', errorText);
          
          // Tentar fazer parse do erro se for JSON
          let errorDetails = errorText;
          try {
            const errorJson = JSON.parse(errorText);
            errorDetails = errorJson.error || errorJson.message || errorText;
          } catch (e) {
            // Manter errorText original se não for JSON válido
          }

          return new Response(
            JSON.stringify({ 
              error: 'Failed to create Z-API instance', 
              details: errorDetails,
              status: zapiResponse.status,
              statusText: zapiResponse.statusText
            }),
            { status: 500, headers: { 'Content-Type': 'application/json', ...corsHeaders } }
          );
        }

        const zapiData = await zapiResponse.json();
        console.log('=== Z-API Success ===');
        console.log('Response data:', JSON.stringify(zapiData, null, 2));

        // Configure auto-read messages (activate automatic message reading)
        try {
          console.log('Configuring auto-read messages...');
          const autoReadResponse = await fetch(`https://api.z-api.io/instances/${zapiData.id || zapiData.instance}/token/${zapiData.token}/update-auto-read-message`, {
            method: 'PUT',
            headers: {
              'Client-Token': 'F25f061eefa514271aac2c1b3dafc9acdS',
              'Authorization': `Bearer ${partnerToken}`,
              'Content-Type': 'application/json',
            },
            body: JSON.stringify({
              value: true
            }),
          });
          
          if (autoReadResponse.ok) {
            console.log('Auto-read messages configured successfully');
          } else {
            console.log('Failed to configure auto-read messages, continuing...');
          }
        } catch (autoReadError) {
          console.log('Error configuring auto-read messages:', autoReadError.message);
        }

        // Save instance to database
        const { data: instanceData, error: dbError } = await supabase
          .from('whatsapp_instances')
          .insert({
            user_id: userId,
            instance_id: zapiData.id || zapiData.instance,
            instance_name: uniqueInstanceName,
            token_instance: zapiData.token,
            webhook_url: `https://mzhyxympbmjjergvbwfa.supabase.co/functions/v1/zapi-webhook?userId=${userId}`,
            status: 'disconnected',
            qr_code: zapiData.qrcode || null
          })
          .select()
          .single();

        if (dbError) {
          console.error('Database error:', dbError);
          return new Response(
            JSON.stringify({ error: 'Failed to save instance to database', details: dbError.message }),
            { status: 500, headers: { 'Content-Type': 'application/json', ...corsHeaders } }
          );
        }

        console.log('=== Database Success ===');
        console.log('Saved instance:', instanceData);

        return new Response(
          JSON.stringify({ 
            success: true, 
            instance: instanceData,
            qrCode: zapiData.qrcode 
          }),
          { status: 200, headers: { 'Content-Type': 'application/json', ...corsHeaders } }
        );
      }

      case 'status': {
        const { instanceId, userId }: UpdateStatusRequest = await req.json();
        
        console.log('Checking status for instance:', instanceId);

        // Get instance from database
        const { data: instance, error: getError } = await supabase
          .from('whatsapp_instances')
          .select('*')
          .eq('user_id', userId)
          .eq('instance_id', instanceId)
          .single();

        if (getError || !instance) {
          console.error('Instance not found:', getError);
          return new Response(
            JSON.stringify({ error: 'Instance not found' }),
            { status: 404, headers: { 'Content-Type': 'application/json', ...corsHeaders } }
          );
        }

        try {
          // Primeiro, verificar o status completo da instância usando endpoint correto da Z-API
          console.log('Fetching complete instance status from Z-API...');
          const instanceResponse = await fetch(`https://api.z-api.io/instances/${instanceId}/token/${instance.token_instance}/status`, {
            headers: {
              'Client-Token': 'F25f061eefa514271aac2c1b3dafc9acdS',
              'Authorization': 'Bearer eyJhbGciOiJIUzI1NiJ9.eyJpYXQiOjQ5MDg0MzU0NTUsInN1YiI6ImNhcmxvc3dlc2xsZW5ob3RtYXJ0QGdtYWlsLmNvbSIsImlzcyI6ImVtRmhjQzF6WldOMWNtbDBlUzFoY0drPSIsImF1ZCI6ImVtRmhjQzFoY0drPSIsImV4cCI6NDkwODQzNTQ1NSwib25EZW1hbmQiOnRydWUsInJvbGUiOiJFTlRFUlBSSVNFIiwiaW50ZWdyYXRvciI6dHJ1ZSwidGVuYW50T3duZXIiOiJaVzFoYVd4QVptOTFjbkpwZUdWc0xtbDAifQ.OmtaNR3G-fQWVVzYmfl8Vbgl1Np009zKmpBTNK8C8Vo',
            },
          });

          console.log('Instance response status:', instanceResponse.status);
          
          if (!instanceResponse.ok) {
            console.error('Z-API instance error:', await instanceResponse.text());
            return new Response(
              JSON.stringify({ error: 'Failed to check instance status' }),
              { status: 500, headers: { 'Content-Type': 'application/json', ...corsHeaders } }
            );
          }

          const instanceData = await instanceResponse.json();
          console.log('Complete instance data:', JSON.stringify(instanceData, null, 2));

          // Verificar o status real da instância
          let realStatus = 'disconnected';
          let qrCodeFormatted = null;
          let isConnected = false;

          // Extrair status e determinar o estado correto
          if (instanceData.status) {
            console.log('Current status:', instanceData.status);
            
            if (instanceData.status === 'qrcode' || instanceData.status === 'QRCODE') {
              realStatus = 'qrcode';
              
              // Tentar buscar QR Code
              if (instanceData.qrcode) {
                qrCodeFormatted = instanceData.qrcode.startsWith('data:') 
                  ? instanceData.qrcode 
                  : `data:image/png;base64,${instanceData.qrcode}`;
                console.log('QR Code found in instance data');
              } else {
                // Buscar QR Code no endpoint específico correto
                console.log('Fetching QR Code from dedicated endpoint...');
                try {
                  const qrResponse = await fetch(`https://api.z-api.io/instances/${instanceId}/token/${instance.token_instance}/qr-code`, {
                    headers: {
                      'Client-Token': 'F25f061eefa514271aac2c1b3dafc9acdS',
                      'Authorization': 'Bearer eyJhbGciOiJIUzI1NiJ9.eyJpYXQiOjQ5MDg0MzU0NTUsInN1YiI6ImNhcmxvc3dlc2xsZW5ob3RtYXJ0QGdtYWlsLmNvbSIsImlzcyI6ImVtRmhjQzF6WldOMWNtbDBlUzFoY0drPSIsImF1ZCI6ImVtRmhjQzFoY0drPSIsImV4cCI6NDkwODQzNTQ1NSwib25EZW1hbmQiOnRydWUsInJvbGUiOiJFTlRFUlBSSVNFIiwiaW50ZWdyYXRvciI6dHJ1ZSwidGVuYW50T3duZXIiOiJaVzFoYVd4QVptOTFjbkpwZUdWc0xtbDAifQ.OmtaNR3G-fQWVVzYmfl8Vbgl1Np009zKmpBTNK8C8Vo',
                    },
                  });
                  
                  if (qrResponse.ok) {
                    const qrData = await qrResponse.json();
                    console.log('QR Code response data:', qrData);
                    
                    if (qrData.qrcode) {
                      qrCodeFormatted = qrData.qrcode.startsWith('data:') 
                        ? qrData.qrcode 
                        : `data:image/png;base64,${qrData.qrcode}`;
                    } else if (qrData.value) {
                      qrCodeFormatted = qrData.value.startsWith('data:') 
                        ? qrData.value 
                        : `data:image/png;base64,${qrData.value}`;
                    }
                  }
                } catch (qrError) {
                  console.log('Error fetching QR code from endpoint:', qrError);
                }
              }
            } else if (instanceData.status === 'connected' || instanceData.status === 'CONNECTED') {
              realStatus = 'connected';
              isConnected = true;
              qrCodeFormatted = null; // Limpar QR code quando conectado
            } else if (instanceData.status === 'waiting_phone' || instanceData.status === 'WAITING_PHONE') {
              realStatus = 'waiting_phone';
            } else if (instanceData.status === 'initializing' || instanceData.status === 'INITIALIZING') {
              realStatus = 'initializing';
            } else {
              realStatus = 'disconnected';
            }
          }

          // Atualizar no banco de dados
          const updateFields: any = { 
            status: realStatus,
            qr_code: qrCodeFormatted
          };

          const { error: updateError } = await supabase
            .from('whatsapp_instances')
            .update(updateFields)
            .eq('user_id', userId)
            .eq('instance_id', instanceId);

          if (updateError) {
            console.error('Database update error:', updateError);
          }

          console.log('Status check completed. Final status:', realStatus);

          return new Response(
            JSON.stringify({ 
              status: realStatus,
              qrCode: qrCodeFormatted,
              connected: isConnected,
              rawData: instanceData // Para debug
            }),
            { status: 200, headers: { 'Content-Type': 'application/json', ...corsHeaders } }
          );

        } catch (error) {
          console.error('Error in status check:', error);
          return new Response(
            JSON.stringify({ 
              error: 'Failed to check instance status',
              message: error.message
            }),
            { status: 500, headers: { 'Content-Type': 'application/json', ...corsHeaders } }
          );
        }
      }

      case 'disconnect': {
        const { instanceId, userId }: DisconnectInstanceRequest = await req.json();
        
        console.log('Disconnecting instance:', instanceId);

        // Get instance from database
        const { data: instance, error: getError } = await supabase
          .from('whatsapp_instances')
          .select('*')
          .eq('user_id', userId)
          .eq('instance_id', instanceId)
          .single();

        if (getError || !instance) {
          console.error('Instance not found:', getError);
          return new Response(
            JSON.stringify({ error: 'Instance not found' }),
            { status: 404, headers: { 'Content-Type': 'application/json', ...corsHeaders } }
          );
        }

        // Disconnect on Z-API using correct endpoint
        const disconnectResponse = await fetch(`https://api.z-api.io/instances/${instanceId}/token/${instance.token_instance}/disconnect`, {
          method: 'GET',
          headers: {
            'Client-Token': 'F25f061eefa514271aac2c1b3dafc9acdS',
            'Authorization': 'Bearer eyJhbGciOiJIUzI1NiJ9.eyJpYXQiOjQ5MDg0MzU0NTUsInN1YiI6ImNhcmxvc3dlc2xsZW5ob3RtYXJ0QGdtYWlsLmNvbSIsImlzcyI6ImVtRmhjQzF6WldOMWNtbDBlUzFoY0drPSIsImF1ZCI6ImVtRmhjQzFoY0drPSIsImV4cCI6NDkwODQzNTQ1NSwib25EZW1hbmQiOnRydWUsInJvbGUiOiJFTlRFUlBSSVNFIiwiaW50ZWdyYXRvciI6dHJ1ZSwidGVuYW50T3duZXIiOiJaVzFoYVd4QVptOTFjbkpwZUdWc0xtbDAifQ.OmtaNR3G-fQWVVzYmfl8Vbgl1Np009zKmpBTNK8C8Vo',
          },
        });

        if (!disconnectResponse.ok) {
          console.error('Z-API disconnect error:', await disconnectResponse.text());
          return new Response(
            JSON.stringify({ error: 'Failed to disconnect instance' }),
            { status: 500, headers: { 'Content-Type': 'application/json', ...corsHeaders } }
          );
        }

        const disconnectData = await disconnectResponse.json();
        console.log('Disconnect response:', disconnectData);

        // Após desconectar, aguardar para permitir que gere novo QR code
        let newQrCode = null;
        try {
          console.log('Waiting for new QR Code after disconnect...');
          // Aguardar 3 segundos após desconectar
          await new Promise(resolve => setTimeout(resolve, 3000));
          
          const qrResponse = await fetch(`https://api.z-api.io/instances/${instanceId}/token/${instance.token_instance}/qr-code`, {
            headers: {
              'Client-Token': 'F25f061eefa514271aac2c1b3dafc9acdS',
              'Authorization': 'Bearer eyJhbGciOiJIUzI1NiJ9.eyJpYXQiOjQ5MDg0MzU0NTUsInN1YiI6ImNhcmxvc3dlc2xsZW5ob3RtYXJ0QGdtYWlsLmNvbSIsImlzcyI6ImVtRmhjQzF6WldOMWNtbDBlUzFoY0drPSIsImF1ZCI6ImVtRmhjQzFoY0drPSIsImV4cCI6NDkwODQzNTQ1NSwib25EZW1hbmQiOnRydWUsInJvbGUiOiJFTlRFUlBSSVNFIiwiaW50ZWdyYXRvciI6dHJ1ZSwidGVuYW50T3duZXIiOiJaVzFoYVd4QVptOTFjbkpwZUdWc0xtbDAifQ.OmtaNR3G-fQWVVzYmfl8Vbgl1Np009zKmpBTNK8C8Vo',
            },
          });
          
          if (qrResponse.ok) {
            const qrData = await qrResponse.json();
            console.log('New QR Code response:', qrData);
            
            const qrCodeRaw = qrData.qrcode || qrData.value;
            if (qrCodeRaw) {
              newQrCode = qrCodeRaw.startsWith('data:') 
                ? qrCodeRaw 
                : `data:image/png;base64,${qrCodeRaw}`;
            }
          }
        } catch (qrError) {
          console.log('Error fetching QR code after disconnect:', qrError);
        }

        // Update status in database
        const { error: updateError } = await supabase
          .from('whatsapp_instances')
          .update({ 
            status: 'disconnected',
            qr_code: newQrCode
          })
          .eq('user_id', userId)
          .eq('instance_id', instanceId);

        if (updateError) {
          console.error('Database update error:', updateError);
        }

        return new Response(
          JSON.stringify({ 
            success: true,
            qrCode: newQrCode 
          }),
          { status: 200, headers: { 'Content-Type': 'application/json', ...corsHeaders } }
        );
      }

      case 'connect-phone': {
        const { instanceId, userId, phone }: ConnectPhoneRequest = await req.json();
        console.log('Connecting with phone number for instance:', instanceId);
        
        // Verificar se a instância existe no banco de dados
        const { data: phoneInstance, error: phoneInstanceError } = await supabase
          .from('whatsapp_instances')
          .select('*')
          .eq('instance_id', instanceId)
          .eq('user_id', userId)
          .single();

        if (phoneInstanceError || !phoneInstance) {
          console.error('Instance not found:', phoneInstanceError);
          return new Response(
            JSON.stringify({ error: 'Instance not found' }),
            { status: 404, headers: { 'Content-Type': 'application/json', ...corsHeaders } }
          );
        }

        // 1. Primeiro verificar o status atual da instância
        try {
          console.log('Checking instance status before connecting phone...');
          const statusResponse = await fetch(`https://api.z-api.io/instances/${instanceId}/token/${phoneInstance.token_instance}/status`, {
            method: 'GET',
            headers: {
              'Client-Token': 'F25f061eefa514271aac2c1b3dafc9acdS',
              'Authorization': 'Bearer eyJhbGciOiJIUzI1NiJ9.eyJpYXQiOjQ5MDg0MzU0NTUsInN1YiI6ImNhcmxvc3dlc2xsZW5ob3RtYXJ0QGdtYWlsLmNvbSIsImlzcyI6ImVtRmhjQzF6WldOMWNtbDBlUzFoY0drPSIsImF1ZCI6ImVtRmhjQzFoY0drPSIsImV4cCI6NDkwODQzNTQ1NSwib25EZW1hbmQiOnRydWUsInJvbGUiOiJFTlRFUlBSSVNFIiwiaW50ZWdyYXRvciI6dHJ1ZSwidGVuYW50T3duZXIiOiJaVzFoYVd4QVptOTFjbkpwZUdWc0xtbDAifQ.OmtaNR3G-fQWVVzYmfl8Vbgl1Np009zKmpBTNK8C8Vo',
            },
          });

          if (statusResponse.ok) {
            const statusData = await statusResponse.json();
            console.log('Instance status before phone connection:', JSON.stringify(statusData, null, 2));
            
            // Verificar se a instância já está conectada
            const currentStatus = statusData.status || statusData.state;
            if (currentStatus === 'connected') {
              return new Response(
                JSON.stringify({ 
                  error: 'Instance already connected',
                  message: 'Esta instância já está conectada. Desconecte primeiro para reconectar.'
                }),
                { status: 400, headers: { 'Content-Type': 'application/json', ...corsHeaders } }
              );
            }

            // Se o status não for "waiting_phone", fazer restart da instância primeiro
            if (currentStatus !== 'waiting_phone') {
              console.log(`Status ${currentStatus} não é 'waiting_phone'. Fazendo restart da instância...`);
              
              const restartResponse = await fetch(`https://api.z-api.io/instances/${instanceId}/token/${phoneInstance.token_instance}/restart`, {
                method: 'GET',
                headers: {
                  'Client-Token': 'F25f061eefa514271aac2c1b3dafc9acdS',
                  'Authorization': 'Bearer eyJhbGciOiJIUzI1NiJ9.eyJpYXQiOjQ5MDg0MzU0NTUsInN1YiI6ImNhcmxvc3dlc2xsZW5ob3RtYXJ0QGdtYWlsLmNvbSIsImlzcyI6ImVtRmhjQzF6WldOMWNtbDBlUzFoY0drPSIsImF1ZCI6ImVtRmhjQzFoY0drPSIsImV4cCI6NDkwODQzNTQ1NSwib25EZW1hbmQiOnRydWUsInJvbGUiOiJFTlRFUlBSSVNFIiwiaW50ZWdyYXRvciI6dHJ1ZSwidGVuYW50T3duZXIiOiJaVzFoYVd4QVptOTFjbkpwZUdWc0xtbDAifQ.OmtaNR3G-fQWVVzYmfl8Vbgl1Np009zKmpBTNK8C8Vo',
                },
              });

              console.log('Restart response status:', restartResponse.status);
              
              if (!restartResponse.ok) {
                const errorText = await restartResponse.text();
                console.error('Restart failed:', errorText);
                return new Response(
                  JSON.stringify({ 
                    error: 'Failed to restart instance',
                    message: `Erro ao reiniciar instância: ${restartResponse.status}. Tente novamente.`,
                    details: errorText
                  }),
                  { status: restartResponse.status, headers: { 'Content-Type': 'application/json', ...corsHeaders } }
                );
              }

              const restartData = await restartResponse.json();
              console.log('Instance restarted successfully:', JSON.stringify(restartData, null, 2));
              
              // Aguardar um pouco após o restart para a instância estabilizar
              console.log('Waiting 5 seconds for instance to stabilize...');
              await new Promise(resolve => setTimeout(resolve, 5000));
            }
          }

          // 2. Tentar conectar com o número usando endpoint correto
          console.log('Connecting with phone:', phone);
          const connectResponse = await fetch(`https://api.z-api.io/instances/${instanceId}/token/${phoneInstance.token_instance}/phone-code/${phone}`, {
            method: 'GET',
            headers: {
              'Client-Token': 'F25f061eefa514271aac2c1b3dafc9acdS',
              'Authorization': 'Bearer eyJhbGciOiJIUzI1NiJ9.eyJpYXQiOjQ5MDg0MzU0NTUsInN1YiI6ImNhcmxvc3dlc2xsZW5ob3RtYXJ0QGdtYWlsLmNvbSIsImlzcyI6ImVtRmhjQzF6WldOMWNtbDBlUzFoY0drPSIsImF1ZCI6ImVtRmhjQzFoY0drPSIsImV4cCI6NDkwODQzNTQ1NSwib25EZW1hbmQiOnRydWUsInJvbGUiOiJFTlRFUlBSSVNFIiwiaW50ZWdyYXRvciI6dHJ1ZSwidGVuYW50T3duZXIiOiJaVzFoYVd4QVptOTFjbkpwZUdWc0xtbDAifQ.OmtaNR3G-fQWVVzYmfl8Vbgl1Np009zKmpBTNK8C8Vo',
            },
          });

          console.log('Connect phone response status:', connectResponse.status);
          
          if (!connectResponse.ok) {
            const errorText = await connectResponse.text();
            console.error('Connect phone request failed:', errorText);
            return new Response(
              JSON.stringify({ 
                error: 'Failed to connect phone',
                message: `Erro ao conectar telefone: ${connectResponse.status}`
              }),
              { status: connectResponse.status, headers: { 'Content-Type': 'application/json', ...corsHeaders } }
            );
          }

          const connectData = await connectResponse.json();
          console.log('Connect phone response data:', JSON.stringify(connectData, null, 2));

          // 3. Verificar se a conexão foi bem-sucedida baseado na resposta
          let newStatus = 'connecting';
          let updateFields: any = { 
            numero_cliente: phone,
            status: newStatus
          };

          // Se a resposta indica sucesso ou conexão estabelecida
          if (connectData.success === true || connectData.connected === true || connectData.status === 'connected') {
            newStatus = 'connected';
            updateFields.status = 'connected';
            updateFields.qr_code = null; // Limpar QR code quando conectado
            console.log('Phone connection successful, updating status to connected');
          } else if (connectData.error || connectData.status === 'error') {
            return new Response(
              JSON.stringify({ 
                error: 'Connection failed',
                message: connectData.message || 'Falha na conexão. Verifique o número fornecido.'
              }),
              { status: 400, headers: { 'Content-Type': 'application/json', ...corsHeaders } }
            );
          }

          // Atualizar status no banco de dados
          const { error: updateError } = await supabase
            .from('whatsapp_instances')
            .update(updateFields)
            .eq('instance_id', instanceId)
            .eq('user_id', userId);

          if (updateError) {
            console.error('Error updating phone connection in database:', updateError);
          }

          return new Response(
            JSON.stringify({ 
              success: true,
              message: newStatus === 'connected' 
                ? 'WhatsApp conectado com sucesso!' 
                : 'Código de verificação enviado para seu telefone.',
              status: newStatus === 'connected' ? 'connected' : 'waiting_verification',
              data: connectData
            }),
            { headers: { 'Content-Type': 'application/json', ...corsHeaders } }
          );

        } catch (error) {
          console.error('Error connecting phone:', error);
          return new Response(
            JSON.stringify({ 
              error: 'Internal server error',
              message: 'Erro interno ao conectar telefone'
            }),
            { status: 500, headers: { 'Content-Type': 'application/json', ...corsHeaders } }
          );
        }
      }

      case 'verify-code': {
        console.log('=== Z-API Manager Debug ===');
        console.log('Action: verify-code');
        console.log('Partner token length:', partnerToken?.length);
        console.log('Partner token starts with:', partnerToken?.substring(0, 10));
        console.log('Partner token configured:', partnerToken ? 'YES' : 'NO');

        const { instanceId: verifyInstanceId, code, userId: verifyUserId } = await req.json();

        if (!verifyInstanceId || !code || !verifyUserId) {
          return new Response(JSON.stringify({
            success: false,
            error: 'Instance ID, verification code and user ID are required'
          }), {
            status: 400,
            headers: { ...corsHeaders, 'Content-Type': 'application/json' },
          });
        }

        console.log('Verifying code for instance:', verifyInstanceId);

        // Buscar a instância no banco
        const { data: verifyInstance, error: verifyInstanceError } = await supabase
          .from('whatsapp_instances')
          .select('*')
          .eq('instance_id', verifyInstanceId)
          .eq('user_id', verifyUserId)
          .single();

        if (verifyInstanceError || !verifyInstance) {
          console.error('Instance not found:', verifyInstanceError);
          return new Response(JSON.stringify({
            success: false,
            error: 'Instance not found'
          }), {
            status: 404,
            headers: { ...corsHeaders, 'Content-Type': 'application/json' },
          });
        }

        try {
          console.log('Sending verification code...');
          const verifyResponse = await fetch(`https://api.z-api.io/instances/${verifyInstanceId}/connect/verify`, {
            method: 'POST',
            headers: {
              'Client-Token': 'F25f061eefa514271aac2c1b3dafc9acdS',
              'Authorization': 'Bearer eyJhbGciOiJIUzI1NiJ9.eyJpYXQiOjQ5MDg0MzU0NTUsInN1YiI6ImNhcmxvc3dlc2xsZW5ob3RtYXJ0QGdtYWlsLmNvbSIsImlzcyI6ImVtRmhjQzF6WldOMWNtbDBlUzFoY0drPSIsImF1ZCI6ImVtRmhjQzFoY0drPSIsImV4cCI6NDkwODQzNTQ1NSwib25EZW1hbmQiOnRydWUsInJvbGUiOiJFTlRFUlBSSVNFIiwiaW50ZWdyYXRvciI6dHJ1ZSwidGVuYW50T3duZXIiOiJaVzFoYVd4QVptOTFjbkpwZUdWc0xtbDAifQ.OmtaNR3G-fQWVVzYmfl8Vbgl1Np009zKmpBTNK8C8Vo',
              'Content-Type': 'application/json',
            },
            body: JSON.stringify({
              code: code
            }),
          });

          console.log('Verify response status:', verifyResponse.status);
          const verifyData = await verifyResponse.json();
          console.log('Verify response data:', JSON.stringify(verifyData, null, 2));

          if (verifyResponse.ok && (verifyData.status === 'connected' || verifyData.success === true)) {
            // Atualizar o status da instância no banco
            const { error: updateError } = await supabase
              .from('whatsapp_instances')
              .update({
                status: 'connected',
                qr_code: null,
                updated_at: new Date().toISOString()
              })
              .eq('instance_id', verifyInstanceId)
              .eq('user_id', verifyUserId);

            if (updateError) {
              console.error('Error updating instance status:', updateError);
            }

            return new Response(JSON.stringify({
              success: true,
              message: 'WhatsApp conectado com sucesso!',
              status: 'connected'
            }), {
              status: 200,
              headers: { ...corsHeaders, 'Content-Type': 'application/json' },
            });
          } else {
            return new Response(JSON.stringify({
              success: false,
              error: 'Invalid verification code',
              message: 'Código de verificação inválido. Tente novamente.',
              details: verifyData
            }), {
              status: 400,
              headers: { ...corsHeaders, 'Content-Type': 'application/json' },
            });
          }

        } catch (error) {
          console.error('Error verifying code:', error);
          return new Response(JSON.stringify({
            success: false,
            error: 'Failed to verify code',
            message: 'Erro ao verificar código. Tente novamente.'
          }), {
            status: 500,
            headers: { ...corsHeaders, 'Content-Type': 'application/json' },
          });
        }
      }

      case 'update-webhooks': {
        const { instanceId, userId }: { instanceId: string, userId: string } = await req.json();
        
        console.log('=== Updating Webhooks ===');
        console.log('Instance ID:', instanceId);
        console.log('User ID:', userId);

        try {
          // Get instance from database
          const { data: instance, error: getError } = await supabase
            .from('whatsapp_instances')
            .select('*')
            .eq('user_id', userId)
            .eq('instance_id', instanceId)
            .single();

          if (getError || !instance) {
            console.error('Instance not found:', getError);
            return new Response(
              JSON.stringify({ error: 'Instance not found' }),
              { status: 404, headers: { 'Content-Type': 'application/json', ...corsHeaders } }
            );
          }

          // Update all webhooks for message notifications
          const webhooks = [
            {
              endpoint: 'update-webhook-received',
              url: `https://mzhyxympbmjjergvbwfa.supabase.co/functions/v1/zapi-webhook?userId=${userId}&type=message`
            },
            {
              endpoint: 'update-webhook-status',
              url: `https://mzhyxympbmjjergvbwfa.supabase.co/functions/v1/zapi-webhook?userId=${userId}&type=status`
            },
            {
              endpoint: 'update-webhook-connect',
              url: `https://mzhyxympbmjjergvbwfa.supabase.co/functions/v1/zapi-webhook?userId=${userId}&type=connect`
            },
            {
              endpoint: 'update-webhook-disconnect',
              url: `https://mzhyxympbmjjergvbwfa.supabase.co/functions/v1/zapi-webhook?userId=${userId}&type=disconnect`
            }
          ];

          const results = [];
          for (const webhook of webhooks) {
            try {
              console.log(`Updating ${webhook.endpoint} to ${webhook.url}`);
              
              const response = await fetch(`https://api.z-api.io/instances/${instanceId}/token/${instance.token_instance}/${webhook.endpoint}`, {
                method: 'PUT',
                headers: {
                  'Content-Type': 'application/json',
                  'Client-Token': 'F25f061eefa514271aac2c1b3dafc9acdS',
                  'Authorization': 'Bearer eyJhbGciOiJIUzI1NiJ9.eyJpYXQiOjQ5MDg0MzU0NTUsInN1YiI6ImNhcmxvc3dlc2xsZW5ob3RtYXJ0QGdtYWlsLmNvbSIsImlzcyI6ImVtRmhjQzF6WldOMWNtbDBlUzFoY0dsOSIsImF1ZCI6ImVtRmhjQzFoY0dsUyIsImV4cCI6NDkwODQzNTQ1NSwib25EZW1hbmQiOnRydWUsInJvbGUiOiJFTlRFUlBSSVNFIiwiaW50ZWdyYXRvciI6dHJ1ZSwidGVuYW50T3duZXIiOiJaVzFoYVdGQVptOTFjbkpwZUdWc0xtbDAifQ.OmtaNR3G-fQWVVzYmfl8Vbgl1Np009zKmpBTNK8C8Vo'
                },
                body: JSON.stringify({ value: webhook.url })
              });

              const result = await response.text();
              console.log(`Webhook ${webhook.endpoint} update result:`, result);
              
              results.push({
                endpoint: webhook.endpoint,
                success: response.ok,
                status: response.status,
                result: result
              });
            } catch (error) {
              console.error(`Error updating ${webhook.endpoint}:`, error);
              results.push({
                endpoint: webhook.endpoint,
                success: false,
                error: error.message
              });
            }
          }

          return new Response(
            JSON.stringify({ 
              success: true,
              message: 'Webhooks atualizados',
              results: results
            }),
            { status: 200, headers: { 'Content-Type': 'application/json', ...corsHeaders } }
          );

        } catch (error) {
          console.error('Error updating webhooks:', error);
          return new Response(
            JSON.stringify({ 
              error: 'Failed to update webhooks',
              message: error.message
            }),
            { status: 500, headers: { 'Content-Type': 'application/json', ...corsHeaders } }
          );
        }
      }
        return new Response(
          JSON.stringify({ error: 'Invalid action' }),
          { status: 400, headers: { 'Content-Type': 'application/json', ...corsHeaders } }
        );
    }
  } catch (error: any) {
    console.error('=== FUNCTION ERROR ===');
    console.error('Error message:', error.message);
    console.error('Error stack:', error.stack);
    return new Response(
      JSON.stringify({ error: error.message }),
      { status: 500, headers: { 'Content-Type': 'application/json', ...corsHeaders } }
    );
  }
};

serve(handler);
