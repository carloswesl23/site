import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

const SUPABASE_URL = Deno.env.get("SUPABASE_URL")!;
const SUPABASE_SERVICE_ROLE = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
const APP_BASE_URL = Deno.env.get("APP_BASE_URL") || "https://mzhyxympbmjjergvbwfa.supabase.co";
const ZAPI_CLIENT_TOKEN = Deno.env.get("ZAPI_CLIENT_TOKEN");

const supabase = createClient(SUPABASE_URL, SUPABASE_SERVICE_ROLE);

serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const { instanceId, tokenInstance, userId } = await req.json();

    if (!instanceId || !tokenInstance || !userId) {
      return new Response(JSON.stringify({ 
        error: 'instanceId, tokenInstance e userId são obrigatórios' 
      }), {
        status: 400,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' }
      });
    }

    // URL do webhook que deve receber todas as mensagens (incluindo fromMe = true)
    const webhookUrl = `${APP_BASE_URL}/functions/v1/wa-webhook`;

    console.log('Configurando webhooks para instância:', instanceId);
    console.log('Webhook URL:', webhookUrl);

    // Configurar webhook para mensagens recebidas COM "enviadas por mim" habilitado
    // Este é o endpoint específico da Z-API para receber mensagens fromMe = true
    const configureReceivedResponse = await fetch(
      `https://api.z-api.io/instances/${instanceId}/token/${tokenInstance}/update-webhook-received-delivery`,
      {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
          'Client-Token': ZAPI_CLIENT_TOKEN || ''
        },
        body: JSON.stringify({
          value: webhookUrl
        })
      }
    );

    console.log('Response configurar received-delivery:', configureReceivedResponse.status);

    if (!configureReceivedResponse.ok) {
      const errorText = await configureReceivedResponse.text();
      console.error('Erro ao configurar webhook received-delivery:', errorText);
      throw new Error(`Erro ao configurar webhook received-delivery: ${errorText}`);
    }

    // Configurar webhook para status de mensagens
    const configureStatusResponse = await fetch(
      `https://api.z-api.io/instances/${instanceId}/token/${tokenInstance}/update-webhook-message-status`,
      {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
          'Client-Token': ZAPI_CLIENT_TOKEN || ''
        },
        body: JSON.stringify({
          value: webhookUrl
        })
      }
    );

    console.log('Response configurar message-status:', configureStatusResponse.status);

    if (!configureStatusResponse.ok) {
      const errorText = await configureStatusResponse.text();
      console.error('Erro ao configurar webhook message-status:', errorText);
      // Não falha se este não funcionar, pois é menos crítico
    }

    // Configurar webhook para mensagens enviadas
    const configureSentResponse = await fetch(
      `https://api.z-api.io/instances/${instanceId}/token/${tokenInstance}/update-webhook-sent`,
      {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
          'Client-Token': ZAPI_CLIENT_TOKEN || ''
        },
        body: JSON.stringify({
          value: webhookUrl
        })
      }
    );

    console.log('Response configurar sent:', configureSentResponse.status);

    if (!configureSentResponse.ok) {
      const errorText = await configureSentResponse.text();
      console.error('Erro ao configurar webhook sent:', errorText);
      // Não falha se este não funcionar
    }

    // Atualizar no banco que os webhooks foram configurados
    const { error: updateError } = await supabase
      .from('whatsapp_instances')
      .update({
        webhook_url: webhookUrl,
        updated_at: new Date().toISOString()
      })
      .eq('instance_id', instanceId)
      .eq('user_id', userId);

    if (updateError) {
      console.error('Erro ao atualizar instância no banco:', updateError);
    }

    return new Response(JSON.stringify({ 
      success: true,
      message: 'Webhooks configurados com sucesso',
      webhookUrl,
      configured: {
        receivedDelivery: configureReceivedResponse.ok,
        messageStatus: configureStatusResponse.ok,
        sent: configureSentResponse.ok
      }
    }), {
      headers: { ...corsHeaders, 'Content-Type': 'application/json' }
    });

  } catch (error) {
    console.error('Erro ao configurar webhooks:', error);
    return new Response(JSON.stringify({ 
      error: 'Erro interno do servidor',
      details: String(error)
    }), {
      status: 500,
      headers: { ...corsHeaders, 'Content-Type': 'application/json' }
    });
  }
});