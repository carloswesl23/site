import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

const SUPABASE_URL = Deno.env.get("SUPABASE_URL")!;
const SUPABASE_SERVICE_ROLE = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
const supabase = createClient(SUPABASE_URL, SUPABASE_SERVICE_ROLE);

// Função para normalizar telefone para formato E164
function normalizePhoneE164(phone: string): string {
  // Remove todos os caracteres não numéricos
  phone = phone.replace(/\D/g, '');
  
  // Se começa com 55 (Brasil) e tem 13 dígitos, adiciona +
  if (phone.match(/^55[0-9]{11}$/)) {
    return '+' + phone;
  }
  
  // Se tem 11 dígitos e não começa com 55, adiciona +55
  if (phone.match(/^[0-9]{11}$/)) {
    return '+55' + phone;
  }
  
  // Se tem 10 dígitos, adiciona +55 e um 9 depois do DDD
  if (phone.match(/^[0-9]{10}$/)) {
    return '+55' + phone.substring(0, 2) + '9' + phone.substring(2);
  }
  
  // Se não está em nenhum formato conhecido, retorna como está com +
  if (!phone.startsWith('+')) {
    return '+' + phone;
  }
  
  return phone;
}

serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const payload = await req.json();
    console.log('Webhook recebido:', JSON.stringify(payload, null, 2));

    // Processar diferentes tipos de webhook da Z-API
    const { instanceId, type, data } = payload;

    if (!instanceId) {
      return new Response(JSON.stringify({ error: 'instanceId required' }), {
        status: 400,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' }
      });
    }

    // Buscar instância correspondente
    const { data: instance } = await supabase
      .from('whatsapp_instances')
      .select('*')
      .eq('instance_id', instanceId)
      .single();

    if (!instance) {
      console.log('Instância não encontrada:', instanceId);
      return new Response(JSON.stringify({ message: 'Instance not found' }), {
        status: 404,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' }
      });
    }

    switch (type) {
      case 'ReceivedCallback':
      case 'message':
        await processIncomingMessage(payload, instance);
        break;
      
      case 'SentCallback':
      case 'MessageStatusCallback':
        await processSentMessage(payload, instance);
        break;
      
      case 'PresenceCallback':
        await processPresenceUpdate(payload, instance);
        break;
      
      case 'ConnectedCallback':
        await processConnectionUpdate(payload, instance, 'connected');
        break;
      
      case 'DisconnectedCallback':
        await processConnectionUpdate(payload, instance, 'disconnected');
        break;
      
      case 'StatusCallback':
        await processStatusUpdate(payload, instance);
        break;
      
      default:
        console.log('Tipo de webhook não processado:', type);
    }

    return new Response(JSON.stringify({ success: true }), {
      headers: { ...corsHeaders, 'Content-Type': 'application/json' }
    });

  } catch (error) {
    console.error('Erro no webhook:', error);
    return new Response(JSON.stringify({ 
      error: 'Internal server error',
      details: String(error)
    }), {
      status: 500,
      headers: { ...corsHeaders, 'Content-Type': 'application/json' }
    });
  }
});

async function processIncomingMessage(payload: any, instance: any) {
  try {
    console.log('Processando mensagem recebida:', JSON.stringify(payload, null, 2));

    // Normalizar phone number para E164  
    let phoneE164 = payload.phone || payload.from;
    if (phoneE164) {
      phoneE164 = normalizePhoneE164(phoneE164);
    }

    console.log('Phone normalizado:', phoneE164);

    // Verificar se é mensagem enviada por mim (from_me = true)
    const isFromMe = payload.fromMe === true || payload.from_me === true;
    const direction = isFromMe ? 'OUT' : 'IN';
    
    // Detectar origem da mensagem para mensagens enviadas
    let messageVia = 'received'; // default para mensagens recebidas
    if (isFromMe) {
      // Se fromApi for explicitamente false, veio do device (WhatsApp Web/celular)
      if (payload.fromApi === false || payload.from_api === false) {
        messageVia = 'device';
      } else {
        messageVia = 'panel'; // enviada via API do painel
      }
    }

    // Extrair conteúdo da mensagem baseado no tipo
    let messageBody = '';
    let mediaUrl = null;

    // Diferentes tipos de mensagem da Z-API
    if (payload.text?.message) {
      messageBody = payload.text.message;
    } else if (payload.image?.caption) {
      messageBody = payload.image.caption || '[Imagem]';
      mediaUrl = payload.image.imageUrl;
    } else if (payload.document) {
      messageBody = payload.document.caption || `[Documento: ${payload.document.fileName || 'arquivo'}]`;
      mediaUrl = payload.document.documentUrl;
    } else if (payload.audio) {
      messageBody = '[Áudio]';
      mediaUrl = payload.audio.audioUrl;
    } else if (payload.video) {
      messageBody = payload.video.caption || '[Vídeo]';
      mediaUrl = payload.video.videoUrl;
    } else if (payload.sticker) {
      messageBody = '[Sticker]';
      mediaUrl = payload.sticker.stickerUrl;
    } else if (payload.contact) {
      messageBody = `[Contato: ${payload.contact.displayName || 'Sem nome'}]`;
    } else if (payload.location) {
      messageBody = `[Localização: ${payload.location.address || 'Coordenadas compartilhadas'}]`;
    } else {
      // Fallback para outros tipos
      messageBody = payload.body || payload.message || '[Mensagem não suportada]';
    }

    console.log('Conteúdo extraído:', { messageBody, mediaUrl });

    // Verificar se é resposta de motoboy (1 ou 2) e se não é mensagem enviada por nós
    const isMotoboyResponse = !isFromMe && (messageBody.trim() === '1' || messageBody.trim() === '2');
    
    if (isMotoboyResponse) {
      console.log('Detectada resposta de motoboy:', messageBody);
      
      try {
        // Processar resposta do motoboy
        await supabase.functions.invoke('handle-courier-response', {
          body: {
            phone_e164: phoneE164,
            message_body: messageBody.trim(),
            instance_id: instance.instance_id
          }
        });
        
        console.log('Resposta do motoboy processada com sucesso');
      } catch (error) {
        console.error('Erro ao processar resposta do motoboy:', error);
      }
    }

    // Upsert mensagem (evita duplicatas)
    const messageData = {
      user_id: instance.user_id,
      phone_e164: phoneE164,
      direction: direction,
      body: messageBody,
      media_url: mediaUrl,
      status: isFromMe ? 'SENT' : 'RECEIVED',
      zapi_msg_id: payload.messageId || payload.id || null
    };

    // First try to find existing message
    const { data: existing } = await supabase
      .from('wa_messages')
      .select('id')
      .eq('zapi_msg_id', messageData.zapi_msg_id)
      .single();

    let messageError = null;
    if (existing) {
      // Update existing message
      const { error } = await supabase
        .from('wa_messages')
        .update(messageData)
        .eq('id', existing.id);
      messageError = error;
    } else {
      // Insert new message
      const { error } = await supabase
        .from('wa_messages')
        .insert(messageData);
      messageError = error;
    }

    if (messageError) {
      console.error('Erro ao salvar mensagem:', messageError);
    } else {
      console.log('Mensagem salva:', messageData);
    }

    // Atualizar ou criar contato
    const contactData = {
      user_id: instance.user_id,
      phone_e164: phoneE164,
      name: payload.senderName || payload.chatName || payload.pushName || payload.name || null,
      last_interaction_at: new Date().toISOString()
    };

    const { error: contactError } = await supabase
      .from('contacts')
      .upsert(contactData, { 
        onConflict: 'user_id,phone_e164' 
      });

    if (contactError) {
      console.error('Erro ao atualizar contato:', contactError);
    }

  } catch (error) {
    console.error('Erro ao processar mensagem:', error);
  }
}

async function processConnectionUpdate(payload: any, instance: any, status: string) {
  try {
    const updateData: any = {
      status,
      updated_at: new Date().toISOString()
    };

    if (status === 'connected') {
      updateData.connected_at = new Date().toISOString();
      updateData.numero_cliente = payload.data?.phone || payload.phone;
    } else {
      updateData.disconnected_at = new Date().toISOString();
    }

    const { error } = await supabase
      .from('whatsapp_instances')
      .update(updateData)
      .eq('id', instance.id);

    if (error) {
      console.error('Erro ao atualizar status da instância:', error);
    } else {
      console.log(`Instância ${instance.instance_id} atualizada para ${status}`);
    }

  } catch (error) {
    console.error('Erro ao processar conexão:', error);
  }
}

async function processStatusUpdate(payload: any, instance: any) {
  try {
    const { data } = payload;
    
    // Atualizar status de mensagens enviadas
    if (data.messageId && data.status) {
      // Only update valid status values
      const validStatuses = ['PENDING', 'SENT', 'RECEIVED', 'READ', 'FAILED'];
      const statusUpper = data.status.toUpperCase();
      
      if (validStatuses.includes(statusUpper)) {
        const { error } = await supabase
          .from('wa_messages')
          .update({
            status: statusUpper,
            updated_at: new Date().toISOString()
          })
          .eq('zapi_msg_id', data.messageId);

        if (error) {
          console.error('Erro ao atualizar status da mensagem:', error);
        }
      } else {
        console.log(`Status inválido ignorado: ${data.status}`);
      }
    }

  } catch (error) {
    console.error('Erro ao processar status:', error);
  }
}

async function processSentMessage(payload: any, instance: any) {
  try {
    console.log('Processando mensagem enviada:', JSON.stringify(payload, null, 2));

    // Tratar diferentes formatos de payload para mensagens enviadas
    let phoneE164: string;
    let messageData: any;

    // Webhook de status de mensagem
    if (payload.status && payload.ids && payload.phone) {
      phoneE164 = normalizePhoneE164(payload.phone);
      
      // Atualizar status das mensagens existentes
      for (const messageId of payload.ids) {
        // Only update valid status values
        const validStatuses = ['PENDING', 'SENT', 'RECEIVED', 'READ', 'FAILED'];
        const statusUpper = payload.status.toUpperCase();
        
        if (validStatuses.includes(statusUpper)) {
          const { error } = await supabase
            .from('wa_messages')
            .update({
              status: statusUpper,
              updated_at: new Date().toISOString()
            })
            .eq('zapi_msg_id', messageId)
            .eq('user_id', instance.user_id);

          if (error) {
            console.error('Erro ao atualizar status da mensagem:', error);
          } else {
            console.log(`Status da mensagem ${messageId} atualizado para ${statusUpper}`);
          }
        } else {
          console.log(`Status inválido ignorado: ${payload.status}`);
        }
      }
      
      return; // Não precisamos criar nova mensagem, apenas atualizar status
    }

    // Mensagem normal enviada
    const message = payload.data || payload;
    phoneE164 = normalizePhoneE164(message.to || message.phone || payload.phone);

    // Determinar origem da mensagem (panel, api, device)
    let messageVia = 'panel'; // default
    if (payload.fromApi === false || payload.from_api === false) {
      messageVia = 'device'; // enviada pelo celular/WhatsApp Web
    } else if (payload.fromApi === true || payload.from_api === true) {
      messageVia = 'api'; // enviada via API
    }

    // Extrair conteúdo da mensagem
    let messageBody = '';
    let mediaUrl = null;

    if (message.text?.message) {
      messageBody = message.text.message;
    } else if (message.image) {
      messageBody = message.image.caption || '[Imagem]';
      mediaUrl = message.image.imageUrl;
    } else if (message.document) {
      messageBody = message.document.caption || `[Documento: ${message.document.fileName || 'arquivo'}]`;
      mediaUrl = message.document.documentUrl;
    } else if (message.audio) {
      messageBody = '[Áudio]';
      mediaUrl = message.audio.audioUrl;
    } else if (message.video) {
      messageBody = message.video.caption || '[Vídeo]';
      mediaUrl = message.video.videoUrl;
    } else {
      messageBody = message.body || message.text || message.caption || payload.body || '';
    }

    // Upsert mensagem enviada (evita duplicatas)
    messageData = {
      user_id: instance.user_id,
      phone_e164: phoneE164,
      direction: 'OUT',
      body: messageBody,
      media_url: mediaUrl,
      status: payload.status?.toUpperCase() || 'SENT',
      zapi_msg_id: message.id || payload.messageId || payload.ids?.[0] || null
    };

    // First try to find existing message
    const { data: existingSent } = await supabase
      .from('wa_messages')
      .select('id')
      .eq('zapi_msg_id', messageData.zapi_msg_id)
      .single();

    let messageError = null;
    if (existingSent) {
      // Update existing message
      const { error } = await supabase
        .from('wa_messages')
        .update(messageData)
        .eq('id', existingSent.id);
      messageError = error;
    } else {
      // Insert new message
      const { error } = await supabase
        .from('wa_messages')
        .insert(messageData);
      messageError = error;
    }

    if (messageError) {
      console.error('Erro ao salvar mensagem enviada:', messageError);
    } else {
      console.log('Mensagem enviada salva:', messageData);
    }

    // Atualizar ou criar contato
    const contactData = {
      user_id: instance.user_id,
      phone_e164: phoneE164,
      name: message.pushName || message.name || null,
      last_interaction_at: new Date().toISOString()
    };

    const { error: contactError } = await supabase
      .from('contacts')
      .upsert(contactData, { 
        onConflict: 'user_id,phone_e164' 
      });

    if (contactError) {
      console.error('Erro ao atualizar contato:', contactError);
    }

  } catch (error) {
    console.error('Erro ao processar mensagem enviada:', error);
  }
}

async function processPresenceUpdate(payload: any, instance: any) {
  try {
    const { data } = payload;
    
    // Normalizar phone number para E164
    let phoneE164 = data.phone || data.from;
    if (phoneE164 && !phoneE164.startsWith('+')) {
      phoneE164 = '+' + phoneE164;
    }

    console.log(`Presença atualizada para ${phoneE164}:`, data.presence);

    // Atualizar status de presença no contato
    if (phoneE164) {
      const { error } = await supabase
        .from('contacts')
        .upsert({
          user_id: instance.user_id,
          phone_e164: phoneE164,
          presence_status: data.presence || 'unavailable',
          last_seen_at: data.lastSeen ? new Date(data.lastSeen * 1000).toISOString() : new Date().toISOString(),
          last_interaction_at: new Date().toISOString()
        }, { 
          onConflict: 'user_id,phone_e164' 
        });

      if (error) {
        console.error('Erro ao atualizar presença:', error);
      }
    }

  } catch (error) {
    console.error('Erro ao processar presença:', error);
  }
}