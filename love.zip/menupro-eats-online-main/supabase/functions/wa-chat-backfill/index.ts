import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

const SUPABASE_URL = Deno.env.get("SUPABASE_URL")!;
const SUPABASE_SERVICE_ROLE = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
const ZAPI_BASE_URL = Deno.env.get('ZAPI_BASE_URL') || 'https://api.z-api.io';
const ZAPI_CLIENT_TOKEN = Deno.env.get('ZAPI_CLIENT_TOKEN');

const supabase = createClient(SUPABASE_URL, SUPABASE_SERVICE_ROLE);

// Função para normalizar telefone para formato E164
function normalizePhoneE164(phone: string): string {
  phone = phone.replace(/\D/g, '');
  
  if (phone.match(/^55[0-9]{11}$/)) {
    return '+' + phone;
  }
  
  if (phone.match(/^[0-9]{11}$/)) {
    return '+55' + phone;
  }
  
  if (phone.match(/^[0-9]{10}$/)) {
    return '+55' + phone.substring(0, 2) + '9' + phone.substring(2);
  }
  
  if (!phone.startsWith('+')) {
    return '+' + phone;
  }
  
  return phone;
}

serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const { instanceId, tokenInstance, phone, userId, limit = 50 } = await req.json();
    
    if (!instanceId || !tokenInstance || !phone || !userId) {
      return new Response(JSON.stringify({ 
        error: "instanceId, tokenInstance, phone, and userId required" 
      }), { 
        status: 400,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' }
      });
    }

    if (!ZAPI_CLIENT_TOKEN) {
      return new Response(JSON.stringify({ error: 'Missing Z-API client token' }), {
        status: 500,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' }
      });
    }

    const phoneE164 = normalizePhoneE164(phone);
    console.log(`Fazendo backfill para ${phoneE164}`);

    // Buscar mensagens existentes no banco para este chat
    const { data: existingMessages } = await supabase
      .from('wa_messages')
      .select('zapi_msg_id')
      .eq('user_id', userId)
      .eq('phone_e164', phoneE164)
      .not('zapi_msg_id', 'is', null);

    const existingIds = new Set(existingMessages?.map(msg => msg.zapi_msg_id) || []);

    // Buscar histórico da Z-API
    const cleanPhone = phone.replace(/\D/g, '');
    const zapiUrl = `${ZAPI_BASE_URL}/instances/${instanceId}/token/${tokenInstance}/chat-messages/${cleanPhone}`;
    
    console.log(`Buscando histórico da Z-API: ${zapiUrl}`);

    const response = await fetch(zapiUrl, {
      method: 'GET',
      headers: {
        'Client-Token': ZAPI_CLIENT_TOKEN
      }
    });

    if (!response.ok) {
      console.error('Erro na Z-API:', response.status, response.statusText);
      return new Response(JSON.stringify({ 
        error: 'Failed to fetch chat history from Z-API',
        status: response.status 
      }), {
        status: 500,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' }
      });
    }

    const zapiData = await response.json();
    const messages = zapiData.messages || zapiData || [];

    console.log(`Encontradas ${messages.length} mensagens na Z-API`);

    let newMessagesSaved = 0;
    
    // Processar mensagens e salvar as que não existem
    for (const msg of messages.slice(0, limit)) {
      if (!msg.id || existingIds.has(msg.id)) {
        continue; // Pular mensagens que já existem
      }

      try {
        // Extrair conteúdo da mensagem
        let messageBody = '';
        let mediaUrl = null;

        if (msg.text?.message) {
          messageBody = msg.text.message;
        } else if (msg.image) {
          messageBody = msg.image.caption || '[Imagem]';
          mediaUrl = msg.image.imageUrl;
        } else if (msg.document) {
          messageBody = msg.document.caption || `[Documento: ${msg.document.fileName || 'arquivo'}]`;
          mediaUrl = msg.document.documentUrl;
        } else if (msg.audio) {
          messageBody = '[Áudio]';
          mediaUrl = msg.audio.audioUrl;
        } else if (msg.video) {
          messageBody = msg.video.caption || '[Vídeo]';
          mediaUrl = msg.video.videoUrl;
        } else if (msg.sticker) {
          messageBody = '[Sticker]';
          mediaUrl = msg.sticker.stickerUrl;
        } else {
          messageBody = msg.body || '[Mensagem não suportada]';
        }

        // Determinar direção baseado em fromMe
        const direction = msg.fromMe ? 'OUT' : 'IN';
        const status = msg.fromMe ? 'SENT' : 'RECEIVED';

        const messageData = {
          user_id: userId,
          phone_e164: phoneE164,
          direction: direction,
          body: messageBody,
          media_url: mediaUrl,
          status: status,
          zapi_msg_id: msg.id,
          created_at: msg.timestamp ? new Date(msg.timestamp * 1000).toISOString() : new Date().toISOString()
        };

        const { error } = await supabase
          .from('wa_messages')
          .insert(messageData);

        if (error) {
          console.error('Erro ao salvar mensagem do backfill:', error);
        } else {
          newMessagesSaved++;
        }

      } catch (msgError) {
        console.error('Erro ao processar mensagem individual:', msgError);
      }
    }

    // Atualizar ou criar contato
    const contactData = {
      user_id: userId,
      phone_e164: phoneE164,
      name: messages[0]?.senderName || messages[0]?.pushName || null,
      last_interaction_at: new Date().toISOString()
    };

    await supabase
      .from('contacts')
      .upsert(contactData, { 
        onConflict: 'user_id,phone_e164' 
      });

    console.log(`Backfill concluído: ${newMessagesSaved} novas mensagens salvas`);

    return new Response(JSON.stringify({
      success: true,
      totalMessages: messages.length,
      newMessagesSaved: newMessagesSaved,
      existingMessages: existingIds.size
    }), {
      headers: { ...corsHeaders, 'Content-Type': 'application/json' }
    });

  } catch (error) {
    console.error('Erro no backfill:', error);
    return new Response(JSON.stringify({ 
      error: 'Failed to perform chat backfill',
      details: String(error)
    }), {
      status: 500,
      headers: { ...corsHeaders, 'Content-Type': 'application/json' }
    });
  }
});