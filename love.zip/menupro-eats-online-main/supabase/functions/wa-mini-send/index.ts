import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const { phone, message, type = 'text', imageUrl } = await req.json();

    if (!phone || !message) {
      throw new Error('Phone and message are required');
    }

    const supabaseClient = createClient(
      Deno.env.get('SUPABASE_URL') ?? '',
      Deno.env.get('SUPABASE_SERVICE_ROLE_KEY') ?? ''
    );

    // Get user from authorization header
    const authHeader = req.headers.get('Authorization');
    if (!authHeader) {
      throw new Error('No authorization header');
    }

    const { data: { user }, error: authError } = await supabaseClient.auth.getUser(
      authHeader.replace('Bearer ', '')
    );

    if (authError || !user) {
      throw new Error('Invalid token');
    }

    // Get user's WhatsApp instance
    const { data: instance } = await supabaseClient
      .from('whatsapp_instances')
      .select('instance_id, token_instance, status')
      .eq('user_id', user.id)
      .eq('status', 'connected')
      .single();

    if (!instance) {
      throw new Error('WhatsApp not connected');
    }

    const ZAPI_BASE = Deno.env.get('ZAPI_BASE_URL') || 'https://api.z-api.io';
    const ZAPI_CLIENT_TOKEN = Deno.env.get('ZAPI_CLIENT_TOKEN');

    if (!ZAPI_CLIENT_TOKEN) {
      throw new Error('Z-API client token not configured');
    }

    // Prepare message payload
    let payload: any = {
      phone: phone.replace('+', ''),
    };

    let endpoint = 'send-text';

    if (type === 'image' && imageUrl) {
      endpoint = 'send-image';
      payload.image = imageUrl;
      payload.caption = message;
    } else {
      payload.message = message;
    }

    // Send message via Z-API
    const zapiUrl = `${ZAPI_BASE}/instances/${instance.instance_id}/token/${instance.token_instance}/${endpoint}`;
    
    const response = await fetch(zapiUrl, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Client-Token': ZAPI_CLIENT_TOKEN
      },
      body: JSON.stringify(payload)
    });

    const result = await response.json();

    if (!response.ok) {
      throw new Error(`Z-API error: ${result.message || 'Unknown error'}`);
    }

    // Save message to database
    const messageContent = type === 'image' ? { text: message, imageUrl } : { text: message };

    const { data: savedMessage, error: saveError } = await supabaseClient
      .from('wa_messages')
      .insert({
        tenant_id: user.id,
        phone_e164: phone,
        direction: 'out',
        type,
        content: messageContent,
        status: 'sent',
        zapi_message_id: result.messageId
      })
      .select()
      .single();

    if (saveError) {
      console.error('Error saving message:', saveError);
    }

    // Update chat info
    await supabaseClient
      .from('wa_chats')
      .upsert({
        tenant_id: user.id,
        phone_e164: phone,
        last_message: type === 'image' ? '📷 Imagem' : message,
        last_message_at: new Date().toISOString()
      });

    return new Response(JSON.stringify({
      success: true,
      data: {
        messageId: result.messageId,
        message: savedMessage
      }
    }), {
      headers: { ...corsHeaders, 'Content-Type': 'application/json' }
    });

  } catch (error) {
    console.error('Error sending message:', error);
    return new Response(JSON.stringify({
      success: false,
      error: error.message
    }), {
      status: 500,
      headers: { ...corsHeaders, 'Content-Type': 'application/json' }
    });
  }
});