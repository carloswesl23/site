import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

const SUPABASE_URL = Deno.env.get("SUPABASE_URL")!;
const SUPABASE_SERVICE_ROLE = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
const ZAPI_CLIENT_TOKEN = Deno.env.get("ZAPI_CLIENT_TOKEN")!;
const ZAPI_BASE = Deno.env.get("ZAPI_BASE_URL") || "https://api.z-api.io";

const sb = createClient(SUPABASE_URL, SUPABASE_SERVICE_ROLE);

serve(async (req) => {
  // Handle CORS preflight requests
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const { userId, instanceId, tokenInstance } = await req.json().catch(() => ({}));
    
    if (!userId || !instanceId || !tokenInstance) {
      return new Response(JSON.stringify({ 
        error: "userId, instanceId, and tokenInstance required" 
      }), { 
        status: 400,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' }
      });
    }

    console.log("Generating QR code for instance:", instanceId);

    // Call Z-API to get QR code
    const url = `${ZAPI_BASE}/instances/${instanceId}/token/${tokenInstance}/qr-code`;
    const zres = await fetch(url, {
      method: "GET",
      headers: {
        'Content-Type': 'application/json',
        'Client-Token': ZAPI_CLIENT_TOKEN
      }
    });

    if (!zres.ok) {
      console.error("Z-API error:", zres.status, await zres.text());
      return new Response(JSON.stringify({ 
        error: "Failed to generate QR code", 
        status: zres.status 
      }), { 
        status: 502,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' }
      });
    }

    const zjson = await zres.json();
    console.log("Z-API QR Response received");

    // Extract QR code from response
    const qrCode = zjson.qrcode || zjson.qr_code || zjson.value;
    
    if (!qrCode) {
      console.error("No QR code in response:", zjson);
      return new Response(JSON.stringify({ 
        error: "No QR code received from Z-API",
        response: zjson 
      }), { 
        status: 502,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' }
      });
    }

    // Update instance with QR code
    const { error: updateError } = await sb
      .from("whatsapp_instances")
      .update({
        qr_code: qrCode,
        qr_image_base64: qrCode,
        status: 'qrcode',
        updated_at: new Date().toISOString()
      })
      .eq("user_id", userId)
      .eq("instance_id", instanceId);

    if (updateError) {
      console.error("Database update error:", updateError);
      throw updateError;
    }

    console.log("QR code generated and saved successfully");

    return new Response(JSON.stringify({ 
      success: true,
      qr_code: qrCode,
      status: 'qrcode'
    }), { 
      status: 200,
      headers: { ...corsHeaders, 'Content-Type': 'application/json' }
    });

  } catch (err) {
    console.error("QR generation error:", err);
    return new Response(JSON.stringify({ 
      error: String(err),
      message: "Failed to generate QR code"
    }), { 
      status: 500,
      headers: { ...corsHeaders, 'Content-Type': 'application/json' }
    });
  }
});