import { serve } from "https://deno.land/std@0.190.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

const supabase = createClient(
  Deno.env.get('SUPABASE_URL') ?? '',
  Deno.env.get('SUPABASE_SERVICE_ROLE_KEY') ?? ''
 );

const ZAPI_BASE = Deno.env.get('ZAPI_BASE_URL') || 'https://api.z-api.io';

// Helper: convert ArrayBuffer to base64 for image responses
const toBase64 = (buffer: ArrayBuffer): string => {
  let binary = '';
  const bytes = new Uint8Array(buffer);
  const len = bytes.byteLength;
  for (let i = 0; i < len; i++) binary += String.fromCharCode(bytes[i]);
  return btoa(binary);
};

interface GenerateQRRequest {
  instanceId: string;
  userId: string;
  tokenOverride?: string;
}

const handler = async (req: Request): Promise<Response> => {
  // Handle CORS preflight requests
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const { instanceId, userId, tokenOverride }: GenerateQRRequest = await req.json();
    
    if (!instanceId || !userId) {
      return new Response(
        JSON.stringify({ error: 'instanceId e userId são obrigatórios' }),
        { status: 400, headers: { 'Content-Type': 'application/json', ...corsHeaders } }
      );
    }

    console.log('=== Gerando QR Code ===');
    console.log('Instance ID:', instanceId);
    console.log('User ID:', userId);
    console.log('Token override recebido:', tokenOverride ? 'SIM' : 'NÃO');

    // Buscar a instância no banco
    const { data: instance, error: instanceError } = await supabase
      .from('whatsapp_instances')
      .select('*')
      .eq('instance_id', instanceId)
      .eq('user_id', userId)
      .single();

    if (instanceError || !instance) {
      console.error('Instância não encontrada:', instanceError);
      return new Response(
        JSON.stringify({ error: 'Instância não encontrada' }),
        { status: 404, headers: { 'Content-Type': 'application/json', ...corsHeaders } }
      );
    }

    console.log('Instância encontrada:', instance.instance_name);

    // Gerar QR Code na Z-API usando o endpoint correto
    try {
      const useToken = (tokenOverride && typeof tokenOverride === 'string' && tokenOverride.trim().length > 0)
        ? tokenOverride.trim()
        : instance.token_instance;

      // Usar o endpoint correto conforme documentação: /instances/SUA_INSTANCIA/token/SEU_TOKEN/qr-code/image
      const qrUrl = `${ZAPI_BASE}/instances/${instanceId}/token/${useToken}/qr-code/image`;
      
      console.log('Chamando endpoint QR:', qrUrl);
      console.log('Usando token:', useToken.substring(0, 10) + '...');
      console.log('Base URL da Z-API:', ZAPI_BASE);
      
      // Obter os headers corretos das secrets
      const zapiClientToken = Deno.env.get('ZAPI_CLIENT_TOKEN');
      const zapiAuthToken = Deno.env.get('ZAPI_AUTH_TOKEN');
      
      if (!zapiClientToken || !zapiAuthToken) {
        throw new Error('ZAPI_CLIENT_TOKEN e ZAPI_AUTH_TOKEN são obrigatórios');
      }
      
      // Fazer requisição com headers corretos
      const resp = await fetch(qrUrl, {
        method: 'GET',
        headers: { 
          'Client-Token': zapiClientToken,
          'Authorization': `Bearer ${zapiAuthToken}`
        }
      });

      console.log('=== RESPOSTA Z-API ===');
      console.log('Status:', resp.status);
      console.log('Status Text:', resp.statusText);
      console.log('Content-Type:', resp.headers.get('content-type'));
      console.log('Headers completos:', Object.fromEntries(resp.headers.entries()));

      if (!resp.ok) {
        const errorText = await resp.text();
        console.error('=== ERRO Z-API ===');
        console.error('Status:', resp.status);
        console.error('Headers da resposta:', Object.fromEntries(resp.headers.entries()));
        console.error('Corpo da resposta:', errorText);
        console.error('URL chamada:', qrUrl);
        throw new Error(`Z-API error: ${resp.status} - ${errorText}`);
      }

      // A Z-API pode retornar JSON ou a imagem diretamente
      const contentType = resp.headers.get('content-type') || '';
      
      let qrCodeData;
      
      if (contentType.includes('application/json')) {
        // Resposta JSON
        const jsonResponse = await resp.json();
        console.log('Resposta JSON da Z-API:', jsonResponse);
        
        // Extrair o QR code da resposta JSON
        if (jsonResponse.value) {
          qrCodeData = jsonResponse.value;
        } else if (jsonResponse.qrCode) {
          qrCodeData = jsonResponse.qrCode;
        } else if (typeof jsonResponse === 'string') {
          qrCodeData = jsonResponse;
        } else {
          throw new Error('QR Code não encontrado na resposta JSON');
        }
      } else {
        // Resposta binária (imagem)
        const imageBuffer = await resp.arrayBuffer();
        console.log('QR Code recebido como imagem, tamanho do buffer:', imageBuffer.byteLength);
        
        if (imageBuffer.byteLength === 0) {
          throw new Error('Resposta vazia da Z-API');
        }
        
        // Converter para base64
        const b64String = toBase64(imageBuffer);
        qrCodeData = `data:image/png;base64,${b64String}`;
      }
      
      console.log('QR Code extraído:', typeof qrCodeData, qrCodeData?.substring?.(0, 50));
      
      if (!qrCodeData) {
        throw new Error('QR Code não encontrado na resposta');
      }
      
      // Garantir que está no formato data URL correto
      let finalQrCode = qrCodeData;
      if (typeof finalQrCode === 'string' && !finalQrCode.startsWith('data:image/')) {
        finalQrCode = `data:image/png;base64,${finalQrCode}`;
      }

      // Atualizar no banco de dados
      const nowIso = new Date().toISOString();
      const { error: updateError } = await supabase
        .from('whatsapp_instances')
        .update({ 
          qr_code: finalQrCode,
          status: 'qrcode',
          qr_refreshed_at: nowIso,
          updated_at: nowIso,
        })
        .eq('instance_id', instanceId)
        .eq('user_id', userId);

      if (updateError) {
        console.error('Erro ao atualizar QR no banco:', updateError);
      } else {
        console.log('QR Code salvo/atualizado no banco com sucesso');
      }

      // Logar sucesso
      await supabase.from('whatsapp_events').insert({
        tenant_id: instance.tenant_id ?? null,
        instance_id: instance.id,
        event_type: 'QR_UPDATED',
        payload: { endpoint: qrUrl, overrideUsed: Boolean(tokenOverride) }
      });

      return new Response(
        JSON.stringify({ 
          success: true, 
          qrCode: finalQrCode,
          status: 'qrcode',
          message: 'QR Code gerado com sucesso'
        }),
        { status: 200, headers: { 'Content-Type': 'application/json', ...corsHeaders } }
      );

    } catch (zapiError) {
      console.error('Erro ao chamar Z-API:', zapiError);
      return new Response(
        JSON.stringify({ 
          error: 'Erro de comunicação com Z-API',
          details: (zapiError as any).message
        }),
        { status: 500, headers: { 'Content-Type': 'application/json', ...corsHeaders } }
      );
    }

  } catch (error: any) {
    console.error('=== FUNCTION ERROR ===');
    console.error('Error message:', error.message);
    console.error('Error stack:', error.stack);
    return new Response(
      JSON.stringify({ error: error.message }),
      { status: 500, headers: { 'Content-Type': 'application/json', ...corsHeaders } }
    );
  }
};

serve(handler);