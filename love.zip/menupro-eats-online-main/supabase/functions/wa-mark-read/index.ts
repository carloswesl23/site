import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

const SUPABASE_URL = Deno.env.get("SUPABASE_URL")!;
const SUPABASE_SERVICE_ROLE = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
const ZAPI_BASE_URL = Deno.env.get('ZAPI_BASE_URL') || 'https://api.z-api.io';
const ZAPI_CLIENT_TOKEN = Deno.env.get('ZAPI_CLIENT_TOKEN');

const supabase = createClient(SUPABASE_URL, SUPABASE_SERVICE_ROLE);

// Função para normalizar telefone para formato E164
function normalizePhoneE164(phone: string): string {
  phone = phone.replace(/\D/g, '');
  
  if (phone.match(/^55[0-9]{11}$/)) {
    return '+' + phone;
  }
  
  if (phone.match(/^[0-9]{11}$/)) {
    return '+55' + phone;
  }
  
  if (phone.match(/^[0-9]{10}$/)) {
    return '+55' + phone.substring(0, 2) + '9' + phone.substring(2);
  }
  
  if (!phone.startsWith('+')) {
    return '+' + phone;
  }
  
  return phone;
}

serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const { instanceId, tokenInstance, phone, userId } = await req.json();
    
    if (!instanceId || !tokenInstance || !phone || !userId) {
      return new Response(JSON.stringify({ 
        error: "instanceId, tokenInstance, phone, and userId required" 
      }), { 
        status: 400,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' }
      });
    }

    if (!ZAPI_CLIENT_TOKEN) {
      return new Response(JSON.stringify({ error: 'Missing Z-API client token' }), {
        status: 500,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' }
      });
    }

    const phoneE164 = normalizePhoneE164(phone);
    console.log(`Marcando mensagens como lidas para ${phoneE164}`);

    // Marcar como lido no WhatsApp via Z-API
    const cleanPhone = phone.replace(/\D/g, '');
    const zapiUrl = `${ZAPI_BASE_URL}/instances/${instanceId}/token/${tokenInstance}/modify-chat`;
    
    const zapiPayload = {
      phone: cleanPhone,
      action: "read"
    };

    console.log(`Marcando como lido na Z-API: ${zapiUrl}`);

    const response = await fetch(zapiUrl, {
      method: 'POST',
      headers: {
        'Client-Token': ZAPI_CLIENT_TOKEN,
        'Content-Type': 'application/json'
      },
      body: JSON.stringify(zapiPayload)
    });

    let zapiSuccess = false;
    if (response.ok) {
      zapiSuccess = true;
      console.log('Chat marcado como lido na Z-API');
    } else {
      console.error('Erro ao marcar como lido na Z-API:', response.status, response.statusText);
    }

    // Marcar mensagens como lidas no banco de dados local
    const { data: updatedMessages, error: updateError } = await supabase
      .from('wa_messages')
      .update({
        status: 'READ',
        read_at: new Date().toISOString(),
        updated_at: new Date().toISOString()
      })
      .eq('user_id', userId)
      .eq('phone_e164', phoneE164)
      .eq('direction', 'IN')
      .neq('status', 'READ')
      .select('id');

    if (updateError) {
      console.error('Erro ao atualizar mensagens no banco:', updateError);
      return new Response(JSON.stringify({ 
        error: 'Failed to update message status in database',
        details: updateError.message
      }), {
        status: 500,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' }
      });
    }

    // Atualizar contador de não lidas no chat
    const { error: chatError } = await supabase
      .from('wa_chats')
      .update({
        unread_count: 0,
        updated_at: new Date().toISOString()
      })
      .eq('tenant_id', userId)
      .eq('phone_e164', phoneE164);

    if (chatError) {
      console.error('Erro ao atualizar contador do chat:', chatError);
    }

    const messagesUpdated = updatedMessages?.length || 0;
    console.log(`${messagesUpdated} mensagens marcadas como lidas`);

    return new Response(JSON.stringify({
      success: true,
      messagesUpdated: messagesUpdated,
      zapiSuccess: zapiSuccess
    }), {
      headers: { ...corsHeaders, 'Content-Type': 'application/json' }
    });

  } catch (error) {
    console.error('Erro ao marcar como lido:', error);
    return new Response(JSON.stringify({ 
      error: 'Failed to mark messages as read',
      details: String(error)
    }), {
      status: 500,
      headers: { ...corsHeaders, 'Content-Type': 'application/json' }
    });
  }
});