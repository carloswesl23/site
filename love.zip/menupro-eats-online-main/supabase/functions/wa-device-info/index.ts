import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

const SUPABASE_URL = Deno.env.get("SUPABASE_URL")!;
const SUPABASE_SERVICE_ROLE = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
const ZAPI_CLIENT_TOKEN = Deno.env.get("ZAPI_CLIENT_TOKEN")!;
const ZAPI_BASE = Deno.env.get("ZAPI_BASE_URL") || "https://api.z-api.io";

const sb = createClient(SUPABASE_URL, SUPABASE_SERVICE_ROLE);

serve(async (req) => {
  // Handle CORS preflight requests
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const { userId, instanceId, tokenInstance } = await req.json().catch(() => ({}));
    
    if (!userId || !instanceId || !tokenInstance) {
      return new Response(JSON.stringify({ 
        error: "userId, instanceId, and tokenInstance required" 
      }), { 
        status: 400,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' }
      });
    }

    console.log("Getting device info for instance:", instanceId);

    // Call Z-API to get device info
    const url = `${ZAPI_BASE}/instances/${instanceId}/token/${tokenInstance}/device`;
    const zres = await fetch(url, {
      method: "GET",
      headers: {
        'Content-Type': 'application/json',
        'Client-Token': ZAPI_CLIENT_TOKEN
      }
    });

    if (!zres.ok) {
      console.error("Z-API error:", zres.status, await zres.text());
      return new Response(JSON.stringify({ 
        error: "Failed to get device info", 
        status: zres.status 
      }), { 
        status: 502,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' }
      });
    }

    const deviceInfo = await zres.json();
    console.log("Device info received:", deviceInfo);

    // Extract device information
    const updateData: any = {
      device_updated_at: new Date().toISOString(),
      device_raw: deviceInfo,
      updated_at: new Date().toISOString()
    };

    // Map known device fields
    if (deviceInfo.pushName) updateData.device_pushname = deviceInfo.pushName;
    if (deviceInfo.phone) updateData.device_phone = deviceInfo.phone;
    if (deviceInfo.platform) updateData.device_platform = deviceInfo.platform;
    if (deviceInfo.battery !== undefined) updateData.device_battery = String(deviceInfo.battery);
    if (deviceInfo.plugged !== undefined) updateData.device_plugged = String(deviceInfo.plugged);

    // Update instance with device info
    const { error: updateError } = await sb
      .from("whatsapp_instances")
      .update(updateData)
      .eq("user_id", userId)
      .eq("instance_id", instanceId);

    if (updateError) {
      console.error("Database update error:", updateError);
      throw updateError;
    }

    console.log("Device info updated successfully");

    return new Response(JSON.stringify({ 
      success: true,
      device_info: deviceInfo
    }), { 
      status: 200,
      headers: { ...corsHeaders, 'Content-Type': 'application/json' }
    });

  } catch (err) {
    console.error("Device info error:", err);
    return new Response(JSON.stringify({ 
      error: String(err),
      message: "Failed to get device info"
    }), { 
      status: 500,
      headers: { ...corsHeaders, 'Content-Type': 'application/json' }
    });
  }
});