import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

const SUPABASE_URL = Deno.env.get("SUPABASE_URL")!;
const SUPABASE_SERVICE_ROLE = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
const supabase = createClient(SUPABASE_URL, SUPABASE_SERVICE_ROLE);

interface ZAPIMessage {
  instanceId: string;
  messageId: string;
  phone: string;
  fromMe: boolean;
  momment: number;
  status: string;
  chatName?: string;
  senderName?: string;
  senderPhoto?: string;
  text?: {
    message: string;
  };
  image?: {
    imageUrl: string;
    caption?: string;
  };
  document?: {
    documentUrl: string;
    caption?: string;
    fileName?: string;
  };
  audio?: {
    audioUrl: string;
  };
}

serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const { instanceId, tokenInstance, phone, userId } = await req.json();
    
    if (!instanceId || !tokenInstance || !phone || !userId) {
      return new Response(JSON.stringify({ 
        error: "instanceId, tokenInstance, phone and userId required" 
      }), { 
        status: 400,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' }
      });
    }

    const ZAPI_BASE = Deno.env.get('ZAPI_BASE_URL') || 'https://api.z-api.io';
    const ZAPI_CLIENT_TOKEN = Deno.env.get('ZAPI_CLIENT_TOKEN');

    if (!ZAPI_CLIENT_TOKEN) {
      return new Response(JSON.stringify({ error: 'Missing Z-API client token' }), {
        status: 500,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' }
      });
    }

    console.log(`Fetching message history for chat: ${phone}`);

    // Normalizar telefone
    const normalizedPhone = phone.replace(/\D/g, '');
    const phoneE164 = normalizedPhone.startsWith('55') ? `+${normalizedPhone}` : `+55${normalizedPhone}`;

    // Primeiro, vamos buscar todas as mensagens do banco de dados
    const { data: dbMessages, error: dbError } = await supabase
      .from('wa_messages')
      .select('*')
      .eq('user_id', userId)
      .eq('phone_e164', phoneE164)
      .order('created_at', { ascending: true });

    if (dbError) {
      console.error('Error loading database messages:', dbError);
    }

    const allMessages: any[] = [];

    // Adicionar mensagens do banco de dados
    if (dbMessages && dbMessages.length > 0) {
      dbMessages.forEach(msg => {
        allMessages.push({
          id: msg.id,
          messageId: msg.zapi_msg_id || msg.id,
          phone: msg.phone_e164,
          fromMe: msg.direction.toLowerCase() === 'out',
          moment: new Date(msg.created_at).getTime(),
          status: msg.status || 'received',
          text: {
            message: msg.body
          },
          mediaUrl: msg.media_url,
          source: 'database',
          created_at: msg.created_at
        });
      });
    }

    // Tentar buscar histórico da Z-API (versão Web apenas)
    try {
      // Verificar se a instância suporta histórico
      const instanceInfo = await fetch(`${ZAPI_BASE}/instances/${instanceId}/token/${tokenInstance}/status`, {
        method: 'GET',
        headers: {
          'Client-Token': ZAPI_CLIENT_TOKEN,
          'Content-Type': 'application/json'
        }
      });

      if (instanceInfo.ok) {
        const instanceData = await instanceInfo.json();
        console.log('Instance data:', instanceData);

        // Se for versão Web, tentar buscar histórico
        if (instanceData.instanceType !== 'multidevice') {
          console.log('Attempting to fetch Z-API message history (Web version)');
          
          let hasMore = true;
          let lastMessageId = '';
          let attempts = 0;
          const maxAttempts = 10; // Limitar tentativas

          while (hasMore && attempts < maxAttempts) {
            attempts++;
            console.log(`Fetching batch ${attempts}, lastMessageId: ${lastMessageId}`);

            const url = `${ZAPI_BASE}/instances/${instanceId}/token/${tokenInstance}/chat-messages/${normalizedPhone}`;
            const params = new URLSearchParams({
              amount: '50',
              ...(lastMessageId && { lastMessageId })
            });

            const response = await fetch(`${url}?${params}`, {
              method: 'GET',
              headers: {
                'Client-Token': ZAPI_CLIENT_TOKEN,
                'Content-Type': 'application/json'
              }
            });

            if (response.ok) {
              const messages: ZAPIMessage[] = await response.json();
              console.log(`Received ${messages.length} messages from Z-API`);

              if (messages.length === 0) {
                hasMore = false;
                break;
              }

              // Processar mensagens da Z-API
              for (const msg of messages) {
                // Verificar se já temos esta mensagem no banco
                const existsInDb = dbMessages?.find(dbMsg => 
                  dbMsg.zapi_msg_id === msg.messageId ||
                  Math.abs(new Date(dbMsg.created_at).getTime() - msg.momment) < 1000
                );

                if (!existsInDb) {
                  // Adicionar à lista
                  allMessages.push({
                    id: msg.messageId,
                    messageId: msg.messageId,
                    phone: msg.phone,
                    fromMe: msg.fromMe,
                    moment: msg.momment,
                    status: msg.status,
                    text: msg.text,
                    image: msg.image,
                    document: msg.document,
                    audio: msg.audio,
                    senderName: msg.senderName,
                    chatName: msg.chatName,
                    source: 'zapi'
                  });

                  // Salvar no banco de dados para futuras consultas
                  const messageBody = msg.text?.message || 
                                   msg.image?.caption || 
                                   msg.document?.caption || 
                                   '[Mídia]';

                  await supabase
                    .from('wa_messages')
                    .insert({
                      user_id: userId,
                      phone_e164: phoneE164,
                      direction: msg.fromMe ? 'OUT' : 'IN',
                      body: messageBody,
                      zapi_msg_id: msg.messageId,
                      status: msg.status?.toLowerCase() || 'received',
                      media_url: msg.image?.imageUrl || msg.document?.documentUrl || msg.audio?.audioUrl,
                      created_at: new Date(msg.momment).toISOString()
                    });
                }
              }

              // Preparar para próxima página
              if (messages.length === 50) {
                lastMessageId = messages[messages.length - 1].messageId;
              } else {
                hasMore = false;
              }

              // Delay para evitar rate limiting
              await new Promise(resolve => setTimeout(resolve, 1000));
            } else {
              console.log(`Z-API history request failed: ${response.status}`);
              hasMore = false;
            }
          }
        } else {
          console.log('Multi Device instance - history not available via API');
        }
      }
    } catch (zapiError) {
      console.log('Z-API history fetch failed:', zapiError);
      // Continuar apenas com mensagens do banco
    }

    // Ordenar todas as mensagens por timestamp
    allMessages.sort((a, b) => {
      const timeA = a.moment || new Date(a.created_at).getTime();
      const timeB = b.moment || new Date(b.created_at).getTime();
      return timeA - timeB;
    });

    console.log(`Returning ${allMessages.length} total messages`);

    return new Response(JSON.stringify({
      success: true,
      messages: allMessages,
      total: allMessages.length,
      sources: {
        database: allMessages.filter(m => m.source === 'database').length,
        zapi: allMessages.filter(m => m.source === 'zapi').length
      }
    }), {
      headers: { ...corsHeaders, 'Content-Type': 'application/json' }
    });

  } catch (error) {
    console.error('Error fetching chat history:', error);
    return new Response(JSON.stringify({ 
      error: 'Failed to fetch chat history',
      details: String(error)
    }), {
      status: 500,
      headers: { ...corsHeaders, 'Content-Type': 'application/json' }
    });
  }
});