import { serve } from "https://deno.land/std@0.190.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

const supabase = createClient(
  Deno.env.get('SUPABASE_URL') ?? '',
  Deno.env.get('SUPABASE_SERVICE_ROLE_KEY') ?? ''
);

const Z = Deno.env.get('ZAPI_BASE_URL') || 'https://api.z-api.io';

interface CreateInstanceRequest {
  instanceName: string;
  phoneNumber: string;
  userId: string;
}

const handler = async (req: Request): Promise<Response> => {
  // Handle CORS preflight requests
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const { instanceName, phoneNumber, userId }: CreateInstanceRequest = await req.json();
    
    if (!instanceName || !phoneNumber || !userId) {
      return new Response(
        JSON.stringify({ error: 'instanceName, phoneNumber e userId são obrigatórios' }),
        { status: 400, headers: { 'Content-Type': 'application/json', ...corsHeaders } }
      );
    }

    const partnerToken = Deno.env.get('ZAPI_PARTNER_TOKEN');
    
    if (!partnerToken || partnerToken.trim() === '') {
      console.error('ZAPI_PARTNER_TOKEN not found or empty');
      return new Response(
        JSON.stringify({ error: 'Token de parceiro Z-API não configurado' }),
        { status: 500, headers: { 'Content-Type': 'application/json', ...corsHeaders } }
      );
    }

    // Gerar sessionName único incluindo o número
    const sessionName = `${phoneNumber}_${instanceName}_${Date.now()}`;
    
    console.log('=== Criando Instância Z-API ===');
    console.log('User ID:', userId);
    console.log('Instance Name:', instanceName);
    console.log('Phone Number:', phoneNumber);
    console.log('Session Name:', sessionName);
    console.log('Partner Token disponível:', !!partnerToken);
    console.log('Partner Token length:', partnerToken.length);

    // Preparar body para Z-API com formato correto
    const requestBody = {
      name: instanceName,
      sessionName: sessionName,
      isDevice: false,
      businessDevice: true
    };

    console.log('Request body:', JSON.stringify(requestBody, null, 2));

    // Criar instância na Z-API usando endpoint on-demand
    const zapiResponse = await fetch(`${Z}/instances/integrator/on-demand`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Client-Token': 'F25f061eefa514271aac2c1b3dafc9acdS',
        'Authorization': 'Bearer eyJhbGciOiJIUzI1NiJ9.eyJpYXQiOjQ5MDg0MzU0NTUsInN1YiI6ImNhcmxvc3dlc2xsZW5ob3RtYXJ0QGdtYWlsLmNvbSIsImlzcyI6ImVtRmhjQzF6WldOMWNtbDBlUzFoY0drPSIsImF1ZCI6ImVtRmhjQzFoY0drPSIsImV4cCI6NDkwODQzNTQ1NSwib25EZW1hbmQiOnRydWUsInJvbGUiOiJFTlRFUlBSSVNFIiwiaW50ZWdyYXRvciI6dHJ1ZSwidGVuYW50T3duZXIiOiJaVzFoYVd4QVptOTFjbkpwZUdWc0xtbDAifQ.OmtaNR3G-fQWVVzYmfl8Vbgl1Np009zKmpBTNK8C8Vo'
      },
      body: JSON.stringify(requestBody),
    });

    console.log('=== Z-API Response ===');
    console.log('Status:', zapiResponse.status);
    console.log('Status Text:', zapiResponse.statusText);

    if (!zapiResponse.ok) {
      const errorText = await zapiResponse.text();
      console.error('=== Z-API ERROR ===');
      console.error('Status:', zapiResponse.status);
      console.error('Response body:', errorText);
      
      let errorDetails = errorText;
      try {
        const errorJson = JSON.parse(errorText);
        errorDetails = errorJson.error || errorJson.message || errorText;
      } catch (e) {
        // Manter errorText original se não for JSON válido
      }

      return new Response(
        JSON.stringify({ 
          error: 'Falha ao criar instância Z-API', 
          details: errorDetails,
          status: zapiResponse.status
        }),
        { status: 500, headers: { 'Content-Type': 'application/json', ...corsHeaders } }
      );
    }

    const zapiData = await zapiResponse.json();
    console.log('=== Z-API Success ===');
    console.log('Response data:', JSON.stringify(zapiData, null, 2));

    // Configurar webhook automaticamente na Z-API
    try {
      const webhookUrl = `https://mzhyxympbmjjergvbwfa.supabase.co/functions/v1/zapi-webhook?userId=${userId}&type=generic`;
      console.log('Configurando webhook:', webhookUrl);
      
      const webhookResponse = await fetch(`${Z}/instances/${zapiData.id}/webhook`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Client-Token': 'F25f061eefa514271aac2c1b3dafc9acdS',
          'Authorization': 'Bearer eyJhbGciOiJIUzI1NiJ9.eyJpYXQiOjQ5MDg0MzU0NTUsInN1YiI6ImNhcmxvc3dlc2xsZW5ob3RtYXJ0QGdtYWlsLmNvbSIsImlzcyI6ImVtRmhjQzF6WldOMWNtbDBlUzFoY0drPSIsImF1ZCI6ImVtRmhjQzFoY0drPSIsImV4cCI6NDkwODQzNTQ1NSwib25EZW1hbmQiOnRydWUsInJvbGUiOiJFTlRFUlBSSVNFIiwiaW50ZWdyYXRvciI6dHJ1ZSwidGVuYW50T3duZXIiOiJaVzFoYVd4QVptOTFjbkpwZUdWc0xtbDAifQ.OmtaNR3G-fQWVVzYmfl8Vbgl1Np009zKmpBTNK8C8Vo'
        },
        body: JSON.stringify({
          url: webhookUrl,
          enabled: true,
          events: ['MESSAGE', 'MESSAGE_STATUS', 'INSTANCE', 'QRCODE']
        })
      });

      if (webhookResponse.ok) {
        console.log('Webhook configurado com sucesso');
      } else {
        console.log('Erro ao configurar webhook:', await webhookResponse.text());
      }
    } catch (webhookError) {
      console.log('Erro ao configurar webhook:', webhookError);
    }

    // Aguardar um pouco antes de gerar QR code
    await new Promise(resolve => setTimeout(resolve, 3000));
    
    let qrCodeData = null;
    try {
      console.log('Tentando gerar QR code...');

      const tryEndpoints = async (): Promise<string | null> => {
        const urls = [
          `${Z}/instances/${zapiData.id}/qr-code`,
          `${Z}/instances/${zapiData.id}/qr-code/image`,
          `${Z}/instances/${zapiData.id}/qrcode`,
          `${Z}/instances/${zapiData.id}/qrcode/image`,
        ];
        for (const url of urls) {
          console.log('QR attempt URL:', url);
          const qrResponse = await fetch(url, {
            method: 'GET',
            headers: { 
              'Client-Token': 'F25f061eefa514271aac2c1b3dafc9acdS',
              'Authorization': 'Bearer eyJhbGciOiJIUzI1NiJ9.eyJpYXQiOjQ5MDg0MzU0NTUsInN1YiI6ImNhcmxvc3dlc2xsZW5ob3RtYXJ0QGdtYWlsLmNvbSIsImlzcyI6ImVtRmhjQzF6WldOMWNtbDBlUzFoY0drPSIsImF1ZCI6ImVtRmhjQzFoY0drPSIsImV4cCI6NDkwODQzNTQ1NSwib25EZW1hbmQiOnRydWUsInJvbGUiOiJFTlRFUlBSSVNFIiwiaW50ZWdyYXRvciI6dHJ1ZSwidGVuYW50T3duZXIiOiJaVzFoYVd4QVptOTFjbkpwZUdWc0xtbDAifQ.OmtaNR3G-fQWVVzYmfl8Vbgl1Np009zKmpBTNK8C8Vo',
              'Accept': 'application/json' 
            }
          });
          console.log('QR Response Status:', qrResponse.status);
          const text = await qrResponse.text();
          let json: any = null;
          try { json = JSON.parse(text); } catch { json = { raw: text }; }
          const candidate = json?.qrcode || json?.base64 || json?.image || json?.qr || null;
          if (candidate && typeof candidate === 'string') {
            return candidate.startsWith('data:') ? candidate : `data:image/png;base64,${candidate}`;
          }
          if (json?.error) console.log('QR endpoint error:', json);
        }
        return null;
      };

      qrCodeData = await tryEndpoints();
    } catch (qrError) {
      console.log('Erro ao obter QR code:', qrError);
    }


    // Salvar instância no banco de dados
    const { data: instanceData, error: dbError } = await supabase
      .from('whatsapp_instances')
      .insert({
        user_id: userId,
        instance_id: zapiData.instanceId || zapiData.id,
        instance_name: instanceName,
        token_instance: zapiData.token,
        numero_cliente: phoneNumber,
        webhook_url: `https://mzhyxympbmjjergvbwfa.supabase.co/functions/v1/zapi-webhook?userId=${userId}&type=generic`,
        status: qrCodeData ? 'qrcode' : 'initializing',
        qr_code: qrCodeData,
        phone_number: phoneNumber,
        versao: 'v2'
      })
      .select()
      .single();

    if (dbError) {
      console.error('Database error:', dbError);
      return new Response(
        JSON.stringify({ error: 'Falha ao salvar instância no banco', details: dbError.message }),
        { status: 500, headers: { 'Content-Type': 'application/json', ...corsHeaders } }
      );
    }

    console.log('=== Database Success ===');
    console.log('Saved instance:', instanceData);

    // Tentar gerar QR Code imediatamente após salvar no banco
    if (!qrCodeData) {
      try {
        console.log('Tentativa final de gerar QR code...');
        await new Promise(resolve => setTimeout(resolve, 2000));
        
        const finalQrResponse = await fetch(`${Z}/instances/${zapiData.id}/qr-code`, {
          method: 'GET',
          headers: {
            'Client-Token': 'F25f061eefa514271aac2c1b3dafc9acdS',
            'Authorization': 'Bearer eyJhbGciOiJIUzI1NiJ9.eyJpYXQiOjQ5MDg0MzU0NTUsInN1YiI6ImNhcmxvc3dlc2xsZW5ob3RtYXJ0QGdtYWlsLmNvbSIsImlzcyI6ImVtRmhjQzF6WldOMWNtbDBlUzFoY0drPSIsImF1ZCI6ImVtRmhjQzFoY0drPSIsImV4cCI6NDkwODQzNTQ1NSwib25EZW1hbmQiOnRydWUsInJvbGUiOiJFTlRFUlBSSVNFIiwiaW50ZWdyYXRvciI6dHJ1ZSwidGVuYW50T3duZXIiOiJaVzFoYVd4QVptOTFjbkpwZUdWc0xtbDAifQ.OmtaNR3G-fQWVVzYmfl8Vbgl1Np009zKmpBTNK8C8Vo'
          }
        });

        if (finalQrResponse.ok) {
          const finalQrData = await finalQrResponse.json();
          if (finalQrData.qrcode) {
            qrCodeData = finalQrData.qrcode.startsWith('data:') ? finalQrData.qrcode : `data:image/png;base64,${finalQrData.qrcode}`;
            
            // Atualizar o banco com o QR code
            await supabase
              .from('whatsapp_instances')
              .update({ 
                qr_code: qrCodeData,
                status: 'qrcode'
              })
              .eq('id', instanceData.id);
              
            console.log('QR Code atualizado no banco de dados');
          }
        }
      } catch (finalError) {
        console.log('Erro na tentativa final de QR code:', finalError);
      }
    }

    return new Response(
      JSON.stringify({ 
        success: true, 
        instance: instanceData,
        instanceId: zapiData.id,
        qrCode: qrCodeData,
        due: zapiData.due,
        message: qrCodeData ? 'Instância criada com QR Code' : 'Instância criada, QR Code será gerado automaticamente'
      }),
      { status: 200, headers: { 'Content-Type': 'application/json', ...corsHeaders } }
    );

  } catch (error: any) {
    console.error('=== FUNCTION ERROR ===');
    console.error('Error message:', error.message);
    console.error('Error stack:', error.stack);
    return new Response(
      JSON.stringify({ error: error.message }),
      { status: 500, headers: { 'Content-Type': 'application/json', ...corsHeaders } }
    );
  }
};

serve(handler);