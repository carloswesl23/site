import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const supabase = createClient(
      Deno.env.get('SUPABASE_URL') ?? '',
      Deno.env.get('SUPABASE_SERVICE_ROLE_KEY') ?? ''
    );

    const { 
      driver_phone, 
      order_number,
      customer_name,
      customer_phone,
      delivery_address,
      total,
      payment_method,
      items,
      instance_id,
      token_instance 
    } = await req.json();

    console.log('Enviando notificação para entregador:', driver_phone);

    // Formatar lista de itens
    const itemsList = Array.isArray(items) ? items
      .map((item: any) => `• ${item.quantity}x ${item.name} - R$ ${item.price?.toFixed(2) || '0,00'}`)
      .join('\n') : 'Itens não disponíveis';

    // Gerar URL do Google Maps se houver endereço
    const mapsUrl = delivery_address 
      ? `https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(delivery_address)}`
      : '';

    // Criar mensagem para o entregador
    const message = `🚴‍♂️ *Nova entrega* #${order_number}
Cliente: ${customer_name}
Tel: ${customer_phone}
Endereço: ${delivery_address || 'Endereço não informado'}
Valor: R$ ${total?.toFixed(2) || '0,00'}
Pagamento: ${payment_method || 'Não informado'}

📋 *ITENS:*
${itemsList}

${mapsUrl ? `🗺️ Rota: ${mapsUrl}` : ''}

Responda: *1* para aceitar | *2* para recusar.`;

    // Limpar número do telefone
    const cleanPhone = driver_phone.replace(/\D/g, '');
    const formattedPhone = cleanPhone.startsWith('55') ? cleanPhone : `55${cleanPhone}`;

    // Enviar via Z-API
    const zapiUrl = `${Deno.env.get('ZAPI_BASE_URL')}/instances/${instance_id}/token/${token_instance}/send-text`;
    
    const zapiResponse = await fetch(zapiUrl, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Client-Token': Deno.env.get('ZAPI_CLIENT_TOKEN') ?? ''
      },
      body: JSON.stringify({
        phone: formattedPhone,
        message: message,
        messageId: `delivery_${order_number}_${Date.now()}`
      })
    });

    const zapiResult = await zapiResponse.json();
    console.log('Resposta Z-API para entregador:', zapiResult);

    if (!zapiResponse.ok || !zapiResult.success) {
      throw new Error(`Falha no envio Z-API: ${zapiResult.error || 'Erro desconhecido'}`);
    }

    // Log da mensagem enviada
    const { error: logError } = await supabase
      .from('whatsapp_message_logs')
      .insert({
        user_id: req.headers.get('user-id'),
        order_id: req.headers.get('order-id'),
        message_type: 'delivery_assignment',
        phone_number: driver_phone,
        message_content: message,
        status: 'sent',
        whatsapp_message_id: zapiResult.messageId
      });

    if (logError) {
      console.error('Erro ao salvar log:', logError);
    }

    return new Response(
      JSON.stringify({ 
        success: true, 
        message: 'Notificação enviada para entregador',
        zapiMessageId: zapiResult.messageId 
      }),
      { 
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        status: 200 
      }
    );

  } catch (error) {
    console.error('Erro ao enviar notificação para entregador:', error);
    
    return new Response(
      JSON.stringify({ 
        success: false, 
        error: error.message || 'Erro interno do servidor' 
      }),
      { 
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        status: 500 
      }
    );
  }
});