import { serve } from "https://deno.land/std@0.190.0/http/server.ts";
import { createClient } from 'https://esm.sh/@supabase/supabase-js@2';

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response('ok', { headers: corsHeaders });
  }

  try {
    const supabaseClient = createClient(
      Deno.env.get('SUPABASE_URL') ?? '',
      Deno.env.get('SUPABASE_SERVICE_ROLE_KEY') ?? ''
    );

    // Aceitar slug via body ou query parameter
    let slug;
    if (req.method === 'POST') {
      const body = await req.json();
      slug = body.slug;
    } else {
      const url = new URL(req.url);
      slug = url.searchParams.get('slug');
    }

    if (!slug) {
      return new Response(JSON.stringify({ error: 'Slug is required' }), {
        status: 400,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      });
    }

    console.log('🔍 Buscando produtos para slug:', slug);

    // Primeiro buscar o estabelecimento
    const { data: establishmentData, error: establishmentError } = await supabaseClient.rpc('get_public_establishment_data', {
      slug: slug
    });

    if (establishmentError || !establishmentData || establishmentData.length === 0) {
      console.error('❌ Estabelecimento não encontrado:', establishmentError);
      return new Response(JSON.stringify({ error: 'Estabelecimento não encontrado' }), {
        status: 404,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      });
    }

    const userId = establishmentData[0].establishment_id;
    console.log('✅ User ID encontrado:', userId);

    // Buscar produtos públicos
    const { data: products, error: productsError } = await supabaseClient
      .from('user_products')
      .select('*')
      .eq('user_id', userId)
      .eq('show_online_menu', true)
      .order('category', { ascending: true })
      .order('name', { ascending: true });

    if (productsError) {
      console.error('❌ Erro ao buscar produtos:', productsError);
      return new Response(JSON.stringify({ error: productsError.message }), {
        status: 500,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      });
    }

    // Buscar categorias públicas
    const { data: categories, error: categoriesError } = await supabaseClient
      .from('user_categories')
      .select('name')
      .eq('user_id', userId)
      .order('sort_order', { ascending: true });

    let categoryNames = ['Todos'];
    if (!categoriesError && categories) {
      categoryNames = ['Todos', ...categories.map(c => c.name)];
    } else {
      // Fallback para categorias únicas dos produtos
      const uniqueCategories = [...new Set(products?.map(p => p.category) || [])];
      categoryNames = ['Todos', ...uniqueCategories];
    }

    console.log('✅ Produtos encontrados:', products?.length || 0);
    console.log('✅ Categorias encontradas:', categoryNames.length);

    return new Response(JSON.stringify({ 
      success: true, 
      data: {
        products: products || [],
        categories: categoryNames
      }
    }), {
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    });

  } catch (error) {
    console.error('❌ Erro inesperado:', error);
    return new Response(JSON.stringify({ error: 'Erro interno do servidor' }), {
      status: 500,
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    });
  }
});