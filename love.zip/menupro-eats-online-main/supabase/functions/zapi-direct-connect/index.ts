import { serve } from "https://deno.land/std@0.190.0/http/server.ts";

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

interface CreateInstanceRequest {
  instanceName: string;
  phoneNumber: string;
}

interface QRCodeRequest {
  instanceId: string;
  token: string;
}

const handler = async (req: Request): Promise<Response> => {
  console.log('=== ZAPI DIRECT CONNECT FUNCTION CALLED ===');
  console.log('Method:', req.method);
  console.log('URL:', req.url);
  
  // Handle CORS preflight requests
  if (req.method === 'OPTIONS') {
    console.log('Handling CORS preflight request');
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const url = new URL(req.url);
    const action = url.searchParams.get('action');

    const partnerToken = Deno.env.get('ZAPI_PARTNER_TOKEN');
    
    if (!partnerToken || partnerToken.trim() === '') {
      console.error('ZAPI_PARTNER_TOKEN not found or empty');
      return new Response(
        JSON.stringify({ error: 'Token de parceiro Z-API não configurado' }),
        { status: 500, headers: { 'Content-Type': 'application/json', ...corsHeaders } }
      );
    }

    if (action === 'create-instance') {
      const { instanceName, phoneNumber }: CreateInstanceRequest = await req.json();
      
      if (!instanceName || !phoneNumber) {
        return new Response(
          JSON.stringify({ error: 'instanceName e phoneNumber são obrigatórios' }),
          { status: 400, headers: { 'Content-Type': 'application/json', ...corsHeaders } }
        );
      }

      const sessionName = `${phoneNumber}_${instanceName}_${Date.now()}`;
      
      console.log('=== Criando Instância Z-API ===');
      console.log('Instance Name:', instanceName);
      console.log('Phone Number:', phoneNumber);
      console.log('Session Name:', sessionName);

      const requestBody = {
        name: instanceName,
        session: `${phoneNumber}_${instanceName}_${Date.now()}`
      };

      console.log('Request body:', JSON.stringify(requestBody, null, 2));

      const zapiResponse = await fetch('https://api.z-api.io/instances', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Client-Token': 'F25f061eefa514271aac2c1b3dafc9acdS',
          'Authorization': 'Bearer eyJhbGciOiJIUzI1NiJ9.eyJpYXQiOjQ5MDg0MzU0NTUsInN1YiI6ImNhcmxvc3dlc2xsZW5ob3RtYXJ0QGdtYWlsLmNvbSIsImlzcyI6ImVtRmhjQzF6WldOMWNtbDBlUzFoY0drPSIsImF1ZCI6ImVtRmhjQzFoY0drPSIsImV4cCI6NDkwODQzNTQ1NSwib25EZW1hbmQiOnRydWUsInJvbGUiOiJFTlRFUlBSSVNFIiwiaW50ZWdyYXRvciI6dHJ1ZSwidGVuYW50T3duZXIiOiJaVzFoYVd4QVptOTFjbkpwZUdWc0xtbDAifQ.OmtaNR3G-fQWVVzYmfl8Vbgl1Np009zKmpBTNK8C8Vo'
        },
        body: JSON.stringify(requestBody),
      });

      console.log('Z-API Response Status:', zapiResponse.status);

      if (!zapiResponse.ok) {
        const errorText = await zapiResponse.text();
        console.error('Z-API ERROR:', errorText);
        
        return new Response(
          JSON.stringify({ 
            error: 'Falha ao criar instância Z-API', 
            details: errorText,
            status: zapiResponse.status
          }),
          { status: 500, headers: { 'Content-Type': 'application/json', ...corsHeaders } }
        );
      }

      const zapiData = await zapiResponse.json();
      console.log('Z-API Success:', JSON.stringify(zapiData, null, 2));

      return new Response(
        JSON.stringify({ 
          success: true, 
          instanceId: zapiData.instance_id || zapiData.instanceId,
          token: zapiData.token,
          session: requestBody.session
        }),
        { status: 200, headers: { 'Content-Type': 'application/json', ...corsHeaders } }
      );

    } else if (action === 'get-qrcode') {
      const { instanceId, token, phoneNumber }: QRCodeRequest & { phoneNumber: string } = await req.json();
      
      if (!instanceId || !token || !phoneNumber) {
        return new Response(
          JSON.stringify({ error: 'instanceId, token e phoneNumber são obrigatórios' }),
          { status: 400, headers: { 'Content-Type': 'application/json', ...corsHeaders } }
        );
      }

      console.log('=== Gerando QR Code via phone-code ===');
      console.log('Instance ID:', instanceId);
      console.log('Phone Number:', phoneNumber);

      const qrResponse = await fetch(`https://api.z-api.io/instances/${instanceId}/token/${token}/phone-code/${phoneNumber}`, {
        method: 'GET',
        headers: {
          'Client-Token': 'F25f061eefa514271aac2c1b3dafc9acdS',
          'Authorization': 'Bearer eyJhbGciOiJIUzI1NiJ9.eyJpYXQiOjQ5MDg0MzU0NTUsInN1YiI6ImNhcmxvc3dlc2xsZW5ob3RtYXJ0QGdtYWlsLmNvbSIsImlzcyI6ImVtRmhjQzF6WldOMWNtbDBlUzFoY0drPSIsImF1ZCI6ImVtRmhjQzFoY0drPSIsImV4cCI6NDkwODQzNTQ1NSwib25EZW1hbmQiOnRydWUsInJvbGUiOiJFTlRFUlBSSVNFIiwiaW50ZWdyYXRvciI6dHJ1ZSwidGVuYW50T3duZXIiOiJaVzFoYVd4QVptOTFjbkpwZUdWc0xtbDAifQ.OmtaNR3G-fQWVVzYmfl8Vbgl1Np009zKmpBTNK8C8Vo'
        }
      });

      console.log('QR Response Status:', qrResponse.status);

      if (!qrResponse.ok) {
        const errorText = await qrResponse.text();
        console.error('Erro na Z-API:', errorText);
        
        return new Response(
          JSON.stringify({ 
            error: 'Erro ao gerar QR Code na Z-API',
            details: errorText,
            status: qrResponse.status
          }),
          { status: 500, headers: { 'Content-Type': 'application/json', ...corsHeaders } }
        );
      }

      const qrData = await qrResponse.json();
      console.log('QR Response:', qrData);

      let qrCodeData = null;
      if (qrData.qrcode) {
        qrCodeData = qrData.qrcode.startsWith('data:') 
          ? qrData.qrcode 
          : `data:image/png;base64,${qrData.qrcode}`;
      }

      return new Response(
        JSON.stringify({ 
          success: true, 
          qrCode: qrCodeData,
          status: qrData.status || 'qrcode',
          message: qrCodeData ? 'QR Code gerado com sucesso' : 'QR Code não disponível ainda'
        }),
        { status: 200, headers: { 'Content-Type': 'application/json', ...corsHeaders } }
      );

    } else {
      return new Response(
        JSON.stringify({ error: 'Action não especificada ou inválida' }),
        { status: 400, headers: { 'Content-Type': 'application/json', ...corsHeaders } }
      );
    }

  } catch (error: any) {
    console.error('=== FUNCTION ERROR ===');
    console.error('Error message:', error.message);
    console.error('Error stack:', error.stack);
    return new Response(
      JSON.stringify({ error: error.message }),
      { status: 500, headers: { 'Content-Type': 'application/json', ...corsHeaders } }
    );
  }
};

serve(handler);