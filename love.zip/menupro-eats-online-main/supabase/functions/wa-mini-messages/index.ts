import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    let phone, page, pageSize;

    if (req.method === 'GET') {
      const url = new URL(req.url);
      phone = url.searchParams.get('phone');
      page = parseInt(url.searchParams.get('page') || '1');
      pageSize = parseInt(url.searchParams.get('pageSize') || '30');
    } else if (req.method === 'POST') {
      const body = await req.json();
      phone = body.phone;
      page = body.page || 1;
      pageSize = body.pageSize || 30;
    }

    if (!phone) {
      throw new Error('Phone parameter is required');
    }

    const supabaseClient = createClient(
      Deno.env.get('SUPABASE_URL') ?? '',
      Deno.env.get('SUPABASE_SERVICE_ROLE_KEY') ?? ''
    );

    // Get user from authorization header
    const authHeader = req.headers.get('Authorization');
    if (!authHeader) {
      throw new Error('No authorization header');
    }

    const { data: { user }, error: authError } = await supabaseClient.auth.getUser(
      authHeader.replace('Bearer ', '')
    );

    if (authError || !user) {
      throw new Error('Invalid token');
    }

    // Get messages for this chat
    const from = (page - 1) * pageSize;
    const to = from + pageSize - 1;

    const { data: messages, error, count } = await supabaseClient
      .from('wa_messages')
      .select('*')
      .eq('user_id', user.id)
      .eq('phone_e164', phone)
      .order('created_at', { ascending: false })
      .range(from, to);

    if (error) {
      throw error;
    }

    // Get chat info
    const { data: chatData } = await supabaseClient
      .from('wa_chats')
      .select('*')
      .eq('tenant_id', user.id)
      .eq('phone_e164', phone)
      .single();

    // Get presence info
    const { data: presenceData } = await supabaseClient
      .from('wa_presence')
      .select('*')
      .eq('tenant_id', user.id)
      .eq('phone_e164', phone)
      .single();

    return new Response(JSON.stringify({
      success: true,
      messages: messages?.reverse() || [], // Reverse to show chronological order
      chat: chatData,
      presence: presenceData,
      pagination: {
        page,
        pageSize,
        total: count || 0,
        hasMore: count ? (from + pageSize) < count : false
      }
    }), {
      headers: { ...corsHeaders, 'Content-Type': 'application/json' }
    });

  } catch (error) {
    console.error('Error fetching messages:', error);
    return new Response(JSON.stringify({
      success: false,
      error: error.message
    }), {
      status: 500,
      headers: { ...corsHeaders, 'Content-Type': 'application/json' }
    });
  }
});