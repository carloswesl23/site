import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

const SUPABASE_URL = Deno.env.get("SUPABASE_URL")!;
const SUPABASE_SERVICE_ROLE = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
const supabase = createClient(SUPABASE_URL, SUPABASE_SERVICE_ROLE);

serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const { 
      userId, 
      instanceId, 
      tokenInstance, 
      message, 
      audienceType, 
      scheduledFor,
      campaignName 
    } = await req.json();
    
    if (!userId || !instanceId || !tokenInstance || !message || !audienceType) {
      return new Response(JSON.stringify({ 
        error: "userId, instanceId, tokenInstance, message and audienceType required" 
      }), { 
        status: 400,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' }
      });
    }

    console.log(`Creating bulk campaign: ${campaignName} for user: ${userId}`);

    // Get target audience based on type
    let recipients: string[] = [];

    switch (audienceType) {
      case 'all':
        // Get all customers who have made orders
        const { data: allCustomers } = await supabase
          .from('user_customers')
          .select('customer_phone')
          .eq('user_id', userId)
          .not('customer_phone', 'is', null);
        
        recipients = allCustomers?.map(c => c.customer_phone).filter(Boolean) || [];
        break;

      case 'vip':
        // Get customers with more than 5 orders or total spent > 200
        const { data: vipCustomers } = await supabase
          .from('user_customers')
          .select('customer_phone')
          .eq('user_id', userId)
          .or('total_orders.gte.5,total_spent.gte.200')
          .not('customer_phone', 'is', null);
        
        recipients = vipCustomers?.map(c => c.customer_phone).filter(Boolean) || [];
        break;

      case 'recent':
        // Get customers who ordered in the last 30 days
        const thirtyDaysAgo = new Date();
        thirtyDaysAgo.setDate(thirtyDaysAgo.getDate() - 30);
        
        const { data: recentCustomers } = await supabase
          .from('user_customers')
          .select('customer_phone')
          .eq('user_id', userId)
          .gte('last_order_date', thirtyDaysAgo.toISOString())
          .not('customer_phone', 'is', null);
        
        recipients = recentCustomers?.map(c => c.customer_phone).filter(Boolean) || [];
        break;

      case 'abandoned':
        // This would require a cart abandonment tracking system
        // For now, returning empty array
        recipients = [];
        break;

      default:
        throw new Error(`Unsupported audience type: ${audienceType}`);
    }

    if (recipients.length === 0) {
      return new Response(JSON.stringify({
        error: 'No recipients found for the selected audience',
        audienceType
      }), {
        status: 400,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' }
      });
    }

    // Create broadcast job
    const { data: job, error: jobError } = await supabase
      .from('broadcast_jobs')
      .insert({
        user_id: userId,
        instance_id: instanceId,
        name: campaignName || `Campanha ${new Date().toLocaleDateString()}`,
        status: scheduledFor ? 'scheduled' : 'ready',
        total_recipients: recipients.length,
        scheduled_for: scheduledFor || null
      })
      .select()
      .single();

    if (jobError || !job) {
      console.error('Error creating broadcast job:', jobError);
      throw new Error('Failed to create broadcast job');
    }

    // Create recipients
    const recipientRecords = recipients.map(phone => ({
      job_id: job.id,
      phone_e164: phone.startsWith('+') ? phone : `+55${phone}`,
      vars: { message },
      status: 'PENDING'
    }));

    const { error: recipientsError } = await supabase
      .from('broadcast_recipients')
      .insert(recipientRecords);

    if (recipientsError) {
      console.error('Error creating recipients:', recipientsError);
      throw new Error('Failed to create recipients');
    }

    // If not scheduled, start sending immediately
    if (!scheduledFor) {
      // Process messages in batches to avoid overwhelming the system
      const BATCH_SIZE = 10;
      let sentCount = 0;
      let failedCount = 0;

      for (let i = 0; i < recipients.length; i += BATCH_SIZE) {
        const batch = recipients.slice(i, i + BATCH_SIZE);
        
        const batchPromises = batch.map(async (phone) => {
          try {
            // Send via wa-send function
            const sendResponse = await fetch(`${req.url.split('/wa-send-bulk')[0]}/wa-send`, {
              method: 'POST',
              headers: { 'Content-Type': 'application/json' },
              body: JSON.stringify({
                userId,
                instanceId,
                tokenInstance,
                chatId: phone,
                type: 'text',
                body: { text: message }
              })
            });

            if (sendResponse.ok) {
              sentCount++;
              // Update recipient status
              await supabase
                .from('broadcast_recipients')
                .update({ 
                  status: 'SENT', 
                  sent_at: new Date().toISOString() 
                })
                .eq('job_id', job.id)
                .eq('phone_e164', phone.startsWith('+') ? phone : `+55${phone}`);
            } else {
              failedCount++;
              await supabase
                .from('broadcast_recipients')
                .update({ 
                  status: 'FAILED',
                  error_details: 'Send failed'
                })
                .eq('job_id', job.id)
                .eq('phone_e164', phone.startsWith('+') ? phone : `+55${phone}`);
            }
          } catch (error) {
            failedCount++;
            console.error(`Failed to send to ${phone}:`, error);
          }
        });

        await Promise.all(batchPromises);
        
        // Small delay between batches to respect rate limits
        if (i + BATCH_SIZE < recipients.length) {
          await new Promise(resolve => setTimeout(resolve, 1000));
        }
      }

      // Update job status
      await supabase
        .from('broadcast_jobs')
        .update({
          status: 'done',
          sent_count: sentCount,
          error_count: failedCount,
          updated_at: new Date().toISOString()
        })
        .eq('id', job.id);
    }

    return new Response(JSON.stringify({
      success: true,
      jobId: job.id,
      totalRecipients: recipients.length,
      status: scheduledFor ? 'scheduled' : 'processing',
      scheduledFor
    }), {
      headers: { ...corsHeaders, 'Content-Type': 'application/json' }
    });

  } catch (error) {
    console.error('Error creating bulk campaign:', error);
    return new Response(JSON.stringify({ 
      error: 'Failed to create bulk campaign',
      details: String(error)
    }), {
      status: 500,
      headers: { ...corsHeaders, 'Content-Type': 'application/json' }
    });
  }
});