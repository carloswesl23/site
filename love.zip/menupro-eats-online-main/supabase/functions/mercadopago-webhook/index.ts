import { serve } from "https://deno.land/std@0.190.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2.45.0";

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

interface MercadoPagoWebhookPayload {
  action: string;
  api_version: string;
  data: {
    id: string;
  };
  date_created: string;
  id: number;
  live_mode: boolean;
  type: string;
  user_id: string;
}

interface MercadoPagoPayment {
  id: string;
  status: string;
  external_reference?: string;
  transaction_amount: number;
  currency_id: string;
  payment_method: {
    id: string;
    type: string;
  };
  payer: {
    id: string;
    email: string;
  };
  date_created: string;
  date_approved?: string;
}

const logStep = (step: string, details?: any) => {
  const detailsStr = details ? ` - ${JSON.stringify(details)}` : '';
  console.log(`[MP-WEBHOOK] ${step}${detailsStr}`);
};

serve(async (req: Request): Promise<Response> => {
  // Handle CORS preflight requests
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    logStep("Webhook received", { method: req.method });

    if (req.method !== 'POST') {
      return new Response('Method not allowed', { 
        status: 405, 
        headers: corsHeaders 
      });
    }

    const supabase = createClient(
      Deno.env.get('SUPABASE_URL') ?? '',
      Deno.env.get('SUPABASE_SERVICE_ROLE_KEY') ?? '',
      { auth: { persistSession: false } }
    );

    const webhookData: MercadoPagoWebhookPayload = await req.json();
    logStep("Webhook payload parsed", webhookData);

    // Verificar se é um evento de pagamento
    if (webhookData.type !== 'payment') {
      logStep("Ignoring non-payment webhook", { type: webhookData.type });
      return new Response('OK', { 
        status: 200, 
        headers: corsHeaders 
      });
    }

    const paymentId = webhookData.data.id;
    logStep("Processing payment webhook", { paymentId });

    // Buscar dados do pagamento no Mercado Pago usando o access token do estabelecimento
    // Primeiro, precisamos identificar qual estabelecimento este webhook pertence
    // Vamos buscar pelo external_reference que deve conter o order_id

    // Temporariamente, vamos usar uma busca geral para encontrar a configuração
    const { data: allSettings } = await supabase
      .from('establishment_settings')
      .select('user_id, mp_access_token, mp_enabled')
      .eq('mp_enabled', true)
      .not('mp_access_token', 'is', null);

    if (!allSettings || allSettings.length === 0) {
      logStep("No MP configurations found");
      return new Response('No configurations found', { 
        status: 400, 
        headers: corsHeaders 
      });
    }

    let paymentData: MercadoPagoPayment | null = null;
    let establishmentUserId: string | null = null;

    // Tentar buscar o pagamento com cada access token até encontrar
    for (const setting of allSettings) {
      try {
        const mpResponse = await fetch(`https://api.mercadopago.com/v1/payments/${paymentId}`, {
          headers: {
            'Authorization': `Bearer ${setting.mp_access_token}`,
            'Content-Type': 'application/json'
          }
        });

        if (mpResponse.ok) {
          paymentData = await mpResponse.json();
          establishmentUserId = setting.user_id;
          logStep("Payment data retrieved", { 
            paymentId, 
            status: paymentData.status,
            userId: establishmentUserId
          });
          break;
        }
      } catch (error) {
        logStep("Error fetching payment with access token", { 
          userId: setting.user_id, 
          error: error.message 
        });
        continue;
      }
    }

    if (!paymentData || !establishmentUserId) {
      logStep("Payment not found in any configuration", { paymentId });
      return new Response('Payment not found', { 
        status: 404, 
        headers: corsHeaders 
      });
    }

    // Verificar se já existe registro deste pagamento
    const { data: existingPayment } = await supabase
      .from('mercadopago_payments')
      .select('*')
      .eq('mp_payment_id', paymentId)
      .eq('user_id', establishmentUserId)
      .single();

    const paymentRecord = {
      user_id: establishmentUserId,
      mp_payment_id: paymentId,
      mp_external_reference: paymentData.external_reference || null,
      status: paymentData.status,
      amount: paymentData.transaction_amount,
      currency: paymentData.currency_id,
      payment_method: paymentData.payment_method.type,
      webhook_data: webhookData,
      updated_at: new Date().toISOString()
    };

    if (existingPayment) {
      // Atualizar registro existente
      const { error: updateError } = await supabase
        .from('mercadopago_payments')
        .update(paymentRecord)
        .eq('id', existingPayment.id);

      if (updateError) {
        logStep("Error updating payment record", updateError);
        throw updateError;
      }
      logStep("Payment record updated", { id: existingPayment.id });
    } else {
      // Criar novo registro
      const newRecord = {
        ...paymentRecord,
        order_id: paymentData.external_reference || paymentId // Usar external_reference ou payment_id como fallback
      };

      const { error: insertError } = await supabase
        .from('mercadopago_payments')
        .insert(newRecord);

      if (insertError) {
        logStep("Error inserting payment record", insertError);
        throw insertError;
      }
      logStep("Payment record created", newRecord);
    }

    // Se o pagamento foi aprovado, atualizar o pedido
    if (paymentData.status === 'approved' && paymentData.external_reference) {
      const orderId = paymentData.external_reference;
      
      // Buscar e atualizar o pedido
      const { data: order, error: orderError } = await supabase
        .from('user_orders')
        .select('*')
        .eq('id', orderId)
        .eq('user_id', establishmentUserId)
        .single();

      if (order && !orderError) {
        // Atualizar status do pedido para "paid" ou "confirmed"
        const { error: updateOrderError } = await supabase
          .from('user_orders')
          .update({ 
            status: 'paid',
            payment_method: 'mercadopago',
            updated_at: new Date().toISOString()
          })
          .eq('id', orderId)
          .eq('user_id', establishmentUserId);

        if (updateOrderError) {
          logStep("Error updating order status", updateOrderError);
        } else {
          logStep("Order status updated to paid", { orderId });

          // Trigger webhook event for payment confirmation
          try {
            await supabase.functions.invoke('send-webhook', {
              body: {
                event_type: 'pagamento_confirmado',
                data: {
                  order_id: orderId,
                  payment_id: paymentId,
                  amount: paymentData.transaction_amount,
                  currency: paymentData.currency_id,
                  payment_method: 'mercadopago',
                  customer_email: paymentData.payer.email,
                  approved_at: paymentData.date_approved || new Date().toISOString()
                },
                user_id: establishmentUserId
              }
            });
            logStep("Payment confirmation webhook sent");
          } catch (webhookError) {
            logStep("Error sending payment webhook", webhookError);
          }

          // Enviar mensagem WhatsApp se configurado
          try {
            await supabase.functions.invoke('send-whatsapp-message', {
              body: {
                user_id: establishmentUserId,
                phone: order.customer_phone,
                message_type: 'payment_confirmed',
                order_data: {
                  order_number: order.order_number,
                  customer_name: order.customer_name,
                  total: order.total
                }
              }
            });
            logStep("WhatsApp payment confirmation sent");
          } catch (whatsappError) {
            logStep("Error sending WhatsApp message", whatsappError);
          }
        }
      } else {
        logStep("Order not found for payment", { orderId, error: orderError });
      }
    }

    return new Response('OK', { 
      status: 200, 
      headers: corsHeaders 
    });

  } catch (error) {
    logStep("Webhook processing error", { 
      message: error.message, 
      stack: error.stack 
    });
    
    return new Response(JSON.stringify({ 
      error: 'Internal server error',
      message: error.message 
    }), {
      status: 500,
      headers: { ...corsHeaders, 'Content-Type': 'application/json' }
    });
  }
});