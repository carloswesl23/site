import { serve } from "https://deno.land/std@0.168.0/http/server.ts"

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
}

serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response('ok', { headers: corsHeaders })
  }

  if (req.method !== 'POST') {
    return new Response(JSON.stringify({ error: 'Method not allowed' }), {
      status: 405,
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    })
  }

  try {
    const body = await req.json()
    const { sessionKey } = body
    
    if (!sessionKey) {
      return new Response(JSON.stringify({ error: 'Session key required' }), {
        status: 400,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      })
    }

    const WA_SERVICE_URL = Deno.env.get('WA_SERVICE_URL') || 'http://localhost:8080'
    const APP_WEBHOOK_SECRET = Deno.env.get('APP_WEBHOOK_SECRET')

    if (!APP_WEBHOOK_SECRET) {
      return new Response(JSON.stringify({ error: 'Missing webhook secret' }), {
        status: 500,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      })
    }

    const response = await fetch(`${WA_SERVICE_URL}/sessions/${sessionKey}/reset`, {
      method: 'POST',
      headers: {
        'X-App-Secret': APP_WEBHOOK_SECRET,
      },
    })

    if (!response.ok) {
      throw new Error(`Service error: ${response.status}`)
    }

    const data = await response.json()
    
    return new Response(JSON.stringify(data), {
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    })
  } catch (error) {
    console.error('Error resetting session:', error)
    return new Response(JSON.stringify({ error: 'Failed to reset session' }), {
      status: 500,
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    })
  }
})