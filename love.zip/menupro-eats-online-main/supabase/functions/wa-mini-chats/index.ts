import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const url = new URL(req.url);
    const page = parseInt(url.searchParams.get('page') || '1');
    const pageSize = parseInt(url.searchParams.get('pageSize') || '20');
    const filter = url.searchParams.get('filter') || 'all'; // all, unread, vip, orders
    const search = url.searchParams.get('search') || '';

    const supabaseClient = createClient(
      Deno.env.get('SUPABASE_URL') ?? '',
      Deno.env.get('SUPABASE_SERVICE_ROLE_KEY') ?? ''
    );

    // Get user from authorization header
    const authHeader = req.headers.get('Authorization');
    if (!authHeader) {
      throw new Error('No authorization header');
    }

    const { data: { user }, error: authError } = await supabaseClient.auth.getUser(
      authHeader.replace('Bearer ', '')
    );

    if (authError || !user) {
      throw new Error('Invalid token');
    }

    // Build query for wa_chats
    let query = supabaseClient
      .from('wa_chats')
      .select('*')
      .eq('tenant_id', user.id)
      .order('is_pinned', { ascending: false })
      .order('last_message_at', { ascending: false });

    // Apply filters
    if (filter === 'unread') {
      query = query.gt('unread_count', 0);
    } else if (filter === 'vip') {
      query = query.eq('is_vip', true);
    } else if (filter === 'orders') {
      query = query.eq('has_open_order', true);
    }

    // Apply search
    if (search) {
      query = query.or(`name.ilike.%${search}%,phone_e164.ilike.%${search}%`);
    }

    // Apply pagination
    const from = (page - 1) * pageSize;
    const to = from + pageSize - 1;
    query = query.range(from, to);

    const { data: chats, error, count } = await query;

    if (error) {
      throw error;
    }

    // Get total unread count
    const { data: unreadData } = await supabaseClient
      .from('wa_chats')
      .select('unread_count')
      .eq('tenant_id', user.id);

    const totalUnread = unreadData?.reduce((sum, chat) => sum + (chat.unread_count || 0), 0) || 0;

    return new Response(JSON.stringify({
      success: true,
      data: {
        chats: chats || [],
        pagination: {
          page,
          pageSize,
          total: count || 0,
          hasMore: count ? (from + pageSize) < count : false
        },
        totalUnread
      }
    }), {
      headers: { ...corsHeaders, 'Content-Type': 'application/json' }
    });

  } catch (error) {
    console.error('Error fetching chats:', error);
    return new Response(JSON.stringify({
      success: false,
      error: error.message
    }), {
      status: 500,
      headers: { ...corsHeaders, 'Content-Type': 'application/json' }
    });
  }
});