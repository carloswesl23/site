import { serve } from "https://deno.land/std@0.168.0/http/server.ts";

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const { instanceId, tokenInstance, phone, limit = 50 } = await req.json();
    
    if (!instanceId || !tokenInstance || !phone) {
      return new Response(JSON.stringify({ 
        error: "instanceId, tokenInstance and phone required" 
      }), { 
        status: 400,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' }
      });
    }

    const ZAPI_BASE = Deno.env.get('ZAPI_BASE_URL') || 'https://api.z-api.io';
    const ZAPI_CLIENT_TOKEN = Deno.env.get('ZAPI_CLIENT_TOKEN');

    if (!ZAPI_CLIENT_TOKEN) {
      return new Response(JSON.stringify({ error: 'Missing Z-API client token' }), {
        status: 500,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' }
      });
    }

    console.log(`Fetching messages for chat: ${phone} with limit: ${limit}`);

    // Z-API doesn't have a direct endpoint for chat message history
    // We'll need to get the chat data which returns recent messages in some implementations
    // First try the chat endpoint to get available data
    const url = `${ZAPI_BASE}/instances/${instanceId}/token/${tokenInstance}/chats/${phone}`;
    
    console.log(`Calling Z-API URL: ${url}`);
    
    const response = await fetch(url, {
      method: 'GET',
      headers: {
        'Client-Token': ZAPI_CLIENT_TOKEN,
        'Content-Type': 'application/json'
      }
    });

    console.log(`Z-API response status: ${response.status}`);

    if (!response.ok) {
      const errorText = await response.text();
      console.error(`Z-API error response: ${errorText}`);
      
      // If specific chat doesn't exist, return empty messages
      if (response.status === 404) {
        console.log('Chat not found, returning empty messages');
        return new Response(JSON.stringify({
          success: true,
          messages: [],
          total: 0,
          note: 'Chat not found or no messages available'
        }), {
          headers: { ...corsHeaders, 'Content-Type': 'application/json' }
        });
      }
      
      throw new Error(`Z-API error: ${response.status} - ${errorText}`);
    }

    const data = await response.json();
    console.log(`Z-API response data:`, JSON.stringify(data, null, 2));
    
    // Since Z-API /chats/{phone} returns metadata, not messages,
    // we'll return the metadata and let the frontend know messages come from webhooks
    const mockMessages = [];
    
    // If there's a lastMessage in the metadata, create a mock message from it
    if (data.lastMessageTime) {
      mockMessages.push({
        id: `meta-${data.phone}-${data.lastMessageTime}`,
        fromMe: false,
        type: 'text',
        body: 'Histórico de mensagens disponível apenas através de webhooks em tempo real',
        timestamp: parseInt(data.lastMessageTime) * 1000,
        status: 'received',
        messageId: `meta-${data.lastMessageTime}`,
        quotedMsgId: null,
        mediaUrl: null,
        caption: null
      });
    }

    console.log(`Created ${mockMessages.length} metadata messages`);
    
    return new Response(JSON.stringify({
      success: true,
      messages: mockMessages,
      total: mockMessages.length,
      chatMetadata: data,
      note: 'Z-API provides chat metadata. Full message history comes from real-time webhooks.'
    }), {
      headers: { ...corsHeaders, 'Content-Type': 'application/json' }
    });

  } catch (error) {
    console.error('Error fetching chat messages:', error);
    return new Response(JSON.stringify({ 
      error: 'Failed to fetch chat messages',
      details: String(error)
    }), {
      status: 500,
      headers: { ...corsHeaders, 'Content-Type': 'application/json' }
    });
  }
});