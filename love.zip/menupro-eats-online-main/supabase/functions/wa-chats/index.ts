import { serve } from "https://deno.land/std@0.168.0/http/server.ts";

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const { instanceId, tokenInstance } = await req.json();
    
    if (!instanceId || !tokenInstance) {
      return new Response(JSON.stringify({ 
        error: "instanceId and tokenInstance required" 
      }), { 
        status: 400,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' }
      });
    }

    const ZAPI_BASE = Deno.env.get('ZAPI_BASE_URL') || 'https://api.z-api.io';
    const ZAPI_CLIENT_TOKEN = Deno.env.get('ZAPI_CLIENT_TOKEN');

    if (!ZAPI_CLIENT_TOKEN) {
      return new Response(JSON.stringify({ error: 'Missing Z-API client token' }), {
        status: 500,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' }
      });
    }

    // Get chats from Z-API
    const url = `${ZAPI_BASE}/instances/${instanceId}/token/${tokenInstance}/chats`;
    const response = await fetch(url, {
      method: 'GET',
      headers: {
        'Client-Token': ZAPI_CLIENT_TOKEN
      }
    });

    if (!response.ok) {
      throw new Error(`Z-API error: ${response.status}`);
    }

    const data = await response.json();
    
    return new Response(JSON.stringify({
      success: true,
      chats: data.chats || data
    }), {
      headers: { ...corsHeaders, 'Content-Type': 'application/json' }
    });

  } catch (error) {
    console.error('Error fetching chats:', error);
    return new Response(JSON.stringify({ 
      error: 'Failed to fetch chats',
      details: String(error)
    }), {
      status: 500,
      headers: { ...corsHeaders, 'Content-Type': 'application/json' }
    });
  }
});