import { serve } from "https://deno.land/std@0.190.0/http/server.ts";
import { createClient } from 'https://esm.sh/@supabase/supabase-js@2';

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response('ok', { headers: corsHeaders });
  }

  try {
    const supabaseClient = createClient(
      Deno.env.get('SUPABASE_URL') ?? '',
      Deno.env.get('SUPABASE_SERVICE_ROLE_KEY') ?? ''
    );

    // Aceitar slug via body ou query parameter
    let slug;
    if (req.method === 'POST') {
      const body = await req.json();
      slug = body.slug;
    } else {
      const url = new URL(req.url);
      slug = url.searchParams.get('slug');
    }

    if (!slug) {
      return new Response(JSON.stringify({ error: 'Slug is required' }), {
        status: 400,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      });
    }

    console.log('🔍 Buscando estabelecimento para slug:', slug);

    // Usar função segura para buscar dados do estabelecimento
    const { data, error } = await supabaseClient.rpc('get_public_establishment_data', {
      slug: slug
    });

    if (error) {
      console.error('❌ Erro ao buscar estabelecimento:', error);
      return new Response(JSON.stringify({ error: error.message }), {
        status: 500,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      });
    }

    if (!data || data.length === 0) {
      console.log('❌ Estabelecimento não encontrado para slug:', slug);
      return new Response(JSON.stringify({ error: 'Estabelecimento não encontrado' }), {
        status: 404,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      });
    }

    console.log('✅ Estabelecimento encontrado:', data[0]);

    // Buscar dados de checkout diretamente da tabela como método principal
    let checkoutData = null;
    let pixData = null;
    
    try {
      console.log('💳 Buscando dados do estabelecimento na tabela...');
      const { data: establishmentSettings, error: settingsError } = await supabaseClient
        .from('establishment_settings')
        .select(`
          pix_enabled, accept_cash, accept_credit_on_delivery, 
          combine_payment_via_whatsapp, show_qr_pix, mp_enabled, 
          business_phone, pix_key, pix_beneficiary_name, is_open
        `)
        .eq('online_menu_slug', slug)
        .single();
      
      if (settingsError) {
        console.log('⚠️ Erro ao buscar configurações:', settingsError);
      } else {
        console.log('✅ Configurações encontradas:', establishmentSettings);
        checkoutData = [establishmentSettings];
        pixData = [establishmentSettings];
      }
    } catch (error) {
      console.log('⚠️ Fallback: tentando RPC functions...');
      
      // Fallback para as funções RPC se a busca direta falhar
      try {
        const { data: checkoutResult } = await supabaseClient.rpc('get_establishment_checkout_data', {
          establishment_slug: slug
        });
        checkoutData = checkoutResult;
      } catch (e) {
        console.log('⚠️ RPC checkout também falhou:', e);
      }

      try {
        const { data: pixResult } = await supabaseClient.rpc('get_pix_data_for_order', {
          establishment_slug: slug,
          order_total: 0
        });
        pixData = pixResult;
      } catch (e) {
        console.log('⚠️ RPC PIX também falhou:', e);
      }
    }

    const establishmentInfo = {
      establishment_id: data[0].establishment_id,
      business_name: data[0].business_name,
      business_logo: data[0].business_logo,
      primary_color: data[0].primary_color,
      secondary_color: data[0].secondary_color,
      mobile_layout_mode: data[0].mobile_layout_mode,
      instagram_url: data[0].instagram_url,
      checkout_custom_message: data[0].checkout_custom_message,
      // Status da loja
      is_open: checkoutData?.[0]?.is_open !== false,
      // Dados de checkout com fallbacks mais robustos
      business_phone: checkoutData?.[0]?.business_phone || null,
      pix_enabled: checkoutData?.[0]?.pix_enabled === true,
      accept_cash: checkoutData?.[0]?.accept_cash !== false,
      accept_credit_on_delivery: checkoutData?.[0]?.accept_credit_on_delivery !== false,
      combine_payment_via_whatsapp: checkoutData?.[0]?.combine_payment_via_whatsapp === true,
      show_qr_pix: checkoutData?.[0]?.show_qr_pix !== false,
      mp_enabled: checkoutData?.[0]?.mp_enabled === true,
      // Dados do PIX
      pix_key: pixData?.[0]?.pix_key || checkoutData?.[0]?.pix_key || null,
      pix_beneficiary_name: pixData?.[0]?.pix_beneficiary_name || checkoutData?.[0]?.pix_beneficiary_name || null
    };

    console.log('🏪 Estabelecimento final montado:', establishmentInfo);

    return new Response(JSON.stringify({ success: true, data: establishmentInfo }), {
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    });

  } catch (error) {
    console.error('❌ Erro inesperado:', error);
    return new Response(JSON.stringify({ error: 'Erro interno do servidor' }), {
      status: 500,
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    });
  }
});