import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const supabase = createClient(
      Deno.env.get('SUPABASE_URL') ?? '',
      Deno.env.get('SUPABASE_SERVICE_ROLE_KEY') ?? ''
    );

    const { order_id, user_id } = await req.json();

    console.log('Processando atribuição automática para pedido:', order_id);

    // Buscar dados do pedido
    const { data: order, error: orderError } = await supabase
      .from('user_orders')
      .select('*')
      .eq('id', order_id)
      .eq('user_id', user_id)
      .single();

    if (orderError || !order) {
      throw new Error('Pedido não encontrado');
    }

    // Verificar se é entrega
    if (order.fulfillment_method !== 'delivery') {
      return new Response(
        JSON.stringify({ success: false, message: 'Pedido não é para entrega' }),
        { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    // Buscar motoboy disponível (rodízio)
    const { data: couriers, error: couriersError } = await supabase
      .from('couriers')
      .select('*')
      .eq('user_id', user_id)
      .eq('is_available', true)
      .order('created_at', { ascending: true });

    if (couriersError || !couriers?.length) {
      throw new Error('Nenhum motoboy disponível');
    }

    // Pegar próximo motoboy no rodízio
    const selectedCourier = couriers[0];

    // Criar atribuição
    const { error: assignError } = await supabase
      .from('delivery_assignments')
      .insert({
        order_id: order_id,
        courier_id: selectedCourier.id,
        status: 'pending'
      });

    if (assignError) {
      throw new Error('Erro ao criar atribuição');
    }

    // Atualizar status do pedido
    const { error: updateError } = await supabase
      .from('user_orders')
      .update({ 
        status: 'out_for_delivery',
        out_for_delivery_at: new Date().toISOString()
      })
      .eq('id', order_id);

    if (updateError) {
      throw new Error('Erro ao atualizar pedido');
    }

    // Log timeline
    await supabase
      .from('order_timeline')
      .insert({
        order_id: order_id,
        user_id: user_id,
        event_type: 'courier_assigned',
        event_data: {
          courier_id: selectedCourier.id,
          courier_name: selectedCourier.name,
          assignment_type: 'automatic'
        }
      });

    // Buscar instância WhatsApp
    const { data: instance } = await supabase
      .from('whatsapp_instances')
      .select('instance_id, token_instance')
      .eq('user_id', user_id)
      .eq('status', 'connected')
      .single();

    if (instance) {
      // Enviar mensagem para motoboy
      try {
        await supabase.functions.invoke('send-courier-message', {
          body: {
            courier_phone: selectedCourier.phone,
            order: order,
            courier_name: selectedCourier.name,
            instance_id: instance.instance_id,
            token_instance: instance.token_instance
          }
        });

        // Enviar mensagem para cliente
        await supabase.functions.invoke('send-customer-delivery-notification', {
          body: {
            customer_phone: order.customer_phone,
            order_number: order.order_number,
            driver_name: selectedCourier.name,
            instance_id: instance.instance_id,
            token_instance: instance.token_instance
          }
        });

        // Log timeline WhatsApp
        await supabase
          .from('order_timeline')
          .insert({
            order_id: order_id,
            user_id: user_id,
            event_type: 'whatsapp_sent',
            event_data: {
              courier_phone: selectedCourier.phone,
              customer_phone: order.customer_phone,
              messages_sent: ['courier_notification', 'customer_notification']
            }
          });

      } catch (error) {
        console.error('Erro ao enviar WhatsApp:', error);
        // Não falha a atribuição se WhatsApp falhar
      }
    }

    return new Response(
      JSON.stringify({ 
        success: true, 
        courier: selectedCourier,
        message: 'Entrega atribuída automaticamente'
      }),
      { 
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        status: 200 
      }
    );

  } catch (error) {
    console.error('Erro na atribuição automática:', error);
    
    return new Response(
      JSON.stringify({ 
        success: false, 
        error: error.message || 'Erro interno do servidor' 
      }),
      { 
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        status: 500 
      }
    );
  }
});