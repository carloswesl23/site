import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const { phone } = await req.json();

    if (!phone) {
      throw new Error('Phone is required');
    }

    const supabaseClient = createClient(
      Deno.env.get('SUPABASE_URL') ?? '',
      Deno.env.get('SUPABASE_SERVICE_ROLE_KEY') ?? ''
    );

    // Get user from authorization header
    const authHeader = req.headers.get('Authorization');
    if (!authHeader) {
      throw new Error('No authorization header');
    }

    const { data: { user }, error: authError } = await supabaseClient.auth.getUser(
      authHeader.replace('Bearer ', '')
    );

    if (authError || !user) {
      throw new Error('Invalid token');
    }

    // Mark chat as read (zero unread_count)
    const { error: updateError } = await supabaseClient
      .from('wa_chats')
      .update({ unread_count: 0 })
      .eq('tenant_id', user.id)
      .eq('phone_e164', phone);

    if (updateError) {
      throw updateError;
    }

    // Mark messages as read
    const { error: messagesError } = await supabaseClient
      .from('wa_messages')
      .update({ status: 'read' })
      .eq('tenant_id', user.id)
      .eq('phone_e164', phone)
      .eq('direction', 'in')
      .neq('status', 'read');

    if (messagesError) {
      console.error('Error updating message status:', messagesError);
    }

    // Optional: Send read receipt via Z-API if available
    try {
      const { data: instance } = await supabaseClient
        .from('whatsapp_instances')
        .select('instance_id, token_instance, status')
        .eq('user_id', user.id)
        .eq('status', 'connected')
        .single();

      if (instance) {
        const ZAPI_BASE = Deno.env.get('ZAPI_BASE_URL') || 'https://api.z-api.io';
        const ZAPI_CLIENT_TOKEN = Deno.env.get('ZAPI_CLIENT_TOKEN');

        if (ZAPI_CLIENT_TOKEN) {
          const zapiUrl = `${ZAPI_BASE}/instances/${instance.instance_id}/token/${instance.token_instance}/mark-as-read`;
          
          await fetch(zapiUrl, {
            method: 'POST',
            headers: {
              'Content-Type': 'application/json',
              'Client-Token': ZAPI_CLIENT_TOKEN
            },
            body: JSON.stringify({
              phone: phone.replace('+', '')
            })
          });
        }
      }
    } catch (error) {
      console.log('Could not send read receipt:', error.message);
    }

    return new Response(JSON.stringify({
      success: true,
      message: 'Messages marked as read'
    }), {
      headers: { ...corsHeaders, 'Content-Type': 'application/json' }
    });

  } catch (error) {
    console.error('Error marking as read:', error);
    return new Response(JSON.stringify({
      success: false,
      error: error.message
    }), {
      status: 500,
      headers: { ...corsHeaders, 'Content-Type': 'application/json' }
    });
  }
});