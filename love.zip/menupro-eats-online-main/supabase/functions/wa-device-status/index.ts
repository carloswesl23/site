import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

const SUPABASE_URL = Deno.env.get("SUPABASE_URL")!;
const SUPABASE_SERVICE_ROLE = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
const supabase = createClient(SUPABASE_URL, SUPABASE_SERVICE_ROLE);

serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const { instanceId, tokenInstance } = await req.json();
    
    if (!instanceId || !tokenInstance) {
      return new Response(JSON.stringify({ 
        error: "instanceId and tokenInstance required" 
      }), { 
        status: 400,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' }
      });
    }

    const ZAPI_BASE = Deno.env.get('ZAPI_BASE_URL') || 'https://api.z-api.io';
    const ZAPI_CLIENT_TOKEN = Deno.env.get('ZAPI_CLIENT_TOKEN');

    if (!ZAPI_CLIENT_TOKEN) {
      return new Response(JSON.stringify({ error: 'Missing Z-API client token' }), {
        status: 500,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' }
      });
    }

    console.log(`Checking device status for instance: ${instanceId}`);

    // Get device info from Z-API
    const statusUrl = `${ZAPI_BASE}/instances/${instanceId}/token/${tokenInstance}/status`;
    const deviceUrl = `${ZAPI_BASE}/instances/${instanceId}/token/${tokenInstance}/device`;

    // Fetch both status and device info
    const [statusResponse, deviceResponse] = await Promise.all([
      fetch(statusUrl, {
        method: 'GET',
        headers: { 'Client-Token': ZAPI_CLIENT_TOKEN }
      }),
      fetch(deviceUrl, {
        method: 'GET',
        headers: { 'Client-Token': ZAPI_CLIENT_TOKEN }
      })
    ]);

    const statusData = statusResponse.ok ? await statusResponse.json() : null;
    const deviceData = deviceResponse.ok ? await deviceResponse.json() : null;

    console.log('Status data:', statusData);
    console.log('Device data:', deviceData);

    // Determine connection status
    let connectionStatus = 'disconnected';
    let phoneNumber = null;

    if (statusData?.connected === true || statusData?.status === 'connected') {
      connectionStatus = 'connected';
      phoneNumber = deviceData?.phone || statusData?.phone || null;
    } else if (statusData?.qrcode || statusData?.status === 'qrcode') {
      connectionStatus = 'qrcode';
    }

    // Update WhatsApp instance in database
    const { error: updateError } = await supabase
      .from('whatsapp_instances')
      .update({
        status: connectionStatus,
        numero_cliente: phoneNumber,
        updated_at: new Date().toISOString()
      })
      .eq('instance_id', instanceId);

    if (updateError) {
      console.error('Error updating instance:', updateError);
    }

    return new Response(JSON.stringify({
      success: true,
      status: connectionStatus,
      connected: connectionStatus === 'connected',
      phone: phoneNumber,
      statusData,
      deviceData
    }), {
      headers: { ...corsHeaders, 'Content-Type': 'application/json' }
    });

  } catch (error) {
    console.error('Error checking device status:', error);
    return new Response(JSON.stringify({ 
      error: 'Failed to check device status',
      details: String(error)
    }), {
      status: 500,
      headers: { ...corsHeaders, 'Content-Type': 'application/json' }
    });
  }
});