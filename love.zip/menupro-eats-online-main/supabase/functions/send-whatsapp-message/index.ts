import { serve } from "https://deno.land/std@0.190.0/http/server.ts";
import { createClient } from 'https://esm.sh/@supabase/supabase-js@2';

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

interface WhatsAppMessageRequest {
  user_id: string;
  order_id: string;
  message_type: 'new_order' | 'pix' | 'payment_confirmed' | 'out_for_delivery';
  phone_number: string;
  order_data: any;
}

serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response('ok', { headers: corsHeaders });
  }

  try {
    const supabaseClient = createClient(
      Deno.env.get('SUPABASE_URL') ?? '',
      Deno.env.get('SUPABASE_SERVICE_ROLE_KEY') ?? ''
    );

    const { user_id, order_id, message_type, phone_number, order_data }: WhatsAppMessageRequest = await req.json();

    // Buscar configurações de mensagem do usuário
    const { data: config, error: configError } = await supabaseClient
      .from('whatsapp_message_configs')
      .select('*')
      .eq('user_id', user_id)
      .single();

    if (configError || !config) {
      throw new Error('Configurações de WhatsApp não encontradas');
    }

    // Buscar nome do estabelecimento
    const { data: establishment, error: establishmentError } = await supabaseClient
      .from('establishment_settings')
      .select('business_name')
      .eq('user_id', user_id)
      .single();

    if (establishmentError || !establishment) {
      throw new Error('Configurações do estabelecimento não encontradas');
    }

    // Usar credenciais Z-API centralizadas
    const ZAPI_INSTANCE_ID = 'INSIRA_AQUI_O_ID_REAL';
    const ZAPI_TOKEN = 'INSIRA_O_TOKEN_REAL';

    // Verificar se mensagens automáticas estão ativadas
    if (!config.auto_messages_enabled) {
      return new Response(JSON.stringify({ message: 'Mensagens automáticas desativadas' }), {
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        status: 200,
      });
    }

    // Selecionar template baseado no tipo de mensagem
    let template = '';
    let enabled = false;

    switch (message_type) {
      case 'new_order':
        template = config.new_order_template;
        enabled = config.new_order_enabled;
        break;
      case 'pix':
        template = config.pix_message_template;
        enabled = config.pix_message_enabled;
        break;
      case 'payment_confirmed':
        template = config.payment_confirmed_template;
        enabled = config.payment_confirmed_enabled;
        break;
      case 'out_for_delivery':
        template = config.out_for_delivery_template;
        enabled = config.out_for_delivery_enabled;
        break;
    }

    if (!enabled) {
      return new Response(JSON.stringify({ message: `Mensagem ${message_type} desativada` }), {
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        status: 200,
      });
    }

    // Processar template com dados do pedido
    const processedMessage = processTemplate(template, order_data, config, establishment.business_name);

    // Criar log da mensagem
    const { error: logError } = await supabaseClient
      .from('whatsapp_message_logs')
      .insert({
        user_id,
        order_id,
        message_type,
        phone_number: phone_number,
        message_content: processedMessage,
        status: 'pending'
      });

    if (logError) {
      console.error('Erro ao criar log:', logError);
    }

    // Enviar mensagem via Z-API
    console.log('Enviando mensagem WhatsApp via Z-API para:', phone_number);
    console.log('Conteúdo:', processedMessage);

    const success = await sendMessageViaZAPI(
      ZAPI_INSTANCE_ID,
      ZAPI_TOKEN,
      phone_number,
      processedMessage
    );

    if (success) {
      // Atualizar log como enviado
      await supabaseClient
        .from('whatsapp_message_logs')
        .update({ status: 'sent' })
        .eq('user_id', user_id)
        .eq('order_id', order_id)
        .eq('message_type', message_type);

      return new Response(JSON.stringify({ 
        success: true, 
        message: 'Mensagem enviada com sucesso',
        content: processedMessage 
      }), {
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        status: 200,
      });
    } else {
      throw new Error('Falha no envio da mensagem');
    }

  } catch (error) {
    console.error('Erro:', error);
    return new Response(JSON.stringify({ 
      error: error.message 
    }), {
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      status: 500,
    });
  }
});

async function sendMessageViaZAPI(instanceId: string, token: string, phoneNumber: string, message: string): Promise<boolean> {
  try {
    // Garantir que o número está no formato correto (sem símbolos, só números)
    const cleanPhone = phoneNumber.replace(/\D/g, '');
    
    const response = await fetch(`https://api.z-api.io/instances/${instanceId}/token/${token}/send-messages`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Client-Token': 'F25f061eefa514271aac2c1b3dafc9acdS',
        'Authorization': 'Bearer eyJhbGciOiJIUzI1NiJ9.eyJpYXQiOjQ5MDg0MzU0NTUsInN1YiI6ImNhcmxvc3dlc2xsZW5ob3RtYXJ0QGdtYWlsLmNvbSIsImlzcyI6ImVtRmhjQzF6WldOMWNtbDBlUzFoY0drPSIsImF1ZCI6ImVtRmhjQzFoY0drPSIsImV4cCI6NDkwODQzNTQ1NSwib25EZW1hbmQiOnRydWUsInJvbGUiOiJFTlRFUlBSSVNFIiwiaW50ZWdyYXRvciI6dHJ1ZSwidGVuYW50T3duZXIiOiJaVzFoYVd4QVptOTFjbkpwZUdWc0xtbDAifQ.OmtaNR3G-fQWVVzYmfl8Vbgl1Np009zKmpBTNK8C8Vo'
      },
      body: JSON.stringify({
        phone: `55${cleanPhone}`, // Adiciona código do país (Brasil)
        message: message
      })
    });

    if (!response.ok) {
      const errorData = await response.text();
      console.error('Erro da Z-API:', response.status, errorData);
      return false;
    }

    const result = await response.json();
    console.log('Mensagem enviada com sucesso via Z-API:', result);
    return true;
    
  } catch (error) {
    console.error('Erro ao enviar mensagem via Z-API:', error);
    return false;
  }
}

function processTemplate(template: string, orderData: any, config: any, businessName: string): string {
  let processed = template;

  // Substituir variáveis com dados do pedido
  const variables = {
    nome_da_loja: businessName || orderData.establishment_name || 'Estabelecimento',
    codigo_do_pedido: orderData.order_number || '',
    nome_do_cliente: orderData.customer_name || '',
    telefone: orderData.customer_phone || '',
    rua: orderData.address?.street || '',
    numero: orderData.address?.number || '',
    bairro: orderData.address?.neighborhood || '',
    cidade: orderData.address?.city || '',
    cep: orderData.address?.zipCode || '',
    itens_do_pedido: formatOrderItems(orderData.items || []),
    subtotal: (orderData.subtotal || 0).toFixed(2),
    taxa_entrega: (orderData.delivery_fee || 0).toFixed(2),
    total: (orderData.total || 0).toFixed(2),
    metodo_pagamento: formatPaymentMethod(orderData.payment_method || ''),
    chave_pix: orderData.pix_key || '',
    nome_beneficiario: orderData.pix_beneficiary_name || '',
    tempo_estimado: config.estimated_delivery_time || '30-45 minutos'
  };

  // Substituir todas as variáveis no template
  Object.entries(variables).forEach(([key, value]) => {
    const regex = new RegExp(`{${key}}`, 'g');
    processed = processed.replace(regex, String(value));
  });

  return processed;
}

function formatOrderItems(items: any[]): string {
  return items.map((item, index) => {
    let itemText = `${index + 1}. ${item.quantity}x ${item.product_name}`;
    
    if (item.customizations) {
      // Adicionar customizações se existirem
      if (item.customizations.notes) {
        itemText += `\n   • Obs: ${item.customizations.notes}`;
      }
    }
    
    itemText += `\n   💰 R$ ${item.price.toFixed(2)}`;
    
    return itemText;
  }).join('\n\n');
}

function formatPaymentMethod(method: string): string {
  const methods: { [key: string]: string } = {
    'pix': 'PIX',
    'cash': 'Dinheiro',
    'card': 'Cartão',
    'whatsapp': 'Combinar pelo WhatsApp'
  };
  
  return methods[method] || method;
}