import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

const SUPABASE_URL = Deno.env.get("SUPABASE_URL")!;
const SUPABASE_SERVICE_ROLE = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
const ZAPI_CLIENT_TOKEN = Deno.env.get("ZAPI_CLIENT_TOKEN")!;
const ZAPI_BASE = Deno.env.get("ZAPI_BASE_URL") || "https://api.z-api.io";

const sb = createClient(SUPABASE_URL, SUPABASE_SERVICE_ROLE);

// Map message types to Z-API endpoints
const endpointMap: { [key: string]: string } = {
  'text': 'send-text',
  'image': 'send-image',
  'link': 'send-link',
  'location': 'send-location',
  'order': 'send-order',
  'order_status': 'order-status-update',
  'order_payment': 'order-payment-update'
};

// Create payload for each message type
function createPayload(type: string, chatId: string, body: any): any {
  const phone = chatId.replace(/^55/, '').replace(/^(\d{2})(\d)/, '55$1$2');
  
  switch (type) {
    case 'text':
      return { phone, message: body.text || body.message };
    
    case 'image':
      return { 
        phone, 
        image: body.image || body.imageUrl,
        caption: body.caption || body.text || ''
      };
    
    case 'link':
      return {
        phone,
        message: body.message || body.text,
        linkUrl: body.linkUrl || body.url,
        linkTitle: body.linkTitle || body.title || 'Abrir Link'
      };
    
    case 'location':
      return {
        phone,
        latitude: body.latitude,
        longitude: body.longitude,
        address: body.address || ''
      };
    
    case 'order':
    case 'order_status':
    case 'order_payment':
      return { phone, ...body };
    
    default:
      return { phone, message: body.text || String(body) };
  }
}

serve(async (req) => {
  // Handle CORS preflight requests
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const { userId, instanceId, tokenInstance, chatId, type, body } = await req.json();
    
    if (!userId || !instanceId || !tokenInstance || !chatId || !type || !body) {
      return new Response(JSON.stringify({ 
        error: "userId, instanceId, tokenInstance, chatId, type, and body required" 
      }), { 
        status: 400,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' }
      });
    }

    console.log(`Sending ${type} message to ${chatId}`);

    // Create message record in database first
    const messageData = {
      user_id: userId,
      phone_e164: chatId,
      direction: 'OUT',
      body: type === 'text' ? body.text || body.message : JSON.stringify(body),
      media_url: body.image || body.imageUrl || null,
      status: 'QUEUED'
    };

    const { data: messageRecord, error: insertError } = await sb
      .from("wa_messages")
      .insert(messageData)
      .select()
      .single();

    if (insertError || !messageRecord) {
      console.error('Error inserting message:', insertError);
      throw new Error('Failed to create message record');
    }

    // Get Z-API endpoint
    const endpoint = endpointMap[type];
    if (!endpoint) {
      throw new Error(`Unsupported message type: ${type}`);
    }

    // Create Z-API payload
    const payload = createPayload(type, chatId, body);

    // Send to Z-API
    const url = `${ZAPI_BASE}/instances/${instanceId}/token/${tokenInstance}/${endpoint}`;
    const zres = await fetch(url, {
      method: "POST",
      headers: {
        'Content-Type': 'application/json',
        'Client-Token': ZAPI_CLIENT_TOKEN
      },
      body: JSON.stringify(payload)
    });

    const zapiResponse = await zres.json();

    if (!zres.ok) {
      console.error("Z-API error:", zres.status, zapiResponse);
      
      // Update message status to failed
      await sb
        .from("wa_messages")
        .update({
          status: 'failed',
          error: `Z-API error: ${zapiResponse.error || zapiResponse.message}`,
          updated_at: new Date().toISOString()
        })
        .eq("id", messageRecord.id);

      return new Response(JSON.stringify({ 
        error: "Failed to send message", 
        details: zapiResponse 
      }), { 
        status: 502,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' }
      });
    }

    // Update message status to sent
    const { error: updateError } = await sb
      .from("wa_messages")
      .update({
        status: 'sent',
        zapi_msg_id: zapiResponse.messageId || zapiResponse.id,
        updated_at: new Date().toISOString()
      })
      .eq("id", messageRecord.id);

    if (updateError) {
      console.error('Error updating message status:', updateError);
    }

    console.log(`Message sent successfully: ${zapiResponse.messageId}`);

    return new Response(JSON.stringify({ 
      success: true,
      messageId: zapiResponse.messageId || zapiResponse.id,
      zapiResponse
    }), { 
      status: 200,
      headers: { ...corsHeaders, 'Content-Type': 'application/json' }
    });

  } catch (err) {
    console.error('Send message error:', err);
    return new Response(JSON.stringify({ 
      error: String(err),
      message: "Failed to send message"
    }), { 
      status: 500,
      headers: { ...corsHeaders, 'Content-Type': 'application/json' }
    });
  }
});