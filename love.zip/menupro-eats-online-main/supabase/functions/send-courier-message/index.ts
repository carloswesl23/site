import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const supabase = createClient(
      Deno.env.get('SUPABASE_URL') ?? '',
      Deno.env.get('SUPABASE_SERVICE_ROLE_KEY') ?? ''
    );

    const { 
      courier_phone, 
      order, 
      courier_name,
      instance_id,
      token_instance 
    } = await req.json();

    console.log('Enviando mensagem para motoboy:', courier_phone);

    // Formatar lista de itens
    const itemsList = Array.isArray(order.items) ? order.items
      .map((item: any) => `• ${item.quantity}x ${item.name} - R$ ${item.price?.toFixed(2) || '0,00'}`)
      .join('\n') : 'Itens não disponíveis';

    // Gerar URL do Google Maps se houver endereço
    const mapsUrl = order.delivery_address 
      ? `https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(order.delivery_address)}`
      : '';

    // Criar mensagem conforme template especificado
    const message = `🚴‍♂️ *Nova entrega* #${order.order_number}
Cliente: ${order.customer_name}
Tel: ${order.customer_phone}
Endereço: ${order.delivery_address || 'Endereço não informado'}
Valor: R$ ${order.total?.toFixed(2) || '0,00'}
Pagamento: ${order.payment_method || 'Não informado'}
${order.notes ? `Obs: ${order.notes}` : ''}
${mapsUrl ? `🗺️ Rota: ${mapsUrl}` : ''}

Responda: *1* para aceitar | *2* para recusar.`;

    // Limpar número do telefone
    const cleanPhone = courier_phone.replace(/\D/g, '');
    const formattedPhone = cleanPhone.startsWith('55') ? cleanPhone : `55${cleanPhone}`;

    // Enviar via Z-API
    const zapiUrl = `${Deno.env.get('ZAPI_BASE_URL')}/instances/${instance_id}/token/${token_instance}/send-text`;
    
    const zapiResponse = await fetch(zapiUrl, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Client-Token': Deno.env.get('ZAPI_CLIENT_TOKEN') ?? ''
      },
      body: JSON.stringify({
        phone: formattedPhone,
        message: message,
        messageId: `courier_${order.order_number}_${Date.now()}`
      })
    });

    const zapiResult = await zapiResponse.json();
    console.log('Resposta Z-API para motoboy:', zapiResult);

    if (!zapiResponse.ok || !zapiResult.success) {
      throw new Error(`Falha no envio Z-API: ${zapiResult.error || 'Erro desconhecido'}`);
    }

    // Enviar localização se houver coordenadas (opcional para futuro)
    // if (order.delivery_lat && order.delivery_lng) {
    //   const locationUrl = `${Deno.env.get('ZAPI_BASE_URL')}/instances/${instance_id}/token/${token_instance}/send-location`;
    //   
    //   await fetch(locationUrl, {
    //     method: 'POST',
    //     headers: {
    //       'Content-Type': 'application/json',
    //       'Client-Token': Deno.env.get('ZAPI_CLIENT_TOKEN') ?? ''
    //     },
    //     body: JSON.stringify({
    //       phone: formattedPhone,
    //       latitude: order.delivery_lat,
    //       longitude: order.delivery_lng,
    //       name: `Entrega #${order.order_number}`
    //     })
    //   });
    // }

    // Log da mensagem enviada
    const { error: logError } = await supabase
      .from('whatsapp_message_logs')
      .insert({
        user_id: order.user_id,
        order_id: order.id,
        message_type: 'courier_delivery_assignment',
        phone_number: courier_phone,
        message_content: message,
        status: 'sent',
        whatsapp_message_id: zapiResult.messageId
      });

    if (logError) {
      console.error('Erro ao salvar log:', logError);
    }

    return new Response(
      JSON.stringify({ 
        success: true, 
        message: 'Mensagem enviada para motoboy',
        zapiMessageId: zapiResult.messageId 
      }),
      { 
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        status: 200 
      }
    );

  } catch (error) {
    console.error('Erro ao enviar mensagem para motoboy:', error);
    
    return new Response(
      JSON.stringify({ 
        success: false, 
        error: error.message || 'Erro interno do servidor' 
      }),
      { 
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        status: 500 
      }
    );
  }
});