import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

const SUPABASE_URL = Deno.env.get("SUPABASE_URL")!;
const SUPABASE_SERVICE_ROLE = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
const supabase = createClient(SUPABASE_URL, SUPABASE_SERVICE_ROLE);

serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const { instanceId, tokenInstance, userId } = await req.json();
    
    if (!instanceId || !tokenInstance || !userId) {
      return new Response(JSON.stringify({ 
        error: "instanceId, tokenInstance and userId required" 
      }), { 
        status: 400,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' }
      });
    }

    const ZAPI_BASE = Deno.env.get('ZAPI_BASE_URL') || 'https://api.z-api.io';
    const ZAPI_CLIENT_TOKEN = Deno.env.get('ZAPI_CLIENT_TOKEN');

    if (!ZAPI_CLIENT_TOKEN) {
      return new Response(JSON.stringify({ error: 'Missing Z-API client token' }), {
        status: 500,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' }
      });
    }

    console.log(`Iniciando sincronização de contatos para instância ${instanceId}`);

    // 1. Buscar todos os chats/contatos da Z-API
    const chatsUrl = `${ZAPI_BASE}/instances/${instanceId}/token/${tokenInstance}/chats`;
    const chatsResponse = await fetch(chatsUrl, {
      method: 'GET',
      headers: {
        'Client-Token': ZAPI_CLIENT_TOKEN
      }
    });

    if (!chatsResponse.ok) {
      throw new Error(`Erro ao buscar chats: ${chatsResponse.status}`);
    }

    const chatsData = await chatsResponse.json();
    console.log(`Encontrados ${Array.isArray(chatsData) ? chatsData.length : 'dados não em array'} chats`);
    
    let allChats = [];
    if (Array.isArray(chatsData)) {
      allChats = chatsData;
    } else if (chatsData.chats && Array.isArray(chatsData.chats)) {
      allChats = chatsData.chats;
    } else if (chatsData.data && Array.isArray(chatsData.data)) {
      allChats = chatsData.data;
    }

    // 2. Buscar contatos específicos da agenda
    let contactsFromAgenda = [];
    try {
      const contactsUrl = `${ZAPI_BASE}/instances/${instanceId}/token/${tokenInstance}/contacts`;
      const contactsResponse = await fetch(contactsUrl, {
        method: 'GET',
        headers: {
          'Client-Token': ZAPI_CLIENT_TOKEN
        }
      });

      if (contactsResponse.ok) {
        const contactsData = await contactsResponse.json();
        console.log(`Encontrados ${Array.isArray(contactsData) ? contactsData.length : 'dados não em array'} contatos da agenda`);
        
        if (Array.isArray(contactsData)) {
          contactsFromAgenda = contactsData;
        } else if (contactsData.contacts && Array.isArray(contactsData.contacts)) {
          contactsFromAgenda = contactsData.contacts;
        } else if (contactsData.data && Array.isArray(contactsData.data)) {
          contactsFromAgenda = contactsData.data;
        }
      }
    } catch (error) {
      console.log('Erro ao buscar contatos da agenda:', error);
      // Continua mesmo se não conseguir buscar contatos da agenda
    }

    // 3. Combinar todos os contatos únicos
    const allContacts = new Map();

    // Adicionar contatos dos chats
    for (const chat of allChats) {
      const phone = chat.phone || chat.id || chat.chatId;
      if (phone && !phone.includes('@g.us')) { // Excluir grupos
        let phoneE164 = phone.replace('@c.us', '').replace('@s.whatsapp.net', '');
        if (!phoneE164.startsWith('+')) {
          phoneE164 = '+' + phoneE164;
        }

        allContacts.set(phoneE164, {
          phone_e164: phoneE164,
          name: chat.name || chat.pushname || chat.notifyName || null,
          last_interaction_at: chat.t ? new Date(chat.t * 1000).toISOString() : new Date().toISOString()
        });
      }
    }

    // Adicionar contatos da agenda
    for (const contact of contactsFromAgenda) {
      const phone = contact.phone || contact.id;
      if (phone) {
        let phoneE164 = phone.replace('@c.us', '').replace('@s.whatsapp.net', '');
        if (!phoneE164.startsWith('+')) {
          phoneE164 = '+' + phoneE164;
        }

        // Se já existe, atualiza o nome se estiver vazio
        if (allContacts.has(phoneE164)) {
          const existing = allContacts.get(phoneE164);
          if (!existing.name && contact.name) {
            existing.name = contact.name;
          }
        } else {
          allContacts.set(phoneE164, {
            phone_e164: phoneE164,
            name: contact.name || contact.pushname || null,
            last_interaction_at: new Date().toISOString()
          });
        }
      }
    }

    console.log(`Total de contatos únicos para sincronizar: ${allContacts.size}`);

    // 4. Sincronizar todos os contatos no banco
    let syncedCount = 0;
    const contactsArray = Array.from(allContacts.values());

    // Processar em lotes para evitar timeouts
    const batchSize = 50;
    for (let i = 0; i < contactsArray.length; i += batchSize) {
      const batch = contactsArray.slice(i, i + batchSize);
      
      for (const contact of batch) {
        try {
          const { error } = await supabase
            .from('contacts')
            .upsert({
              user_id: userId,
              phone_e164: contact.phone_e164,
              name: contact.name,
              last_interaction_at: contact.last_interaction_at,
              opt_in: true
            }, { 
              onConflict: 'user_id,phone_e164' 
            });

          if (error) {
            console.error('Erro ao sincronizar contato:', contact.phone_e164, error);
          } else {
            syncedCount++;
          }
        } catch (error) {
          console.error('Erro ao processar contato:', contact.phone_e164, error);
        }
      }
    }

    console.log(`Sincronização concluída: ${syncedCount} contatos sincronizados`);

    return new Response(JSON.stringify({
      success: true,
      totalContactsFound: allContacts.size,
      contactsSynced: syncedCount,
      message: `${syncedCount} contatos sincronizados com sucesso`
    }), {
      headers: { ...corsHeaders, 'Content-Type': 'application/json' }
    });

  } catch (error) {
    console.error('Erro na sincronização de contatos:', error);
    return new Response(JSON.stringify({ 
      error: 'Falha na sincronização de contatos',
      details: String(error)
    }), {
      status: 500,
      headers: { ...corsHeaders, 'Content-Type': 'application/json' }
    });
  }
});