
import { createClient } from 'https://esm.sh/@supabase/supabase-js@2'

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
}

interface WebhookPayload {
  event_type: string;
  data: any;
  timestamp: string;
  establishment_id?: string;
}

Deno.serve(async (req) => {
  // Handle CORS preflight requests
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const supabase = createClient(
      Deno.env.get('SUPABASE_URL') ?? '',
      Deno.env.get('SUPABASE_SERVICE_ROLE_KEY') ?? ''
    )

    const { event_type, data, user_id } = await req.json()

    console.log('Processing webhook event:', event_type, 'for user:', user_id)

    // Buscar configurações de webhook do usuário
    const { data: webhookConfigs, error: configError } = await supabase
      .from('webhook_configs')
      .select('*')
      .eq('user_id', user_id)
      .eq('is_active', true)

    if (configError) {
      console.error('Error fetching webhook configs:', configError)
      return new Response(
        JSON.stringify({ error: 'Failed to fetch webhook configs' }),
        { status: 500, headers: corsHeaders }
      )
    }

    if (!webhookConfigs || webhookConfigs.length === 0) {
      console.log('No active webhook configs found for user:', user_id)
      return new Response(
        JSON.stringify({ message: 'No active webhooks configured' }),
        { status: 200, headers: corsHeaders }
      )
    }

    // Processar cada configuração de webhook
    for (const config of webhookConfigs) {
      // Verificar se este evento está habilitado
      const events = config.events as Record<string, boolean>
      if (!events[event_type]) {
        console.log(`Event ${event_type} not enabled for webhook ${config.id}`)
        continue
      }

      // Preparar payload do webhook
      const webhookPayload: WebhookPayload = {
        event_type,
        data,
        timestamp: new Date().toISOString(),
        establishment_id: user_id
      }

      // Gerar assinatura HMAC
      const signature = await generateSignature(JSON.stringify(webhookPayload), config.secret_token)

      // Enviar webhook
      try {
        const response = await fetch(config.url, {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            'X-LoveMenu-Signature': signature,
            'User-Agent': 'LoveMenu-Webhook/1.0'
          },
          body: JSON.stringify(webhookPayload)
        })

        const responseBody = await response.text()
        const success = response.status >= 200 && response.status < 300

        // Registrar log do webhook
        await supabase
          .from('webhook_logs')
          .insert({
            webhook_config_id: config.id,
            event_type,
            payload: webhookPayload,
            response_status: response.status,
            response_body: responseBody.substring(0, 1000), // Limitar tamanho
            success,
            attempt_count: 1
          })

        console.log(`Webhook sent to ${config.url}, status: ${response.status}, success: ${success}`)

      } catch (error) {
        console.error('Error sending webhook:', error)
        
        // Registrar erro no log
        await supabase
          .from('webhook_logs')
          .insert({
            webhook_config_id: config.id,
            event_type,
            payload: webhookPayload,
            response_status: 0,
            response_body: error.message,
            success: false,
            attempt_count: 1
          })
      }
    }

    return new Response(
      JSON.stringify({ message: 'Webhooks processed successfully' }),
      { status: 200, headers: corsHeaders }
    )

  } catch (error) {
    console.error('Webhook processing error:', error)
    return new Response(
      JSON.stringify({ error: 'Internal server error' }),
      { status: 500, headers: corsHeaders }
    )
  }
})

async function generateSignature(payload: string, secret: string): Promise<string> {
  const encoder = new TextEncoder()
  const keyData = encoder.encode(secret)
  const messageData = encoder.encode(payload)
  
  const cryptoKey = await crypto.subtle.importKey(
    'raw',
    keyData,
    { name: 'HMAC', hash: 'SHA-256' },
    false,
    ['sign']
  )
  
  const signature = await crypto.subtle.sign('HMAC', cryptoKey, messageData)
  const hashArray = Array.from(new Uint8Array(signature))
  const hashHex = hashArray.map(b => b.toString(16).padStart(2, '0')).join('')
  
  return `sha256=${hashHex}`
}
