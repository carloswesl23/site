import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const supabase = createClient(
      Deno.env.get('SUPABASE_URL') ?? '',
      Deno.env.get('SUPABASE_SERVICE_ROLE_KEY') ?? ''
    );

    const { phone_e164, message_body, instance_id } = await req.json();

    console.log('Processando resposta do motoboy:', phone_e164, message_body);

    // Buscar motoboy pelo telefone
    const { data: courier, error: courierError } = await supabase
      .from('couriers')
      .select('*')
      .eq('phone', phone_e164)
      .single();

    if (courierError || !courier) {
      console.log('Motoboy não encontrado:', phone_e164);
      return new Response(
        JSON.stringify({ success: false, message: 'Motoboy não encontrado' }),
        { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    // Buscar atribuição pendente mais recente
    const { data: assignment, error: assignmentError } = await supabase
      .from('delivery_assignments')
      .select(`
        *,
        user_orders (*)
      `)
      .eq('courier_id', courier.id)
      .eq('status', 'pending')
      .order('created_at', { ascending: false })
      .limit(1)
      .single();

    if (assignmentError || !assignment) {
      console.log('Nenhuma atribuição pendente encontrada para:', courier.name);
      return new Response(
        JSON.stringify({ success: false, message: 'Nenhuma entrega pendente' }),
        { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    const order = assignment.user_orders;
    const response = message_body.trim();

    if (response === '1') {
      // ACEITAR ENTREGA
      console.log(`Motoboy ${courier.name} aceitou entrega #${order.order_number}`);

      // Atualizar atribuição
      const { error: updateError } = await supabase
        .from('delivery_assignments')
        .update({ 
          status: 'accepted',
          accepted_at: new Date().toISOString()
        })
        .eq('id', assignment.id);

      if (updateError) {
        throw new Error('Erro ao atualizar atribuição');
      }

      // Atualizar pedido para "Em entrega"
      const { error: orderUpdateError } = await supabase
        .from('user_orders')
        .update({ status: 'out_for_delivery' })
        .eq('id', order.id);

      if (orderUpdateError) {
        throw new Error('Erro ao atualizar pedido');
      }

      // Log timeline
      await supabase
        .from('order_timeline')
        .insert({
          order_id: order.id,
          user_id: order.user_id,
          event_type: 'courier_accepted',
          event_data: {
            courier_id: courier.id,
            courier_name: courier.name,
            accepted_at: new Date().toISOString()
          }
        });

      // Buscar instância WhatsApp do estabelecimento
      const { data: instance } = await supabase
        .from('whatsapp_instances')
        .select('instance_id, token_instance')
        .eq('user_id', order.user_id)
        .eq('status', 'connected')
        .single();

      if (instance) {
        // Notificar cliente que entrega está a caminho
        const customerMessage = `🚚 Seu pedido *#${order.order_number}* está a caminho!
        
Entregador: ${courier.name}
Estimativa: 30-45 minutos

Qualquer dúvida, estamos aqui! 😊`;

        const customerPhone = order.customer_phone.replace(/\D/g, '');
        const formattedCustomerPhone = customerPhone.startsWith('55') ? customerPhone : `55${customerPhone}`;

        try {
          const zapiUrl = `${Deno.env.get('ZAPI_BASE_URL')}/instances/${instance.instance_id}/token/${instance.token_instance}/send-text`;
          
          await fetch(zapiUrl, {
            method: 'POST',
            headers: {
              'Content-Type': 'application/json',
              'Client-Token': Deno.env.get('ZAPI_CLIENT_TOKEN') ?? ''
            },
            body: JSON.stringify({
              phone: formattedCustomerPhone,
              message: customerMessage,
              messageId: `customer_delivery_accepted_${order.order_number}_${Date.now()}`
            })
          });

          // Log timeline WhatsApp
          await supabase
            .from('order_timeline')
            .insert({
              order_id: order.id,
              user_id: order.user_id,
              event_type: 'customer_notified_delivery',
              event_data: {
                customer_phone: order.customer_phone,
                courier_name: courier.name,
                message_sent: true
              }
            });

        } catch (error) {
          console.error('Erro ao notificar cliente:', error);
        }

        // Confirmar aceite ao motoboy
        const confirmMessage = `✅ *Entrega confirmada!*

Pedido #${order.order_number} foi atribuído a você.
Cliente já foi notificado que a entrega está a caminho.

Boa entrega! 🚀`;

        try {
          const courierPhone = courier.phone.replace(/\D/g, '');
          const formattedCourierPhone = courierPhone.startsWith('55') ? courierPhone : `55${courierPhone}`;

          const zapiUrl = `${Deno.env.get('ZAPI_BASE_URL')}/instances/${instance.instance_id}/token/${instance.token_instance}/send-text`;
          
          await fetch(zapiUrl, {
            method: 'POST',
            headers: {
              'Content-Type': 'application/json',
              'Client-Token': Deno.env.get('ZAPI_CLIENT_TOKEN') ?? ''
            },
            body: JSON.stringify({
              phone: formattedCourierPhone,
              message: confirmMessage,
              messageId: `courier_confirm_${order.order_number}_${Date.now()}`
            })
          });

        } catch (error) {
          console.error('Erro ao confirmar aceite ao motoboy:', error);
        }
      }

    } else if (response === '2') {
      // RECUSAR ENTREGA
      console.log(`Motoboy ${courier.name} recusou entrega #${order.order_number}`);

      // Atualizar atribuição como rejeitada
      const { error: rejectError } = await supabase
        .from('delivery_assignments')
        .update({ 
          status: 'rejected',
          attempts: assignment.attempts + 1
        })
        .eq('id', assignment.id);

      if (rejectError) {
        throw new Error('Erro ao atualizar atribuição rejeitada');
      }

      // Log timeline
      await supabase
        .from('order_timeline')
        .insert({
          order_id: order.id,
          user_id: order.user_id,
          event_type: 'courier_rejected',
          event_data: {
            courier_id: courier.id,
            courier_name: courier.name,
            rejected_at: new Date().toISOString()
          }
        });

      // Buscar próximo motoboy disponível para rodízio
      const { data: nextCouriers } = await supabase
        .from('couriers')
        .select('*')
        .eq('user_id', order.user_id)
        .eq('is_available', true)
        .neq('id', courier.id) // Excluir o que recusou
        .order('created_at', { ascending: true });

      if (nextCouriers && nextCouriers.length > 0) {
        // Dispara para próximo motoboy
        try {
          await supabase.functions.invoke('auto-delivery-assignment', {
            body: {
              order_id: order.id,
              user_id: order.user_id,
              excluded_courier_ids: [courier.id]
            }
          });
        } catch (error) {
          console.error('Erro ao reatribuir entrega:', error);
        }
      } else {
        // Nenhum motoboy disponível - notificar estabelecimento
        console.log('Nenhum motoboy disponível para pedido', order.order_number);
        
        await supabase
          .from('order_timeline')
          .insert({
            order_id: order.id,
            user_id: order.user_id,
            event_type: 'no_courier_available',
            event_data: {
              rejected_by: courier.id,
              message: 'Nenhum motoboy disponível para entrega'
            }
          });
      }
    } else {
      // Resposta inválida
      console.log('Resposta inválida do motoboy:', response);
      return new Response(
        JSON.stringify({ success: false, message: 'Resposta inválida' }),
        { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    return new Response(
      JSON.stringify({ 
        success: true, 
        message: 'Resposta processada com sucesso'
      }),
      { 
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        status: 200 
      }
    );

  } catch (error) {
    console.error('Erro ao processar resposta do motoboy:', error);
    
    return new Response(
      JSON.stringify({ 
        success: false, 
        error: error.message || 'Erro interno do servidor' 
      }),
      { 
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        status: 500 
      }
    );
  }
});