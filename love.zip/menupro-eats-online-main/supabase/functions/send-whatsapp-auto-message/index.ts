import { serve } from "https://deno.land/std@0.190.0/http/server.ts";
import { createClient } from 'https://esm.sh/@supabase/supabase-js@2';

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

interface WhatsAppMessageRequest {
  user_id: string;
  order_id: string;
  message_type: 'new_order' | 'pix' | 'payment_confirmed' | 'out_for_delivery';
  phone_number: string;
  order_data: any;
}

serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response('ok', { headers: corsHeaders });
  }

  try {
    const supabaseClient = createClient(
      Deno.env.get('SUPABASE_URL') ?? '',
      Deno.env.get('SUPABASE_SERVICE_ROLE_KEY') ?? ''
    );

    const { user_id, order_id, message_type, phone_number, order_data }: WhatsAppMessageRequest = await req.json();

    console.log('Processando mensagem automática:', { user_id, order_id, message_type, phone_number });

    // Buscar configurações de mensagem do usuário
    const { data: config, error: configError } = await supabaseClient
      .from('whatsapp_message_configs')
      .select('*')
      .eq('user_id', user_id)
      .single();

    if (configError || !config) {
      console.log('Configurações não encontradas:', configError);
      return new Response(JSON.stringify({ 
        success: false, 
        message: 'Configurações de WhatsApp não encontradas' 
      }), {
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        status: 200,
      });
    }

    // Verificar se mensagens automáticas estão ativadas
    if (!config.auto_messages_enabled) {
      console.log('Mensagens automáticas desativadas');
      return new Response(JSON.stringify({ 
        success: false, 
        message: 'Mensagens automáticas desativadas' 
      }), {
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        status: 200,
      });
    }

    // Buscar instância ativa do WhatsApp
    const { data: instance, error: instanceError } = await supabaseClient
      .from('whatsapp_instances')
      .select('instance_id, token_instance, status')
      .eq('user_id', user_id)
      .eq('status', 'connected')
      .order('updated_at', { ascending: false })
      .limit(1)
      .single();

    if (instanceError || !instance) {
      console.log('Instância WhatsApp não encontrada ou não conectada:', instanceError);
      return new Response(JSON.stringify({ 
        success: false, 
        message: 'WhatsApp não conectado' 
      }), {
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        status: 200,
      });
    }

    // Buscar dados do estabelecimento
    const { data: establishment, error: establishmentError } = await supabaseClient
      .from('establishment_settings')
      .select('business_name, pix_key, pix_beneficiary_name')
      .eq('user_id', user_id)
      .single();

    if (establishmentError || !establishment) {
      console.log('Estabelecimento não encontrado:', establishmentError);
      return new Response(JSON.stringify({ 
        success: false, 
        message: 'Estabelecimento não encontrado' 
      }), {
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        status: 200,
      });
    }

    // Selecionar template baseado no tipo de mensagem
    let template = '';
    let enabled = false;

    switch (message_type) {
      case 'new_order':
        template = config.new_order_template;
        enabled = config.new_order_enabled;
        break;
      case 'pix':
        template = config.pix_message_template;
        enabled = config.pix_message_enabled;
        break;
      case 'payment_confirmed':
        template = config.payment_confirmed_template;
        enabled = config.payment_confirmed_enabled;
        break;
      case 'out_for_delivery':
        template = config.out_for_delivery_template;
        enabled = config.out_for_delivery_enabled;
        break;
    }

    if (!enabled) {
      console.log(`Mensagem ${message_type} desativada`);
      return new Response(JSON.stringify({ 
        success: false, 
        message: `Mensagem ${message_type} desativada` 
      }), {
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        status: 200,
      });
    }

    // Processar template com dados do pedido
    const processedMessage = processTemplate(template, order_data, config, establishment);

    console.log('Mensagem processada:', processedMessage);

    // Criar log da mensagem
    const { data: logData, error: logError } = await supabaseClient
      .from('whatsapp_message_logs')
      .insert({
        user_id,
        order_id,
        message_type,
        phone_number: phone_number,
        message_content: processedMessage,
        status: 'pending'
      })
      .select()
      .single();

    if (logError) {
      console.error('Erro ao criar log:', logError);
    }

    // Enviar mensagem via Z-API
    console.log('Enviando mensagem WhatsApp via Z-API para:', phone_number);
    
    const success = await sendMessageViaZAPI(
      instance.instance_id,
      instance.token_instance,
      phone_number,
      processedMessage
    );

    if (success) {
      // Atualizar log como enviado
      if (logData) {
        await supabaseClient
          .from('whatsapp_message_logs')
          .update({ status: 'sent' })
          .eq('id', logData.id);
      }

      console.log('Mensagem enviada com sucesso');
      return new Response(JSON.stringify({ 
        success: true, 
        message: 'Mensagem enviada com sucesso',
        content: processedMessage 
      }), {
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        status: 200,
      });
    } else {
      // Atualizar log como falhado
      if (logData) {
        await supabaseClient
          .from('whatsapp_message_logs')
          .update({ status: 'failed' })
          .eq('id', logData.id);
      }

      throw new Error('Falha no envio da mensagem');
    }

  } catch (error) {
    console.error('Erro:', error);
    return new Response(JSON.stringify({ 
      success: false,
      error: error.message 
    }), {
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      status: 500,
    });
  }
});

async function sendMessageViaZAPI(instanceId: string, token: string, phoneNumber: string, message: string): Promise<boolean> {
  try {
    // Garantir que o número está no formato correto (sem símbolos, só números)
    const cleanPhone = phoneNumber.replace(/\D/g, '');
    
    // URL da Z-API para envio de mensagens
    const apiUrl = `https://api.z-api.io/instances/${instanceId}/token/${token}/send-text`;
    
    console.log('Enviando para Z-API:', apiUrl);
    console.log('Telefone:', cleanPhone);
    
    const response = await fetch(apiUrl, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Client-Token': Deno.env.get('ZAPI_CLIENT_TOKEN') ?? ''
      },
      body: JSON.stringify({
        phone: cleanPhone.startsWith('55') ? cleanPhone : `55${cleanPhone}`,
        message: message
      })
    });

    if (!response.ok) {
      const errorData = await response.text();
      console.error('Erro da Z-API:', response.status, errorData);
      return false;
    }

    const result = await response.json();
    console.log('Resposta da Z-API:', result);

    // Verificar se a Z-API retornou sucesso
    if (result && result.error) {
      console.error('Erro na resposta da Z-API:', result);
      return false;
    }

    console.log('Mensagem enviada com sucesso via Z-API');
    return true;
    
  } catch (error) {
    console.error('Erro ao enviar mensagem via Z-API:', error);
    return false;
  }
}

function processTemplate(template: string, orderData: any, config: any, establishment: any): string {
  let processed = template;

  // Dados do estabelecimento
  const businessName = establishment.business_name || orderData.establishment_name || 'Estabelecimento';
  
  // Substituir variáveis com dados do pedido
  const variables = {
    nome_da_loja: businessName,
    codigo_do_pedido: orderData.order_number || '',
    nome_do_cliente: orderData.customer_name || '',
    telefone: orderData.customer_phone || '',
    rua: orderData.address?.street || '',
    numero: orderData.address?.number || '',
    bairro: orderData.address?.neighborhood || '',
    cidade: orderData.address?.city || '',
    cep: orderData.address?.zipCode || '',
    itens_do_pedido: formatOrderItems(orderData.items || []),
    subtotal: (orderData.subtotal || 0).toFixed(2),
    taxa_entrega: (orderData.delivery_fee || 0).toFixed(2),
    total: (orderData.total || 0).toFixed(2),
    metodo_pagamento: formatPaymentMethod(orderData.payment_method || ''),
    chave_pix: establishment.pix_key || orderData.pix_key || '',
    nome_beneficiario: establishment.pix_beneficiary_name || orderData.pix_beneficiary_name || '',
    tempo_estimado: config.estimated_delivery_time || '30-45 minutos'
  };

  // Substituir todas as variáveis no template
  Object.entries(variables).forEach(([key, value]) => {
    const regex = new RegExp(`{${key}}`, 'g');
    processed = processed.replace(regex, String(value));
  });

  return processed;
}

function formatOrderItems(items: any[]): string {
  return items.map((item, index) => {
    let itemText = `${index + 1}. ${item.quantity}x ${item.product_name || item.name}`;
    
    if (item.customizations) {
      // Adicionar customizações se existirem
      if (item.customizations.notes) {
        itemText += `\n   • Obs: ${item.customizations.notes}`;
      }
    }
    
    const price = item.totalPrice || item.price || 0;
    itemText += `\n   💰 R$ ${price.toFixed(2)}`;
    
    return itemText;
  }).join('\n\n');
}

function formatPaymentMethod(method: string): string {
  const methods: { [key: string]: string } = {
    'pix': 'PIX',
    'cash': 'Dinheiro',
    'card': 'Cartão',
    'whatsapp': 'Combinar pelo WhatsApp'
  };
  
  return methods[method] || method;
}