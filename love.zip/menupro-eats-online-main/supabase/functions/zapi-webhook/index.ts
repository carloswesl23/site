import { serve } from "https://deno.land/std@0.190.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

const supabase = createClient(
  Deno.env.get('SUPABASE_URL') ?? '',
  Deno.env.get('SUPABASE_SERVICE_ROLE_KEY') ?? ''
);

interface WebhookPayload {
  event?: string;
  data?: any;
  instance?: {
    id: string;
    status?: string;
    phone?: string;
  };
  phone?: {
    waId?: string;
    number?: string;
  };
  status?: string;
  connected?: boolean;
  disconnected?: boolean;
}

const handler = async (req: Request): Promise<Response> => {
  // Handle CORS preflight requests
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const url = new URL(req.url);
    const userId = url.searchParams.get('userId');
    const type = url.searchParams.get('type'); // message, status, connect, disconnect
    
    console.log('=== Z-API Webhook Received ===');
    console.log('User ID:', userId);
    console.log('Type:', type);
    console.log('Method:', req.method);

    if (!userId) {
      console.error('User ID not provided in webhook');
      return new Response(
        JSON.stringify({ error: 'User ID required' }),
        { status: 400, headers: { 'Content-Type': 'application/json', ...corsHeaders } }
      );
    }

    const payload: WebhookPayload = await req.json();
    console.log('Webhook payload:', JSON.stringify(payload, null, 2));

    // Handle different webhook types
    switch (type) {
      case 'connect': {
        console.log('Processing connection webhook...');
        
        const instanceId = payload.instance?.id;
        if (!instanceId) {
          console.error('Instance ID not found in connect webhook');
          break;
        }

        // Atualizar status da instância para conectado
        const updateData: any = {
          status: 'connected',
          qr_code: null, // Limpar QR code quando conectado
          updated_at: new Date().toISOString()
        };

        // Se temos informações do telefone, adicionar
        if (payload.phone?.waId || payload.phone?.number) {
          updateData.numero_cliente = payload.phone.waId || payload.phone.number;
        }

        const { error: updateError } = await supabase
          .from('whatsapp_instances')
          .update(updateData)
          .eq('instance_id', instanceId)
          .eq('user_id', userId);

        if (updateError) {
          console.error('Error updating instance on connect:', updateError);
        } else {
          console.log('Instance marked as connected successfully');
        }
        
        break;
      }

      case 'disconnect': {
        console.log('Processing disconnection webhook...');
        
        const instanceId = payload.instance?.id;
        if (!instanceId) {
          console.error('Instance ID not found in disconnect webhook');
          break;
        }

        // Atualizar status da instância para desconectado
        const { error: updateError } = await supabase
          .from('whatsapp_instances')
          .update({
            status: 'disconnected',
            qr_code: null,
            numero_cliente: null,
            updated_at: new Date().toISOString()
          })
          .eq('instance_id', instanceId)
          .eq('user_id', userId);

        if (updateError) {
          console.error('Error updating instance on disconnect:', updateError);
        } else {
          console.log('Instance marked as disconnected successfully');
        }
        
        break;
      }

      case 'status': {
        console.log('Processing status webhook...');
        
        const instanceId = payload.instance?.id;
        if (!instanceId) {
          console.error('Instance ID not found in status webhook');
          break;
        }

        // Determinar o status baseado no payload
        let newStatus = 'disconnected';
        const updateData: any = {
          updated_at: new Date().toISOString()
        };

        if (payload.connected === true || payload.status === 'connected') {
          newStatus = 'connected';
          updateData.qr_code = null;
          
          if (payload.phone?.waId || payload.phone?.number) {
            updateData.numero_cliente = payload.phone.waId || payload.phone.number;
          }
        } else if (payload.disconnected === true || payload.status === 'disconnected') {
          newStatus = 'disconnected';
          updateData.qr_code = null;
          updateData.numero_cliente = null;
        } else if (payload.status === 'qrcode' || payload.status === 'QRCODE') {
          newStatus = 'qrcode';
        } else if (payload.status === 'waiting_phone' || payload.status === 'WAITING_PHONE') {
          newStatus = 'waiting_phone';
        } else if (payload.status === 'initializing' || payload.status === 'INITIALIZING') {
          newStatus = 'initializing';
        }

        updateData.status = newStatus;

        const { error: updateError } = await supabase
          .from('whatsapp_instances')
          .update(updateData)
          .eq('instance_id', instanceId)
          .eq('user_id', userId);

        if (updateError) {
          console.error('Error updating instance status:', updateError);
        } else {
          console.log(`Instance status updated to: ${newStatus}`);
        }
        
        break;
      }

      case 'message': {
        console.log('Processing message webhook...');
        await processIncomingMessage(payload, userId);
        break;
      }

      default: {
        // Webhook genérico - tentar processar como status ou mensagem
        console.log('Processing generic webhook...');
        
        // Verificar se é uma mensagem recebida - melhorar detecção
        const message = payload.data || payload;
        const hasMessageContent = message && (
          message.body || message.text || message.message || 
          message.caption || message.messageBody ||
          (message.text && message.text.message)
        );
        const hasFromInfo = message && (
          message.from || message.phone || message.chatId || 
          message.instanceId || message.participantPhone
        );
        
        if (hasMessageContent && hasFromInfo) {
          console.log('Detected incoming message in generic webhook');
          await processIncomingMessage(payload, userId);
          break;
        }
        
        // Se não for mensagem, processar como status
        if (payload.instance?.id) {
          const instanceId = payload.instance.id;
          
          let newStatus = 'disconnected';
          const updateData: any = {
            updated_at: new Date().toISOString()
          };

          if (payload.connected === true) {
            newStatus = 'connected';
            updateData.qr_code = null;
            
            if (payload.phone?.waId || payload.phone?.number) {
              updateData.numero_cliente = payload.phone.waId || payload.phone.number;
            }
          } else if (payload.disconnected === true) {
            newStatus = 'disconnected';
            updateData.qr_code = null;
            updateData.numero_cliente = null;
          }

          updateData.status = newStatus;

          const { error: updateError } = await supabase
            .from('whatsapp_instances')
            .update(updateData)
            .eq('instance_id', instanceId)
            .eq('user_id', userId);

          if (updateError) {
            console.error('Error updating instance in generic webhook:', updateError);
          } else {
            console.log(`Instance updated via generic webhook: ${newStatus}`);
          }
        }
        break;
      }
    }

    return new Response(
      JSON.stringify({ success: true, received: true }),
      { status: 200, headers: { 'Content-Type': 'application/json', ...corsHeaders } }
    );

  } catch (error) {
    console.error('Webhook error:', error);
    return new Response(
      JSON.stringify({ error: 'Internal server error', details: error.message }),
      { status: 500, headers: { 'Content-Type': 'application/json', ...corsHeaders } }
    );
  }
};

async function processIncomingMessage(payload: any, userId: string) {
  try {
    console.log('Processing incoming message:', JSON.stringify(payload, null, 2));
    
    // O payload da Z-API pode vir em diferentes formatos
    let message = payload.data || payload;
    
    // Se ainda não temos o formato correto, verificar se é o payload direto
    if (!message.from && !message.phone && !message.chatId && payload.from) {
      message = payload;
    }
    
    console.log('Extracted message:', JSON.stringify(message, null, 2));
    
    // Extrair dados da mensagem de acordo com a documentação Z-API
    // Para mensagens de grupo, usar participantPhone em vez do phone (que é o ID do grupo)
    let phoneE164;
    if (message.isGroup && message.participantPhone) {
      phoneE164 = message.participantPhone; // Telefone real do participante em grupos
    } else {
      phoneE164 = message.from || message.phone || message.chatId || message.instanceId;
    }
    
    let messageBody = message.body || message.text || message.caption || message.message || '';
    let mediaUrl = message.mediaUrl || message.url || message.media || null;
    let messageId = message.id || message.messageId || message.messageID || null;
    let senderName = message.pushName || message.name || message.senderName || message.notifyName || null;
    
    console.log('Parsed message details:', {
      phoneE164,
      messageBody,
      mediaUrl,
      messageId,
      senderName
    });

    // Normalizar phone number para E164
    if (phoneE164 && !phoneE164.startsWith('+')) {
      // Se não tem + e começa com 55, adicionar +
      if (phoneE164.startsWith('55')) {
        phoneE164 = '+' + phoneE164;
      } else {
        // Se não começa com 55, assumir que é BR e adicionar +55
        phoneE164 = '+55' + phoneE164;
      }
    }

    if (!phoneE164) {
      console.error('Phone number not found in message payload');
      return;
    }

    // Detectar se é mensagem recebida (IN) ou enviada (OUT)
    const isIncoming = message.fromMe === false || 
                      message.direction === 'in' || 
                      message.direction === 'IN' ||
                      (!message.fromMe && !message.direction); // Assume incoming se não especificado

    const direction = isIncoming ? 'in' : 'out';
    const status = isIncoming ? 'received' : 'sent';

    // Salvar mensagem
    const messageData = {
      user_id: userId,
      phone_e164: phoneE164,
      direction: direction,
      type: message.type || 'text',
      body: messageBody,
      media_url: mediaUrl,
      status: status,
      zapi_msg_id: messageId,
      created_at: new Date().toISOString()
    };

    console.log('Saving message with data:', messageData);

    const { data: savedMessage, error: messageError } = await supabase
      .from('wa_messages')
      .insert(messageData)
      .select()
      .single();

    if (messageError) {
      console.error('Error saving message:', messageError);
      return;
    } else {
      console.log('Message saved successfully:', savedMessage);
    }

    // Atualizar ou criar contato apenas para mensagens recebidas
    if (isIncoming) {
      const contactData = {
        user_id: userId,
        phone_e164: phoneE164,
        name: senderName || phoneE164,
        last_interaction_at: new Date().toISOString()
      };

      console.log('Updating/creating contact:', contactData);

      const { error: contactError } = await supabase
        .from('contacts')
        .upsert(contactData, { 
          onConflict: 'user_id,phone_e164',
          ignoreDuplicates: false
        });

      if (contactError) {
        console.error('Error updating contact:', contactError);
      } else {
        console.log('Contact updated successfully');
      }
    }

  } catch (error) {
    console.error('Error processing incoming message:', error);
  }
}

serve(handler);