import { serve } from "https://deno.land/std@0.190.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

const supabase = createClient(
  Deno.env.get('SUPABASE_URL') ?? '',
  Deno.env.get('SUPABASE_SERVICE_ROLE_KEY') ?? ''
);

interface ResolveRequest {
  slug?: string;
}

const handler = async (req: Request): Promise<Response> => {
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const { slug }: ResolveRequest = await req.json().catch(() => ({ slug: undefined }));
    const url = new URL(req.url);
    const slugParam = slug || url.searchParams.get('slug') || '';

    if (!slugParam) {
      return new Response(
        JSON.stringify({ error: 'slug é obrigatório' }),
        { status: 400, headers: { 'Content-Type': 'application/json', ...corsHeaders } }
      );
    }

    // Encontrar o estabelecimento pelo slug
    const { data: est, error: estError } = await supabase
      .from('establishment_settings')
      .select('user_id, business_name, business_phone')
      .eq('online_menu_slug', slugParam)
      .maybeSingle();

    if (estError || !est) {
      return new Response(
        JSON.stringify({ error: 'Estabelecimento não encontrado para o slug informado.' }),
        { status: 404, headers: { 'Content-Type': 'application/json', ...corsHeaders } }
      );
    }

    const userId = est.user_id as string;

    // Buscar uma instância existente (mais recente)
    const { data: instance, error: instError } = await supabase
      .from('whatsapp_instances')
      .select('id, instance_id, status')
      .eq('user_id', userId)
      .order('created_at', { ascending: false })
      .limit(1)
      .maybeSingle();

    if (!instError && instance && instance.instance_id) {
      return new Response(
        JSON.stringify({ userId, instanceId: instance.instance_id, dbId: instance.id, status: instance.status }),
        { status: 200, headers: { 'Content-Type': 'application/json', ...corsHeaders } }
      );
    }

    // Nenhuma instância: criar uma nova via função existente
    const instanceName = `${slugParam}-${Date.now().toString().slice(-6)}`;
    const phoneNumber = (est.business_phone && est.business_phone.trim() !== '') ? est.business_phone : '0000000000';

    const { data: created, error: createErr } = await supabase.functions.invoke('criar-instancia-zapi', {
      body: {
        instanceName,
        phoneNumber,
        userId
      }
    });

    if (createErr || !created) {
      return new Response(
        JSON.stringify({ error: 'Falha ao criar instância', details: createErr?.message || created?.error }),
        { status: 500, headers: { 'Content-Type': 'application/json', ...corsHeaders } }
      );
    }

    // criar-instancia-zapi retorna: { success, instance, instanceId, qrCode, ... }
    const result = created as any;
    const zapiId = result.instanceId || result.instance?.instance_id;
    const dbId = result.instance?.id;

    return new Response(
      JSON.stringify({ userId, instanceId: zapiId, dbId, status: result.instance?.status || 'initializing', qrCode: result.qrCode || null }),
      { status: 200, headers: { 'Content-Type': 'application/json', ...corsHeaders } }
    );
  } catch (error: any) {
    return new Response(
      JSON.stringify({ error: 'Erro interno', details: error.message }),
      { status: 500, headers: { 'Content-Type': 'application/json', ...corsHeaders } }
    );
  }
};

serve(handler);
