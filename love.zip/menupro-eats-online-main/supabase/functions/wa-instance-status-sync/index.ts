import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

const SUPABASE_URL = Deno.env.get("SUPABASE_URL")!;
const SUPABASE_SERVICE_ROLE = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
const sb = createClient(SUPABASE_URL, SUPABASE_SERVICE_ROLE);

// Mapeamento de status que a UI espera
function mapStatus(z: any): "connected" | "disconnected" | "qrcode" | "expired" {
  console.log("Z-API Response:", JSON.stringify(z, null, 2));
  
  // Exemplo de payload Z-API:
  // { connected: true, me: { id: "...", pushName: "...", wid: "5541999999999@whatsapp.net" }, ... }
  if (z?.connected === true) return "connected";
  
  // Alguns retornos durante pareamento:
  if (z?.qrcode === true || z?.pairing === true) return "qrcode";
  if (z?.expired === true) return "expired";
  
  return "disconnected";
}

serve(async (req) => {
  // Handle CORS preflight requests
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const { userId, tenantId } = await req.json().catch(() => ({}));
    
    if (!userId && !tenantId) {
      return new Response(JSON.stringify({ error: "userId or tenantId required" }), { 
        status: 400,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' }
      });
    }

    console.log("Syncing status for:", { userId, tenantId });

    // Pegue credenciais da instância do tenant/user
    let query = sb
      .from("whatsapp_instances")
      .select("id, instance_id, token_instance, user_id, tenant_id");

    if (tenantId) {
      query = query.eq("tenant_id", tenantId);
    } else {
      query = query.eq("user_id", userId);
    }

    const { data: inst, error: e1 } = await query
      .order("updated_at", { ascending: false })
      .limit(1)
      .maybeSingle();

    if (e1) {
      console.error("Database error:", e1);
      return new Response(JSON.stringify({ error: "Database error", details: e1.message }), { 
        status: 500,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' }
      });
    }

    if (!inst) {
      console.log("No instance found for:", { userId, tenantId });
      return new Response(JSON.stringify({ error: "instance not found" }), { 
        status: 404,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' }
      });
    }

    if (!inst.instance_id || !inst.token_instance) {
      console.log("Instance missing credentials:", inst);
      return new Response(JSON.stringify({ error: "instance credentials incomplete" }), { 
        status: 400,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' }
      });
    }

    console.log("Checking Z-API status for instance:", inst.instance_id);

    const url = `https://api.z-api.io/instances/${inst.instance_id}/token/${inst.token_instance}/status`;
    const zres = await fetch(url, { 
      method: "GET",
      headers: {
        'Content-Type': 'application/json'
      }
    });

    if (!zres.ok) {
      console.error("Z-API error:", zres.status, await zres.text());
      return new Response(JSON.stringify({ 
        error: "Z-API request failed", 
        status: zres.status 
      }), { 
        status: 502,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' }
      });
    }

    const zjson = await zres.json();
    console.log("Z-API Response:", zjson);

    const status = mapStatus(zjson);
    const numero = zjson?.me?.wid?.replace("@whatsapp.net", "") ?? null;

    const patch: any = {
      status,
      updated_at: new Date().toISOString(),
    };

    if (status === "connected") {
      patch.qr_code = null;
      if (numero) patch.numero_cliente = numero;
    }

    console.log("Updating instance with:", patch);

    const { error: e2 } = await sb
      .from("whatsapp_instances")
      .update(patch)
      .eq("id", inst.id);

    if (e2) {
      console.error("Update error:", e2);
      throw e2;
    }

    console.log("Status sync completed successfully:", { status, numero });

    return new Response(JSON.stringify({ 
      success: true,
      status, 
      numero_cliente: numero,
      raw: zjson 
    }), { 
      status: 200,
      headers: { ...corsHeaders, 'Content-Type': 'application/json' }
    });

  } catch (err) {
    console.error("Sync error:", err);
    return new Response(JSON.stringify({ 
      error: String(err),
      message: "Failed to sync WhatsApp instance status"
    }), { 
      status: 500,
      headers: { ...corsHeaders, 'Content-Type': 'application/json' }
    });
  }
});