import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

serve(async (req) => {
  // Handle CORS preflight requests
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const supabase = createClient(
      Deno.env.get('SUPABASE_URL') ?? '',
      Deno.env.get('SUPABASE_SERVICE_ROLE_KEY') ?? ''
    );

    const { 
      customer_phone, 
      order_number, 
      driver_name,
      instance_id,
      token_instance 
    } = await req.json();

    console.log('Enviando notificação de entrega para cliente:', customer_phone);

    // Criar mensagem de notificação para o cliente
    const message = `🚚 *Seu pedido saiu para entrega!*

📋 *Pedido:* #${order_number}
🚴 *Entregador:* ${driver_name}

Seu pedido está a caminho! 
Obrigado por escolher nossa loja! 🍔`;

    // Enviar via Z-API
    const zapiUrl = `${Deno.env.get('ZAPI_BASE_URL')}/instances/${instance_id}/token/${token_instance}/send-text`;
    
    const zapiResponse = await fetch(zapiUrl, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Client-Token': Deno.env.get('ZAPI_CLIENT_TOKEN') ?? ''
      },
      body: JSON.stringify({
        phone: customer_phone.replace('+', ''),
        message: message,
        messageId: `delivery_customer_${order_number}_${Date.now()}`
      })
    });

    const zapiResult = await zapiResponse.json();
    console.log('Resposta Z-API:', zapiResult);

    if (!zapiResponse.ok || !zapiResult.success) {
      throw new Error(`Falha no envio Z-API: ${zapiResult.error || 'Erro desconhecido'}`);
    }

    // Log da notificação enviada
    const { error: logError } = await supabase
      .from('whatsapp_message_logs')
      .insert({
        user_id: req.headers.get('user-id'),
        order_id: req.headers.get('order-id'),
        message_type: 'customer_delivery_notification',
        phone_number: customer_phone,
        message_content: message,
        status: 'sent',
        whatsapp_message_id: zapiResult.messageId
      });

    if (logError) {
      console.error('Erro ao salvar log:', logError);
    }

    return new Response(
      JSON.stringify({ 
        success: true, 
        message: 'Notificação enviada com sucesso',
        zapiMessageId: zapiResult.messageId 
      }),
      { 
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        status: 200 
      }
    );

  } catch (error) {
    console.error('Erro ao enviar notificação para cliente:', error);
    
    return new Response(
      JSON.stringify({ 
        success: false, 
        error: error.message || 'Erro interno do servidor' 
      }),
      { 
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        status: 500 
      }
    );
  }
});