-- Adicionar colunas de presença na tabela contacts
ALTER TABLE public.contacts 
ADD COLUMN IF NOT EXISTS presence_status TEXT DEFAULT 'unavailable',
ADD COLUMN IF NOT EXISTS last_seen_at TIMESTAMP WITH TIME ZONE;