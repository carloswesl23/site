-- Adicionar campos para filtros de aplicação de cupons
ALTER TABLE discount_coupons 
ADD COLUMN applies_to_type text DEFAULT 'all' CHECK (applies_to_type IN ('all', 'categories', 'products')),
ADD COLUMN applies_to_categories text[] DEFAULT '{}',
ADD COLUMN applies_to_products uuid[] DEFAULT '{}';