-- Remover tabelas do WhatsApp 2.0 (WA Service) para evitar confusão
-- Mantendo apenas as tabelas da implementação Z-API que está funcionando

-- Primeiro, verificar se as tabelas existem antes de tentar removê-las
DROP TABLE IF EXISTS public.wa_events CASCADE;
DROP TABLE IF EXISTS public.wa_sessions CASCADE;
DROP TABLE IF EXISTS public.broadcast_recipients CASCADE;  
DROP TABLE IF EXISTS public.broadcast_jobs CASCADE;

-- Comentário: As tabelas whatsapp_instances e whatsapp_events permanecem 
-- pois são usadas pela implementação Z-API que está funcionando corretamente