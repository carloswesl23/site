
-- Criar tabela para configurações de tempo de preparo por estabelecimento
CREATE TABLE public.preparation_time_settings (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id UUID REFERENCES auth.users NOT NULL,
  default_preparation_time INTEGER NOT NULL DEFAULT 30, -- tempo em minutos
  peak_hours_start TIME, -- horário de início do pico (ex: 19:00)
  peak_hours_end TIME, -- horário de fim do pico (ex: 21:00)
  peak_hours_extra_time INTEGER DEFAULT 0, -- tempo extra em minutos durante pico
  auto_send_whatsapp BOOLEAN NOT NULL DEFAULT true,
  whatsapp_message_template TEXT DEFAULT '🍽️ Pedido confirmado! Estimamos {tempo} minutos para preparo. Em breve estará a caminho!',
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Criar tabela para tempos personalizados por categoria
CREATE TABLE public.category_preparation_times (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id UUID REFERENCES auth.users NOT NULL,
  category_name TEXT NOT NULL,
  preparation_time INTEGER NOT NULL, -- tempo em minutos
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  UNIQUE(user_id, category_name)
);

-- Criar tabela para histórico de pedidos com tempos estimados
CREATE TABLE public.order_preparation_tracking (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id UUID REFERENCES auth.users NOT NULL,
  order_number TEXT NOT NULL,
  customer_name TEXT NOT NULL,
  customer_phone TEXT NOT NULL,
  estimated_time INTEGER NOT NULL, -- tempo estimado calculado
  status TEXT NOT NULL DEFAULT 'received', -- received, preparing, ready, delivered
  whatsapp_sent BOOLEAN NOT NULL DEFAULT false,
  whatsapp_sent_at TIMESTAMP WITH TIME ZONE,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Adicionar RLS (Row Level Security) para todas as tabelas
ALTER TABLE public.preparation_time_settings ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.category_preparation_times ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.order_preparation_tracking ENABLE ROW LEVEL SECURITY;

-- Políticas RLS para preparation_time_settings
CREATE POLICY "Users can view their own preparation settings" 
  ON public.preparation_time_settings 
  FOR SELECT 
  USING (auth.uid() = user_id);

CREATE POLICY "Users can create their own preparation settings" 
  ON public.preparation_time_settings 
  FOR INSERT 
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update their own preparation settings" 
  ON public.preparation_time_settings 
  FOR UPDATE 
  USING (auth.uid() = user_id);

-- Políticas RLS para category_preparation_times
CREATE POLICY "Users can view their own category times" 
  ON public.category_preparation_times 
  FOR SELECT 
  USING (auth.uid() = user_id);

CREATE POLICY "Users can create their own category times" 
  ON public.category_preparation_times 
  FOR INSERT 
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update their own category times" 
  ON public.category_preparation_times 
  FOR UPDATE 
  USING (auth.uid() = user_id);

CREATE POLICY "Users can delete their own category times" 
  ON public.category_preparation_times 
  FOR DELETE 
  USING (auth.uid() = user_id);

-- Políticas RLS para order_preparation_tracking
CREATE POLICY "Users can view their own order tracking" 
  ON public.order_preparation_tracking 
  FOR SELECT 
  USING (auth.uid() = user_id);

CREATE POLICY "Users can create their own order tracking" 
  ON public.order_preparation_tracking 
  FOR INSERT 
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update their own order tracking" 
  ON public.order_preparation_tracking 
  FOR UPDATE 
  USING (auth.uid() = user_id);
