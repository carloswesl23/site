-- Add Mercado Pago configuration fields to establishment_settings
ALTER TABLE public.establishment_settings 
ADD COLUMN IF NOT EXISTS mp_public_key text,
ADD COLUMN IF NOT EXISTS mp_access_token text,
ADD COLUMN IF NOT EXISTS mp_webhook_url text,
ADD COLUMN IF NOT EXISTS mp_enabled boolean DEFAULT false;

-- Create table for Mercado Pago payment tracking
CREATE TABLE IF NOT EXISTS public.mercadopago_payments (
  id uuid NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id uuid NOT NULL,
  order_id uuid NOT NULL,
  mp_payment_id text NOT NULL,
  mp_external_reference text,
  status text NOT NULL DEFAULT 'pending',
  amount numeric NOT NULL,
  currency text DEFAULT 'BRL',
  payment_method text,
  created_at timestamp with time zone NOT NULL DEFAULT now(),
  updated_at timestamp with time zone NOT NULL DEFAULT now(),
  webhook_data jsonb,
  UNIQUE(mp_payment_id, user_id)
);

-- Enable RLS
ALTER TABLE public.mercadopago_payments ENABLE ROW LEVEL SECURITY;

-- Create RLS policies
CREATE POLICY "Users can view their own MP payments" 
ON public.mercadopago_payments 
FOR SELECT 
USING (auth.uid() = user_id);

CREATE POLICY "Users can create their own MP payments" 
ON public.mercadopago_payments 
FOR INSERT 
WITH CHECK (auth.uid() = user_id);

CREATE POLICY "System can update MP payments" 
ON public.mercadopago_payments 
FOR UPDATE 
USING (true);

-- Create trigger for updated_at
CREATE OR REPLACE FUNCTION public.update_mercadopago_payments_updated_at()
RETURNS trigger
LANGUAGE plpgsql
AS $function$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$function$;

CREATE TRIGGER update_mercadopago_payments_updated_at
BEFORE UPDATE ON public.mercadopago_payments
FOR EACH ROW
EXECUTE FUNCTION public.update_mercadopago_payments_updated_at();