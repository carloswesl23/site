-- Add payment configuration fields to establishment_settings table
ALTER TABLE public.establishment_settings 
ADD COLUMN accept_cash boolean DEFAULT true,
ADD COLUMN accept_credit_on_delivery boolean DEFAULT true,
ADD COLUMN combine_payment_via_whatsapp boolean DEFAULT true;