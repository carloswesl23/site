-- Criar tabela de clientes para armazenar dados únicos dos clientes de cada estabelecimento
CREATE TABLE public.user_customers (
  id uuid NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id uuid NOT NULL,
  customer_name text NOT NULL,
  customer_phone text,
  customer_email text,
  delivery_address text,
  total_orders integer NOT NULL DEFAULT 1,
  total_spent numeric NOT NULL DEFAULT 0,
  last_order_date timestamp with time zone NOT NULL DEFAULT now(),
  created_at timestamp with time zone NOT NULL DEFAULT now(),
  updated_at timestamp with time zone NOT NULL DEFAULT now(),
  
  -- Index para busca eficiente
  CONSTRAINT unique_customer_per_user UNIQUE(user_id, customer_phone, customer_email)
);

-- Enable Row Level Security
ALTER TABLE public.user_customers ENABLE ROW LEVEL SECURITY;

-- Políticas RLS para user_customers
CREATE POLICY "Users can view their own customers" 
ON public.user_customers 
FOR SELECT 
USING (auth.uid() = user_id);

CREATE POLICY "Users can create their own customers" 
ON public.user_customers 
FOR INSERT 
WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update their own customers" 
ON public.user_customers 
FOR UPDATE 
USING (auth.uid() = user_id);

CREATE POLICY "Users can delete their own customers" 
ON public.user_customers 
FOR DELETE 
USING (auth.uid() = user_id);

-- Função para atualizar updated_at automaticamente
CREATE OR REPLACE FUNCTION public.update_user_customers_updated_at()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Trigger para atualizar updated_at
CREATE TRIGGER update_user_customers_updated_at
BEFORE UPDATE ON public.user_customers
FOR EACH ROW
EXECUTE FUNCTION public.update_user_customers_updated_at();

-- Função para atualizar ou criar cliente automaticamente quando um pedido é feito
CREATE OR REPLACE FUNCTION public.upsert_customer_on_order()
RETURNS TRIGGER AS $$
BEGIN
  -- Atualizar ou inserir cliente
  INSERT INTO public.user_customers (
    user_id, 
    customer_name, 
    customer_phone, 
    customer_email, 
    delivery_address,
    total_orders,
    total_spent,
    last_order_date
  ) VALUES (
    NEW.user_id,
    NEW.customer_name,
    NEW.customer_phone,
    NEW.customer_email,
    NEW.delivery_address,
    1,
    NEW.total,
    NEW.created_at
  )
  ON CONFLICT (user_id, customer_phone, customer_email) 
  DO UPDATE SET
    customer_name = EXCLUDED.customer_name,
    delivery_address = COALESCE(EXCLUDED.delivery_address, user_customers.delivery_address),
    total_orders = user_customers.total_orders + 1,
    total_spent = user_customers.total_spent + EXCLUDED.total_spent,
    last_order_date = EXCLUDED.last_order_date,
    updated_at = now();
    
  RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Trigger para executar a função sempre que um pedido for inserido
CREATE TRIGGER upsert_customer_on_new_order
AFTER INSERT ON public.user_orders
FOR EACH ROW
EXECUTE FUNCTION public.upsert_customer_on_order();