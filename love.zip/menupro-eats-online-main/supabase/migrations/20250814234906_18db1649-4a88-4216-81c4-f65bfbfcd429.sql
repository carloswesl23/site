-- Corrigir problemas de segurança detectados

-- 1. Remover a view com SECURITY DEFINER e criar função mais segura
DROP VIEW IF EXISTS public.public_establishment_view;

-- 2. Função segura para buscar dados públicos de estabelecimento
CREATE OR REPLACE FUNCTION public.get_public_establishment_data(slug text)
 RETURNS TABLE(establishment_id uuid, business_name text, business_logo text, primary_color text, secondary_color text, mobile_layout_mode text, instagram_url text, online_menu_slug text, checkout_custom_message text)
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
BEGIN
  -- Validate slug to prevent injection
  IF NOT public.validate_establishment_slug(slug) THEN
    RAISE EXCEPTION 'Invalid establishment identifier';
  END IF;

  -- Log access for monitoring
  PERFORM public.log_security_event('ESTABLISHMENT_DATA_ACCESS', jsonb_build_object(
    'slug', slug,
    'function', 'get_public_establishment_data'
  ));
  
  RETURN QUERY
  SELECT 
    es.user_id,
    es.business_name,
    es.business_logo,
    es.primary_color,
    es.secondary_color,
    es.mobile_layout_mode,
    es.instagram_url,
    es.online_menu_slug,
    es.checkout_custom_message
  FROM public.establishment_settings es
  WHERE es.online_menu_slug = slug
    AND es.online_menu_slug IS NOT NULL;
END;
$function$;

-- 3. Corrigir search_path em funções sem
CREATE OR REPLACE FUNCTION public.update_updated_at_column()
 RETURNS trigger
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$function$;

CREATE OR REPLACE FUNCTION public.update_last_interaction()
 RETURNS trigger
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
BEGIN
  UPDATE contacts 
  SET last_interaction_at = NEW.created_at 
  WHERE user_id = NEW.user_id AND phone_e164 = NEW.phone_e164;
  RETURN NEW;
END;
$function$;

-- 4. Função específica para buscar dados de menu público de forma segura
CREATE OR REPLACE FUNCTION public.get_establishment_menu_data_secure(slug text)
 RETURNS TABLE(establishment_id uuid, business_name text, business_logo text, primary_color text, secondary_color text, mobile_layout_mode text, instagram_url text, business_phone text, checkout_custom_message text)
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
BEGIN
  -- Validate slug first
  IF NOT public.validate_establishment_slug(slug) THEN
    RAISE EXCEPTION 'Invalid establishment identifier';
  END IF;

  -- Check rate limiting for menu access
  IF NOT public.check_rate_limit(
    COALESCE(inet_client_addr()::text, 'unknown'),
    'menu_access',
    30,  -- Max 30 requests
    60   -- Per hour
  ) THEN
    RAISE EXCEPTION 'Rate limit exceeded for menu access';
  END IF;
  
  RETURN QUERY
  SELECT 
    es.user_id,
    es.business_name,
    es.business_logo,
    es.primary_color,
    es.secondary_color,
    es.mobile_layout_mode,
    es.instagram_url,
    es.business_phone,
    es.checkout_custom_message
  FROM public.establishment_settings es
  WHERE es.online_menu_slug = slug
    AND es.online_menu_slug IS NOT NULL;
END;
$function$;