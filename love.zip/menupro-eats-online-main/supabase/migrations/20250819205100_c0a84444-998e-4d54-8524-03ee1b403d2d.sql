-- Atualizar alguns pedidos para status 'preparing' para teste
UPDATE user_orders 
SET status = 'preparing' 
WHERE id IN (
  SELECT id 
  FROM user_orders 
  WHERE status = 'delivery' 
  ORDER BY created_at DESC 
  LIMIT 2
);

-- Verificar os pedidos atualizados
SELECT id, order_number, status, customer_name FROM user_orders 
WHERE status = 'preparing' 
ORDER BY created_at DESC;