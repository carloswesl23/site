
-- Criar tabela para configurações de webhooks
CREATE TABLE public.webhook_configs (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id UUID REFERENCES auth.users NOT NULL,
  url TEXT NOT NULL,
  secret_token TEXT NOT NULL,
  events JSONB NOT NULL DEFAULT '{}',
  is_active BOOLEAN NOT NULL DEFAULT true,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Criar tabela para logs de webhooks (histórico de envios)
CREATE TABLE public.webhook_logs (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  webhook_config_id UUID REFERENCES public.webhook_configs(id) ON DELETE CASCADE NOT NULL,
  event_type TEXT NOT NULL,
  payload JSONB NOT NULL,
  response_status INTEGER,
  response_body TEXT,
  attempt_count INTEGER NOT NULL DEFAULT 1,
  sent_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  success BOOLEAN NOT NULL DEFAULT false
);

-- Habilitar RLS nas tabelas
ALTER TABLE public.webhook_configs ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.webhook_logs ENABLE ROW LEVEL SECURITY;

-- Políticas RLS para webhook_configs
CREATE POLICY "Users can view their own webhook configs" 
  ON public.webhook_configs 
  FOR SELECT 
  USING (auth.uid() = user_id);

CREATE POLICY "Users can create their own webhook configs" 
  ON public.webhook_configs 
  FOR INSERT 
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update their own webhook configs" 
  ON public.webhook_configs 
  FOR UPDATE 
  USING (auth.uid() = user_id);

CREATE POLICY "Users can delete their own webhook configs" 
  ON public.webhook_configs 
  FOR DELETE 
  USING (auth.uid() = user_id);

-- Políticas RLS para webhook_logs
CREATE POLICY "Users can view webhook logs from their configs" 
  ON public.webhook_logs 
  FOR SELECT 
  USING (
    EXISTS (
      SELECT 1 FROM public.webhook_configs 
      WHERE webhook_configs.id = webhook_logs.webhook_config_id 
      AND webhook_configs.user_id = auth.uid()
    )
  );

-- Adicionar índices para performance
CREATE INDEX idx_webhook_configs_user_id ON public.webhook_configs(user_id);
CREATE INDEX idx_webhook_logs_config_id ON public.webhook_logs(webhook_config_id);
CREATE INDEX idx_webhook_logs_event_type ON public.webhook_logs(event_type);
CREATE INDEX idx_webhook_logs_sent_at ON public.webhook_logs(sent_at);
