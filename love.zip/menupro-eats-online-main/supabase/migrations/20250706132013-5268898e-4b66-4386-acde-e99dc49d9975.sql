-- Adicionar constraint única para user_id na tabela whatsapp_message_configs
ALTER TABLE public.whatsapp_message_configs 
ADD CONSTRAINT whatsapp_message_configs_user_id_unique UNIQUE (user_id);

-- Criar configurações padrão para estabelecimentos existentes que não possuem
INSERT INTO public.whatsapp_message_configs (user_id)
SELECT DISTINCT user_id 
FROM public.establishment_settings 
WHERE user_id NOT IN (SELECT user_id FROM public.whatsapp_message_configs);

-- Criar trigger para gerar configurações automaticamente para novos usuários
CREATE OR REPLACE TRIGGER create_whatsapp_config_for_new_establishment
    AFTER INSERT ON public.establishment_settings
    FOR EACH ROW
    EXECUTE FUNCTION public.create_default_whatsapp_config();