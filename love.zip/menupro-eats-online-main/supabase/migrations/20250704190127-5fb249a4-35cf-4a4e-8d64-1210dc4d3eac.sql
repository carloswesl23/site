-- Create storage bucket for establishment banners if it doesn't exist
INSERT INTO storage.buckets (id, name, public) 
VALUES ('establishment-banners', 'establishment-banners', true)
ON CONFLICT (id) DO NOTHING;