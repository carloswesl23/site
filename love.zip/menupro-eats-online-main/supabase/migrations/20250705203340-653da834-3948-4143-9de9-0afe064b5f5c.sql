-- Add allow_half_half column to user_products table
ALTER TABLE public.user_products 
ADD COLUMN allow_half_half boolean NOT NULL DEFAULT false;