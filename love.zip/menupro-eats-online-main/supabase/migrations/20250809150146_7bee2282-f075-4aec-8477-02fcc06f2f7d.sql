-- Fix security issues - Update function search paths to be secure

-- Update the existing trigger function to be secure
CREATE OR REPLACE FUNCTION update_wa_sessions_updated_at()
RETURNS TRIGGER 
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = ''
AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$;