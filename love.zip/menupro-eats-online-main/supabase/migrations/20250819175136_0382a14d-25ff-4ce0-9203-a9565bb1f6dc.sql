-- 1) Tipo enumerado para status de entrega
DO $$
BEGIN
  IF NOT EXISTS (SELECT 1 FROM pg_type WHERE typname = 'delivery_status') THEN
    CREATE TYPE delivery_status AS ENUM ('assigned', 'picked_up', 'on_route', 'delivered', 'canceled');
  END IF;
END$$;

-- 2) Motoboys (adaptando estrutura atual - usando user_id para manter compatibilidade)
CREATE TABLE IF NOT EXISTS public.motoboys (
  id            uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id       uuid NOT NULL,                       -- loja/estabelecimento
  name          text NOT NULL,
  phone_e164    text NOT NULL,                       -- ex: +55949812XXXX
  active        boolean NOT NULL DEFAULT true,
  vehicle_type  text DEFAULT 'motorcycle',
  notes         text,
  created_at    timestamptz NOT NULL DEFAULT now(),
  updated_at    timestamptz NOT NULL DEFAULT now()
);

CREATE UNIQUE INDEX IF NOT EXISTS motoboys_user_phone_uq ON public.motoboys(user_id, phone_e164);
CREATE INDEX IF NOT EXISTS motoboys_user_active_idx ON public.motoboys(user_id, active);

-- 3) Deliveries/entregas (nova tabela normalizada)
CREATE TABLE IF NOT EXISTS public.deliveries (
  id             uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id        uuid NOT NULL,                       -- loja/estabelecimento
  order_id       uuid NOT NULL REFERENCES public.user_orders(id) ON DELETE CASCADE,
  motoboy_id     uuid NOT NULL REFERENCES public.motoboys(id) ON DELETE RESTRICT,
  status         delivery_status NOT NULL DEFAULT 'assigned',
  assigned_at    timestamptz NOT NULL DEFAULT now(),
  picked_up_at   timestamptz,
  delivered_at   timestamptz,
  canceled_at    timestamptz,
  assigned_by    uuid,                               -- quem clicou
  price_cents    integer,
  notes          text,
  created_at     timestamptz NOT NULL DEFAULT now(),
  updated_at     timestamptz NOT NULL DEFAULT now()
);

-- Um pedido só pode ter 1 entrega ativa (não cancelada)
CREATE UNIQUE INDEX IF NOT EXISTS deliveries_one_active_per_order
ON public.deliveries(order_id) WHERE status <> 'canceled';

CREATE INDEX IF NOT EXISTS deliveries_user_status_idx ON public.deliveries(user_id, status);
CREATE INDEX IF NOT EXISTS deliveries_user_order_idx  ON public.deliveries(user_id, order_id);

-- 4) RLS Policies
ALTER TABLE public.motoboys ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.deliveries ENABLE ROW LEVEL SECURITY;

-- Políticas para motoboys
DROP POLICY IF EXISTS "motoboys_select" ON public.motoboys;
DROP POLICY IF EXISTS "motoboys_all" ON public.motoboys;

CREATE POLICY "motoboys_select" ON public.motoboys
FOR SELECT
USING (auth.uid() = user_id);

CREATE POLICY "motoboys_all" ON public.motoboys
FOR ALL
USING (auth.uid() = user_id)
WITH CHECK (auth.uid() = user_id);

-- Políticas para deliveries  
DROP POLICY IF EXISTS "deliveries_select" ON public.deliveries;
DROP POLICY IF EXISTS "deliveries_ins" ON public.deliveries;
DROP POLICY IF EXISTS "deliveries_upd" ON public.deliveries;

CREATE POLICY "deliveries_select" ON public.deliveries
FOR SELECT
USING (auth.uid() = user_id);

CREATE POLICY "deliveries_ins" ON public.deliveries
FOR INSERT
WITH CHECK (auth.uid() = user_id);

CREATE POLICY "deliveries_upd" ON public.deliveries
FOR UPDATE
USING (auth.uid() = user_id)
WITH CHECK (auth.uid() = user_id);

-- 5) Função para atualizar updated_at
CREATE OR REPLACE FUNCTION public.update_deliveries_updated_at()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Trigger para updated_at
DROP TRIGGER IF EXISTS update_deliveries_updated_at ON public.deliveries;
CREATE TRIGGER update_deliveries_updated_at
  BEFORE UPDATE ON public.deliveries
  FOR EACH ROW
  EXECUTE FUNCTION public.update_deliveries_updated_at();

DROP TRIGGER IF EXISTS update_motoboys_updated_at ON public.motoboys;
CREATE TRIGGER update_motoboys_updated_at
  BEFORE UPDATE ON public.motoboys
  FOR EACH ROW
  EXECUTE FUNCTION public.update_updated_at_column();