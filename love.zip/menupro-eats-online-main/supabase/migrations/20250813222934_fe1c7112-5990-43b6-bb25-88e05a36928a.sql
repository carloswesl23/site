-- Create WhatsApp related tables for full messaging system

-- Table for WhatsApp messages (inbox and history)
CREATE TABLE public.wa_messages (
  id uuid NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  tenant_id uuid REFERENCES auth.users(id) ON DELETE CASCADE,
  instance_id text NOT NULL,
  chat_id text NOT NULL, -- phone number
  direction text NOT NULL CHECK (direction IN ('in', 'out')),
  type text NOT NULL DEFAULT 'text' CHECK (type IN ('text', 'image', 'link', 'location', 'order', 'status_update', 'payment_update')),
  body text,
  media_url text,
  zapi_message_id text,
  status text DEFAULT 'queued' CHECK (status IN ('queued', 'sent', 'delivered', 'failed', 'read', 'received')),
  error text,
  created_at timestamp with time zone NOT NULL DEFAULT now(),
  updated_at timestamp with time zone NOT NULL DEFAULT now()
);

-- Table for WhatsApp chats (conversation list)
CREATE TABLE public.wa_chats (
  id uuid NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  tenant_id uuid REFERENCES auth.users(id) ON DELETE CASCADE,
  instance_id text NOT NULL,
  chat_id text NOT NULL, -- phone number
  display_name text,
  last_message_preview text,
  last_message_at timestamp with time zone,
  unread_count integer DEFAULT 0,
  archived boolean DEFAULT false,
  muted boolean DEFAULT false,
  meta_raw jsonb DEFAULT '{}',
  created_at timestamp with time zone NOT NULL DEFAULT now(),
  updated_at timestamp with time zone NOT NULL DEFAULT now(),
  UNIQUE(tenant_id, instance_id, chat_id)
);

-- Table for broadcast jobs (campaigns)
CREATE TABLE public.broadcast_jobs (
  id uuid NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  tenant_id uuid REFERENCES auth.users(id) ON DELETE CASCADE,
  name text NOT NULL,
  template_id uuid,
  segment jsonb DEFAULT '{}', -- selection rules
  schedule_at timestamp with time zone,
  status text DEFAULT 'scheduled' CHECK (status IN ('scheduled', 'running', 'done', 'failed', 'canceled')),
  counters jsonb DEFAULT '{"total": 0, "sent": 0, "failed": 0, "responses": 0}',
  created_at timestamp with time zone NOT NULL DEFAULT now(),
  updated_at timestamp with time zone NOT NULL DEFAULT now()
);

-- Table for broadcast recipients
CREATE TABLE public.broadcast_recipients (
  id uuid NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  job_id uuid REFERENCES public.broadcast_jobs(id) ON DELETE CASCADE,
  tenant_id uuid REFERENCES auth.users(id) ON DELETE CASCADE,
  chat_id text NOT NULL,
  payload jsonb DEFAULT '{}', -- data for variable merging
  status text DEFAULT 'queued' CHECK (status IN ('queued', 'sent', 'failed')),
  error text,
  message_id uuid REFERENCES public.wa_messages(id),
  created_at timestamp with time zone NOT NULL DEFAULT now(),
  updated_at timestamp with time zone NOT NULL DEFAULT now()
);

-- Table for WhatsApp message templates
CREATE TABLE public.wa_templates (
  id uuid NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  tenant_id uuid REFERENCES auth.users(id) ON DELETE CASCADE,
  name text NOT NULL,
  type text DEFAULT 'text' CHECK (type IN ('text', 'image', 'link', 'location')),
  content jsonb NOT NULL DEFAULT '{}', -- {text, link_title, link_url, image_url, etc}
  created_at timestamp with time zone NOT NULL DEFAULT now(),
  updated_at timestamp with time zone NOT NULL DEFAULT now()
);

-- Table for webhook logs (optional for audit)
CREATE TABLE public.webhook_logs (
  id uuid NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  tenant_id uuid REFERENCES auth.users(id) ON DELETE CASCADE,
  event_type text NOT NULL,
  payload jsonb NOT NULL,
  created_at timestamp with time zone NOT NULL DEFAULT now()
);

-- Enable RLS on all tables
ALTER TABLE public.wa_messages ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.wa_chats ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.broadcast_jobs ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.broadcast_recipients ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.wa_templates ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.webhook_logs ENABLE ROW LEVEL SECURITY;

-- Create RLS policies for wa_messages
CREATE POLICY "Users can manage their own WhatsApp messages" 
ON public.wa_messages 
FOR ALL 
USING (auth.uid() = tenant_id);

-- Create RLS policies for wa_chats
CREATE POLICY "Users can manage their own WhatsApp chats" 
ON public.wa_chats 
FOR ALL 
USING (auth.uid() = tenant_id);

-- Create RLS policies for broadcast_jobs
CREATE POLICY "Users can manage their own broadcast jobs" 
ON public.broadcast_jobs 
FOR ALL 
USING (auth.uid() = tenant_id);

-- Create RLS policies for broadcast_recipients
CREATE POLICY "Users can manage their own broadcast recipients" 
ON public.broadcast_recipients 
FOR ALL 
USING (auth.uid() = tenant_id);

-- Create RLS policies for wa_templates
CREATE POLICY "Users can manage their own WhatsApp templates" 
ON public.wa_templates 
FOR ALL 
USING (auth.uid() = tenant_id);

-- Create RLS policies for webhook_logs
CREATE POLICY "Users can view their own webhook logs" 
ON public.webhook_logs 
FOR SELECT 
USING (auth.uid() = tenant_id);

-- Create policy for service role to manage webhook logs
CREATE POLICY "Service role can manage webhook logs" 
ON public.webhook_logs 
FOR ALL 
USING (auth.role() = 'service_role');

-- Create indexes for better performance
CREATE INDEX idx_wa_messages_tenant_chat ON public.wa_messages(tenant_id, chat_id, created_at DESC);
CREATE INDEX idx_wa_messages_zapi_id ON public.wa_messages(zapi_message_id);
CREATE INDEX idx_wa_chats_tenant ON public.wa_chats(tenant_id, last_message_at DESC);
CREATE INDEX idx_broadcast_jobs_tenant_status ON public.broadcast_jobs(tenant_id, status);
CREATE INDEX idx_broadcast_recipients_job_status ON public.broadcast_recipients(job_id, status);

-- Create function to update wa_chats when a message is inserted
CREATE OR REPLACE FUNCTION public.update_wa_chat_on_message()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path TO 'public'
AS $function$
BEGIN
  INSERT INTO public.wa_chats (
    tenant_id,
    instance_id,
    chat_id,
    display_name,
    last_message_preview,
    last_message_at,
    unread_count
  ) VALUES (
    NEW.tenant_id,
    NEW.instance_id,
    NEW.chat_id,
    NEW.chat_id, -- default to phone number
    CASE 
      WHEN NEW.type = 'text' THEN LEFT(NEW.body, 100)
      ELSE NEW.type
    END,
    NEW.created_at,
    CASE WHEN NEW.direction = 'in' THEN 1 ELSE 0 END
  )
  ON CONFLICT (tenant_id, instance_id, chat_id) 
  DO UPDATE SET
    last_message_preview = CASE 
      WHEN NEW.type = 'text' THEN LEFT(NEW.body, 100)
      ELSE NEW.type
    END,
    last_message_at = NEW.created_at,
    unread_count = CASE 
      WHEN NEW.direction = 'in' THEN wa_chats.unread_count + 1
      ELSE wa_chats.unread_count
    END,
    updated_at = now();
    
  RETURN NEW;
END;
$function$;

-- Create trigger to update wa_chats when messages are inserted
CREATE TRIGGER update_wa_chat_on_message_insert
  AFTER INSERT ON public.wa_messages
  FOR EACH ROW
  EXECUTE FUNCTION public.update_wa_chat_on_message();

-- Create function to mark chat as read
CREATE OR REPLACE FUNCTION public.mark_chat_as_read(p_tenant_id uuid, p_chat_id text)
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path TO 'public'
AS $function$
BEGIN
  UPDATE public.wa_chats 
  SET unread_count = 0, updated_at = now()
  WHERE tenant_id = p_tenant_id AND chat_id = p_chat_id;
  
  UPDATE public.wa_messages
  SET status = 'read', updated_at = now()
  WHERE tenant_id = p_tenant_id 
    AND chat_id = p_chat_id 
    AND direction = 'in' 
    AND status != 'read';
END;
$function$;