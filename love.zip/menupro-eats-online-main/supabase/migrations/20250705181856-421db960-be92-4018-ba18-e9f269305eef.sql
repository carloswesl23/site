-- Adicionar campos PIX à tabela establishment_settings
ALTER TABLE public.establishment_settings 
ADD COLUMN pix_key text,
ADD COLUMN pix_beneficiary_name text,
ADD COLUMN pix_beneficiary_document text,
ADD COLUMN pix_enabled boolean DEFAULT false;