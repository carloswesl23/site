-- Update get_establishment_by_slug function to include instagram_url
CREATE OR REPLACE FUNCTION public.get_establishment_by_slug(slug text)
 RETURNS TABLE(establishment_id uuid, business_name text, business_phone text, business_address text, business_logo text, primary_color text, secondary_color text, mobile_layout_mode text, instagram_url text)
 LANGUAGE plpgsql
 SECURITY DEFINER
AS $function$
BEGIN
  RETURN QUERY
  SELECT 
    es.user_id as establishment_id,
    es.business_name,
    es.business_phone,
    es.business_address,
    es.business_logo,
    es.primary_color,
    es.secondary_color,
    es.mobile_layout_mode,
    es.instagram_url
  FROM establishment_settings es
  WHERE es.online_menu_slug = slug;
END;
$function$