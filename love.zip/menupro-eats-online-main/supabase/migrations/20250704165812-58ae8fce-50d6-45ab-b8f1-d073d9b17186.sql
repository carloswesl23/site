-- Corrigir função para usar UPSERT e evitar conflitos de chaves duplicadas
CREATE OR REPLACE FUNCTION public.create_user_initial_setup()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
  business_name_clean text;
  unique_code text;
  final_slug text;
BEGIN
  -- Limpar e formatar o nome da empresa
  business_name_clean := COALESCE(NEW.raw_user_meta_data->>'business_name', 'meu-negocio');
  business_name_clean := lower(business_name_clean);
  business_name_clean := translate(business_name_clean, 'àáâãäåçèéêëìíîïñòóôõöùúûüýÿ', 'aaaaaaceeeeiiiinooooouuuuyy');
  business_name_clean := regexp_replace(business_name_clean, '[^a-z0-9\s-]', '', 'g');
  business_name_clean := regexp_replace(business_name_clean, '\s+', '-', 'g');
  business_name_clean := regexp_replace(business_name_clean, '-+', '-', 'g');
  business_name_clean := trim(business_name_clean, '-');
  
  -- Gerar código único de 4 caracteres
  unique_code := substr(md5(random()::text || clock_timestamp()::text), 1, 4);
  
  -- Formar slug final
  final_slug := business_name_clean || '-' || unique_code;

  -- Criar configurações do estabelecimento usando UPSERT
  INSERT INTO public.establishment_settings (
    user_id,
    business_name,
    online_menu_slug,
    primary_color,
    secondary_color,
    mobile_layout_mode
  ) VALUES (
    NEW.id,
    COALESCE(NEW.raw_user_meta_data->>'business_name', 'Meu Negócio'),
    final_slug,
    '#FF6B35',
    '#F7931E',
    'single'
  )
  ON CONFLICT (user_id) 
  DO UPDATE SET
    business_name = EXCLUDED.business_name,
    online_menu_slug = EXCLUDED.online_menu_slug,
    updated_at = now();

  -- Criar categorias padrão usando UPSERT
  INSERT INTO public.user_categories (user_id, name, sort_order) 
  VALUES
    (NEW.id, 'Hambúrgueres', 1),
    (NEW.id, 'Combos', 2),
    (NEW.id, 'Acompanhamentos', 3),
    (NEW.id, 'Bebidas', 4),
    (NEW.id, 'Sobremesas', 5)
  ON CONFLICT (user_id, name) DO NOTHING;

  -- Criar produtos de exemplo apenas se não existirem
  IF NOT EXISTS (SELECT 1 FROM public.user_products WHERE user_id = NEW.id) THEN
    PERFORM public.create_sample_products_for_user(NEW.id);
  END IF;

  RETURN NEW;
END;
$$;