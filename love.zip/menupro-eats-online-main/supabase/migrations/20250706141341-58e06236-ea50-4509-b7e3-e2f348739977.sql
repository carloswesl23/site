-- Adicionar campos para configuração da Z-API na tabela establishment_settings
ALTER TABLE public.establishment_settings 
ADD COLUMN zapi_instance_id TEXT,
ADD COLUMN zapi_token TEXT,
ADD COLUMN zapi_enabled BOOLEAN DEFAULT false;

-- Comentário explicativo
COMMENT ON COLUMN public.establishment_settings.zapi_instance_id IS 'ID da instância Z-API do cliente';
COMMENT ON COLUMN public.establishment_settings.zapi_token IS 'Token de acesso da Z-API do cliente';
COMMENT ON COLUMN public.establishment_settings.zapi_enabled IS 'Se a integração Z-API está ativa para este cliente';