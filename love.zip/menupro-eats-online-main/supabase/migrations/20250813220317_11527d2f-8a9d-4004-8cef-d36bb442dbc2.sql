-- Ensure all required fields exist in whatsapp_instances table
-- Most fields already exist, but let's make sure we have the right structure

-- Update the status column to use proper enum values if needed
ALTER TABLE public.whatsapp_instances 
ALTER COLUMN status SET DEFAULT 'disconnected';

-- Ensure we have the instance_token field (might be named differently)
-- The field token_instance already exists, so we'll use that

-- Add index for better performance on tenant queries
CREATE INDEX IF NOT EXISTS idx_whatsapp_instances_tenant_id 
ON public.whatsapp_instances(tenant_id) 
WHERE tenant_id IS NOT NULL;

-- Add index for better performance on user queries  
CREATE INDEX IF NOT EXISTS idx_whatsapp_instances_user_id 
ON public.whatsapp_instances(user_id);

-- Ensure RLS policy allows service role to update
DROP POLICY IF EXISTS "Service role can update instances for sync" ON public.whatsapp_instances;
CREATE POLICY "Service role can update instances for sync" 
ON public.whatsapp_instances 
FOR UPDATE 
USING (auth.role() = 'service_role');

-- Add helpful function to get active instance for user
CREATE OR REPLACE FUNCTION public.get_active_whatsapp_instance(user_id_param uuid)
RETURNS TABLE(
  id uuid,
  instance_id text,
  token_instance text, 
  status text,
  qr_code text,
  numero_cliente text,
  updated_at timestamp with time zone
)
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path TO 'public'
AS $function$
BEGIN
  RETURN QUERY
  SELECT 
    wi.id,
    wi.instance_id,
    wi.token_instance,
    wi.status,
    wi.qr_code,
    wi.numero_cliente,
    wi.updated_at
  FROM public.whatsapp_instances wi
  WHERE wi.user_id = user_id_param
  ORDER BY wi.updated_at DESC
  LIMIT 1;
END;
$function$;