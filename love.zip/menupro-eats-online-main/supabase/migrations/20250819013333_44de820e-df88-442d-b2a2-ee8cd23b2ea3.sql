-- Criar tabela de motoboys (couriers)
CREATE TABLE public.couriers (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id UUID NOT NULL,
  name TEXT NOT NULL,
  phone TEXT NOT NULL,
  is_available BOOLEAN NOT NULL DEFAULT true,
  vehicle_type TEXT DEFAULT 'motorcycle',
  notes TEXT,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Enable RLS
ALTER TABLE public.couriers ENABLE ROW LEVEL SECURITY;

-- Create policies
CREATE POLICY "Users can manage their own couriers" 
ON public.couriers 
FOR ALL 
USING (auth.uid() = user_id);

-- Atualizar tabela delivery_assignments para usar couriers
ALTER TABLE public.delivery_assignments 
ADD COLUMN courier_id UUID,
ADD COLUMN attempts INTEGER DEFAULT 0,
ADD COLUMN last_error TEXT;

-- Adicionar campos extras à tabela user_orders
ALTER TABLE public.user_orders 
ADD COLUMN fulfillment_method TEXT DEFAULT 'delivery',
ADD COLUMN out_for_delivery_at TIMESTAMP WITH TIME ZONE,
ADD COLUMN delivered_at TIMESTAMP WITH TIME ZONE;

-- Criar tabela order_timeline para log de eventos
CREATE TABLE public.order_timeline (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  order_id UUID NOT NULL,
  event_type TEXT NOT NULL,
  event_data JSONB DEFAULT '{}',
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  user_id UUID NOT NULL
);

-- Enable RLS
ALTER TABLE public.order_timeline ENABLE ROW LEVEL SECURITY;

-- Create policies
CREATE POLICY "Users can manage their own order timeline" 
ON public.order_timeline 
FOR ALL 
USING (auth.uid() = user_id);

-- Atualizar trigger para timestamps
CREATE TRIGGER update_couriers_updated_at
BEFORE UPDATE ON public.couriers
FOR EACH ROW
EXECUTE FUNCTION public.update_updated_at_column();

-- Foreign key constraints
ALTER TABLE public.delivery_assignments 
ADD CONSTRAINT fk_delivery_assignments_courier 
FOREIGN KEY (courier_id) REFERENCES public.couriers(id);

ALTER TABLE public.order_timeline 
ADD CONSTRAINT fk_order_timeline_order 
FOREIGN KEY (order_id) REFERENCES public.user_orders(id);

-- Adicionar campo de isDefault aos couriers
ALTER TABLE public.couriers ADD COLUMN is_default BOOLEAN DEFAULT false;