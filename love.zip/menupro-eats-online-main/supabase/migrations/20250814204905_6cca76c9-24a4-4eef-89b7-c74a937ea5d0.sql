-- Update the get_user_conversations function to ensure proper ordering
CREATE OR REPLACE FUNCTION public.get_user_conversations(user_id_param uuid)
 RETURNS TABLE(tenant_id uuid, phone_e164 text, display_name text, last_message_at timestamp with time zone, unread_count bigint, last_snippet text)
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
BEGIN
  RETURN QUERY
  SELECT
    c.user_id as tenant_id,
    c.phone_e164,
    COALESCE(c.name, c.phone_e164) as display_name,
    COALESCE(MAX(m.created_at), c.created_at) as last_message_at,
    COUNT(CASE WHEN m.direction='in' AND m.status != 'read' THEN 1 END) as unread_count,
    COALESCE((ARRAY_AGG(m.body ORDER BY m.created_at DESC))[1], 'Nenhuma mensagem') as last_snippet
  FROM contacts c
  LEFT JOIN wa_messages m ON m.user_id = c.user_id AND m.phone_e164 = c.phone_e164
  WHERE c.user_id = user_id_param
  GROUP BY c.user_id, c.phone_e164, c.name, c.created_at
  ORDER BY last_message_at DESC NULLS LAST;
END;
$function$