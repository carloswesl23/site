-- Add print settings columns to establishment_settings table
ALTER TABLE public.establishment_settings 
ADD COLUMN auto_print_on_confirm boolean DEFAULT false,
ADD COLUMN auto_print_on_ready boolean DEFAULT false,
ADD COLUMN print_customer_copy boolean DEFAULT false,
ADD COLUMN include_qr_code boolean DEFAULT true,
ADD COLUMN print_establishment_copy boolean DEFAULT true;