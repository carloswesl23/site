-- Migrar dados das tabelas antigas para motoboys
INSERT INTO public.motoboys (user_id, name, phone_e164, active, created_at, updated_at)
SELECT 
  user_id,
  name,
  phone_e164,
  is_active,
  created_at,
  updated_at
FROM public.delivery_drivers
WHERE user_id IS NOT NULL
ON CONFLICT (user_id, phone_e164) DO NOTHING;

-- Migrar dados de couriers para motoboys (se não existirem)
INSERT INTO public.motoboys (user_id, name, phone_e164, active, created_at, updated_at)
SELECT 
  user_id,
  name,
  phone,
  is_available,
  created_at,
  updated_at
FROM public.couriers
WHERE user_id IS NOT NULL
  AND NOT EXISTS (
    SELECT 1 FROM public.motoboys 
    WHERE motoboys.user_id = couriers.user_id 
    AND motoboys.phone_e164 = couriers.phone
  )
ON CONFLICT (user_id, phone_e164) DO NOTHING;