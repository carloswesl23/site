-- Create wa_chats table for WhatsApp chat storage
CREATE TABLE public.wa_chats (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  tenant_id UUID NOT NULL,
  phone_e164 TEXT NOT NULL,
  name TEXT,
  last_message TEXT,
  last_message_at TIMESTAMP WITH TIME ZONE,
  unread_count INTEGER NOT NULL DEFAULT 0,
  is_pinned BOOLEAN NOT NULL DEFAULT false,
  is_vip BOOLEAN NOT NULL DEFAULT false,
  has_open_order BOOLEAN NOT NULL DEFAULT false,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  UNIQUE(tenant_id, phone_e164)
);

-- Create wa_messages table for WhatsApp message storage
CREATE TABLE public.wa_messages (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  tenant_id UUID NOT NULL,
  phone_e164 TEXT NOT NULL,
  direction TEXT NOT NULL CHECK (direction IN ('in', 'out')),
  type TEXT NOT NULL DEFAULT 'text',
  content JSONB,
  media_url TEXT,
  status TEXT NOT NULL DEFAULT 'pending',
  zapi_msg_id TEXT,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Create wa_presence table for WhatsApp presence tracking
CREATE TABLE public.wa_presence (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  tenant_id UUID NOT NULL,
  phone_e164 TEXT NOT NULL,
  status TEXT NOT NULL DEFAULT 'offline',
  last_seen TIMESTAMP WITH TIME ZONE,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  UNIQUE(tenant_id, phone_e164)
);

-- Enable RLS on all tables
ALTER TABLE public.wa_chats ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.wa_messages ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.wa_presence ENABLE ROW LEVEL SECURITY;

-- Create RLS policies for wa_chats
CREATE POLICY "Users can manage their own chats" ON public.wa_chats
  FOR ALL USING (auth.uid() = tenant_id);

-- Create RLS policies for wa_messages  
CREATE POLICY "Users can manage their own messages" ON public.wa_messages
  FOR ALL USING (auth.uid() = tenant_id);

-- Create RLS policies for wa_presence
CREATE POLICY "Users can manage their own presence" ON public.wa_presence
  FOR ALL USING (auth.uid() = tenant_id);

-- Create indexes for performance
CREATE INDEX idx_wa_chats_tenant_updated ON public.wa_chats(tenant_id, updated_at DESC);
CREATE INDEX idx_wa_chats_phone ON public.wa_chats(phone_e164);
CREATE INDEX idx_wa_messages_tenant_phone ON public.wa_messages(tenant_id, phone_e164, created_at DESC);
CREATE INDEX idx_wa_messages_direction ON public.wa_messages(direction);
CREATE INDEX idx_wa_presence_tenant_phone ON public.wa_presence(tenant_id, phone_e164);

-- Enable Realtime for real-time updates
ALTER PUBLICATION supabase_realtime ADD TABLE public.wa_chats;
ALTER PUBLICATION supabase_realtime ADD TABLE public.wa_messages;
ALTER PUBLICATION supabase_realtime ADD TABLE public.wa_presence;

-- Add updated_at triggers
CREATE TRIGGER update_wa_chats_updated_at
  BEFORE UPDATE ON public.wa_chats
  FOR EACH ROW
  EXECUTE FUNCTION public.update_updated_at_column();

CREATE TRIGGER update_wa_messages_updated_at
  BEFORE UPDATE ON public.wa_messages
  FOR EACH ROW
  EXECUTE FUNCTION public.update_updated_at_column();

CREATE TRIGGER update_wa_presence_updated_at
  BEFORE UPDATE ON public.wa_presence
  FOR EACH ROW
  EXECUTE FUNCTION public.update_updated_at_column();