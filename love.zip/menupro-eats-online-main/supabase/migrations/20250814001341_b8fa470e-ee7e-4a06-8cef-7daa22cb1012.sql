-- Enable realtime for user_orders table
ALTER TABLE public.user_orders REPLICA IDENTITY FULL;

-- Enable realtime for user_customers table  
ALTER TABLE public.user_customers REPLICA IDENTITY FULL;

-- Enable realtime for user_products table
ALTER TABLE public.user_products REPLICA IDENTITY FULL;

-- Add tables to the realtime publication
ALTER PUBLICATION supabase_realtime ADD TABLE public.user_orders;
ALTER PUBLICATION supabase_realtime ADD TABLE public.user_customers;
ALTER PUBLICATION supabase_realtime ADD TABLE public.user_products;