-- Adicionar coluna para armazenar o número do cliente na instância WhatsApp
ALTER TABLE public.whatsapp_instances 
ADD COLUMN numero_cliente text;