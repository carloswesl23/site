-- Adicionar novos campos para o fluxo de código telefônico
ALTER TABLE public.whatsapp_instances 
ADD COLUMN IF NOT EXISTS codigo_verificacao TEXT,
ADD COLUMN IF NOT EXISTS verificado_em TIMESTAMP WITH TIME ZONE,
ADD COLUMN IF NOT EXISTS versao TEXT DEFAULT 'v2',
ADD COLUMN IF NOT EXISTS mensagens JSONB DEFAULT '[]'::jsonb;

-- Atualizar instâncias existentes para v1
UPDATE public.whatsapp_instances 
SET versao = 'v1' 
WHERE versao IS NULL;