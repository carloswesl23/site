-- Helper function to bump updated_at
CREATE OR REPLACE FUNCTION public.update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- 1) Tenants
CREATE TABLE IF NOT EXISTS public.tenants (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  slug text UNIQUE NOT NULL,
  owner_user_id uuid NOT NULL,
  created_at timestamptz DEFAULT now()
);

ALTER TABLE public.tenants ENABLE ROW LEVEL SECURITY;

DO $$ BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_policies WHERE schemaname = 'public' AND tablename = 'tenants' AND policyname = 'Tenants: owner can select'
  ) THEN
    CREATE POLICY "Tenants: owner can select"
      ON public.tenants FOR SELECT
      USING (owner_user_id = auth.uid());
  END IF;
  IF NOT EXISTS (
    SELECT 1 FROM pg_policies WHERE schemaname = 'public' AND tablename = 'tenants' AND policyname = 'Tenants: owner can insert'
  ) THEN
    CREATE POLICY "Tenants: owner can insert"
      ON public.tenants FOR INSERT
      WITH CHECK (owner_user_id = auth.uid());
  END IF;
  IF NOT EXISTS (
    SELECT 1 FROM pg_policies WHERE schemaname = 'public' AND tablename = 'tenants' AND policyname = 'Tenants: owner can update'
  ) THEN
    CREATE POLICY "Tenants: owner can update"
      ON public.tenants FOR UPDATE
      USING (owner_user_id = auth.uid());
  END IF;
END $$;

-- 2) Extend existing whatsapp_instances to support multi-tenant & telemetry
ALTER TABLE public.whatsapp_instances
  ADD COLUMN IF NOT EXISTS tenant_id uuid,
  ADD COLUMN IF NOT EXISTS inbound_webhook_url text,
  ADD COLUMN IF NOT EXISTS events_webhook_url text,
  ADD COLUMN IF NOT EXISTS qr_image_base64 text,
  ADD COLUMN IF NOT EXISTS qr_refreshed_at timestamptz,
  ADD COLUMN IF NOT EXISTS connected_at timestamptz,
  ADD COLUMN IF NOT EXISTS disconnected_at timestamptz,
  ADD COLUMN IF NOT EXISTS last_error text,
  ADD COLUMN IF NOT EXISTS webhook_secret text;

-- FK for tenant (nullable for backwards compatibility)
DO $$ BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_constraint c
    JOIN pg_class t ON c.conrelid = t.oid
    WHERE t.relname = 'whatsapp_instances' AND c.conname = 'whatsapp_instances_tenant_id_fkey'
  ) THEN
    ALTER TABLE public.whatsapp_instances
      ADD CONSTRAINT whatsapp_instances_tenant_id_fkey
      FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE SET NULL;
  END IF;
END $$;

-- Unique for Z-API instance id if not present
DO $$ BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_class c JOIN pg_indexes i ON i.indexname = c.relname
    WHERE i.schemaname = 'public' AND i.tablename = 'whatsapp_instances' AND i.indexname = 'whatsapp_instances_instance_id_key'
  ) THEN
    CREATE UNIQUE INDEX whatsapp_instances_instance_id_key ON public.whatsapp_instances (instance_id);
  END IF;
END $$;

-- 3) Telemetry table
CREATE TABLE IF NOT EXISTS public.whatsapp_events (
  id bigserial PRIMARY KEY,
  tenant_id uuid REFERENCES public.tenants(id) ON DELETE CASCADE,
  instance_id uuid REFERENCES public.whatsapp_instances(id) ON DELETE CASCADE,
  event_type text NOT NULL,
  payload jsonb,
  created_at timestamptz DEFAULT now()
);

ALTER TABLE public.whatsapp_events ENABLE ROW LEVEL SECURITY;

DO $$ BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_policies WHERE schemaname = 'public' AND tablename = 'whatsapp_events' AND policyname = 'Events: owner can select'
  ) THEN
    CREATE POLICY "Events: owner can select"
      ON public.whatsapp_events FOR SELECT
      USING (EXISTS (
        SELECT 1 FROM public.whatsapp_instances wi
        WHERE wi.id = whatsapp_events.instance_id AND wi.user_id = auth.uid()
      ));
  END IF;
END $$;

-- 4) Broadcast jobs & recipients
CREATE TABLE IF NOT EXISTS public.broadcast_jobs (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id uuid NOT NULL REFERENCES public.tenants(id) ON DELETE CASCADE,
  instance_id uuid NOT NULL REFERENCES public.whatsapp_instances(id) ON DELETE CASCADE,
  name text NOT NULL,
  message_template text NOT NULL,
  status text NOT NULL DEFAULT 'DRAFT',
  scheduled_for timestamptz,
  created_by uuid,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

CREATE TABLE IF NOT EXISTS public.broadcast_recipients (
  id bigserial PRIMARY KEY,
  job_id uuid NOT NULL REFERENCES public.broadcast_jobs(id) ON DELETE CASCADE,
  phone_e164 text NOT NULL,
  vars jsonb,
  status text NOT NULL DEFAULT 'PENDING',
  last_error text,
  sent_at timestamptz
);

ALTER TABLE public.broadcast_jobs ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.broadcast_recipients ENABLE ROW LEVEL SECURITY;

DO $$ BEGIN
  -- Jobs policies
  IF NOT EXISTS (
    SELECT 1 FROM pg_policies WHERE schemaname = 'public' AND tablename = 'broadcast_jobs' AND policyname = 'Jobs: owner can select'
  ) THEN
    CREATE POLICY "Jobs: owner can select"
      ON public.broadcast_jobs FOR SELECT
      USING (EXISTS (
        SELECT 1 FROM public.whatsapp_instances wi
        WHERE wi.id = broadcast_jobs.instance_id AND wi.user_id = auth.uid()
      ));
  END IF;
  IF NOT EXISTS (
    SELECT 1 FROM pg_policies WHERE schemaname = 'public' AND tablename = 'broadcast_jobs' AND policyname = 'Jobs: owner can insert'
  ) THEN
    CREATE POLICY "Jobs: owner can insert"
      ON public.broadcast_jobs FOR INSERT
      WITH CHECK (EXISTS (
        SELECT 1 FROM public.whatsapp_instances wi
        WHERE wi.id = broadcast_jobs.instance_id AND wi.user_id = auth.uid()
      ));
  END IF;
  IF NOT EXISTS (
    SELECT 1 FROM pg_policies WHERE schemaname = 'public' AND tablename = 'broadcast_jobs' AND policyname = 'Jobs: owner can update'
  ) THEN
    CREATE POLICY "Jobs: owner can update"
      ON public.broadcast_jobs FOR UPDATE
      USING (EXISTS (
        SELECT 1 FROM public.whatsapp_instances wi
        WHERE wi.id = broadcast_jobs.instance_id AND wi.user_id = auth.uid()
      ));
  END IF;

  -- Recipients policies
  IF NOT EXISTS (
    SELECT 1 FROM pg_policies WHERE schemaname = 'public' AND tablename = 'broadcast_recipients' AND policyname = 'Recipients: owner can select'
  ) THEN
    CREATE POLICY "Recipients: owner can select"
      ON public.broadcast_recipients FOR SELECT
      USING (EXISTS (
        SELECT 1 FROM public.broadcast_jobs bj
        JOIN public.whatsapp_instances wi ON wi.id = bj.instance_id
        WHERE bj.id = broadcast_recipients.job_id AND wi.user_id = auth.uid()
      ));
  END IF;
  IF NOT EXISTS (
    SELECT 1 FROM pg_policies WHERE schemaname = 'public' AND tablename = 'broadcast_recipients' AND policyname = 'Recipients: owner can update'
  ) THEN
    CREATE POLICY "Recipients: owner can update"
      ON public.broadcast_recipients FOR UPDATE
      USING (EXISTS (
        SELECT 1 FROM public.broadcast_jobs bj
        JOIN public.whatsapp_instances wi ON wi.id = bj.instance_id
        WHERE bj.id = broadcast_recipients.job_id AND wi.user_id = auth.uid()
      ));
  END IF;
  IF NOT EXISTS (
    SELECT 1 FROM pg_policies WHERE schemaname = 'public' AND tablename = 'broadcast_recipients' AND policyname = 'Recipients: owner can insert'
  ) THEN
    CREATE POLICY "Recipients: owner can insert"
      ON public.broadcast_recipients FOR INSERT
      WITH CHECK (EXISTS (
        SELECT 1 FROM public.broadcast_jobs bj
        JOIN public.whatsapp_instances wi ON wi.id = bj.instance_id
        WHERE bj.id = broadcast_recipients.job_id AND wi.user_id = auth.uid()
      ));
  END IF;
END $$;

-- Trigger to auto-update updated_at for jobs
DO $$ BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_trigger WHERE tgname = 'update_broadcast_jobs_updated_at'
  ) THEN
    CREATE TRIGGER update_broadcast_jobs_updated_at
    BEFORE UPDATE ON public.broadcast_jobs
    FOR EACH ROW
    EXECUTE FUNCTION public.update_updated_at_column();
  END IF;
END $$;
