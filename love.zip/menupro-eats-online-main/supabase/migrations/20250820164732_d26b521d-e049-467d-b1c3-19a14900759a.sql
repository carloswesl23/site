-- Adicionar campo para controle de abertura/fechamento da loja
ALTER TABLE public.establishment_settings 
ADD COLUMN is_open boolean DEFAULT true;

-- Comentário para documentar o campo
COMMENT ON COLUMN public.establishment_settings.is_open IS 'Controla se a loja está aberta para receber pedidos online';