-- Add instagram_url column to establishment_settings table
ALTER TABLE public.establishment_settings 
ADD COLUMN IF NOT EXISTS instagram_url TEXT;