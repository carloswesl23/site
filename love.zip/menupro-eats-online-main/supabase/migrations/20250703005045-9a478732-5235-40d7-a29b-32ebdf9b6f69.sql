-- Criar tabela de produtos por usuário
CREATE TABLE public.user_products (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id UUID NOT NULL,
  name TEXT NOT NULL,
  description TEXT,
  price DECIMAL(10,2) NOT NULL,
  image TEXT,
  category TEXT NOT NULL,
  is_promotion BOOLEAN NOT NULL DEFAULT false,
  promotion_price DECIMAL(10,2),
  show_online_menu BOOLEAN NOT NULL DEFAULT true,
  customizable BOOLEAN NOT NULL DEFAULT false,
  is_pizza BOOLEAN NOT NULL DEFAULT false,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Criar tabela de categorias por usuário
CREATE TABLE public.user_categories (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id UUID NOT NULL,
  name TEXT NOT NULL,
  sort_order INTEGER DEFAULT 0,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  UNIQUE(user_id, name)
);

-- Criar tabela de pedidos por usuário
CREATE TABLE public.user_orders (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id UUID NOT NULL,
  order_number TEXT NOT NULL,
  customer_name TEXT NOT NULL,
  customer_phone TEXT,
  customer_email TEXT,
  items JSONB NOT NULL,
  total DECIMAL(10,2) NOT NULL,
  status TEXT NOT NULL DEFAULT 'pending',
  payment_method TEXT,
  delivery_address TEXT,
  notes TEXT,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Criar tabela de configurações do estabelecimento
CREATE TABLE public.establishment_settings (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id UUID NOT NULL UNIQUE,
  business_name TEXT NOT NULL,
  business_phone TEXT,
  business_address TEXT,
  business_logo TEXT,
  online_menu_slug TEXT UNIQUE,
  mobile_layout_mode TEXT DEFAULT 'single' CHECK (mobile_layout_mode IN ('single', 'double')),
  primary_color TEXT DEFAULT '#FF6B35',
  secondary_color TEXT DEFAULT '#F7931E',
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Habilitar RLS em todas as tabelas
ALTER TABLE public.user_products ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.user_categories ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.user_orders ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.establishment_settings ENABLE ROW LEVEL SECURITY;

-- Políticas RLS para user_products
CREATE POLICY "Users can view their own products" 
  ON public.user_products 
  FOR SELECT 
  USING (auth.uid() = user_id);

CREATE POLICY "Users can create their own products" 
  ON public.user_products 
  FOR INSERT 
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update their own products" 
  ON public.user_products 
  FOR UPDATE 
  USING (auth.uid() = user_id);

CREATE POLICY "Users can delete their own products" 
  ON public.user_products 
  FOR DELETE 
  USING (auth.uid() = user_id);

-- Políticas RLS para user_categories
CREATE POLICY "Users can view their own categories" 
  ON public.user_categories 
  FOR SELECT 
  USING (auth.uid() = user_id);

CREATE POLICY "Users can create their own categories" 
  ON public.user_categories 
  FOR INSERT 
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update their own categories" 
  ON public.user_categories 
  FOR UPDATE 
  USING (auth.uid() = user_id);

CREATE POLICY "Users can delete their own categories" 
  ON public.user_categories 
  FOR DELETE 
  USING (auth.uid() = user_id);

-- Políticas RLS para user_orders
CREATE POLICY "Users can view their own orders" 
  ON public.user_orders 
  FOR SELECT 
  USING (auth.uid() = user_id);

CREATE POLICY "Users can create their own orders" 
  ON public.user_orders 
  FOR INSERT 
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update their own orders" 
  ON public.user_orders 
  FOR UPDATE 
  USING (auth.uid() = user_id);

CREATE POLICY "Users can delete their own orders" 
  ON public.user_orders 
  FOR DELETE 
  USING (auth.uid() = user_id);

-- Políticas RLS para establishment_settings
CREATE POLICY "Users can view their own settings" 
  ON public.establishment_settings 
  FOR SELECT 
  USING (auth.uid() = user_id);

CREATE POLICY "Users can create their own settings" 
  ON public.establishment_settings 
  FOR INSERT 
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update their own settings" 
  ON public.establishment_settings 
  FOR UPDATE 
  USING (auth.uid() = user_id);

-- Função para criar configurações iniciais quando um usuário se registra
CREATE OR REPLACE FUNCTION public.create_user_initial_setup()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
BEGIN
  -- Criar configurações do estabelecimento
  INSERT INTO public.establishment_settings (
    user_id,
    business_name,
    online_menu_slug
  ) VALUES (
    NEW.id,
    COALESCE(NEW.raw_user_meta_data->>'business_name', 'Meu Negócio'),
    'menu-' || substr(NEW.id::text, 1, 8)
  );

  -- Criar categorias padrão
  INSERT INTO public.user_categories (user_id, name, sort_order) VALUES
    (NEW.id, 'Hambúrgueres', 1),
    (NEW.id, 'Combos', 2),
    (NEW.id, 'Acompanhamentos', 3),
    (NEW.id, 'Bebidas', 4),
    (NEW.id, 'Sobremesas', 5);

  RETURN NEW;
END;
$$;

-- Trigger para criar configuração inicial quando usuário se registra
CREATE TRIGGER on_auth_user_created_setup
  AFTER INSERT ON auth.users
  FOR EACH ROW EXECUTE PROCEDURE public.create_user_initial_setup();

-- Índices para performance
CREATE INDEX idx_user_products_user_id ON public.user_products(user_id);
CREATE INDEX idx_user_categories_user_id ON public.user_categories(user_id);
CREATE INDEX idx_user_orders_user_id ON public.user_orders(user_id);
CREATE INDEX idx_user_orders_status ON public.user_orders(status);
CREATE INDEX idx_establishment_settings_user_id ON public.establishment_settings(user_id);
CREATE INDEX idx_establishment_settings_slug ON public.establishment_settings(online_menu_slug);