-- Add customization fields to user_products table
ALTER TABLE public.user_products 
ADD COLUMN IF NOT EXISTS ingredients text[] DEFAULT '{}',
ADD COLUMN IF NOT EXISTS extras jsonb DEFAULT '[]',
ADD COLUMN IF NOT EXISTS max_flavors integer DEFAULT 1,
ADD COLUMN IF NOT EXISTS pizza_borders jsonb DEFAULT '[]',
ADD COLUMN IF NOT EXISTS pizza_flavors jsonb DEFAULT '[]';

-- Add comments for documentation
COMMENT ON COLUMN public.user_products.ingredients IS 'Array of ingredients that can be removed by customers';
COMMENT ON COLUMN public.user_products.extras IS 'Array of optional extras with name and price: [{"name": "Extra cheese", "price": 2.50}]';
COMMENT ON COLUMN public.user_products.max_flavors IS 'Maximum number of flavors allowed for customizable products (especially pizzas)';
COMMENT ON COLUMN public.user_products.pizza_borders IS 'Array of available pizza borders with name and price: [{"name": "Catupiry", "price": 5.00}]';
COMMENT ON COLUMN public.user_products.pizza_flavors IS 'Array of available pizza flavors with details: [{"name": "Margherita", "price": 25.00, "ingredients": ["tomato", "mozzarella"]}]';