-- Criar tabela para configurações de mensagens automáticas
CREATE TABLE public.whatsapp_message_configs (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id UUID NOT NULL,
  
  -- Configurações gerais
  auto_messages_enabled BOOLEAN NOT NULL DEFAULT true,
  estimated_delivery_time TEXT DEFAULT '30-45 minutos',
  
  -- Mensagem 1: Novo pedido
  new_order_enabled BOOLEAN NOT NULL DEFAULT true,
  new_order_template TEXT DEFAULT '🍔 *NOVO PEDIDO - {nome_da_loja}*

📋 *Pedido:* #{codigo_do_pedido}
👤 *Cliente:* {nome_do_cliente}
📱 *Telefone:* {telefone}
📍 *Endereço de Entrega:*
   Rua: {rua}, {numero}
   Bairro: {bairro}
   Cidade: {cidade}
   CEP: {cep}

📋 *ITENS DO PEDIDO:*
{itens_do_pedido}

💰 *Subtotal: R$ {subtotal}*
🚚 *Taxa de entrega: R$ {taxa_entrega}*
💳 *TOTAL: R$ {total}*
💰 *Forma de pagamento:* {metodo_pagamento}

🕒 Aguarde a confirmação do seu pedido!',

  -- Mensagem 2: PIX
  pix_message_enabled BOOLEAN NOT NULL DEFAULT true,
  pix_message_template TEXT DEFAULT '💸 *Copie e cole o PIX para pagamento:*

🔐 *Chave PIX:* {chave_pix}
👤 *Beneficiário:* {nome_beneficiario}
💰 *Valor:* R$ {total}

📋 *Pedido:* #{codigo_do_pedido}

⏰ Após o pagamento, seu pedido será confirmado automaticamente!',

  -- Mensagem 3: Confirmação de pagamento
  payment_confirmed_enabled BOOLEAN NOT NULL DEFAULT true,
  payment_confirmed_template TEXT DEFAULT '✅ *Pagamento confirmado!*

Seu pedido #{codigo_do_pedido} está sendo preparado.
⏱️ *Tempo estimado:* {tempo_estimado}

Obrigado por escolher o {nome_da_loja}! 🍔',

  -- Mensagem 4: Saiu para entrega
  out_for_delivery_enabled BOOLEAN NOT NULL DEFAULT true,
  out_for_delivery_template TEXT DEFAULT '📦 *Seu pedido saiu para entrega!*

🚴 Entregador a caminho.
Aproveite sua refeição e obrigado por comprar com a gente!

💬 Qualquer dúvida, estamos por aqui no WhatsApp.',

  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Enable RLS
ALTER TABLE public.whatsapp_message_configs ENABLE ROW LEVEL SECURITY;

-- Create policies
CREATE POLICY "Users can view their own message configs" 
ON public.whatsapp_message_configs 
FOR SELECT 
USING (auth.uid() = user_id);

CREATE POLICY "Users can create their own message configs" 
ON public.whatsapp_message_configs 
FOR INSERT 
WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update their own message configs" 
ON public.whatsapp_message_configs 
FOR UPDATE 
USING (auth.uid() = user_id);

-- Criar tabela para logs de mensagens enviadas
CREATE TABLE public.whatsapp_message_logs (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id UUID NOT NULL,
  order_id UUID NOT NULL,
  message_type TEXT NOT NULL, -- 'new_order', 'pix', 'payment_confirmed', 'out_for_delivery'
  phone_number TEXT NOT NULL,
  message_content TEXT NOT NULL,
  sent_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  status TEXT NOT NULL DEFAULT 'pending', -- 'pending', 'sent', 'failed'
  error_message TEXT,
  whatsapp_message_id TEXT,
  
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Enable RLS for logs
ALTER TABLE public.whatsapp_message_logs ENABLE ROW LEVEL SECURITY;

-- Create policies for logs
CREATE POLICY "Users can view their own message logs" 
ON public.whatsapp_message_logs 
FOR SELECT 
USING (auth.uid() = user_id);

CREATE POLICY "Users can create their own message logs" 
ON public.whatsapp_message_logs 
FOR INSERT 
WITH CHECK (auth.uid() = user_id);

-- Criar função para atualizar updated_at
CREATE OR REPLACE FUNCTION public.update_whatsapp_message_configs_updated_at()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Criar trigger para updated_at
CREATE TRIGGER update_whatsapp_message_configs_updated_at
  BEFORE UPDATE ON public.whatsapp_message_configs
  FOR EACH ROW
  EXECUTE FUNCTION public.update_whatsapp_message_configs_updated_at();

-- Criar configuração padrão para novos usuários
CREATE OR REPLACE FUNCTION public.create_default_whatsapp_config()
RETURNS TRIGGER AS $$
BEGIN
  INSERT INTO public.whatsapp_message_configs (user_id)
  VALUES (NEW.id)
  ON CONFLICT (user_id) DO NOTHING;
  
  RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Trigger para criar configuração padrão quando usuário é criado
-- (Este trigger será executado quando novos usuários se registrarem)