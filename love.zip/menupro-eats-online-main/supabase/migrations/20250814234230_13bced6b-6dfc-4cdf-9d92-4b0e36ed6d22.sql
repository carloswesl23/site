-- Criar tabela de logs de mensagens WhatsApp se não existir
CREATE TABLE IF NOT EXISTS public.whatsapp_message_logs (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  order_id TEXT NOT NULL,
  message_type TEXT NOT NULL CHECK (message_type IN ('new_order', 'pix', 'payment_confirmed', 'out_for_delivery')),
  phone_number TEXT NOT NULL,
  message_content TEXT NOT NULL,
  status TEXT NOT NULL DEFAULT 'pending' CHECK (status IN ('pending', 'sent', 'failed')),
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Habilitar RLS
ALTER TABLE public.whatsapp_message_logs ENABLE ROW LEVEL SECURITY;

-- Política para usuários verem apenas seus próprios logs
CREATE POLICY "Users can view their own message logs" 
ON public.whatsapp_message_logs 
FOR SELECT 
USING (auth.uid() = user_id);

-- Política para inserir logs
CREATE POLICY "Users can insert their own message logs" 
ON public.whatsapp_message_logs 
FOR INSERT 
WITH CHECK (auth.uid() = user_id);

-- Política para atualizar logs
CREATE POLICY "Users can update their own message logs" 
ON public.whatsapp_message_logs 
FOR UPDATE 
USING (auth.uid() = user_id);

-- Trigger para atualizar updated_at
CREATE OR REPLACE FUNCTION public.update_whatsapp_message_logs_updated_at()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER update_whatsapp_message_logs_updated_at
BEFORE UPDATE ON public.whatsapp_message_logs
FOR EACH ROW
EXECUTE FUNCTION public.update_whatsapp_message_logs_updated_at();

-- Índices para performance
CREATE INDEX IF NOT EXISTS idx_whatsapp_message_logs_user_id ON public.whatsapp_message_logs(user_id);
CREATE INDEX IF NOT EXISTS idx_whatsapp_message_logs_order_id ON public.whatsapp_message_logs(order_id);
CREATE INDEX IF NOT EXISTS idx_whatsapp_message_logs_status ON public.whatsapp_message_logs(status);