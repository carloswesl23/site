-- Add carrousel_banners column to establishment_settings table
ALTER TABLE public.establishment_settings 
ADD COLUMN IF NOT EXISTS carrousel_banners TEXT;