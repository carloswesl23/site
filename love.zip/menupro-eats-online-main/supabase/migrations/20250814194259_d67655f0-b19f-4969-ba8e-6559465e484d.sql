-- Enable realtime for wa_messages table
ALTER TABLE public.wa_messages REPLICA IDENTITY FULL;

-- Add wa_messages to realtime publication
INSERT INTO supabase_realtime.publication_tables (publication_name, table_name, schema_name) 
VALUES ('supabase_realtime', 'wa_messages', 'public')
ON CONFLICT (publication_name, table_name, schema_name) DO NOTHING;