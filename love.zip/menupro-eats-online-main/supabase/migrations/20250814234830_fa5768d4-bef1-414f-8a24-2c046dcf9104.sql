-- Corrigir erro na função check_rate_limit (problema: window_start ambíguo)
CREATE OR REPLACE FUNCTION public.check_rate_limit(p_identifier text, p_action_type text, p_limit integer DEFAULT 10, p_window_minutes integer DEFAULT 60)
 RETURNS boolean
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
DECLARE
  current_count integer;
  window_start_time timestamp with time zone;
BEGIN
  window_start_time := now() - (p_window_minutes || ' minutes')::interval;
  
  -- Clean old entries
  DELETE FROM public.security_rate_limits 
  WHERE security_rate_limits.window_start < now() - '24 hours'::interval;
  
  -- Get current count in window
  SELECT COALESCE(SUM(request_count), 0) INTO current_count
  FROM public.security_rate_limits
  WHERE identifier = p_identifier 
    AND action_type = p_action_type
    AND security_rate_limits.window_start > window_start_time;
  
  -- Check if limit exceeded
  IF current_count >= p_limit THEN
    -- Log security event
    PERFORM public.log_security_event('RATE_LIMIT_EXCEEDED', jsonb_build_object(
      'identifier', p_identifier,
      'action_type', p_action_type,
      'current_count', current_count,
      'limit', p_limit
    ));
    RETURN false;
  END IF;
  
  -- Record this request
  INSERT INTO public.security_rate_limits (identifier, action_type, request_count, window_start)
  VALUES (p_identifier, p_action_type, 1, now())
  ON CONFLICT (identifier, action_type) 
  DO UPDATE SET 
    request_count = security_rate_limits.request_count + 1,
    window_start = CASE 
      WHEN security_rate_limits.window_start < window_start_time THEN now()
      ELSE security_rate_limits.window_start
    END;
  
  RETURN true;
END;
$function$;

-- Criar view para estabelecimentos públicos que estava faltando
CREATE OR REPLACE VIEW public.public_establishment_view AS
SELECT 
  es.user_id as establishment_id,
  es.business_name,
  es.business_logo,
  es.primary_color,
  es.secondary_color,
  es.mobile_layout_mode,
  es.instagram_url,
  es.online_menu_slug,
  es.business_address,
  es.checkout_custom_message,
  es.business_phone
FROM public.establishment_settings es
WHERE es.online_menu_slug IS NOT NULL
  AND es.online_menu_slug != '';

-- Garantir que a tabela whatsapp_message_logs tem RLS corretamente
ALTER TABLE public.whatsapp_message_logs ENABLE ROW LEVEL SECURITY;

-- Política para usuários atualizarem logs (necessária para edge functions)
DROP POLICY IF EXISTS "Users can update their own message logs" ON public.whatsapp_message_logs;
DROP POLICY IF EXISTS "Service role can manage message logs" ON public.whatsapp_message_logs;

CREATE POLICY "Users can update their own message logs" 
ON public.whatsapp_message_logs 
FOR UPDATE 
USING (auth.uid() = user_id);

CREATE POLICY "Service role can manage message logs" 
ON public.whatsapp_message_logs 
FOR ALL 
USING (auth.role() = 'service_role');

-- Corrigir função para obter dados de estabelecimento por slug
CREATE OR REPLACE FUNCTION public.get_establishment_by_slug(slug text)
 RETURNS TABLE(establishment_id uuid, business_name text, business_phone text, business_address text, business_logo text, primary_color text, secondary_color text, mobile_layout_mode text, instagram_url text)
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
BEGIN
  -- Validar slug para prevenir injection
  IF NOT public.validate_establishment_slug(slug) THEN
    RAISE EXCEPTION 'Invalid establishment identifier';
  END IF;
  
  RETURN QUERY
  SELECT 
    es.user_id,
    es.business_name,
    es.business_phone,
    es.business_address,
    es.business_logo,
    es.primary_color,
    es.secondary_color,
    es.mobile_layout_mode,
    es.instagram_url
  FROM public.establishment_settings es
  WHERE es.online_menu_slug = slug
    AND es.online_menu_slug IS NOT NULL;
END;
$function$;