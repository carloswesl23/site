-- Tabela de entregadores
CREATE TABLE IF NOT EXISTS public.delivery_drivers (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL,
  name TEXT NOT NULL,
  phone_e164 TEXT NOT NULL,
  employment_type TEXT NOT NULL CHECK (employment_type IN ('fixo', 'terceirizado')),
  is_default BOOLEAN DEFAULT false,
  is_active BOOLEAN DEFAULT true,
  created_at TIMESTAMPTZ DEFAULT now(),
  updated_at TIMESTAMPTZ DEFAULT now()
);

-- Tabela de atribuição de entregas
CREATE TABLE IF NOT EXISTS public.delivery_assignments (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  order_id UUID NOT NULL,
  driver_id UUID NOT NULL,
  status TEXT NOT NULL CHECK (status IN ('pendente','aceito','recusado','em_transito','entregue')) DEFAULT 'pendente',
  assigned_at TIMESTAMPTZ DEFAULT now(),
  accepted_at TIMESTAMPTZ NULL,
  out_for_delivery_at TIMESTAMPTZ NULL,
  delivered_at TIMESTAMPTZ NULL,
  notes TEXT NULL,
  created_at TIMESTAMPTZ DEFAULT now(),
  updated_at TIMESTAMPTZ DEFAULT now()
);

-- Habilitar RLS
ALTER TABLE public.delivery_drivers ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.delivery_assignments ENABLE ROW LEVEL SECURITY;

-- Políticas RLS para delivery_drivers
CREATE POLICY "Users can manage their own drivers" 
ON public.delivery_drivers 
FOR ALL 
USING (auth.uid() = user_id);

-- Políticas RLS para delivery_assignments
CREATE POLICY "Users can manage their order assignments" 
ON public.delivery_assignments 
FOR ALL 
USING (EXISTS (
  SELECT 1 FROM public.user_orders 
  WHERE user_orders.id = delivery_assignments.order_id 
  AND user_orders.user_id = auth.uid()
));

-- Triggers para updated_at
CREATE TRIGGER update_delivery_drivers_updated_at
  BEFORE UPDATE ON public.delivery_drivers
  FOR EACH ROW
  EXECUTE FUNCTION public.update_updated_at_column();

CREATE TRIGGER update_delivery_assignments_updated_at
  BEFORE UPDATE ON public.delivery_assignments
  FOR EACH ROW
  EXECUTE FUNCTION public.update_updated_at_column();

-- Adicionar referências de chave estrangeira
ALTER TABLE public.delivery_assignments 
ADD CONSTRAINT delivery_assignments_order_id_fkey 
FOREIGN KEY (order_id) REFERENCES public.user_orders(id) ON DELETE CASCADE;

ALTER TABLE public.delivery_assignments 
ADD CONSTRAINT delivery_assignments_driver_id_fkey 
FOREIGN KEY (driver_id) REFERENCES public.delivery_drivers(id) ON DELETE CASCADE;

-- Função para normalizar telefone para entregadores
CREATE OR REPLACE FUNCTION public.normalize_driver_phone()
RETURNS TRIGGER AS $$
BEGIN
  NEW.phone_e164 := public.normalize_phone_to_e164(NEW.phone_e164);
  RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Trigger para normalizar telefone
CREATE TRIGGER normalize_driver_phone_trigger
  BEFORE INSERT OR UPDATE ON public.delivery_drivers
  FOR EACH ROW
  EXECUTE FUNCTION public.normalize_driver_phone();