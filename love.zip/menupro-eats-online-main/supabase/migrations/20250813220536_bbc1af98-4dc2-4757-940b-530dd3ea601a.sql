-- Fix function search path issues by updating the search path properly
CREATE OR REPLACE FUNCTION public.get_active_whatsapp_instance(user_id_param uuid)
RETURNS TABLE(
  id uuid,
  instance_id text,
  token_instance text, 
  status text,
  qr_code text,
  numero_cliente text,
  updated_at timestamp with time zone
)
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path TO 'public'
AS $function$
BEGIN
  RETURN QUERY
  SELECT 
    wi.id,
    wi.instance_id,
    wi.token_instance,
    wi.status,
    wi.qr_code,
    wi.numero_cliente,
    wi.updated_at
  FROM public.whatsapp_instances wi
  WHERE wi.user_id = user_id_param
  ORDER BY wi.updated_at DESC
  LIMIT 1;
END;
$function$;