-- Add checkout configuration fields to establishment_settings table
ALTER TABLE public.establishment_settings 
ADD COLUMN show_qr_pix boolean DEFAULT true,
ADD COLUMN checkout_custom_message text DEFAULT 'Obrigado! Aguarde que já vamos preparar seu pedido.';