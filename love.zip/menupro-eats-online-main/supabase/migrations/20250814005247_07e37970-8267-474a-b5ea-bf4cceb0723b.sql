-- Fix wa_messages status constraint to include all existing and valid statuses
ALTER TABLE wa_messages DROP CONSTRAINT IF EXISTS wa_messages_status_check;

-- Add proper status constraint with all valid values including existing ones
ALTER TABLE wa_messages ADD CONSTRAINT wa_messages_status_check 
CHECK (status IN ('PENDING', 'QUEUED', 'sent', 'delivered', 'read', 'failed', 'error', 'DELIVERED', 'RECEIVED'));

-- Ensure proper indexes for performance  
CREATE INDEX IF NOT EXISTS idx_wa_messages_user_phone ON wa_messages(user_id, phone_e164);
CREATE INDEX IF NOT EXISTS idx_wa_messages_created_at ON wa_messages(created_at DESC);