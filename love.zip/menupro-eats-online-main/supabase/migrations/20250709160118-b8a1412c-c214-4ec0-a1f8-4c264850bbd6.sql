-- Criar tabela para tracking de visualizações do cardápio
CREATE TABLE public.menu_views (
  id uuid NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id uuid NOT NULL,
  establishment_slug text NOT NULL,
  viewer_ip inet,
  user_agent text,
  created_at timestamp with time zone NOT NULL DEFAULT now()
);

-- Enable Row Level Security
ALTER TABLE public.menu_views ENABLE ROW LEVEL SECURITY;

-- Políticas RLS para menu_views
CREATE POLICY "Users can view their own menu views" 
ON public.menu_views 
FOR SELECT 
USING (auth.uid() = user_id);

CREATE POLICY "Public can insert menu views" 
ON public.menu_views 
FOR INSERT 
WITH CHECK (true); -- Permitir inserção pública para tracking

-- Index para melhor performance
CREATE INDEX idx_menu_views_user_created ON public.menu_views(user_id, created_at);
CREATE INDEX idx_menu_views_slug_created ON public.menu_views(establishment_slug, created_at);