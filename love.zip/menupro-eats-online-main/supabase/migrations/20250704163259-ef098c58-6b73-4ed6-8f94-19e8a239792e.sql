-- Primeiro, verificar se o trigger existe e criá-lo se necessário
DROP TRIGGER IF EXISTS on_auth_user_created ON auth.users;

-- Criar o trigger para chamar a função quando um usuário é criado
CREATE TRIGGER on_auth_user_created
  AFTER INSERT ON auth.users
  FOR EACH ROW EXECUTE FUNCTION public.create_user_initial_setup();

-- Criar alguns produtos de exemplo para novos usuários
CREATE OR REPLACE FUNCTION public.create_sample_products_for_user(user_id_param uuid)
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
BEGIN
  -- Inserir produtos de exemplo
  INSERT INTO public.user_products (
    user_id, name, description, price, category, show_online_menu, image
  ) VALUES 
    (user_id_param, 'Hambúrguer Clássico', 'Pão, carne bovina, queijo, alface, tomate', 25.90, 'Hambúrgueres', true, 'https://images.unsplash.com/photo-1568901346375-23c9450c58cd?w=400&h=300&fit=crop&crop=center'),
    (user_id_param, 'Hambúrguer Bacon', 'Pão, carne bovina, bacon, queijo, cebola caramelizada', 28.90, 'Hambúrgueres', true, 'https://images.unsplash.com/photo-1586190848861-99aa4a171e90?w=400&h=300&fit=crop&crop=center'),
    (user_id_param, 'Combo Clássico', 'Hambúrguer + Batata + Refrigerante', 35.90, 'Combos', true, 'https://images.unsplash.com/photo-1561758033-d89a9ad46330?w=400&h=300&fit=crop&crop=center'),
    (user_id_param, 'Batata Frita', 'Porção individual de batata frita crocante', 12.90, 'Acompanhamentos', true, 'https://images.unsplash.com/photo-1578662996442-48f60103fc96?w=400&h=300&fit=crop&crop=center'),
    (user_id_param, 'Refrigerante Lata', 'Coca-Cola, Pepsi, Guaraná ou Fanta', 5.90, 'Bebidas', true, 'https://images.unsplash.com/photo-1624552045480-0a7d2a9f9e5d?w=400&h=300&fit=crop&crop=center'),
    (user_id_param, 'Milkshake Chocolate', 'Cremoso milkshake de chocolate', 15.90, 'Sobremesas', true, 'https://images.unsplash.com/photo-1579954115545-a95591f28bfc?w=400&h=300&fit=crop&crop=center');
END;
$$;

-- Atualizar a função de setup inicial para incluir produtos de exemplo
CREATE OR REPLACE FUNCTION public.create_user_initial_setup()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
  business_name_clean text;
  unique_code text;
  final_slug text;
BEGIN
  -- Limpar e formatar o nome da empresa
  business_name_clean := COALESCE(NEW.raw_user_meta_data->>'business_name', 'meu-negocio');
  business_name_clean := lower(business_name_clean);
  business_name_clean := translate(business_name_clean, 'àáâãäåçèéêëìíîïñòóôõöùúûüýÿ', 'aaaaaaceeeeiiiinooooouuuuyy');
  business_name_clean := regexp_replace(business_name_clean, '[^a-z0-9\s-]', '', 'g');
  business_name_clean := regexp_replace(business_name_clean, '\s+', '-', 'g');
  business_name_clean := regexp_replace(business_name_clean, '-+', '-', 'g');
  business_name_clean := trim(business_name_clean, '-');
  
  -- Gerar código único de 4 caracteres
  unique_code := substr(md5(random()::text || clock_timestamp()::text), 1, 4);
  
  -- Formar slug final
  final_slug := business_name_clean || '-' || unique_code;

  -- Criar configurações do estabelecimento
  INSERT INTO public.establishment_settings (
    user_id,
    business_name,
    online_menu_slug
  ) VALUES (
    NEW.id,
    COALESCE(NEW.raw_user_meta_data->>'business_name', 'Meu Negócio'),
    final_slug
  );

  -- Criar categorias padrão
  INSERT INTO public.user_categories (user_id, name, sort_order) VALUES
    (NEW.id, 'Hambúrgueres', 1),
    (NEW.id, 'Combos', 2),
    (NEW.id, 'Acompanhamentos', 3),
    (NEW.id, 'Bebidas', 4),
    (NEW.id, 'Sobremesas', 5);

  -- Criar produtos de exemplo
  PERFORM public.create_sample_products_for_user(NEW.id);

  RETURN NEW;
END;
$$;