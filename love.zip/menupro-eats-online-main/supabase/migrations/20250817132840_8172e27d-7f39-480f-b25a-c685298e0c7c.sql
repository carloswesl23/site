-- Create wa_chats table for chat metadata
CREATE TABLE IF NOT EXISTS wa_chats (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id UUID NOT NULL,
  phone_e164 TEXT NOT NULL,
  name TEXT,
  last_message TEXT,
  last_message_at TIMESTAMPTZ,
  unread_count INTEGER DEFAULT 0,
  is_pinned BOOLEAN DEFAULT false,
  is_vip BOOLEAN DEFAULT false,
  customer_id UUID,
  has_open_order BOOLEAN DEFAULT false,
  created_at TIMESTAMPTZ DEFAULT now(),
  updated_at TIMESTAMPTZ DEFAULT now(),
  UNIQUE(tenant_id, phone_e164)
);

-- Create wa_messages table for message history
CREATE TABLE IF NOT EXISTS wa_messages (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id UUID NOT NULL,
  phone_e164 TEXT NOT NULL,
  direction TEXT NOT NULL CHECK (direction IN ('in', 'out')),
  type TEXT NOT NULL DEFAULT 'text',
  content JSONB NOT NULL,
  status TEXT DEFAULT 'sent' CHECK (status IN ('sent', 'delivered', 'read', 'failed')),
  zapi_message_id TEXT,
  created_at TIMESTAMPTZ DEFAULT now(),
  updated_at TIMESTAMPTZ DEFAULT now()
);

-- Create wa_presence table for typing/online status
CREATE TABLE IF NOT EXISTS wa_presence (
  tenant_id UUID NOT NULL,
  phone_e164 TEXT NOT NULL,
  typing BOOLEAN DEFAULT false,
  online BOOLEAN DEFAULT false,
  updated_at TIMESTAMPTZ DEFAULT now(),
  PRIMARY KEY (tenant_id, phone_e164)
);

-- Create indexes for performance
CREATE INDEX IF NOT EXISTS idx_wa_chats_tenant_last_message ON wa_chats(tenant_id, last_message_at DESC);
CREATE INDEX IF NOT EXISTS idx_wa_chats_unread ON wa_chats(tenant_id, unread_count) WHERE unread_count > 0;
CREATE INDEX IF NOT EXISTS idx_wa_messages_tenant_phone_created ON wa_messages(tenant_id, phone_e164, created_at DESC);
CREATE INDEX IF NOT EXISTS idx_wa_messages_zapi_id ON wa_messages(zapi_message_id) WHERE zapi_message_id IS NOT NULL;

-- RLS Policies
ALTER TABLE wa_chats ENABLE ROW LEVEL SECURITY;
ALTER TABLE wa_messages ENABLE ROW LEVEL SECURITY;
ALTER TABLE wa_presence ENABLE ROW LEVEL SECURITY;

-- wa_chats policies
CREATE POLICY "Users can manage their own chats" ON wa_chats
  FOR ALL USING (auth.uid() = tenant_id);

-- wa_messages policies  
CREATE POLICY "Users can manage their own messages" ON wa_messages
  FOR ALL USING (auth.uid() = tenant_id);

-- wa_presence policies
CREATE POLICY "Users can manage their own presence" ON wa_presence
  FOR ALL USING (auth.uid() = tenant_id);

-- Enable realtime
ALTER PUBLICATION supabase_realtime ADD TABLE wa_chats;
ALTER PUBLICATION supabase_realtime ADD TABLE wa_messages;
ALTER PUBLICATION supabase_realtime ADD TABLE wa_presence;

-- Set replica identity for realtime
ALTER TABLE wa_chats REPLICA IDENTITY FULL;
ALTER TABLE wa_messages REPLICA IDENTITY FULL;
ALTER TABLE wa_presence REPLICA IDENTITY FULL;

-- Trigger to update updated_at
CREATE OR REPLACE FUNCTION update_wa_updated_at()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER update_wa_chats_updated_at
  BEFORE UPDATE ON wa_chats
  FOR EACH ROW EXECUTE FUNCTION update_wa_updated_at();

CREATE TRIGGER update_wa_messages_updated_at
  BEFORE UPDATE ON wa_messages
  FOR EACH ROW EXECUTE FUNCTION update_wa_updated_at();