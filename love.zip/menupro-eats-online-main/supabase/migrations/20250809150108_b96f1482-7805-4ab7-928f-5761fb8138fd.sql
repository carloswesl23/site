-- WhatsApp 2.0 Gateway Tables

-- Sessions table for managing WhatsApp connections
CREATE TABLE IF NOT EXISTS wa_sessions (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id UUID NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
  session_key TEXT UNIQUE NOT NULL,
  status TEXT NOT NULL DEFAULT 'PENDING_QR',
  phone_number TEXT,
  device_name TEXT,
  last_qr TEXT,
  last_qr_at TIMESTAMPTZ,
  last_error TEXT,
  created_at TIMESTAMPTZ DEFAULT now(),
  updated_at TIMESTAMPTZ DEFAULT now()
);

-- Events table for tracking WhatsApp events
CREATE TABLE IF NOT EXISTS wa_events (
  id BIGSERIAL PRIMARY KEY,
  tenant_id UUID NOT NULL,
  session_id UUID NOT NULL REFERENCES wa_sessions(id) ON DELETE CASCADE,
  type TEXT NOT NULL,
  payload JSONB,
  created_at TIMESTAMPTZ DEFAULT now()
);

-- Updated broadcast_jobs to use wa_sessions
ALTER TABLE broadcast_jobs 
ADD COLUMN IF NOT EXISTS session_id UUID REFERENCES wa_sessions(id) ON DELETE CASCADE;

-- Enable RLS
ALTER TABLE wa_sessions ENABLE ROW LEVEL SECURITY;
ALTER TABLE wa_events ENABLE ROW LEVEL SECURITY;

-- RLS policies for wa_sessions
CREATE POLICY "Users can manage their own WA sessions"
ON wa_sessions
FOR ALL
USING (
  tenant_id IN (
    SELECT id FROM tenants WHERE owner_user_id = auth.uid()
  )
);

-- RLS policies for wa_events  
CREATE POLICY "Users can view their own WA events"
ON wa_events
FOR SELECT
USING (
  tenant_id IN (
    SELECT id FROM tenants WHERE owner_user_id = auth.uid()
  )
);

-- Create indexes for performance
CREATE INDEX IF NOT EXISTS idx_wa_sessions_tenant_id ON wa_sessions(tenant_id);
CREATE INDEX IF NOT EXISTS idx_wa_sessions_session_key ON wa_sessions(session_key);
CREATE INDEX IF NOT EXISTS idx_wa_events_session_id ON wa_events(session_id);
CREATE INDEX IF NOT EXISTS idx_wa_events_created_at ON wa_events(created_at);

-- Trigger for updating wa_sessions updated_at
CREATE OR REPLACE FUNCTION update_wa_sessions_updated_at()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER update_wa_sessions_updated_at
  BEFORE UPDATE ON wa_sessions
  FOR EACH ROW
  EXECUTE FUNCTION update_wa_sessions_updated_at();