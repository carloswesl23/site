-- Criar tabela de cupons de desconto
CREATE TABLE public.discount_coupons (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id UUID NOT NULL,
  code TEXT NOT NULL,
  name TEXT NOT NULL,
  discount_type TEXT NOT NULL CHECK (discount_type IN ('percentage', 'fixed')),
  discount_value NUMERIC NOT NULL,
  is_active BOOLEAN NOT NULL DEFAULT true,
  auto_apply BOOLEAN NOT NULL DEFAULT false,
  max_uses INTEGER,
  current_uses INTEGER NOT NULL DEFAULT 0,
  valid_from TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  valid_until TIMESTAMP WITH TIME ZONE,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  UNIQUE(user_id, code)
);

-- Criar tabela de uso de cupons (para métricas)
CREATE TABLE public.coupon_usage (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  coupon_id UUID NOT NULL REFERENCES public.discount_coupons(id) ON DELETE CASCADE,
  order_id UUID NOT NULL REFERENCES public.user_orders(id) ON DELETE CASCADE,
  user_id UUID NOT NULL,
  customer_name TEXT NOT NULL,
  customer_phone TEXT,
  discount_applied NUMERIC NOT NULL,
  order_total NUMERIC NOT NULL,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Habilitar RLS nas tabelas
ALTER TABLE public.discount_coupons ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.coupon_usage ENABLE ROW LEVEL SECURITY;

-- Políticas RLS para discount_coupons
CREATE POLICY "Users can view their own coupons" 
ON public.discount_coupons 
FOR SELECT 
USING (auth.uid() = user_id);

CREATE POLICY "Users can create their own coupons" 
ON public.discount_coupons 
FOR INSERT 
WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update their own coupons" 
ON public.discount_coupons 
FOR UPDATE 
USING (auth.uid() = user_id);

CREATE POLICY "Users can delete their own coupons" 
ON public.discount_coupons 
FOR DELETE 
USING (auth.uid() = user_id);

-- Política pública para validar cupons no checkout
CREATE POLICY "Public can view active coupons for validation" 
ON public.discount_coupons 
FOR SELECT 
USING (
  is_active = true 
  AND (valid_until IS NULL OR valid_until > now())
  AND (max_uses IS NULL OR current_uses < max_uses)
  AND user_id IN (
    SELECT user_id 
    FROM establishment_settings 
    WHERE online_menu_slug IS NOT NULL
  )
);

-- Políticas RLS para coupon_usage
CREATE POLICY "Users can view their own coupon usage" 
ON public.coupon_usage 
FOR SELECT 
USING (auth.uid() = user_id);

CREATE POLICY "Users can create coupon usage records" 
ON public.coupon_usage 
FOR INSERT 
WITH CHECK (auth.uid() = user_id);

-- Função para atualizar updated_at automaticamente
CREATE OR REPLACE FUNCTION public.update_discount_coupons_updated_at()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Trigger para atualizar updated_at
CREATE TRIGGER update_discount_coupons_updated_at
  BEFORE UPDATE ON public.discount_coupons
  FOR EACH ROW
  EXECUTE FUNCTION public.update_discount_coupons_updated_at();

-- Função para atualizar contador de uso do cupom
CREATE OR REPLACE FUNCTION public.increment_coupon_usage()
RETURNS TRIGGER AS $$
BEGIN
  UPDATE public.discount_coupons 
  SET current_uses = current_uses + 1,
      updated_at = now()
  WHERE id = NEW.coupon_id;
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Trigger para incrementar uso do cupom
CREATE TRIGGER increment_coupon_usage_trigger
  AFTER INSERT ON public.coupon_usage
  FOR EACH ROW
  EXECUTE FUNCTION public.increment_coupon_usage();