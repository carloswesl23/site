-- Criar tabelas para o novo padrão de clientes (não anônimos)

-- PERFIL DO CLIENTE (um por número)
CREATE TABLE IF NOT EXISTS public.customers (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id UUID NOT NULL,
  phone_e164 TEXT NOT NULL,
  name TEXT,
  created_at TIMESTAMPTZ DEFAULT now(),
  updated_at TIMESTAMPTZ DEFAULT now(),
  UNIQUE (tenant_id, phone_e164)
);

-- Enable RLS
ALTER TABLE public.customers ENABLE ROW LEVEL SECURITY;

-- RLS Policies for customers
CREATE POLICY "Users can manage their own customers"
ON public.customers
FOR ALL
USING (auth.uid() = tenant_id);

-- ENDEREÇOS DOS CLIENTES
CREATE TABLE IF NOT EXISTS public.customer_addresses (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id UUID NOT NULL,
  customer_id UUID NOT NULL REFERENCES public.customers(id) ON DELETE CASCADE,
  label TEXT DEFAULT 'Endereço',
  street TEXT NOT NULL,
  number TEXT,
  complement TEXT,
  district TEXT,
  city TEXT NOT NULL,
  state TEXT NOT NULL,
  zipcode TEXT,
  is_default BOOLEAN DEFAULT false,
  created_at TIMESTAMPTZ DEFAULT now()
);

-- Enable RLS
ALTER TABLE public.customer_addresses ENABLE ROW LEVEL SECURITY;

-- RLS Policies for customer_addresses
CREATE POLICY "Users can manage their customers addresses"
ON public.customer_addresses
FOR ALL
USING (auth.uid() = tenant_id);

-- Índices para performance
CREATE INDEX IF NOT EXISTS idx_customers_tenant_phone ON public.customers(tenant_id, phone_e164);
CREATE INDEX IF NOT EXISTS idx_addr_customer ON public.customer_addresses(customer_id);
CREATE INDEX IF NOT EXISTS idx_addr_tenant ON public.customer_addresses(tenant_id);

-- Adicionar customer_id na tabela user_orders (se não existir)
ALTER TABLE public.user_orders 
ADD COLUMN IF NOT EXISTS customer_id UUID REFERENCES public.customers(id);

-- Índice para user_orders.customer_id
CREATE INDEX IF NOT EXISTS idx_orders_customer ON public.user_orders(customer_id);

-- Função para normalizar telefone para E.164
CREATE OR REPLACE FUNCTION public.normalize_phone_to_e164(input_phone TEXT)
RETURNS TEXT
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
BEGIN
  -- Remove todos os caracteres não numéricos
  input_phone := regexp_replace(input_phone, '[^0-9]', '', 'g');
  
  -- Se já tem 13 dígitos e começa com 55, adiciona +
  IF input_phone ~ '^55[0-9]{11}$' THEN
    RETURN '+' || input_phone;
  END IF;
  
  -- Se tem 11 dígitos, adiciona +55
  IF input_phone ~ '^[0-9]{11}$' THEN
    RETURN '+55' || input_phone;
  END IF;
  
  -- Se tem 10 dígitos, adiciona +55 e um 9 depois do DDD
  IF input_phone ~ '^[0-9]{10}$' THEN
    RETURN '+55' || substring(input_phone, 1, 2) || '9' || substring(input_phone, 3);
  END IF;
  
  -- Se não está em formato conhecido, retorna como está com +
  IF NOT input_phone ~ '^\+' THEN
    RETURN '+' || input_phone;
  END IF;
  
  RETURN input_phone;
END;
$$;

-- Função para upsert customer
CREATE OR REPLACE FUNCTION public.upsert_customer(
  p_tenant_id UUID,
  p_phone TEXT,
  p_name TEXT
)
RETURNS UUID
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
  customer_id UUID;
  normalized_phone TEXT;
BEGIN
  -- Normalizar telefone
  normalized_phone := public.normalize_phone_to_e164(p_phone);
  
  -- Upsert customer
  INSERT INTO public.customers (tenant_id, phone_e164, name, updated_at)
  VALUES (p_tenant_id, normalized_phone, p_name, now())
  ON CONFLICT (tenant_id, phone_e164)
  DO UPDATE SET 
    name = EXCLUDED.name,
    updated_at = now()
  RETURNING id INTO customer_id;
  
  RETURN customer_id;
END;
$$;

-- Função para criar order com customer obrigatório
CREATE OR REPLACE FUNCTION public.create_order_with_customer(
  p_establishment_slug TEXT,
  p_customer_phone TEXT,
  p_customer_name TEXT,
  p_address_data JSONB,
  p_order_data JSONB
)
RETURNS UUID
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
  establishment_id UUID;
  customer_id UUID;
  address_id UUID;
  order_id UUID;
  order_number TEXT;
  delivery_address TEXT;
BEGIN
  -- Validar establishment
  SELECT user_id INTO establishment_id
  FROM public.establishment_settings
  WHERE online_menu_slug = p_establishment_slug
  AND online_menu_slug IS NOT NULL;
  
  IF establishment_id IS NULL THEN
    RAISE EXCEPTION 'Invalid establishment slug';
  END IF;
  
  -- Rate limiting
  IF NOT public.check_rate_limit(
    COALESCE(inet_client_addr()::text, p_customer_phone),
    'order_creation',
    3,
    60
  ) THEN
    RAISE EXCEPTION 'Rate limit exceeded. Please try again later.';
  END IF;
  
  -- Upsert customer
  customer_id := public.upsert_customer(
    establishment_id,
    p_customer_phone,
    p_customer_name
  );
  
  -- Criar endereço se necessário
  IF p_address_data IS NOT NULL THEN
    delivery_address := CONCAT(
      p_address_data->>'street', ', ',
      p_address_data->>'number',
      CASE WHEN p_address_data->>'complement' != '' 
           THEN ', ' || (p_address_data->>'complement') 
           ELSE '' END,
      ', ', p_address_data->>'neighborhood',
      ', ', p_address_data->>'city',
      ', ', p_address_data->>'zipCode',
      CASE WHEN p_address_data->>'reference' != '' 
           THEN ' - ' || (p_address_data->>'reference') 
           ELSE '' END
    );
    
    -- Upsert address
    INSERT INTO public.customer_addresses (
      tenant_id, customer_id, street, number, complement, 
      district, city, state, zipcode, is_default
    )
    VALUES (
      establishment_id,
      customer_id,
      p_address_data->>'street',
      p_address_data->>'number',
      p_address_data->>'complement',
      p_address_data->>'neighborhood',
      p_address_data->>'city',
      p_address_data->>'state',
      p_address_data->>'zipCode',
      NOT EXISTS (
        SELECT 1 FROM public.customer_addresses 
        WHERE customer_id = customer_id
      )
    )
    ON CONFLICT (tenant_id, customer_id) WHERE is_default = true
    DO UPDATE SET
      street = EXCLUDED.street,
      number = EXCLUDED.number,
      complement = EXCLUDED.complement,
      district = EXCLUDED.district,
      city = EXCLUDED.city,
      state = EXCLUDED.state,
      zipcode = EXCLUDED.zipcode
    RETURNING id INTO address_id;
  END IF;
  
  -- Gerar order number
  order_number := 'LM-' || extract(epoch from now())::text || '-' || substr(encode(gen_random_bytes(3), 'hex'), 1, 6);
  
  -- Criar order
  INSERT INTO public.user_orders (
    user_id,
    customer_id,
    order_number,
    customer_name,
    customer_phone,
    delivery_address,
    items,
    total,
    payment_method,
    notes,
    status
  ) VALUES (
    establishment_id,
    customer_id,
    order_number,
    p_customer_name,
    p_customer_phone,
    delivery_address,
    p_order_data->'items',
    (p_order_data->>'total')::numeric,
    p_order_data->>'payment_method',
    p_order_data->>'notes',
    'pending'
  )
  RETURNING id INTO order_id;
  
  -- Log creation
  PERFORM public.log_security_event('ORDER_CREATED_WITH_CUSTOMER', jsonb_build_object(
    'order_id', order_id,
    'customer_id', customer_id,
    'establishment_id', establishment_id
  ));
  
  RETURN order_id;
END;
$$;

-- Trigger para updated_at nas novas tabelas
CREATE TRIGGER update_customers_updated_at
BEFORE UPDATE ON public.customers
FOR EACH ROW
EXECUTE FUNCTION public.update_updated_at_column();

-- RLS policy para permitir acesso público aos customers durante checkout
CREATE POLICY "Public can create customers during checkout"
ON public.customers
FOR INSERT
WITH CHECK (true);

CREATE POLICY "Public can read customers for checkout"
ON public.customers
FOR SELECT
USING (tenant_id IN (
  SELECT user_id FROM public.establishment_settings 
  WHERE online_menu_slug IS NOT NULL
));