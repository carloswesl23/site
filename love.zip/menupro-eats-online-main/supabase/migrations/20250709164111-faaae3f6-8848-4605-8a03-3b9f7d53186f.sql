-- Criar policy pública para visualizar upsells ativos no cardápio público
CREATE POLICY "Public can view active upsells for online menu" 
ON public.upsell_configs 
FOR SELECT 
USING (
  is_active = true 
  AND user_id IN (
    SELECT user_id 
    FROM establishment_settings 
    WHERE online_menu_slug IS NOT NULL
  )
);