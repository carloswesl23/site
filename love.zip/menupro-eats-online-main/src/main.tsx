import { createRoot } from 'react-dom/client'
import App from './App.tsx'
import './index.css'
import { applySecurityHeaders } from './middleware/securityHeaders'
import { initializeProductionSecurity } from './utils/productionSecurity'

// Apply security headers
applySecurityHeaders();

// Initialize production security monitoring
initializeProductionSecurity();

createRoot(document.getElementById("root")!).render(<App />);
