export interface Product {
  id: string;
  name: string;
  description: string;
  price: number;
  image: string;
  category: string;
  isPromotion: boolean;
  promotionPrice?: number;
  customizable?: boolean;
  ingredients?: string[];
  extras?: { name: string; price: number }[];
  isPizza?: boolean;
  pizzaFlavors?: any[];
  pizzaBorders?: any[];
  maxFlavors?: number;
  allowHalfHalf?: boolean;
}

export interface CartItem {
  id: string;
  product: Product;
  quantity: number;
  customizations?: {
    bread?: string;
    ingredients?: string[];
    extras?: { name: string; price: number }[];
    notes?: string;
    // Pizza specific
    flavors?: any[];
    flavorCount?: number;
    removedIngredients?: string[];
    border?: any;
    pizzaPrice?: number;
    borderPrice?: number;
  };
  totalPrice: number;
}