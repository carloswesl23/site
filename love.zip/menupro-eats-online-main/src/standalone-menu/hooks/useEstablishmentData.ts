import { useState, useEffect } from "react";
import { supabase } from "../integrations/supabase/client";

interface EstablishmentData {
  user_id: string;
  business_name: string;
  business_phone: string | null;
  business_address: string | null;
  business_logo: string | null;
  primary_color: string | null;
  secondary_color: string | null;
  mobile_layout_mode: string | null;
  instagram_url: string | null;
  pix_key: string | null;
  pix_beneficiary_name: string | null;
  pix_enabled: boolean | null;
  accept_cash: boolean | null;
  accept_credit_on_delivery: boolean | null;
  combine_payment_via_whatsapp: boolean | null;
  show_qr_pix: boolean | null;
  checkout_custom_message: string | null;
  is_open: boolean | null;
}

export const useEstablishmentData = (slug?: string) => {
  const [establishmentData, setEstablishmentData] = useState<EstablishmentData | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    const fetchEstablishmentData = async () => {
      if (!slug) {
        console.log('❌ useEstablishmentData: No slug provided');
        setLoading(false);
        return;
      }

      try {
        console.log('🔍 useEstablishmentData: Buscando estabelecimento para slug:', slug);
        
        // Usar edge function para buscar dados de forma mais confiável
        const { data, error } = await supabase.functions.invoke('get-establishment-data', {
          body: { slug: slug }
        });

        if (error) {
          console.error('❌ useEstablishmentData: Erro ao buscar estabelecimento:', error);
          setError(error.message);
          return;
        }

        console.log('📋 useEstablishmentData: Dados recebidos:', data);
        
        if (data?.success && data?.data) {
          const establishmentRecord = data.data;
          
          const establishmentInfo = {
            user_id: establishmentRecord.establishment_id,
            business_name: establishmentRecord.business_name,
            business_phone: establishmentRecord.business_phone,
            business_address: null,
            business_logo: establishmentRecord.business_logo,
            primary_color: establishmentRecord.primary_color,
            secondary_color: establishmentRecord.secondary_color,
            mobile_layout_mode: establishmentRecord.mobile_layout_mode,
            instagram_url: establishmentRecord.instagram_url,
            pix_key: establishmentRecord.pix_key,
            pix_beneficiary_name: establishmentRecord.pix_beneficiary_name,
            pix_enabled: establishmentRecord.pix_enabled,
            accept_cash: establishmentRecord.accept_cash,
            accept_credit_on_delivery: establishmentRecord.accept_credit_on_delivery,
            combine_payment_via_whatsapp: establishmentRecord.combine_payment_via_whatsapp,
            show_qr_pix: establishmentRecord.show_qr_pix,
            checkout_custom_message: establishmentRecord.checkout_custom_message,
            is_open: establishmentRecord.is_open ?? true
          };
          
          console.log('✅ useEstablishmentData: Estabelecimento encontrado:', establishmentInfo);
          console.log('💳 useEstablishmentData: Configurações de pagamento:', {
            pix_enabled: establishmentInfo.pix_enabled,
            pix_key: establishmentInfo.pix_key,
            combine_payment_via_whatsapp: establishmentInfo.combine_payment_via_whatsapp,
            accept_cash: establishmentInfo.accept_cash,
            accept_credit_on_delivery: establishmentInfo.accept_credit_on_delivery
          });
          setEstablishmentData(establishmentInfo);
        } else {
          console.log('❌ useEstablishmentData: Nenhum estabelecimento encontrado para slug:', slug);
          setError('Estabelecimento não encontrado');
        }
      } catch (err) {
        console.error('Erro ao buscar dados do estabelecimento:', err);
        setError('Erro ao carregar dados do estabelecimento');
      } finally {
        setLoading(false);
      }
    };

    fetchEstablishmentData();
  }, [slug]);

  return {
    establishmentData,
    loading,
    error
  };
};