import { useState, useEffect } from "react";
import { supabase } from "../integrations/supabase/client";

interface UpsellProduct {
  id: string;
  name: string;
  price: number;
  image: string | null;
}

interface UpsellConfig {
  product_id: string;
  is_active: boolean;
  suggested_products: string[];
}

export const useMenuUpsell = (userId?: string) => {
  const [upsellConfigs, setUpsellConfigs] = useState<UpsellConfig[]>([]);
  const [allProducts, setAllProducts] = useState<UpsellProduct[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchUpsellData = async () => {
      if (!userId) {
        setLoading(false);
        return;
      }

      try {
        // Buscar todas as configurações de upsell ativas
        const { data: upsellData, error: upsellError } = await supabase
          .from('upsell_configs')
          .select('product_id, is_active, suggested_products')
          .eq('user_id', userId)
          .eq('is_active', true);

        if (upsellError) {
          console.error('Error fetching upsell configs:', upsellError);
          return;
        }

        console.log('🎯 Upsell configs found:', upsellData?.length || 0, upsellData);
        setUpsellConfigs(upsellData || []);

        // Buscar todos os produtos para poder mostrar as sugestões
        const { data: productsData, error: productsError } = await supabase
          .from('user_products')
          .select('id, name, price, image')
          .eq('user_id', userId)
          .eq('show_online_menu', true);

        if (productsError) {
          console.error('Error fetching products for upsell:', productsError);
          return;
        }

        console.log('📦 Products for upsell found:', productsData?.length || 0);
        setAllProducts(productsData || []);

      } catch (error) {
        console.error('Error in fetchUpsellData:', error);
      } finally {
        setLoading(false);
      }
    };

    fetchUpsellData();
  }, [userId]);

  const getUpsellSuggestions = (productId: string): UpsellProduct[] => {
    const config = upsellConfigs.find(c => c.product_id === productId);
    console.log('🔍 Looking for upsell config for product:', productId, 'found:', config);
    
    if (!config || !config.is_active || !config.suggested_products?.length) {
      return [];
    }

    const suggestions = allProducts.filter(product => 
      config.suggested_products.includes(product.id)
    );
    
    console.log('✨ Upsell suggestions for product:', productId, suggestions);
    return suggestions;
  };

  return {
    getUpsellSuggestions,
    loading
  };
};