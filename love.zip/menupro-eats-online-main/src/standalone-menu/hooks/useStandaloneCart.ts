import { useState } from "react";
import { useToast } from "@/hooks/use-toast";
import { Product, CartItem } from "../types";

export const useStandaloneCart = () => {
  const [cart, setCart] = useState<CartItem[]>([]);
  const { toast } = useToast();

  const cartTotal = cart.reduce((total, item) => total + item.totalPrice, 0);
  const cartItemsCount = cart.reduce((total, item) => total + item.quantity, 0);

  const addToCart = (product: Product, customizations?: any, quantity: number = 1) => {
    let totalPrice: number;

    if (product.isPizza && customizations?.flavors) {
      // Para pizzas, usar o preço calculado das customizações
      totalPrice = (customizations.pizzaPrice + (customizations.borderPrice || 0)) * quantity;
    } else {
      // Para produtos normais
      const basePrice = product.isPromotion && product.promotionPrice ? product.promotionPrice : product.price;
      const extrasPrice = customizations?.extras?.reduce((sum: number, extra: any) => sum + extra.price, 0) || 0;
      totalPrice = (basePrice + extrasPrice) * quantity;
    }

    const cartItem: CartItem = {
      id: `${product.id}-${Date.now()}`,
      product,
      quantity,
      customizations,
      totalPrice
    };

    setCart(prev => [...prev, cartItem]);
    
    toast({
      title: "Produto adicionado!",
      description: `${product.name} foi adicionado à sua sacola`,
    });
  };

  const updateCartItem = (itemId: string, quantity: number) => {
    if (quantity === 0) {
      setCart(prev => prev.filter(item => item.id !== itemId));
      return;
    }

    setCart(prev => prev.map(item => {
      if (item.id === itemId) {
        let newTotalPrice: number;

        if (item.product.isPizza && item.customizations?.flavors) {
          // Para pizzas
          newTotalPrice = (item.customizations.pizzaPrice + (item.customizations.borderPrice || 0)) * quantity;
        } else {
          // Para produtos normais
          const basePrice = item.product.isPromotion && item.product.promotionPrice 
            ? item.product.promotionPrice 
            : item.product.price;
          const extrasPrice = item.customizations?.extras?.reduce((sum: number, extra: any) => sum + extra.price, 0) || 0;
          newTotalPrice = (basePrice + extrasPrice) * quantity;
        }

        return { ...item, quantity, totalPrice: newTotalPrice };
      }
      return item;
    }));
  };

  return {
    cart,
    cartTotal,
    cartItemsCount,
    addToCart,
    updateCartItem
  };
};