import { useState } from "react";
import { Product } from "../types";

export const useStandaloneModals = () => {
  const [isCartOpen, setIsCartOpen] = useState(false);
  const [selectedProduct, setSelectedProduct] = useState<Product | null>(null);
  const [isCheckoutOpen, setIsCheckoutOpen] = useState(false);
  const [showUpsell, setShowUpsell] = useState<string | null>(null);

  const handleQuickAdd = (product: Product, onAddToCart: (product: Product) => void) => {
    if (product.customizable || product.isPizza) {
      setSelectedProduct(product);
    } else {
      onAddToCart(product);
    }
  };

  const handleToggleUpsell = (productId: string) => {
    setShowUpsell(showUpsell === productId ? null : productId);
  };

  const openCart = () => setIsCartOpen(true);
  const closeCart = () => setIsCartOpen(false);
  
  const openCheckout = () => {
    setIsCartOpen(false);
    setIsCheckoutOpen(true);
  };
  
  const closeCheckout = () => setIsCheckoutOpen(false);
  const closeProductModal = () => setSelectedProduct(null);

  return {
    isCartOpen,
    selectedProduct,
    isCheckoutOpen,
    showUpsell,
    handleQuickAdd,
    handleToggleUpsell,
    openCart,
    closeCart,
    openCheckout,
    closeCheckout,
    closeProductModal,
    setSelectedProduct
  };
};