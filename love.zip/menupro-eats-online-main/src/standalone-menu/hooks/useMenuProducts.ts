import { useState, useEffect } from "react";
import { supabase } from "../integrations/supabase/client";

interface Product {
  id: string;
  name: string;
  description: string | null;
  price: number;
  image: string | null;
  category: string;
  is_promotion: boolean;
  promotion_price: number | null;
  customizable: boolean;
  is_pizza: boolean;
  show_online_menu: boolean;
  allow_half_half: boolean;
  ingredients: string[] | null;
  extras: any[] | null;
  max_flavors: number | null;
  pizza_flavors: any[] | null;
  pizza_borders: any[] | null;
}

export const useMenuProducts = (slug?: string) => {
  const [products, setProducts] = useState<Product[]>([]);
  const [categories, setCategories] = useState<string[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    const fetchMenuData = async () => {
      if (!slug) {
        setLoading(false);
        return;
      }

      try {
        console.log('🔍 useMenuProducts: Buscando produtos para slug:', slug);
        
        // Usar edge function para buscar dados de forma mais confiável
        const { data, error } = await supabase.functions.invoke('get-menu-products', {
          body: { slug: slug }
        });

        if (error) {
          console.error('❌ useMenuProducts: Erro ao buscar produtos:', error);
          setError(error.message);
          setLoading(false);
          return;
        }

        if (data?.success && data?.data) {
          const { products: productsData, categories: categoriesData } = data.data;
          
          console.log('✅ useMenuProducts: Produtos recebidos:', productsData?.length || 0);
          console.log('✅ useMenuProducts: Categorias recebidas:', categoriesData);
          console.log('✅ useMenuProducts: Dados completos:', { products: productsData, categories: categoriesData });
          
          setProducts(productsData || []);
          setCategories(categoriesData || ['Todos']);
        } else {
          console.log('❌ useMenuProducts: Dados não encontrados - data:', data);
          setError('Dados não encontrados');
        }

      } catch (err) {
        console.error('Erro ao buscar dados do menu:', err);
        setError('Erro ao carregar cardápio');
      } finally {
        setLoading(false);
      }
    };

    fetchMenuData();
  }, [slug]);

  // Transformar produtos para o formato esperado
  const transformedProducts = products.map(product => ({
    id: product.id,
    name: product.name,
    description: product.description || '',
    price: Number(product.price),
    image: product.image || 'https://images.unsplash.com/photo-1565299624946-b28f40a0ca4b?w=400&h=300&fit=crop&crop=center',
    category: product.category,
    isPromotion: product.is_promotion,
    promotionPrice: product.promotion_price ? Number(product.promotion_price) : undefined,
    customizable: product.customizable,
    isPizza: product.is_pizza,
    allowHalfHalf: product.allow_half_half,
    ingredients: product.ingredients || [],
    extras: product.extras ? (Array.isArray(product.extras) ? product.extras : []) : [],
    maxFlavors: product.max_flavors || 1,
    pizzaFlavors: product.pizza_flavors ? (Array.isArray(product.pizza_flavors) ? product.pizza_flavors : []) : [],
    pizzaBorders: product.pizza_borders ? (Array.isArray(product.pizza_borders) ? product.pizza_borders : []) : []
  }));

  return {
    products: transformedProducts,
    categories,
    loading,
    error
  };
};