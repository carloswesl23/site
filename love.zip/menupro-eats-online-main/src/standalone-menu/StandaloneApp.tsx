import { Toaster } from "@/components/ui/toaster";
import { Toaster as Sonner } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { BrowserRouter, Routes, Route } from "react-router-dom";
import StandaloneMenu from "./StandaloneMenu";
import NotFound from "@/pages/NotFound";

const queryClient = new QueryClient();

const StandaloneApp = () => (
  <QueryClientProvider client={queryClient}>
    <TooltipProvider>
      <Toaster />
      <Sonner />
      <BrowserRouter>
        <Routes>
          {/* Rota principal para /:slug */}
          <Route path="/:establishmentSlug" element={<StandaloneMenu />} />
          {/* Rota para index.html */}
          <Route path="/" element={<div className="min-h-screen bg-gray-50 flex items-center justify-center">
            <div className="text-center">
              <h1 className="text-2xl font-bold text-gray-900 mb-4">Cardápio Digital</h1>
              <p className="text-gray-600">Acesse o cardápio através do link do estabelecimento</p>
            </div>
          </div>} />
          <Route path="*" element={<NotFound />} />
        </Routes>
      </BrowserRouter>
    </TooltipProvider>
  </QueryClientProvider>
);

export default StandaloneApp;