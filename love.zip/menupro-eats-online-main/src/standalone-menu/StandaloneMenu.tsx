import { useState, useEffect } from "react";
import { useParams } from "react-router-dom";

// Components
import { StandaloneMenuHeader } from "../components/standalone/StandaloneMenuHeader";
import { StandaloneCategoryTabs } from "../components/standalone/StandaloneCategoryTabs";
import { StandaloneMenuLoadingState } from "./components/StandaloneMenuLoadingState";
import { StandaloneMenuErrorState } from "./components/StandaloneMenuErrorState";
import { StandaloneProductGrid } from "./components/StandaloneProductGrid";
import { StandaloneFloatingCartButton } from "./components/StandaloneFloatingCartButton";
import { StandaloneMenuModals } from "./components/StandaloneMenuModals";
import { StoreClosedMessage } from "./components/StoreClosedMessage";

// Hooks
import { useEstablishmentData } from "./hooks/useEstablishmentData";
import { useMenuProducts } from "./hooks/useMenuProducts";
import { useMenuUpsell } from "./hooks/useMenuUpsell";
import { useStandaloneCart } from "./hooks/useStandaloneCart";
import { useStandaloneModals } from "./hooks/useStandaloneModals";

// Utils
import { monitorMenuAccess, validateEstablishmentAccess } from "@/utils/productionSecurity";
import { trackMenuView } from "@/utils/menuTracking";

export default function StandaloneMenu() {
  const { establishmentSlug } = useParams();
  const slug = establishmentSlug;
  
  // Category filter state
  const [selectedCategory, setSelectedCategory] = useState("Todos");
  
  // Data hooks
  const { establishmentData, loading: establishmentLoading } = useEstablishmentData(slug);
  const { products, categories, loading: productsLoading } = useMenuProducts(slug);
  const { getUpsellSuggestions, loading: upsellLoading } = useMenuUpsell(establishmentData?.user_id);
  
  // Cart management
  const { cart, cartTotal, cartItemsCount, addToCart, updateCartItem } = useStandaloneCart();
  
  // Modal management
  const {
    isCartOpen,
    selectedProduct,
    isCheckoutOpen,
    showUpsell,
    handleQuickAdd,
    handleToggleUpsell,
    openCart,
    closeCart,
    openCheckout,
    closeCheckout,
    closeProductModal,
    setSelectedProduct
  } = useStandaloneModals();
  
  // Security monitoring
  useEffect(() => {
    if (slug) {
      monitorMenuAccess(slug, navigator.userAgent);
    }
  }, [slug]);
  
  // Validate establishment data
  useEffect(() => {
    if (establishmentData && !validateEstablishmentAccess(slug || '', establishmentData)) {
      window.location.href = '/';
    }
  }, [establishmentData, slug]);
  
  // Track menu view when establishment data is loaded
  useEffect(() => {
    if (establishmentData?.user_id && slug) {
      trackMenuView(slug, establishmentData.user_id);
    }
  }, [establishmentData?.user_id, slug]);

  // Filter products by category
  const filteredProducts = selectedCategory === "Todos" 
    ? products 
    : products.filter(product => product.category === selectedCategory);

  // Handle quick add with modal logic
  const handleProductQuickAdd = (product: any) => {
    handleQuickAdd(product, addToCart);
  };

  // Loading state
  if (establishmentLoading || productsLoading || upsellLoading) {
    return <StandaloneMenuLoadingState slug={slug} />;
  }

  // Error state
  if (!establishmentData) {
    return <StandaloneMenuErrorState slug={slug} />;
  }

  // Store closed state
  if (establishmentData.is_open === false) {
    return <StoreClosedMessage businessName={establishmentData.business_name} />;
  }

  // Debug info
  if (import.meta.env.DEV) {
    console.log('🚀 StandaloneMenu render - slug:', slug);
    console.log('🏪 StandaloneMenu render - establishmentData:', establishmentData);
    console.log('📦 StandaloneMenu render - products count:', products.length);
    console.log('📂 StandaloneMenu render - categories:', categories);
    console.log('🎯 StandaloneMenu render - selectedCategory:', selectedCategory);
    console.log('🔍 StandaloneMenu render - filteredProducts count:', filteredProducts.length);
    console.log('⏳ StandaloneMenu render - loading states:', { establishmentLoading, productsLoading, upsellLoading });
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <StandaloneMenuHeader 
        establishmentName={establishmentData.business_name}
        image={establishmentData.business_logo || "https://images.unsplash.com/photo-1555396273-367ea4eb4db5?w=800&h=400&fit=crop&crop=center"}
        rating={4.8}
        deliveryTime="30-45 min"
        address={establishmentData.business_address || "Endereço não informado"}
        whatsappNumber={establishmentData.business_phone || "5511999999999"}
        instagramUrl={establishmentData.instagram_url || "https://instagram.com/estabelecimento"}
      />
      
      <div className="container mx-auto px-4 py-6 max-w-6xl">
        <div className="mb-4">
          <StandaloneCategoryTabs 
            categories={categories}
            selectedCategory={selectedCategory}
            onCategoryChange={setSelectedCategory}
          />
        </div>

        <StandaloneProductGrid
          products={filteredProducts}
          onQuickAdd={handleProductQuickAdd}
          onCustomize={setSelectedProduct}
          showUpsell={showUpsell}
          onToggleUpsell={handleToggleUpsell}
          getUpsellSuggestions={getUpsellSuggestions}
        />
      </div>

      <StandaloneFloatingCartButton
        cartItemsCount={cartItemsCount}
        onOpenCart={openCart}
      />

      <StandaloneMenuModals
        isCartOpen={isCartOpen}
        onCloseCart={closeCart}
        cart={cart}
        cartTotal={cartTotal}
        onUpdateCartItem={updateCartItem}
        onOpenCheckout={openCheckout}
        selectedProduct={selectedProduct}
        onCloseProductModal={closeProductModal}
        onAddToCart={addToCart}
        isCheckoutOpen={isCheckoutOpen}
        onCloseCheckout={closeCheckout}
        establishmentData={establishmentData}
      />
    </div>
  );
}