import { createClient } from '@supabase/supabase-js';

const SUPABASE_URL = "https://mzhyxympbmjjergvbwfa.supabase.co";
const SUPABASE_PUBLISHABLE_KEY = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Im16aHl4eW1wYm1qamVyZ3Zid2ZhIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NDk0ODAzMjIsImV4cCI6MjA2NTA1NjMyMn0.FKNhn4qozN91o6a762REWH9LWVQuVRhVQuhrPFUgTqo";

export const supabase = createClient(SUPABASE_URL, SUPABASE_PUBLISHABLE_KEY);