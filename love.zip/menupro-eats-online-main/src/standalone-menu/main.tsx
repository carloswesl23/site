import { createRoot } from 'react-dom/client'
import StandaloneApp from './StandaloneApp.tsx'
import './standalone.css'

createRoot(document.getElementById("root")!).render(<StandaloneApp />);