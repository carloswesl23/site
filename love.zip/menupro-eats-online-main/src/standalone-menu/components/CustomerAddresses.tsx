import { useState, useEffect } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { MapPin, Plus, Edit, Trash2, Star } from "lucide-react";
import { supabase } from "../integrations/supabase/client";
import { useToast } from "@/hooks/use-toast";

interface CustomerAddressesProps {
  customerId: string;
  tenantId: string;
}

export const CustomerAddresses = ({ customerId, tenantId }: CustomerAddressesProps) => {
  const { toast } = useToast();
  const [addresses, setAddresses] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [editingAddress, setEditingAddress] = useState<any>(null);
  const [formData, setFormData] = useState({
    label: 'Endereço',
    street: '',
    number: '',
    complement: '',
    district: '',
    city: '',
    state: 'PA',
    zipcode: '',
    is_default: false
  });

  const loadAddresses = async () => {
    try {
      setLoading(true);
      const { data, error } = await supabase
        .from('customer_addresses')
        .select('*')
        .eq('customer_id', customerId)
        .order('is_default', { ascending: false })
        .order('created_at', { ascending: false });
        
      if (error) throw error;
      setAddresses(data || []);
    } catch (error) {
      console.error('Erro ao carregar endereços:', error);
      toast({
        title: "Erro",
        description: "Não foi possível carregar os endereços",
        variant: "destructive"
      });
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadAddresses();
  }, [customerId]);

  const resetForm = () => {
    setFormData({
      label: 'Endereço',
      street: '',
      number: '',
      complement: '',
      district: '',
      city: '',
      state: 'PA',
      zipcode: '',
      is_default: false
    });
    setEditingAddress(null);
  };

  const handleEdit = (address: any) => {
    setEditingAddress(address);
    setFormData({
      label: address.label || 'Endereço',
      street: address.street || '',
      number: address.number || '',
      complement: address.complement || '',
      district: address.district || '',
      city: address.city || '',
      state: address.state || 'PA',
      zipcode: address.zipcode || '',
      is_default: address.is_default || false
    });
    setIsDialogOpen(true);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    try {
      if (editingAddress) {
        // Atualizar endereço existente
        const { error } = await supabase
          .from('customer_addresses')
          .update(formData)
          .eq('id', editingAddress.id);
          
        if (error) throw error;
        
        toast({
          title: "Sucesso",
          description: "Endereço atualizado com sucesso"
        });
      } else {
        // Criar novo endereço
        const { error } = await supabase
          .from('customer_addresses')
          .insert({
            ...formData,
            tenant_id: tenantId,
            customer_id: customerId
          });
          
        if (error) throw error;
        
        toast({
          title: "Sucesso",
          description: "Endereço adicionado com sucesso"
        });
      }
      
      setIsDialogOpen(false);
      resetForm();
      loadAddresses();
    } catch (error) {
      console.error('Erro ao salvar endereço:', error);
      toast({
        title: "Erro",
        description: "Não foi possível salvar o endereço",
        variant: "destructive"
      });
    }
  };

  const handleSetDefault = async (addressId: string) => {
    try {
      // Primeiro, remover o padrão de todos os endereços
      await supabase
        .from('customer_addresses')
        .update({ is_default: false })
        .eq('customer_id', customerId);
        
      // Depois, definir o novo padrão
      const { error } = await supabase
        .from('customer_addresses')
        .update({ is_default: true })
        .eq('id', addressId);
        
      if (error) throw error;
      
      toast({
        title: "Sucesso",
        description: "Endereço padrão atualizado"
      });
      
      loadAddresses();
    } catch (error) {
      console.error('Erro ao definir endereço padrão:', error);
      toast({
        title: "Erro",
        description: "Não foi possível definir como padrão",
        variant: "destructive"
      });
    }
  };

  const handleDelete = async (addressId: string) => {
    if (!confirm('Tem certeza que deseja excluir este endereço?')) return;
    
    try {
      const { error } = await supabase
        .from('customer_addresses')
        .delete()
        .eq('id', addressId);
        
      if (error) throw error;
      
      toast({
        title: "Sucesso",
        description: "Endereço excluído com sucesso"
      });
      
      loadAddresses();
    } catch (error) {
      console.error('Erro ao excluir endereço:', error);
      toast({
        title: "Erro",
        description: "Não foi possível excluir o endereço",
        variant: "destructive"
      });
    }
  };

  const formatZipCode = (value: string) => {
    const numbers = value.replace(/\D/g, '');
    if (numbers.length <= 5) {
      return numbers;
    }
    return numbers.replace(/(\d{5})(\d{1,3})/, '$1-$2');
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-[200px]">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Header com botão adicionar */}
      <div className="flex justify-between items-center">
        <h2 className="text-xl font-semibold">Meus Endereços</h2>
        <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
          <DialogTrigger asChild>
            <Button onClick={resetForm}>
              <Plus className="w-4 h-4 mr-2" />
              Adicionar Endereço
            </Button>
          </DialogTrigger>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>
                {editingAddress ? 'Editar Endereço' : 'Novo Endereço'}
              </DialogTitle>
            </DialogHeader>
            
            <form onSubmit={handleSubmit} className="space-y-4">
              <div>
                <Label htmlFor="label">Nome do endereço</Label>
                <Input
                  id="label"
                  value={formData.label}
                  onChange={(e) => setFormData(prev => ({ ...prev, label: e.target.value }))}
                  placeholder="Ex: Casa, Trabalho..."
                />
              </div>
              
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="zipcode">CEP</Label>
                  <Input
                    id="zipcode"
                    value={formData.zipcode}
                    onChange={(e) => setFormData(prev => ({ ...prev, zipcode: formatZipCode(e.target.value) }))}
                    placeholder="00000-000"
                    maxLength={9}
                  />
                </div>
                <div>
                  <Label htmlFor="state">Estado</Label>
                  <Input
                    id="state"
                    value={formData.state}
                    onChange={(e) => setFormData(prev => ({ ...prev, state: e.target.value }))}
                    placeholder="PA"
                  />
                </div>
              </div>
              
              <div>
                <Label htmlFor="street">Rua/Avenida *</Label>
                <Input
                  id="street"
                  value={formData.street}
                  onChange={(e) => setFormData(prev => ({ ...prev, street: e.target.value }))}
                  placeholder="Nome da rua"
                  required
                />
              </div>
              
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="number">Número</Label>
                  <Input
                    id="number"
                    value={formData.number}
                    onChange={(e) => setFormData(prev => ({ ...prev, number: e.target.value }))}
                    placeholder="123"
                  />
                </div>
                <div>
                  <Label htmlFor="complement">Complemento</Label>
                  <Input
                    id="complement"
                    value={formData.complement}
                    onChange={(e) => setFormData(prev => ({ ...prev, complement: e.target.value }))}
                    placeholder="Apto, Bloco..."
                  />
                </div>
              </div>
              
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="district">Bairro *</Label>
                  <Input
                    id="district"
                    value={formData.district}
                    onChange={(e) => setFormData(prev => ({ ...prev, district: e.target.value }))}
                    placeholder="Nome do bairro"
                    required
                  />
                </div>
                <div>
                  <Label htmlFor="city">Cidade *</Label>
                  <Input
                    id="city"
                    value={formData.city}
                    onChange={(e) => setFormData(prev => ({ ...prev, city: e.target.value }))}
                    placeholder="Nome da cidade"
                    required
                  />
                </div>
              </div>
              
              <div className="flex items-center space-x-2">
                <input
                  type="checkbox"
                  id="is_default"
                  checked={formData.is_default}
                  onChange={(e) => setFormData(prev => ({ ...prev, is_default: e.target.checked }))}
                  className="rounded border-gray-300"
                />
                <Label htmlFor="is_default" className="text-sm">
                  Definir como endereço padrão
                </Label>
              </div>
              
              <div className="flex gap-2">
                <Button type="submit" className="flex-1">
                  {editingAddress ? 'Atualizar' : 'Adicionar'}
                </Button>
                <Button 
                  type="button" 
                  variant="outline" 
                  onClick={() => setIsDialogOpen(false)}
                >
                  Cancelar
                </Button>
              </div>
            </form>
          </DialogContent>
        </Dialog>
      </div>

      {/* Lista de endereços */}
      <div className="space-y-4">
        {addresses.map((address) => (
          <Card key={address.id}>
            <CardContent className="p-6">
              <div className="flex justify-between items-start">
                <div className="space-y-2">
                  <div className="flex items-center gap-2">
                    <MapPin className="w-4 h-4 text-muted-foreground" />
                    <h3 className="font-medium">{address.label}</h3>
                    {address.is_default && (
                      <Badge variant="default">
                        <Star className="w-3 h-3 mr-1" />
                        Padrão
                      </Badge>
                    )}
                  </div>
                  
                  <div className="text-sm text-muted-foreground">
                    <p>{address.street}, {address.number}</p>
                    {address.complement && <p>{address.complement}</p>}
                    <p>{address.district}, {address.city} - {address.state}</p>
                    {address.zipcode && <p>CEP: {address.zipcode}</p>}
                  </div>
                </div>
                
                <div className="flex gap-1">
                  {!address.is_default && (
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => handleSetDefault(address.id)}
                      title="Definir como padrão"
                    >
                      <Star className="w-4 h-4" />
                    </Button>
                  )}
                  
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => handleEdit(address)}
                  >
                    <Edit className="w-4 h-4" />
                  </Button>
                  
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => handleDelete(address.id)}
                  >
                    <Trash2 className="w-4 h-4" />
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
        
        {addresses.length === 0 && (
          <Card>
            <CardContent className="text-center py-12">
              <MapPin className="w-12 h-12 mx-auto text-muted-foreground mb-4" />
              <h3 className="text-lg font-semibold mb-2">Nenhum endereço cadastrado</h3>
              <p className="text-muted-foreground mb-4">
                Adicione endereços para facilitar seus próximos pedidos.
              </p>
              <Button onClick={() => setIsDialogOpen(true)}>
                <Plus className="w-4 h-4 mr-2" />
                Adicionar Primeiro Endereço
              </Button>
            </CardContent>
          </Card>
        )}
      </div>
    </div>
  );
};