import { useState } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent } from "@/components/ui/card";
import { Checkbox } from "@/components/ui/checkbox";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Plus, Minus } from "lucide-react";
import { StandalonePizzaModal } from "./StandalonePizzaModal";

interface Product {
  id: string;
  name: string;
  description: string;
  price: number;
  image: string;
  category: string;
  isPromotion: boolean;
  promotionPrice?: number;
  customizable?: boolean;
  ingredients?: string[];
  extras?: { name: string; price: number; is_free?: boolean }[];
  isPizza?: boolean;
  pizzaFlavors?: any[];
  pizzaBorders?: any[];
  maxFlavors?: number;
}

interface StandaloneProductModalProps {
  product: Product | null;
  isOpen: boolean;
  onClose: () => void;
  onAddToCart: (product: Product, customizations?: any, quantity?: number) => void;
}

export const StandaloneProductModal = ({ product, isOpen, onClose, onAddToCart }: StandaloneProductModalProps) => {
  const [quantity, setQuantity] = useState(1);
  const [selectedIngredients, setSelectedIngredients] = useState<string[]>([]);
  const [selectedExtras, setSelectedExtras] = useState<{ name: string; price: number }[]>([]);
  const [selectedBread, setSelectedBread] = useState("");
  const [notes, setNotes] = useState("");

  if (!product) return null;

  // Se é pizza, usar o StandalonePizzaModal
  if (product.isPizza) {
    return (
      <StandalonePizzaModal
        product={product}
        isOpen={isOpen}
        onClose={onClose}
        onAddToCart={onAddToCart}
      />
    );
  }

  const handleIngredientToggle = (ingredient: string) => {
    setSelectedIngredients(prev => 
      prev.includes(ingredient) 
        ? prev.filter(item => item !== ingredient)
        : [...prev, ingredient]
    );
  };

  const handleExtraToggle = (extra: { name: string; price: number }) => {
    setSelectedExtras(prev => 
      prev.some(item => item.name === extra.name)
        ? prev.filter(item => item.name !== extra.name)
        : [...prev, extra]
    );
  };

  const calculateTotal = () => {
    const basePrice = product.isPromotion && product.promotionPrice ? product.promotionPrice : product.price;
    const extrasPrice = selectedExtras.reduce((sum, extra) => sum + extra.price, 0);
    return (basePrice + extrasPrice) * quantity;
  };

  const handleAddToCart = () => {
    const customizations = {
      bread: selectedBread,
      ingredients: selectedIngredients,
      extras: selectedExtras,
      notes: notes
    };

    onAddToCart(product, customizations, quantity);
    onClose();
    
    // Reset form
    setQuantity(1);
    setSelectedIngredients([]);
    setSelectedExtras([]);
    setSelectedBread("");
    setNotes("");
  };

  const breadOptions = ["Pão tradicional", "Pão integral", "Pão australiano", "Pão brioche"];

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>{product.name}</DialogTitle>
        </DialogHeader>

        <div className="space-y-6">
          <div className="flex gap-4">
            <img
              src={product.image}
              alt={product.name}
              className="w-32 h-32 object-cover rounded-lg"
            />
            <div className="flex-1">
              <p className="text-gray-600 mb-2">{product.description}</p>
              <div className="flex items-center gap-2">
                {product.isPromotion && product.promotionPrice ? (
                  <>
                    <span className="text-2xl font-bold text-green-600">
                      R$ {product.promotionPrice.toFixed(2)}
                    </span>
                    <span className="text-lg text-gray-500 line-through">
                      R$ {product.price.toFixed(2)}
                    </span>
                    <Badge className="bg-red-500">Promoção</Badge>
                  </>
                ) : (
                  <span className="text-2xl font-bold text-gray-900">
                    R$ {product.price.toFixed(2)}
                  </span>
                )}
              </div>
            </div>
          </div>

          {/* Tipo de pão */}
          {product.customizable && (
            <Card>
              <CardContent className="p-4">
                <h3 className="font-semibold mb-3">Escolha o pão:</h3>
                <div className="grid grid-cols-2 gap-2">
                  {breadOptions.map((bread) => (
                    <Label
                      key={bread}
                      className={`flex items-center space-x-2 p-3 rounded-lg border cursor-pointer transition-colors ${
                        selectedBread === bread 
                          ? 'border-orange-500 bg-orange-50' 
                          : 'border-gray-200 hover:border-gray-300'
                      }`}
                    >
                      <input
                        type="radio"
                        name="bread"
                        value={bread}
                        checked={selectedBread === bread}
                        onChange={(e) => setSelectedBread(e.target.value)}
                        className="sr-only"
                      />
                      <span className="text-sm">{bread}</span>
                    </Label>
                  ))}
                </div>
              </CardContent>
            </Card>
          )}

          {/* Ingredientes */}
          {product.ingredients && product.ingredients.length > 0 && (
            <Card>
              <CardContent className="p-4">
                <h3 className="font-semibold mb-3">Ingredientes inclusos:</h3>
                <div className="grid grid-cols-2 gap-2">
                  {product.ingredients.map((ingredient) => (
                    <Label
                      key={ingredient}
                      className="flex items-center space-x-2 cursor-pointer"
                    >
                      <Checkbox
                        checked={selectedIngredients.includes(ingredient)}
                        onCheckedChange={() => handleIngredientToggle(ingredient)}
                      />
                      <span className="text-sm">{ingredient}</span>
                    </Label>
                  ))}
                </div>
              </CardContent>
            </Card>
          )}

          {/* Extras */}
          {product.extras && product.extras.length > 0 && (
            <Card>
              <CardContent className="p-4">
                <h3 className="font-semibold mb-3">Extras (adicionais):</h3>
                <div className="space-y-2">
                  {product.extras.map((extra) => (
                    <Label
                      key={extra.name}
                      className="flex items-center justify-between p-3 rounded-lg border cursor-pointer hover:border-gray-300"
                    >
                      <div className="flex items-center space-x-2">
                        <Checkbox
                          checked={selectedExtras.some(item => item.name === extra.name)}
                          onCheckedChange={() => handleExtraToggle(extra)}
                        />
                        <span className="text-sm">{extra.name}</span>
                      </div>
                      <span className="text-sm font-medium text-green-600">
                        +R$ {extra.price.toFixed(2)}
                      </span>
                    </Label>
                  ))}
                </div>
              </CardContent>
            </Card>
          )}

          {/* Observações */}
          <Card>
            <CardContent className="p-4">
              <Label htmlFor="notes" className="font-semibold">
                Observações (opcional):
              </Label>
              <Textarea
                id="notes"
                value={notes}
                onChange={(e) => setNotes(e.target.value)}
                placeholder="Ex: Sem cebola, bem passado, etc..."
                className="mt-2 resize-none"
                rows={3}
              />
            </CardContent>
          </Card>

          {/* Quantidade e Preço */}
          <div className="flex items-center justify-between p-4 bg-gray-50 rounded-lg">
            <div className="flex items-center gap-3">
              <span className="font-medium">Quantidade:</span>
              <div className="flex items-center gap-2">
                <Button
                  size="sm"
                  variant="outline"
                  onClick={() => setQuantity(Math.max(1, quantity - 1))}
                  className="h-8 w-8 p-0"
                >
                  <Minus className="w-3 h-3" />
                </Button>
                <span className="w-8 text-center font-medium">{quantity}</span>
                <Button
                  size="sm"
                  variant="outline"
                  onClick={() => setQuantity(quantity + 1)}
                  className="h-8 w-8 p-0"
                >
                  <Plus className="w-3 h-3" />
                </Button>
              </div>
            </div>
            <div className="text-right">
              <div className="text-sm text-gray-600">Total:</div>
              <div className="text-xl font-bold text-orange-600">
                R$ {calculateTotal().toFixed(2)}
              </div>
            </div>
          </div>

          <Button
            onClick={handleAddToCart}
            className="w-full bg-orange-500 hover:bg-orange-600 h-12 text-lg"
          >
            Adicionar à sacola
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
};