import { StandaloneCartDrawer } from "./StandaloneCartDrawer";
import { StandaloneProductModal } from "./StandaloneProductModal";
import { StandalonePizzaModal } from "./StandalonePizzaModal";
import { StandaloneCheckoutModal } from "./StandaloneCheckoutModal";
import { Product, CartItem } from "../types";

interface EstablishmentData {
  business_name: string;
  business_phone: string;
  user_id: string;
  pix_key?: string;
  pix_beneficiary_name?: string;
  pix_enabled?: boolean;
  accept_cash?: boolean;
  accept_credit_on_delivery?: boolean;
  combine_payment_via_whatsapp?: boolean;
}

interface StandaloneMenuModalsProps {
  // Cart Drawer props
  isCartOpen: boolean;
  onCloseCart: () => void;
  cart: CartItem[];
  cartTotal: number;
  onUpdateCartItem: (itemId: string, quantity: number) => void;
  onOpenCheckout: () => void;
  
  // Product Modal props
  selectedProduct: Product | null;
  onCloseProductModal: () => void;
  onAddToCart: (product: Product, customizations?: any, quantity?: number) => void;
  
  // Checkout Modal props
  isCheckoutOpen: boolean;
  onCloseCheckout: () => void;
  establishmentData: EstablishmentData;
}

export const StandaloneMenuModals = ({
  isCartOpen,
  onCloseCart,
  cart,
  cartTotal,
  onUpdateCartItem,
  onOpenCheckout,
  selectedProduct,
  onCloseProductModal,
  onAddToCart,
  isCheckoutOpen,
  onCloseCheckout,
  establishmentData
}: StandaloneMenuModalsProps) => {
  return (
    <>
      <StandaloneCartDrawer
        isOpen={isCartOpen}
        onClose={onCloseCart}
        cart={cart}
        onUpdateItem={onUpdateCartItem}
        onCheckout={onOpenCheckout}
        total={cartTotal}
      />

      {selectedProduct?.isPizza ? (
        <StandalonePizzaModal
          product={selectedProduct}
          isOpen={!!selectedProduct}
          onClose={onCloseProductModal}
          onAddToCart={onAddToCart}
        />
      ) : (
        <StandaloneProductModal
          product={selectedProduct}
          isOpen={!!selectedProduct}
          onClose={onCloseProductModal}
          onAddToCart={onAddToCart}
        />
      )}

      <StandaloneCheckoutModal
        isOpen={isCheckoutOpen}
        onClose={onCloseCheckout}
        cart={cart}
        total={cartTotal}
        establishmentName={establishmentData.business_name}
        establishmentPhone={establishmentData.business_phone || ""}
        establishmentData={{
          user_id: establishmentData.user_id,
          pix_key: establishmentData.pix_key || null,
          pix_beneficiary_name: establishmentData.pix_beneficiary_name || null,
          pix_enabled: establishmentData.pix_enabled,
          accept_cash: establishmentData.accept_cash,
          accept_credit_on_delivery: establishmentData.accept_credit_on_delivery,
          combine_payment_via_whatsapp: establishmentData.combine_payment_via_whatsapp
        }}
      />
    </>
  );
};