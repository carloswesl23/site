import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { ShoppingCart } from "lucide-react";

interface StandaloneFloatingCartButtonProps {
  cartItemsCount: number;
  onOpenCart: () => void;
}

export const StandaloneFloatingCartButton = ({ 
  cartItemsCount, 
  onOpenCart 
}: StandaloneFloatingCartButtonProps) => {
  if (cartItemsCount === 0) return null;

  return (
    <div className="fixed bottom-4 right-4 z-50">
      <Button
        type="button"
        onClick={onOpenCart}
        className="h-14 w-14 rounded-full bg-orange-500 hover:bg-orange-600 shadow-lg"
        size="icon"
      >
        <div className="relative">
          <ShoppingCart className="w-6 h-6" />
          <Badge className="absolute -top-2 -right-2 bg-red-500 text-white text-xs min-w-[20px] h-5 flex items-center justify-center rounded-full">
            {cartItemsCount}
          </Badge>
        </div>
      </Button>
    </div>
  );
};