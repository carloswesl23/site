import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { User, Phone, Save } from "lucide-react";
import { supabase } from "../integrations/supabase/client";
import { useToast } from "@/hooks/use-toast";

interface CustomerProfileProps {
  customer: any;
  onUpdate: (customer: any) => void;
}

export const CustomerProfile = ({ customer, onUpdate }: CustomerProfileProps) => {
  const { toast } = useToast();
  const [loading, setLoading] = useState(false);
  const [formData, setFormData] = useState({
    name: customer.name || '',
    phone_e164: customer.phone_e164 || ''
  });

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!formData.name.trim()) {
      toast({
        title: "Erro",
        description: "Nome é obrigatório",
        variant: "destructive"
      });
      return;
    }

    try {
      setLoading(true);
      
      const { error } = await supabase
        .from('customers')
        .update({
          name: formData.name.trim(),
          phone_e164: formData.phone_e164.trim(),
          updated_at: new Date().toISOString()
        })
        .eq('id', customer.id);
        
      if (error) throw error;
      
      const updatedCustomer = {
        ...customer,
        name: formData.name.trim(),
        phone_e164: formData.phone_e164.trim()
      };
      
      onUpdate(updatedCustomer);
      
      toast({
        title: "Sucesso",
        description: "Seus dados foram atualizados com sucesso"
      });
    } catch (error) {
      console.error('Erro ao atualizar perfil:', error);
      toast({
        title: "Erro",
        description: "Não foi possível atualizar seus dados",
        variant: "destructive"
      });
    } finally {
      setLoading(false);
    }
  };

  const formatPhoneForDisplay = (phone: string) => {
    // Remove +55 e formata para exibição
    const cleaned = phone.replace(/^\+55/, '');
    if (cleaned.length === 11) {
      return cleaned.replace(/(\d{2})(\d{5})(\d{4})/, '($1) $2-$3');
    }
    return phone;
  };

  const normalizePhoneInput = (input: string) => {
    // Remove todos os caracteres não numéricos
    const numbers = input.replace(/\D/g, '');
    
    // Se começa com 55, mantém
    if (numbers.startsWith('55') && numbers.length === 13) {
      return `+${numbers}`;
    }
    
    // Se tem 11 dígitos, adiciona +55
    if (numbers.length === 11) {
      return `+55${numbers}`;
    }
    
    // Se tem 10 dígitos, adiciona +55 e o 9
    if (numbers.length === 10) {
      return `+55${numbers.substring(0, 2)}9${numbers.substring(2)}`;
    }
    
    return `+55${numbers}`;
  };

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <User className="w-5 h-5" />
            Meus Dados Pessoais
          </CardTitle>
        </CardHeader>
        <CardContent>
          <form onSubmit={handleSubmit} className="space-y-6">
            <div className="space-y-4">
              <div>
                <Label htmlFor="name">Nome completo *</Label>
                <Input
                  id="name"
                  value={formData.name}
                  onChange={(e) => setFormData(prev => ({ ...prev, name: e.target.value }))}
                  placeholder="Seu nome completo"
                  required
                />
              </div>
              
              <div>
                <Label htmlFor="phone">Telefone/WhatsApp *</Label>
                <div className="relative">
                  <Phone className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-muted-foreground" />
                  <Input
                    id="phone"
                    value={formatPhoneForDisplay(formData.phone_e164)}
                    onChange={(e) => {
                      const normalized = normalizePhoneInput(e.target.value);
                      setFormData(prev => ({ ...prev, phone_e164: normalized }));
                    }}
                    placeholder="(11) 99999-9999"
                    className="pl-10"
                    required
                  />
                </div>
                <p className="text-xs text-muted-foreground mt-1">
                  Usado para identificar você nos próximos pedidos
                </p>
              </div>
            </div>
            
            <div className="pt-4 border-t">
              <Button 
                type="submit" 
                disabled={loading}
                className="w-full"
              >
                <Save className="w-4 h-4 mr-2" />
                {loading ? 'Salvando...' : 'Salvar Alterações'}
              </Button>
            </div>
          </form>
        </CardContent>
      </Card>
      
      {/* Informações da conta */}
      <Card>
        <CardHeader>
          <CardTitle>Informações da Conta</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-3 text-sm">
            <div className="flex justify-between">
              <span className="text-muted-foreground">Cliente desde:</span>
              <span>{new Date(customer.created_at).toLocaleDateString('pt-BR')}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-muted-foreground">Última atualização:</span>
              <span>{new Date(customer.updated_at).toLocaleDateString('pt-BR')}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-muted-foreground">ID do cliente:</span>
              <span className="font-mono text-xs">{customer.id.substring(0, 8)}...</span>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};