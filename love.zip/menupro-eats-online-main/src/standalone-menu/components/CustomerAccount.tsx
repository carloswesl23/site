import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { User, MapPin, ShoppingBag, ArrowLeft } from "lucide-react";
import { CustomerOrders } from "./CustomerOrders";
import { CustomerAddresses } from "./CustomerAddresses";
import { CustomerProfile } from "./CustomerProfile";
import { supabase } from "../integrations/supabase/client";

interface CustomerAccountProps {
  establishmentSlug: string;
  customerId?: string;
  customerPhone?: string;
  onBack: () => void;
}

export const CustomerAccount = ({ 
  establishmentSlug, 
  customerId, 
  customerPhone,
  onBack 
}: CustomerAccountProps) => {
  const [customer, setCustomer] = useState<any>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const loadCustomer = async () => {
      if (!customerId && !customerPhone) return;
      
      try {
        setLoading(true);
        
        // Se temos customer ID, buscar por ID
        if (customerId) {
          const { data, error } = await supabase
            .from('customers')
            .select('*')
            .eq('id', customerId)
            .single();
            
          if (error) throw error;
          setCustomer(data);
        } 
        // Se temos apenas o telefone, buscar pelo telefone
        else if (customerPhone) {
          const { data: establishmentData } = await supabase
            .from('establishment_settings')
            .select('user_id')
            .eq('online_menu_slug', establishmentSlug)
            .single();
            
          if (establishmentData) {
            const { data, error } = await supabase
              .from('customers')
              .select('*')
              .eq('tenant_id', establishmentData.user_id)
              .eq('phone_e164', customerPhone)
              .single();
              
            if (error) throw error;
            setCustomer(data);
          }
        }
      } catch (error) {
        console.error('Erro ao carregar dados do cliente:', error);
      } finally {
        setLoading(false);
      }
    };

    loadCustomer();
  }, [customerId, customerPhone, establishmentSlug]);

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-[400px]">
        <div className="text-center space-y-2">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary mx-auto"></div>
          <p className="text-sm text-muted-foreground">Carregando dados...</p>
        </div>
      </div>
    );
  }

  if (!customer) {
    return (
      <div className="text-center space-y-4 p-8">
        <h2 className="text-xl font-semibold">Cliente não encontrado</h2>
        <p className="text-muted-foreground">
          Não foi possível encontrar seus dados. Faça um pedido primeiro para criar seu perfil.
        </p>
        <Button onClick={onBack} variant="outline">
          <ArrowLeft className="w-4 h-4 mr-2" />
          Voltar ao Menu
        </Button>
      </div>
    );
  }

  return (
    <div className="max-w-4xl mx-auto space-y-6">
      {/* Header */}
      <Card>
        <CardHeader>
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="p-2 bg-primary/10 rounded-full">
                <User className="w-6 h-6 text-primary" />
              </div>
              <div>
                <CardTitle>Minha Conta</CardTitle>
                <p className="text-sm text-muted-foreground">
                  Olá, {customer.name}!
                </p>
              </div>
            </div>
            <Button onClick={onBack} variant="outline" size="sm">
              <ArrowLeft className="w-4 h-4 mr-2" />
              Voltar
            </Button>
          </div>
        </CardHeader>
      </Card>

      {/* Tabs */}
      <Tabs defaultValue="orders" className="space-y-6">
        <TabsList className="grid w-full grid-cols-3">
          <TabsTrigger value="orders" className="flex items-center gap-2">
            <ShoppingBag className="w-4 h-4" />
            Meus Pedidos
          </TabsTrigger>
          <TabsTrigger value="addresses" className="flex items-center gap-2">
            <MapPin className="w-4 h-4" />
            Endereços
          </TabsTrigger>
          <TabsTrigger value="profile" className="flex items-center gap-2">
            <User className="w-4 h-4" />
            Meus Dados
          </TabsTrigger>
        </TabsList>

        <TabsContent value="orders">
          <CustomerOrders 
            customerId={customer.id}
            tenantId={customer.tenant_id}
          />
        </TabsContent>

        <TabsContent value="addresses">
          <CustomerAddresses 
            customerId={customer.id}
            tenantId={customer.tenant_id}
          />
        </TabsContent>

        <TabsContent value="profile">
          <CustomerProfile 
            customer={customer}
            onUpdate={setCustomer}
          />
        </TabsContent>
      </Tabs>
    </div>
  );
};