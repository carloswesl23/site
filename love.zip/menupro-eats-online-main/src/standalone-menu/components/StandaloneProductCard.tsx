import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Plus, Settings, Pizza } from "lucide-react";
import { useIsMobile } from "@/hooks/use-mobile";
import { UpsellSuggestions } from "@/components/OnlineMenu/UpsellSuggestions";

interface Product {
  id: string;
  name: string;
  description: string;
  price: number;
  image: string;
  category: string;
  isPromotion: boolean;
  promotionPrice?: number;
  customizable?: boolean;
  isPizza?: boolean;
  allowHalfHalf?: boolean;
  ingredients?: string[];
  extras?: { name: string; price: number; is_free?: boolean }[];
  maxFlavors?: number;
  pizzaFlavors?: { name: string; price: number; ingredients: string[] }[];
  pizzaBorders?: { name: string; price: number; is_free?: boolean }[];
}

interface StandaloneProductCardProps {
  product: Product;
  onQuickAdd: (product: Product) => void;
  onCustomize: (product: Product) => void;
  showUpsell: boolean;
  onToggleUpsell: () => void;
  upsellSuggestions?: Array<{
    id: string;
    name: string;
    price: number;
    image: string | null;
  }>;
}

export const StandaloneProductCard = ({ 
  product, 
  onQuickAdd, 
  onCustomize, 
  showUpsell, 
  onToggleUpsell,
  upsellSuggestions = []
}: StandaloneProductCardProps) => {
  const displayPrice = product.isPromotion && product.promotionPrice ? product.promotionPrice : product.price;
  const isMobile = useIsMobile();

  const handleQuickAdd = () => {
    onQuickAdd(product);
    // Mostrar upsell automaticamente após adicionar produto se houver sugestões
    if (upsellSuggestions.length > 0) {
      onToggleUpsell();
    }
  };

  return (
    <Card className="overflow-hidden hover:shadow-lg transition-shadow h-full flex flex-col">
      {/* Imagem do produto */}
      <div className="relative">
        <img
          src={product.image}
          alt={product.name}
          className="w-full h-48 object-cover"
        />
        {product.isPromotion && (
          <Badge className="absolute top-1 left-1 bg-red-500 text-white">
            Promoção
          </Badge>
        )}
        {product.isPizza && (
          <Badge className="absolute top-1 right-1 bg-orange-500 text-white">
            <Pizza className="w-3 h-3 mr-1" />
            Pizza
          </Badge>
        )}
      </div>
      
      {/* Conteúdo do card */}
      <CardContent className="p-4 flex flex-col flex-grow">
        {/* Nome do produto */}
        <h3 className="font-semibold text-lg mb-2 line-clamp-2 min-h-[3.5rem] flex items-center">
          {product.name}
        </h3>
        
        {/* Descrição do produto */}
        <p className="text-gray-600 text-sm mb-4 line-clamp-2 min-h-[2.5rem] flex-grow">
          {product.description}
        </p>
        
        {/* Preço */}
        <div className="mb-4">
          {product.isPromotion && product.promotionPrice ? (
            <div className="flex items-center gap-2 justify-center">
              <span className="font-bold text-green-600 text-xl">
                R$ {product.promotionPrice.toFixed(2)}
              </span>
              <span className="text-gray-500 line-through text-sm">
                R$ {product.price.toFixed(2)}
              </span>
            </div>
          ) : (
            <div className="text-center">
              <span className="font-bold text-gray-900 text-xl">
                R$ {product.price.toFixed(2)}
              </span>
            </div>
          )}
        </div>

        {/* Botões de ação */}
        <div className="mb-4">
          {product.customizable || product.isPizza ? (
            <div className="flex gap-2">
              <Button
                variant="outline"
                size="sm"
                onClick={() => onCustomize(product)}
                className="flex-1 h-10"
              >
                {product.isPizza ? (
                  <>
                    <Pizza className="w-4 h-4 mr-2" />
                    Montar
                  </>
                ) : (
                  <>
                    <Settings className="w-4 h-4 mr-2" />
                    Personalizar
                  </>
                )}
              </Button>
              <Button
                size="sm"
                onClick={handleQuickAdd}
                className="bg-orange-500 hover:bg-orange-600 h-10 px-4"
              >
                <Plus className="w-4 h-4" />
              </Button>
            </div>
          ) : (
            <Button
              size="sm"
              onClick={handleQuickAdd}
              className="w-full bg-orange-500 hover:bg-orange-600 h-10"
            >
              <Plus className="w-4 h-4 mr-2" />
              Adicionar
            </Button>
          )}
        </div>

        {/* Upsell Suggestions - Aparecem automaticamente após adicionar se houver sugestões */}
        {showUpsell && upsellSuggestions.length > 0 && (
          <UpsellSuggestions
            suggestions={upsellSuggestions}
            onAddToCart={(upsellProduct) => {
              onQuickAdd({
                ...product,
                id: upsellProduct.id,
                name: upsellProduct.name,
                price: upsellProduct.price,
                image: upsellProduct.image || product.image,
                description: "Sugestão automática",
                isPromotion: false,
                customizable: false,
                isPizza: false
              });
              // Fechar upsell após adicionar sugestão
              onToggleUpsell();
            }}
          />
        )}
      </CardContent>
    </Card>
  );
};