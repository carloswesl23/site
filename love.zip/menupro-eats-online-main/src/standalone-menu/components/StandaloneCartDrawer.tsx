import { Sheet, SheetContent, SheetHeader, SheetTitle } from "@/components/ui/sheet";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Plus, Minus, Trash2, ShoppingCart, Pizza } from "lucide-react";

interface CartItem {
  id: string;
  product: any;
  quantity: number;
  customizations?: any;
  totalPrice: number;
}

interface StandaloneCartDrawerProps {
  isOpen: boolean;
  onClose: () => void;
  cart: CartItem[];
  onUpdateItem: (itemId: string, quantity: number) => void;
  onCheckout: () => void;
  total: number;
}

export const StandaloneCartDrawer = ({ 
  isOpen, 
  onClose, 
  cart, 
  onUpdateItem, 
  onCheckout, 
  total 
}: StandaloneCartDrawerProps) => {
  if (cart.length === 0) {
    return (
      <Sheet open={isOpen} onOpenChange={onClose}>
        <SheetContent side="right" className="w-full sm:w-96">
          <SheetHeader>
            <SheetTitle className="flex items-center gap-2">
              <ShoppingCart className="w-5 h-5" />
              Sua Sacola
            </SheetTitle>
          </SheetHeader>
          
          <div className="flex flex-col items-center justify-center h-96 text-gray-500">
            <ShoppingCart className="w-16 h-16 mb-4" />
            <p className="text-lg font-medium">Sua sacola está vazia</p>
            <p className="text-sm">Adicione alguns produtos deliciosos!</p>
          </div>
        </SheetContent>
      </Sheet>
    );
  }

  const renderPizzaCustomizations = (customizations: any) => {
    if (!customizations.flavors) return null;

    return (
      <div className="space-y-1">
        {/* Sabores */}
        <div>
          <span className="text-xs font-medium text-gray-700">Sabores:</span>
          <div className="flex flex-wrap gap-1 mt-1">
            {customizations.flavors.map((flavor: any, index: number) => (
              <Badge key={flavor.id} variant="outline" className="text-xs">
                {flavor.name}
              </Badge>
            ))}
          </div>
        </div>

        {/* Ingredientes removidos */}
        {customizations.removedIngredients && customizations.removedIngredients.length > 0 && (
          <div>
            <span className="text-xs font-medium text-gray-700">Retirar:</span>
            <p className="text-xs text-gray-600">
              {customizations.removedIngredients.join(", ")}
            </p>
          </div>
        )}

        {/* Borda */}
        {customizations.border && (
          <div>
            <span className="text-xs font-medium text-gray-700">Borda:</span>
            <span className="text-xs text-gray-600 ml-1">
              {customizations.border.name} (+R$ {customizations.border.price.toFixed(2)})
            </span>
          </div>
        )}

        {/* Observações */}
        {customizations.notes && (
          <div>
            <span className="text-xs font-medium text-gray-700">Obs:</span>
            <p className="text-xs text-gray-600">{customizations.notes}</p>
          </div>
        )}
      </div>
    );
  };

  const renderRegularCustomizations = (customizations: any) => {
    return (
      <div className="text-xs text-gray-600 mt-1">
        {customizations.bread && (
          <p>Pão: {customizations.bread}</p>
        )}
        {customizations.extras && customizations.extras.length > 0 && (
          <p>Extras: {customizations.extras.map((e: any) => e.name).join(', ')}</p>
        )}
        {customizations.notes && (
          <p>Obs: {customizations.notes}</p>
        )}
      </div>
    );
  };

  return (
    <Sheet open={isOpen} onOpenChange={onClose}>
      <SheetContent side="right" className="w-full sm:w-96 flex flex-col">
        <SheetHeader>
          <SheetTitle className="flex items-center gap-2">
            <ShoppingCart className="w-5 h-5" />
            Sua Sacola ({cart.length} {cart.length === 1 ? 'item' : 'itens'})
          </SheetTitle>
        </SheetHeader>

        <div className="flex-1 overflow-y-auto space-y-4 py-4">
          {cart.map((item) => (
            <Card key={item.id}>
              <CardContent className="p-4">
                <div className="flex gap-3">
                  <div className="relative">
                    <img
                      src={item.product.image}
                      alt={item.product.name}
                      className="w-16 h-16 object-cover rounded-lg"
                    />
                    {item.product.isPizza && (
                      <div className="absolute -top-1 -right-1 bg-orange-500 text-white rounded-full p-1">
                        <Pizza className="w-3 h-3" />
                      </div>
                    )}
                  </div>
                  
                  <div className="flex-1">
                    <h4 className="font-medium text-sm line-clamp-1">
                      {item.product.name}
                      {item.product.isPizza && item.customizations?.flavorCount > 1 && (
                        <span className="text-xs text-orange-600 ml-1">
                          ({item.customizations.flavorCount} sabores)
                        </span>
                      )}
                    </h4>
                    
                    {item.customizations && (
                      item.product.isPizza 
                        ? renderPizzaCustomizations(item.customizations)
                        : renderRegularCustomizations(item.customizations)
                    )}
                    
                    <div className="flex items-center justify-between mt-2">
                      <span className="font-bold text-orange-600">
                        R$ {item.totalPrice.toFixed(2)}
                      </span>
                      
                      <div className="flex items-center gap-2">
                        <Button
                          size="sm"
                          variant="outline"
                          onClick={() => onUpdateItem(item.id, item.quantity - 1)}
                          className="h-8 w-8 p-0"
                        >
                          <Minus className="w-3 h-3" />
                        </Button>
                        
                        <span className="text-sm font-medium w-8 text-center">
                          {item.quantity}
                        </span>
                        
                        <Button
                          size="sm"
                          variant="outline"
                          onClick={() => onUpdateItem(item.id, item.quantity + 1)}
                          className="h-8 w-8 p-0"
                        >
                          <Plus className="w-3 h-3" />
                        </Button>
                        
                        <Button
                          size="sm"
                          variant="outline"
                          onClick={() => onUpdateItem(item.id, 0)}
                          className="h-8 w-8 p-0 text-red-600 hover:text-red-700"
                        >
                          <Trash2 className="w-3 h-3" />
                        </Button>
                      </div>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        <div className="border-t pt-4 space-y-4">
          <div className="flex justify-between items-center text-lg font-bold">
            <span>Total:</span>
            <span className="text-orange-600">R$ {total.toFixed(2)}</span>
          </div>
          
          <Button
            onClick={onCheckout}
            className="w-full bg-orange-500 hover:bg-orange-600 h-12 text-lg"
          >
            Finalizar Pedido
          </Button>
        </div>
      </SheetContent>
    </Sheet>
  );
};