import { useState } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Checkbox } from "@/components/ui/checkbox";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { Plus, Minus, Pizza } from "lucide-react";

interface PizzaFlavor {
  id: string;
  name: string;
  ingredients: string[];
  price: number;
}

interface PizzaBorder {
  id: string;
  name: string;
  price: number;
}

interface Product {
  id: string;
  name: string;
  description: string;
  price: number;
  image: string;
  category: string;
  isPromotion: boolean;
  promotionPrice?: number;
  isPizza?: boolean;
  allowHalfHalf?: boolean;
  pizzaFlavors?: PizzaFlavor[];
  pizzaBorders?: PizzaBorder[];
  maxFlavors?: number;
}

interface StandalonePizzaModalProps {
  product: Product | null;
  isOpen: boolean;
  onClose: () => void;
  onAddToCart: (product: Product, customizations: any, quantity: number) => void;
}

const mockPizzaFlavors: PizzaFlavor[] = [
  {
    id: "1",
    name: "Margherita",
    ingredients: ["Molho de tomate", "Mozzarella", "Manjericão", "Orégano"],
    price: 32.90
  },
  {
    id: "2", 
    name: "Calabresa",
    ingredients: ["Molho de tomate", "Mozzarella", "Calabresa", "Cebola", "Orégano"],
    price: 35.90
  },
  {
    id: "3",
    name: "Portuguesa",
    ingredients: ["Molho de tomate", "Mozzarella", "Presunto", "Ovos", "Cebola", "Azeitona", "Orégano"],
    price: 42.90
  },
  {
    id: "4",
    name: "Quatro Queijos",
    ingredients: ["Molho de tomate", "Mozzarella", "Gorgonzola", "Provolone", "Parmesão", "Orégano"],
    price: 45.90
  },
  {
    id: "5",
    name: "Frango com Catupiry",
    ingredients: ["Molho de tomate", "Mozzarella", "Frango desfiado", "Catupiry", "Orégano"],
    price: 38.90
  }
];

const mockPizzaBorders: PizzaBorder[] = [
  { id: "1", name: "Catupiry", price: 8.90 },
  { id: "2", name: "Cheddar", price: 9.90 },
  { id: "3", name: "Chocolate", price: 7.90 },
  { id: "4", name: "Cream Cheese", price: 10.90 }
];

export const StandalonePizzaModal = ({ product, isOpen, onClose, onAddToCart }: StandalonePizzaModalProps) => {
  const [selectedFlavors, setSelectedFlavors] = useState<PizzaFlavor[]>([]);
  const [flavorCount, setFlavorCount] = useState(1);
  const [removedIngredients, setRemovedIngredients] = useState<string[]>([]);
  const [selectedBorder, setSelectedBorder] = useState<PizzaBorder | null>(null);
  const [notes, setNotes] = useState("");
  const [quantity, setQuantity] = useState(1);

  if (!product || !product.isPizza) return null;

  const maxFlavors = product.maxFlavors || 4;
  const availableFlavors = product.pizzaFlavors && product.pizzaFlavors.length > 0 ? product.pizzaFlavors : mockPizzaFlavors;
  const availableBorders = product.pizzaBorders && product.pizzaBorders.length > 0 ? product.pizzaBorders : mockPizzaBorders;

  // Calcular preço da pizza baseado no sabor mais caro
  const calculatePizzaPrice = () => {
    if (selectedFlavors.length === 0) return product.price;
    
    const highestPrice = Math.max(...selectedFlavors.map(flavor => flavor.price));
    return highestPrice;
  };

  const pizzaPrice = calculatePizzaPrice();
  const borderPrice = selectedBorder ? selectedBorder.price : 0;
  const totalPrice = (pizzaPrice + borderPrice) * quantity;

  // Obter todos os ingredientes únicos dos sabores selecionados
  const getAllIngredients = () => {
    const allIngredients = new Set<string>();
    selectedFlavors.forEach(flavor => {
      flavor.ingredients.forEach(ingredient => allIngredients.add(ingredient));
    });
    return Array.from(allIngredients);
  };

  const handleFlavorSelection = (flavor: PizzaFlavor, checked: boolean) => {
    if (checked && selectedFlavors.length < flavorCount) {
      setSelectedFlavors(prev => [...prev, flavor]);
    } else if (!checked) {
      setSelectedFlavors(prev => prev.filter(f => f.id !== flavor.id));
    }
  };

  const handleIngredientRemoval = (ingredient: string, checked: boolean) => {
    if (checked) {
      setRemovedIngredients(prev => [...prev, ingredient]);
    } else {
      setRemovedIngredients(prev => prev.filter(i => i !== ingredient));
    }
  };

  const handleAddToCart = () => {
    const customizations = {
      flavors: selectedFlavors,
      flavorCount,
      removedIngredients,
      border: selectedBorder,
      notes: notes.trim(),
      pizzaPrice,
      borderPrice
    };

    onAddToCart(product, customizations, quantity);
    
    // Reset form
    setSelectedFlavors([]);
    setFlavorCount(1);
    setRemovedIngredients([]);
    setSelectedBorder(null);
    setNotes("");
    setQuantity(1);
    onClose();
  };

  const isValid = selectedFlavors.length === flavorCount;

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2 text-xl">
            <Pizza className="w-6 h-6" />
            {product.name} - Monte sua Pizza
          </DialogTitle>
        </DialogHeader>

        <div className="grid gap-6 md:grid-cols-2">
          {/* Coluna Esquerda - Configurações */}
          <div className="space-y-6">
            {/* Escolha de Sabores */}
            <Card>
              <CardContent className="p-4">
                <h3 className="font-semibold mb-3">
                  1. Quantos sabores? (máx. {maxFlavors})
                </h3>
                <RadioGroup
                  value={flavorCount.toString()}
                  onValueChange={(value) => {
                    const newCount = parseInt(value);
                    setFlavorCount(newCount);
                    if (selectedFlavors.length > newCount) {
                      setSelectedFlavors(prev => prev.slice(0, newCount));
                    }
                  }}
                >
                  {Array.from({ length: maxFlavors }, (_, i) => i + 1).map((count) => (
                    <div key={count} className="flex items-center space-x-2">
                      <RadioGroupItem value={count.toString()} id={`flavors-${count}`} />
                      <Label htmlFor={`flavors-${count}`}>
                        {count === 1 ? "1 sabor" : 
                         count === 2 ? "2 sabores (meia/meia)" : 
                         `${count} sabores`}
                      </Label>
                    </div>
                  ))}
                </RadioGroup>
              </CardContent>
            </Card>

            {/* Seleção de Sabores */}
            <Card>
              <CardContent className="p-4">
                <h3 className="font-semibold mb-3">
                  2. Escolha {flavorCount === 1 ? "o sabor" : `os ${flavorCount} sabores`}
                  {selectedFlavors.length > 0 && (
                    <span className="text-sm font-normal text-gray-600 ml-2">
                      ({selectedFlavors.length}/{flavorCount})
                    </span>
                  )}
                </h3>
                <div className="space-y-3 max-h-60 overflow-y-auto">
                  {availableFlavors.map((flavor) => (
                    <div key={flavor.id} className="flex items-start space-x-3 p-3 border rounded-lg hover:bg-gray-50">
                      <Checkbox
                        id={flavor.id}
                        checked={selectedFlavors.some(f => f.id === flavor.id)}
                        onCheckedChange={(checked) => handleFlavorSelection(flavor, checked as boolean)}
                        disabled={!selectedFlavors.some(f => f.id === flavor.id) && selectedFlavors.length >= flavorCount}
                      />
                      <div className="flex-1">
                        <div className="flex justify-between items-start">
                          <Label htmlFor={flavor.id} className="font-medium">
                            {flavor.name}
                          </Label>
                          <span className="text-orange-600 font-bold">
                            R$ {flavor.price.toFixed(2)}
                          </span>
                        </div>
                        <p className="text-xs text-gray-600 mt-1">
                          {flavor.ingredients.join(", ")}
                        </p>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>

            {/* Retirar Ingredientes */}
            {selectedFlavors.length > 0 && (
              <Card>
                <CardContent className="p-4">
                  <h3 className="font-semibold mb-3">3. Retirar ingredientes (opcional)</h3>
                  <div className="space-y-2 max-h-40 overflow-y-auto">
                    {getAllIngredients().map((ingredient) => (
                      <div key={ingredient} className="flex items-center space-x-2">
                        <Checkbox
                          id={`remove-${ingredient}`}
                          checked={removedIngredients.includes(ingredient)}
                          onCheckedChange={(checked) => handleIngredientRemoval(ingredient, checked as boolean)}
                        />
                        <Label htmlFor={`remove-${ingredient}`} className="text-sm">
                          Retirar {ingredient}
                        </Label>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            )}

            {/* Bordas */}
            <Card>
              <CardContent className="p-4">
                <h3 className="font-semibold mb-3">4. Escolha a borda (opcional)</h3>
                <RadioGroup
                  value={selectedBorder?.id || "none"}
                  onValueChange={(value) => {
                    if (value === "none") {
                      setSelectedBorder(null);
                    } else {
                      const border = availableBorders.find(b => b.id === value);
                      setSelectedBorder(border || null);
                    }
                  }}
                >
                  <div className="flex items-center space-x-2">
                    <RadioGroupItem value="none" id="no-border" />
                    <Label htmlFor="no-border">Sem borda recheada</Label>
                  </div>
                  {availableBorders.map((border) => (
                    <div key={border.id} className="flex items-center justify-between">
                      <div className="flex items-center space-x-2">
                        <RadioGroupItem value={border.id} id={border.id} />
                        <Label htmlFor={border.id}>{border.name}</Label>
                      </div>
                      <span className="text-orange-600 font-medium">
                        + R$ {border.price.toFixed(2)}
                      </span>
                    </div>
                  ))}
                </RadioGroup>
              </CardContent>
            </Card>

            {/* Observações */}
            <Card>
              <CardContent className="p-4">
                <h3 className="font-semibold mb-3">5. Observações (opcional)</h3>
                <Textarea
                  placeholder="Ex: massa fina, bem assada, sem azeitona..."
                  value={notes}
                  onChange={(e) => setNotes(e.target.value)}
                  className="resize-none"
                  rows={3}
                />
              </CardContent>
            </Card>
          </div>

          {/* Coluna Direita - Resumo */}
          <div className="space-y-6">
            <Card className="sticky top-0">
              <CardContent className="p-4">
                <h3 className="font-semibold mb-4 flex items-center gap-2">
                  <Pizza className="w-4 h-4" />
                  Resumo da sua Pizza
                </h3>

                {/* Imagem da Pizza */}
                <img
                  src={product.image}
                  alt={product.name}
                  className="w-full h-32 object-cover rounded-lg mb-4"
                />

                {/* Sabores Selecionados */}
                <div className="mb-4">
                  <p className="text-sm font-medium text-gray-700 mb-2">Sabores:</p>
                  {selectedFlavors.length === 0 ? (
                    <p className="text-sm text-gray-500">Nenhum sabor selecionado</p>
                  ) : (
                    <div className="space-y-1">
                      {selectedFlavors.map((flavor, index) => (
                        <div key={flavor.id} className="flex justify-between text-sm">
                          <span>{flavor.name}</span>
                          <span className="text-orange-600">R$ {flavor.price.toFixed(2)}</span>
                        </div>
                      ))}
                    </div>
                  )}
                </div>

                {/* Ingredientes Removidos */}
                {removedIngredients.length > 0 && (
                  <div className="mb-4">
                    <p className="text-sm font-medium text-gray-700 mb-2">Retirar:</p>
                    <div className="flex flex-wrap gap-1">
                      {removedIngredients.map((ingredient) => (
                        <Badge key={ingredient} variant="secondary" className="text-xs">
                          Sem {ingredient}
                        </Badge>
                      ))}
                    </div>
                  </div>
                )}

                {/* Borda Selecionada */}
                {selectedBorder && (
                  <div className="mb-4">
                    <p className="text-sm font-medium text-gray-700 mb-2">Borda:</p>
                    <div className="flex justify-between text-sm">
                      <span>{selectedBorder.name}</span>
                      <span className="text-orange-600">+ R$ {selectedBorder.price.toFixed(2)}</span>
                    </div>
                  </div>
                )}

                {/* Observações */}
                {notes.trim() && (
                  <div className="mb-4">
                    <p className="text-sm font-medium text-gray-700 mb-2">Observações:</p>
                    <p className="text-sm text-gray-600 bg-gray-50 p-2 rounded">{notes}</p>
                  </div>
                )}

                {/* Quantidade e Preço */}
                <div className="border-t pt-4">
                  <div className="flex items-center justify-between mb-3">
                    <span className="font-medium">Quantidade:</span>
                    <div className="flex items-center gap-2">
                      <Button
                        size="sm"
                        variant="outline"
                        onClick={() => setQuantity(Math.max(1, quantity - 1))}
                        className="h-8 w-8 p-0"
                      >
                        <Minus className="w-3 h-3" />
                      </Button>
                      <span className="text-lg font-medium w-8 text-center">{quantity}</span>
                      <Button
                        size="sm"
                        variant="outline"
                        onClick={() => setQuantity(quantity + 1)}
                        className="h-8 w-8 p-0"
                      >
                        <Plus className="w-3 h-3" />
                      </Button>
                    </div>
                  </div>

                  <div className="space-y-1 text-sm">
                    <div className="flex justify-between">
                      <span>Pizza:</span>
                      <span>R$ {pizzaPrice.toFixed(2)}</span>
                    </div>
                    {selectedBorder && (
                      <div className="flex justify-between">
                        <span>Borda:</span>
                        <span>R$ {borderPrice.toFixed(2)}</span>
                      </div>
                    )}
                    <div className="flex justify-between font-bold text-lg border-t pt-2">
                      <span>Total:</span>
                      <span className="text-orange-600">R$ {totalPrice.toFixed(2)}</span>
                    </div>
                  </div>
                </div>

                <Button
                  onClick={handleAddToCart}
                  disabled={!isValid}
                  className="w-full bg-orange-500 hover:bg-orange-600 h-12 text-lg mt-4"
                >
                  Adicionar à Sacola
                </Button>

                {!isValid && selectedFlavors.length !== flavorCount && (
                  <p className="text-center text-sm text-red-600 mt-2">
                    Selecione {flavorCount === 1 ? "o sabor" : `os ${flavorCount} sabores`} para continuar
                  </p>
                )}
              </CardContent>
            </Card>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
};