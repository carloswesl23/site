import { useIsMobile } from "@/hooks/use-mobile";
import { StandaloneProductCard } from "./StandaloneProductCard";
import { Product } from "../types";

interface StandaloneProductGridProps {
  products: Product[];
  onQuickAdd: (product: Product) => void;
  onCustomize: (product: Product) => void;
  showUpsell: string | null;
  onToggleUpsell: (productId: string) => void;
  getUpsellSuggestions: (productId: string) => Array<{
    id: string;
    name: string;
    price: number;
    image: string | null;
  }>;
}

export const StandaloneProductGrid = ({
  products,
  onQuickAdd,
  onCustomize,
  showUpsell,
  onToggleUpsell,
  getUpsellSuggestions
}: StandaloneProductGridProps) => {
  const isMobile = useIsMobile();

  return (
    <div className={`grid gap-4 ${
      isMobile 
        ? 'grid-cols-1'
        : 'grid-cols-2 lg:grid-cols-3'
    }`}>
      {products.map((product) => (
        <StandaloneProductCard
          key={product.id}
          product={product}
          onQuickAdd={onQuickAdd}
          onCustomize={onCustomize}
          showUpsell={showUpsell === product.id}
          onToggleUpsell={() => onToggleUpsell(product.id)}
          upsellSuggestions={getUpsellSuggestions(product.id)}
        />
      ))}
    </div>
  );
};