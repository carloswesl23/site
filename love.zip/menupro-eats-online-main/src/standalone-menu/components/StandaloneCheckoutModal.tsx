import { useState, useEffect } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Card, CardContent } from "@/components/ui/card";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { MessageSquare, MapPin, User, Phone, CreditCard } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { PixPaymentSection } from "@/components/standalone/checkout/PixPaymentSection";
import { CouponSection } from "@/components/standalone/checkout/CouponSection";
import { supabase } from "../integrations/supabase/client";
import { useWhatsAppMessages } from "@/hooks/useWhatsAppMessages";

interface CartItem {
  id: string;
  product: any;
  quantity: number;
  customizations?: any;
  totalPrice: number;
}

interface StandaloneCheckoutModalProps {
  isOpen: boolean;
  onClose: () => void;
  cart: CartItem[];
  total: number;
  establishmentName: string;
  establishmentPhone?: string | null;
  establishmentData?: {
    user_id: string;
    pix_key: string | null;
    pix_beneficiary_name: string | null;
    pix_enabled: boolean | null;
    accept_cash?: boolean | null;
    accept_credit_on_delivery?: boolean | null;
    combine_payment_via_whatsapp?: boolean | null;
  };
}

export const StandaloneCheckoutModal = ({ 
  isOpen, 
  onClose, 
  cart, 
  total, 
  establishmentName,
  establishmentPhone,
  establishmentData
}: StandaloneCheckoutModalProps) => {
  const { toast } = useToast();
  const { sendOrderNotification } = useWhatsAppMessages();
  const [step, setStep] = useState<'form' | 'payment' | 'pix'>('form');
  const [paymentMethod, setPaymentMethod] = useState<'whatsapp' | 'pix' | 'cash' | 'card'>('whatsapp');
  const [orderNumber, setOrderNumber] = useState('');
  const [deliveryFee] = useState(5.00);
  const [customerData, setCustomerData] = useState({
    name: "",
    phone: "",
    deliveryType: "delivery",
    address: {
      street: "",
      number: "",
      neighborhood: "",
      city: "",
      zipCode: "",
      reference: ""
    }
  });
  const [isLoadingCep, setIsLoadingCep] = useState(false);
  const [appliedCoupon, setAppliedCoupon] = useState<any>(null);
  const [couponDiscount, setCouponDiscount] = useState(0);

  // Calcular total com frete e desconto
  const subtotalWithDelivery = customerData.deliveryType === "delivery" ? total + deliveryFee : total;
  const totalWithDelivery = subtotalWithDelivery - couponDiscount;

  // Gerar número do pedido único
  useEffect(() => {
    if (isOpen && !orderNumber) {
      const timestamp = Date.now();
      const random = Math.floor(Math.random() * 1000).toString().padStart(3, '0');
      const orderNum = `PED-${timestamp}-${random}`;
      setOrderNumber(orderNum);
    }
  }, [isOpen]);

  const formatZipCode = (value: string) => {
    const numbers = value.replace(/\D/g, '');
    if (numbers.length <= 5) {
      return numbers;
    }
    return numbers.replace(/(\d{5})(\d{1,3})/, '$1-$2');
  };

  const searchAddressByCep = async (cep: string) => {
    const cleanCep = cep.replace(/\D/g, '');
    if (cleanCep.length !== 8) return;

    setIsLoadingCep(true);
    try {
      const response = await fetch(`https://viacep.com.br/ws/${cleanCep}/json/`);
      const data = await response.json();
      
      if (!data.erro) {
        setCustomerData(prev => ({
          ...prev,
          address: {
            ...prev.address,
            street: data.logradouro || prev.address.street,
            neighborhood: data.bairro || prev.address.neighborhood,
            city: data.localidade || prev.address.city,
            zipCode: formatZipCode(cleanCep)
          }
        }));
        
        toast({
          title: "Endereço encontrado!",
          description: "Dados preenchidos automaticamente via CEP",
        });
      } else {
        toast({
          title: "CEP não encontrado",
          description: "Verifique o CEP digitado",
          variant: "destructive"
        });
      }
    } catch (error) {
      toast({
        title: "Erro ao buscar CEP",
        description: "Tente novamente ou preencha manualmente",
        variant: "destructive"
      });
    } finally {
      setIsLoadingCep(false);
    }
  };

  const handleZipCodeChange = (value: string) => {
    const formatted = formatZipCode(value);
    setCustomerData(prev => ({
      ...prev,
      address: { ...prev.address, zipCode: formatted }
    }));

    if (formatted.length === 9) {
    searchAddressByCep(formatted);
    }
  };

  const handleCouponApplied = (coupon: any, discount: number) => {
    setAppliedCoupon(coupon);
    setCouponDiscount(discount);
  };

  const handleCouponRemoved = () => {
    setAppliedCoupon(null);
    setCouponDiscount(0);
  };

  // Check if form is valid for showing coupon section
  const isFormValid = Boolean(customerData.name && customerData.phone && 
    (customerData.deliveryType === "pickup" || 
     (customerData.address.street && customerData.address.number && 
      customerData.address.neighborhood && customerData.address.city)));

  const formatPizzaForWhatsApp = (item: CartItem) => {
    if (!item.product.isPizza || !item.customizations.flavors) {
      return `   • ${item.product.name}`;
    }

    let pizzaDescription = `   🍕 ${item.product.name}`;
    
    if (item.customizations.flavors.length === 1) {
      pizzaDescription += ` - ${item.customizations.flavors[0].name}`;
    } else {
      pizzaDescription += ` - ${item.customizations.flavorCount} sabores:`;
      item.customizations.flavors.forEach((flavor: any) => {
        pizzaDescription += `\n      • ${flavor.name}`;
      });
    }

    if (item.customizations.removedIngredients && item.customizations.removedIngredients.length > 0) {
      pizzaDescription += `\n      Retirar: ${item.customizations.removedIngredients.join(', ')}`;
    }

    if (item.customizations.border) {
      pizzaDescription += `\n      Borda: ${item.customizations.border.name} (+R$ ${item.customizations.border.price.toFixed(2)})`;
    }

    if (item.customizations.notes) {
      pizzaDescription += `\n      Obs: ${item.customizations.notes}`;
    }

    return pizzaDescription;
  };

  const formatOrderForWhatsApp = () => {
    let message = `🍔 *NOVO PEDIDO - ${establishmentName}*\n\n`;
    
    message += `📋 *Pedido:* #${orderNumber}\n`;
    message += `👤 *Cliente:* ${customerData.name}\n`;
    message += `📱 *Telefone:* ${customerData.phone}\n`;
    
    if (customerData.deliveryType === "delivery") {
      message += `📍 *Endereço de Entrega:*\n`;
      message += `   Rua: ${customerData.address.street}, ${customerData.address.number}\n`;
      message += `   Bairro: ${customerData.address.neighborhood}\n`;
      message += `   Cidade: ${customerData.address.city}\n`;
      message += `   CEP: ${customerData.address.zipCode}\n`;
      if (customerData.address.reference) {
        message += `   Referência: ${customerData.address.reference}\n`;
      }
    } else {
      message += `🏪 *Retirada no local*\n`;
    }
    
    message += `\n📋 *ITENS DO PEDIDO:*\n`;
    
    cart.forEach((item, index) => {
      message += `\n${index + 1}. *${item.quantity}x* `;
      
      if (item.product.isPizza) {
        message += formatPizzaForWhatsApp(item);
      } else {
        message += `${item.product.name}`;
        
        if (item.customizations) {
          if (item.customizations.bread) {
            message += `\n   • Pão: ${item.customizations.bread}`;
          }
          if (item.customizations.ingredients && item.customizations.ingredients.length > 0) {
            message += `\n   • Ingredientes: ${item.customizations.ingredients.join(', ')}`;
          }
          if (item.customizations.extras && item.customizations.extras.length > 0) {
            message += `\n   • Extras: ${item.customizations.extras.map((e: any) => e.name).join(', ')}`;
          }
          if (item.customizations.notes) {
            message += `\n   • Obs: ${item.customizations.notes}`;
          }
        }
      }
      
      message += `\n   💰 R$ ${item.totalPrice.toFixed(2)}\n`;
    });
    
    message += `\n💰 *Subtotal: R$ ${total.toFixed(2)}*`;
    
    if (customerData.deliveryType === "delivery") {
      message += `\n🚚 *Taxa de entrega: R$ ${deliveryFee.toFixed(2)}*`;
    }
    
    message += `\n💳 *TOTAL: R$ ${totalWithDelivery.toFixed(2)}*`;
    
    if (paymentMethod === 'pix') {
      message += `\n💰 *Forma de pagamento:* PIX`;
    }
    
    return encodeURIComponent(message);
  };

  const handleContinueToPayment = () => {
    if (!customerData.name || !customerData.phone) {
      toast({
        title: "Dados incompletos",
        description: "Por favor, preencha pelo menos o nome e telefone",
        variant: "destructive"
      });
      return;
    }

    if (customerData.deliveryType === "delivery") {
      const { street, number, neighborhood, city } = customerData.address;
      if (!street || !number || !neighborhood || !city) {
        toast({
          title: "Endereço incompleto",
          description: "Para entrega, preencha pelo menos rua, número, bairro e cidade",
          variant: "destructive"
        });
        return;
      }
    }

    setStep('payment');
  };

  const handleSubmitOrder = async () => {
    try {
      console.log('🚀 Iniciando processo de finalização do pedido...');
      console.log('💳 Método de pagamento selecionado:', paymentMethod);
      console.log('📊 Dados do estabelecimento:', establishmentData);
      
      // Validar dados necessários
      if (!establishmentData?.user_id) {
        console.error('❌ ID do estabelecimento não encontrado');
        toast({
          title: "Erro",
          description: "Dados do estabelecimento não encontrados. Recarregue a página.",
          variant: "destructive"
        });
        return;
      }

      // Validar dados obrigatórios do cliente
      if (!customerData.name || customerData.name.trim().length < 2) {
        toast({
          title: "Erro",
          description: "Nome do cliente é obrigatório (mínimo 2 caracteres).",
          variant: "destructive"
        });
        return;
      }

      if (!customerData.phone || customerData.phone.trim().length < 10) {
        toast({
          title: "Erro", 
          description: "Telefone válido é obrigatório.",
          variant: "destructive"
        });
        return;
      }

      // Usar o novo sistema que sempre cria/vincula customers
      const orderData = {
        items: cart.map(item => ({
          product_name: item.product.name,
          quantity: item.quantity,
          unit_price: item.product.price,
          total_price: item.totalPrice,
          customizations: item.customizations || {}
        })),
        total: totalWithDelivery,
        payment_method: paymentMethod,
        notes: null
      };

      const addressData = customerData.deliveryType === "delivery" ? {
        street: customerData.address.street,
        number: customerData.address.number,
        complement: customerData.address.reference || '',
        neighborhood: customerData.address.neighborhood,
        city: customerData.address.city,
        state: 'PA', // Default state
        zipCode: customerData.address.zipCode,
        reference: customerData.address.reference || ''
      } : null;

      console.log('📝 Criando pedido com customer obrigatório...');
      
      // Usar a nova função que sempre cria customer + order
      const currentSlug = window.location.pathname.split('/').pop();
      const { data: orderId, error: orderError } = await supabase.rpc('create_order_with_customer', {
        p_establishment_slug: currentSlug || '',
        p_customer_phone: customerData.phone.trim(),
        p_customer_name: customerData.name.trim(),
        p_address_data: addressData,
        p_order_data: orderData
      });

      if (orderError) {
        console.error('❌ Erro ao criar pedido:', orderError);
        toast({
          title: "Erro ao finalizar pedido",
          description: "Ocorreu um erro ao processar seu pedido. Tente novamente.",
          variant: "destructive"
        });
        return;
      }

      console.log('✅ Pedido criado com sucesso, ID:', orderId);

      // Enviar mensagem automática via WhatsApp
      try {
        await sendOrderNotification(
          establishmentData?.user_id || '',
          orderNumber,
          customerData,
          cart,
          paymentMethod,
          totalWithDelivery,
          establishmentName
        );
        console.log('Mensagem WhatsApp enviada com sucesso');
      } catch (error) {
        console.error('Erro ao enviar WhatsApp:', error);
      }

      if (paymentMethod === 'pix') {
        // Ir para tela de PIX
        setStep('pix');
        return;
      }

      // Envio via WhatsApp
      const whatsappMessage = formatOrderForWhatsApp();
      const whatsappNumber = establishmentPhone || "5511999999999";
      const whatsappUrl = `https://wa.me/${whatsappNumber}?text=${whatsappMessage}`;
      
      window.open(whatsappUrl, '_blank');
      
      toast({
        title: "Pedido enviado!",
        description: "Seu pedido foi enviado via WhatsApp.",
      });
      
      onClose();
    } catch (error) {
      console.error('Erro ao processar pedido:', error);
      toast({
        title: "Erro ao processar pedido",
        description: "Tente novamente em alguns instantes",
        variant: "destructive"
      });
    }
  };

  const resetForm = () => {
    setStep('form');
    setPaymentMethod('whatsapp');
    setOrderNumber('');
    setCustomerData({
      name: "",
      phone: "",
      deliveryType: "delivery",
      address: {
        street: "",
        number: "",
        neighborhood: "",
        city: "",
        zipCode: "",
        reference: ""
      }
    });
    setAppliedCoupon(null);
    setCouponDiscount(0);
  };

  const handleModalClose = () => {
    resetForm();
    onClose();
  };

  return (
    <Dialog open={isOpen} onOpenChange={handleModalClose}>
      <DialogContent className="max-w-lg max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            {step === 'form' ? (
              <>
                <User className="w-5 h-5" />
                Dados do Pedido
              </>
            ) : step === 'payment' ? (
              <>
                <CreditCard className="w-5 h-5" />
                Forma de Pagamento
              </>
            ) : (
              <>
                <CreditCard className="w-5 h-5" />
                Pagamento PIX
              </>
            )}
          </DialogTitle>
        </DialogHeader>

        {step === 'form' ? (
          <div className="space-y-6">
            {/* Dados do cliente */}
            <Card>
              <CardContent className="p-4 space-y-4">
                <h3 className="font-semibold flex items-center gap-2">
                  <User className="w-4 h-4" />
                  Seus Dados
                </h3>
                
                <div className="space-y-3">
                  <div>
                    <Label htmlFor="name">Nome completo *</Label>
                    <Input
                      id="name"
                      value={customerData.name}
                      onChange={(e) => setCustomerData(prev => ({ ...prev, name: e.target.value }))}
                      placeholder="Seu nome completo"
                    />
                  </div>
                  
                  <div>
                    <Label htmlFor="phone">WhatsApp *</Label>
                    <Input
                      id="phone"
                      value={customerData.phone}
                      onChange={(e) => setCustomerData(prev => ({ ...prev, phone: e.target.value }))}
                      placeholder="(11) 99999-9999"
                    />
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Tipo de entrega */}
            <Card>
              <CardContent className="p-4">
                <h3 className="font-semibold mb-3">Tipo de Entrega</h3>
                <RadioGroup
                  value={customerData.deliveryType}
                  onValueChange={(value) => setCustomerData(prev => ({ ...prev, deliveryType: value }))}
                >
                  <div className="flex items-center space-x-2">
                    <RadioGroupItem value="delivery" id="delivery" />
                    <Label htmlFor="delivery" className="flex items-center gap-2">
                      🛵 Entrega 
                      <span className="text-sm text-gray-500">(+R$ {deliveryFee.toFixed(2)})</span>
                    </Label>
                  </div>
                  <div className="flex items-center space-x-2">
                    <RadioGroupItem value="pickup" id="pickup" />
                    <Label htmlFor="pickup">🏪 Retirada no local</Label>
                  </div>
                </RadioGroup>
              </CardContent>
            </Card>

            {/* Endereço (se entrega) */}
            {customerData.deliveryType === "delivery" && (
              <Card>
                <CardContent className="p-4">
                  <h3 className="font-semibold flex items-center gap-2 mb-3">
                    <MapPin className="w-4 h-4" />
                    Endereço de Entrega
                  </h3>

                  <div className="space-y-3">
                    <div>
                      <Label htmlFor="zipCode">CEP</Label>
                      <Input
                        id="zipCode"
                        value={customerData.address.zipCode}
                        onChange={(e) => handleZipCodeChange(e.target.value)}
                        placeholder="00000-000"
                        maxLength={9}
                        disabled={isLoadingCep}
                      />
                      {isLoadingCep && (
                        <p className="text-xs text-muted-foreground mt-1">
                          Buscando endereço...
                        </p>
                      )}
                    </div>

                    <div className="grid grid-cols-3 gap-2">
                      <div className="col-span-2">
                        <Label htmlFor="street">Rua *</Label>
                        <Input
                          id="street"
                          value={customerData.address.street}
                          onChange={(e) => setCustomerData(prev => ({
                            ...prev,
                            address: { ...prev.address, street: e.target.value }
                          }))}
                          placeholder="Nome da rua"
                        />
                      </div>
                      <div>
                        <Label htmlFor="number">Número *</Label>
                        <Input
                          id="number"
                          value={customerData.address.number}
                          onChange={(e) => setCustomerData(prev => ({
                            ...prev,
                            address: { ...prev.address, number: e.target.value }
                          }))}
                          placeholder="123"
                        />
                      </div>
                    </div>

                    <div>
                      <Label htmlFor="neighborhood">Bairro *</Label>
                      <Input
                        id="neighborhood"
                        value={customerData.address.neighborhood}
                        onChange={(e) => setCustomerData(prev => ({
                          ...prev,
                          address: { ...prev.address, neighborhood: e.target.value }
                        }))}
                        placeholder="Nome do bairro"
                      />
                    </div>

                    <div>
                      <Label htmlFor="city">Cidade *</Label>
                      <Input
                        id="city"
                        value={customerData.address.city}
                        onChange={(e) => setCustomerData(prev => ({
                          ...prev,
                          address: { ...prev.address, city: e.target.value }
                        }))}
                        placeholder="Nome da cidade"
                      />
                    </div>

                    <div>
                      <Label htmlFor="reference">Ponto de referência</Label>
                      <Input
                        id="reference"
                        value={customerData.address.reference}
                        onChange={(e) => setCustomerData(prev => ({
                          ...prev,
                          address: { ...prev.address, reference: e.target.value }
                        }))}
                        placeholder="Ex: Próximo ao supermercado"
                      />
                    </div>
                  </div>
                </CardContent>
              </Card>
            )}

            {/* Cupom de Desconto */}
            {isFormValid && (
              <CouponSection
                establishmentId={establishmentData?.user_id || ''}
                subtotal={subtotalWithDelivery}
                appliedCoupon={appliedCoupon}
                onCouponApplied={handleCouponApplied}
                onCouponRemoved={handleCouponRemoved}
                cart={cart}
                isFormValid={isFormValid}
              />
            )}

            {/* Total */}
            <Card>
              <CardContent className="p-4">
                <div className="space-y-2">
                  <div className="flex justify-between">
                    <span>Subtotal:</span>
                    <span>R$ {total.toFixed(2)}</span>
                  </div>
                  {customerData.deliveryType === "delivery" && (
                    <div className="flex justify-between">
                      <span>Taxa de entrega:</span>
                      <span>R$ {deliveryFee.toFixed(2)}</span>
                    </div>
                  )}
                  {couponDiscount > 0 && (
                    <div className="flex justify-between text-green-600">
                      <span>Desconto ({appliedCoupon?.code}):</span>
                      <span>-R$ {couponDiscount.toFixed(2)}</span>
                    </div>
                  )}
                  <div className="flex justify-between font-bold text-lg border-t pt-2">
                    <span>Total:</span>
                    <span className="text-orange-600">R$ {totalWithDelivery.toFixed(2)}</span>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Button
              onClick={handleContinueToPayment}
              className="w-full bg-orange-500 hover:bg-orange-600 h-12 text-lg"
            >
              Continuar
            </Button>
          </div>
        ) : step === 'payment' ? (
          <div className="space-y-6">
            {/* Forma de pagamento */}
            <Card>
              <CardContent className="p-4">
                <h3 className="font-semibold mb-3">Como você prefere pagar?</h3>
                <RadioGroup
                  value={paymentMethod}
                  onValueChange={(value: 'whatsapp' | 'pix' | 'cash' | 'card') => setPaymentMethod(value)}
                >
                   {establishmentData?.combine_payment_via_whatsapp && (
                     <div className="flex items-center space-x-2">
                       <RadioGroupItem value="whatsapp" id="whatsapp" />
                       <Label htmlFor="whatsapp" className="flex items-center gap-2">
                         <MessageSquare className="w-4 h-4" />
                         Combinar pelo WhatsApp
                       </Label>
                     </div>
                   )}
                   
                   {(establishmentData?.pix_enabled && establishmentData?.pix_key) && (
                     <div className="flex items-center space-x-2">
                       <RadioGroupItem value="pix" id="pix" />
                       <Label htmlFor="pix" className="flex items-center gap-2">
                         <CreditCard className="w-4 h-4" />
                         PIX
                       </Label>
                     </div>
                   )}
                   
                   {establishmentData?.accept_cash && (
                     <div className="flex items-center space-x-2">
                       <RadioGroupItem value="cash" id="cash" />
                       <Label htmlFor="cash" className="flex items-center gap-2">
                         💰 Dinheiro
                       </Label>
                     </div>
                   )}
                   
                   {establishmentData?.accept_credit_on_delivery && (
                     <div className="flex items-center space-x-2">
                       <RadioGroupItem value="card" id="card" />
                       <Label htmlFor="card" className="flex items-center gap-2">
                         <CreditCard className="w-4 h-4" />
                         Cartão (na entrega)
                       </Label>
                     </div>
                   )}
                </RadioGroup>
              </CardContent>
            </Card>

            {/* Resumo do pedido */}
            <Card>
              <CardContent className="p-4">
                <h3 className="font-semibold mb-3">Resumo do Pedido</h3>
                <div className="space-y-2 text-sm">
                  <div className="flex justify-between">
                    <span>Cliente:</span>
                    <span>{customerData.name}</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Telefone:</span>
                    <span>{customerData.phone}</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Entrega:</span>
                    <span>{customerData.deliveryType === "delivery" ? "Delivery" : "Retirada"}</span>
                  </div>
                  <div className="flex justify-between font-bold text-lg border-t pt-2">
                    <span>Total:</span>
                    <span className="text-orange-600">R$ {totalWithDelivery.toFixed(2)}</span>
                  </div>
                </div>
              </CardContent>
            </Card>

            <div className="flex gap-3">
              <Button
                variant="outline"
                onClick={() => setStep('form')}
                className="flex-1"
              >
                Voltar
              </Button>
              <Button
                onClick={handleSubmitOrder}
                className="flex-1 bg-orange-500 hover:bg-orange-600"
              >
                Finalizar Pedido
              </Button>
            </div>
          </div>
        ) : (
          <div className="space-y-6">
            <PixPaymentSection 
              total={totalWithDelivery} 
              pixKey={establishmentData?.pix_key || establishmentPhone || ""} 
              beneficiaryName={establishmentData?.pix_beneficiary_name || establishmentName}
              orderNumber={orderNumber}
            />
            
            <Button
              onClick={() => resetForm()}
              variant="outline"
              className="w-full"
            >
              Finalizar
            </Button>
          </div>
        )}
      </DialogContent>
    </Dialog>
  );
};