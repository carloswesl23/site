import { supabase } from '@/integrations/supabase/client';

export async function trackMenuView(establishmentSlug: string, userId: string) {
  try {
    // Registrar visualização do cardápio
    await supabase
      .from('menu_views')
      .insert({
        user_id: userId,
        establishment_slug: establishmentSlug,
        viewer_ip: null, // O IP seria capturado pelo servidor
        user_agent: navigator.userAgent
      });
  } catch (error) {
    console.error('Error tracking menu view:', error);
    // Não mostrar erro para o usuário, apenas logar
  }
}

export async function getMenuViewsCount(userId: string, periodStart: Date, periodEnd: Date): Promise<number> {
  try {
    const { count } = await supabase
      .from('menu_views')
      .select('*', { count: 'exact', head: true })
      .eq('user_id', userId)
      .gte('created_at', periodStart.toISOString())
      .lte('created_at', periodEnd.toISOString());
    
    return count || 0;
  } catch (error) {
    console.error('Error getting menu views count:', error);
    return 0;
  }
}