// Enhanced validation utilities with security focus

import { sanitizeInput } from './security';

// Validate URL slugs with security considerations
export const validateSlug = (slug: string): { isValid: boolean; error?: string } => {
  const trimmedSlug = slug.trim().toLowerCase();
  
  if (!trimmedSlug) {
    return { isValid: false, error: 'Slug é obrigatório' };
  }
  
  // Check for valid characters (alphanumeric, hyphens, underscores)
  const slugRegex = /^[a-z0-9-_]+$/;
  if (!slugRegex.test(trimmedSlug)) {
    return { isValid: false, error: 'Slug deve conter apenas letras, números, hífens e underscores' };
  }
  
  // Length validation
  if (trimmedSlug.length < 3) {
    return { isValid: false, error: 'Slug deve ter pelo menos 3 caracteres' };
  }
  
  if (trimmedSlug.length > 50) {
    return { isValid: false, error: 'Slug deve ter no máximo 50 caracteres' };
  }
  
  // Check for reserved words
  const reservedWords = [
    'admin', 'api', 'app', 'auth', 'dashboard', 'login', 'logout', 'signup',
    'settings', 'profile', 'user', 'users', 'public', 'private', 'www',
    'mail', 'email', 'support', 'help', 'blog', 'news', 'about', 'contact',
    'terms', 'privacy', 'cookie', 'legal', 'sitemap', 'robots', 'favicon',
    'test', 'demo', 'example', 'null', 'undefined', 'void', 'delete'
  ];
  
  if (reservedWords.includes(trimmedSlug)) {
    return { isValid: false, error: 'Este slug não pode ser usado' };
  }
  
  return { isValid: true };
};

// Validate business data with security considerations
export const validateBusinessData = (data: any): { isValid: boolean; errors: Record<string, string> } => {
  const errors: Record<string, string> = {};
  
  // Business name validation
  if (!data.business_name || data.business_name.trim().length < 2) {
    errors.business_name = 'Nome do negócio deve ter pelo menos 2 caracteres';
  } else if (data.business_name.length > 100) {
    errors.business_name = 'Nome do negócio deve ter no máximo 100 caracteres';
  }
  
  // Phone validation (if provided)
  if (data.business_phone) {
    const phoneRegex = /^\+?[\d\s\-\(\)]{10,20}$/;
    if (!phoneRegex.test(data.business_phone)) {
      errors.business_phone = 'Formato de telefone inválido';
    }
  }
  
  // Address validation (if provided)
  if (data.business_address && data.business_address.length > 200) {
    errors.business_address = 'Endereço deve ter no máximo 200 caracteres';
  }
  
  // Color validation (if provided)
  const colorRegex = /^#[0-9A-F]{6}$/i;
  if (data.primary_color && !colorRegex.test(data.primary_color)) {
    errors.primary_color = 'Cor primária deve estar no formato #RRGGBB';
  }
  
  if (data.secondary_color && !colorRegex.test(data.secondary_color)) {
    errors.secondary_color = 'Cor secundária deve estar no formato #RRGGBB';
  }
  
  return {
    isValid: Object.keys(errors).length === 0,
    errors
  };
};

// Validate product data with security considerations
export const validateProductData = (data: any): { isValid: boolean; errors: Record<string, string> } => {
  const errors: Record<string, string> = {};
  
  // Name validation
  if (!data.name || data.name.trim().length < 2) {
    errors.name = 'Nome do produto deve ter pelo menos 2 caracteres';
  } else if (data.name.length > 100) {
    errors.name = 'Nome do produto deve ter no máximo 100 caracteres';
  }
  
  // Price validation
  if (typeof data.price !== 'number' || data.price < 0) {
    errors.price = 'Preço deve ser um número positivo';
  } else if (data.price > 999999.99) {
    errors.price = 'Preço deve ser menor que R$ 999.999,99';
  }
  
  // Promotion price validation (if provided)
  if (data.promotion_price !== undefined && data.promotion_price !== null) {
    if (typeof data.promotion_price !== 'number' || data.promotion_price < 0) {
      errors.promotion_price = 'Preço promocional deve ser um número positivo';
    } else if (data.promotion_price >= data.price) {
      errors.promotion_price = 'Preço promocional deve ser menor que o preço normal';
    }
  }
  
  // Description validation (if provided)
  if (data.description && data.description.length > 500) {
    errors.description = 'Descrição deve ter no máximo 500 caracteres';
  }
  
  // Category validation
  if (!data.category || data.category.trim().length < 2) {
    errors.category = 'Categoria é obrigatória';
  } else if (data.category.length > 50) {
    errors.category = 'Categoria deve ter no máximo 50 caracteres';
  }
  
  return {
    isValid: Object.keys(errors).length === 0,
    errors
  };
};

// Sanitize and validate order data
export const validateOrderData = (data: any): { isValid: boolean; errors: Record<string, string> } => {
  const errors: Record<string, string> = {};
  
  // Customer name
  if (!data.customer_name || data.customer_name.trim().length < 2) {
    errors.customer_name = 'Nome do cliente é obrigatório';
  } else if (data.customer_name.length > 100) {
    errors.customer_name = 'Nome deve ter no máximo 100 caracteres';
  }
  
  // Customer phone (if provided)
  if (data.customer_phone) {
    const phoneRegex = /^\+?[\d\s\-\(\)]{10,20}$/;
    if (!phoneRegex.test(data.customer_phone)) {
      errors.customer_phone = 'Formato de telefone inválido';
    }
  }
  
  // Items validation
  if (!Array.isArray(data.items) || data.items.length === 0) {
    errors.items = 'Pedido deve conter pelo menos um item';
  } else {
    // Validate each item
    data.items.forEach((item: any, index: number) => {
      if (!item.name || typeof item.quantity !== 'number' || typeof item.price !== 'number') {
        errors[`item_${index}`] = `Item ${index + 1} está incompleto`;
      }
    });
  }
  
  // Total validation
  if (typeof data.total !== 'number' || data.total <= 0) {
    errors.total = 'Total do pedido inválido';
  }
  
  return {
    isValid: Object.keys(errors).length === 0,
    errors
  };
};