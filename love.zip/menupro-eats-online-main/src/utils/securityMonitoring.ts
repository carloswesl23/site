// Security monitoring and logging utilities

interface SecurityEvent {
  type: 'rate_limit_exceeded' | 'invalid_file_upload' | 'suspicious_activity' | 'access_denied';
  severity: 'low' | 'medium' | 'high';
  details: Record<string, any>;
  timestamp: number;
  userAgent?: string;
  path?: string;
}

class SecurityMonitor {
  private events: SecurityEvent[] = [];
  private readonly maxEvents = 1000; // Keep last 1000 events in memory

  logEvent(event: Omit<SecurityEvent, 'timestamp' | 'userAgent' | 'path'>): void {
    const securityEvent: SecurityEvent = {
      ...event,
      timestamp: Date.now(),
      userAgent: navigator.userAgent,
      path: window.location.pathname
    };

    this.events.push(securityEvent);

    // Keep only recent events
    if (this.events.length > this.maxEvents) {
      this.events = this.events.slice(-this.maxEvents);
    }

  // Log to console in development only
  if (import.meta.env.DEV) {
    console.warn('Security Event:', securityEvent);
  }

  // In production, send to monitoring service
  this.reportIfSuspicious(securityEvent);
  
  // Send to external monitoring if production
  if (import.meta.env.PROD) {
    this.sendToMonitoringService(securityEvent);
  }
  }

  private reportIfSuspicious(event: SecurityEvent): void {
    if (event.severity === 'high') {
      // In development, log to console
      if (import.meta.env.DEV) {
        console.error('High severity security event:', event);
      }
      
      // In production, this would trigger alerts
      if (import.meta.env.PROD) {
        this.triggerSecurityAlert(event);
      }
    }
  }

  private sendToMonitoringService(event: SecurityEvent): void {
    // In production, this would send to a real monitoring service
    // For now, we'll use a sanitized version for potential future integration
    const sanitizedEvent = {
      type: event.type,
      severity: event.severity,
      timestamp: event.timestamp,
      path: event.path,
      // Remove sensitive details for external logging
      details: this.sanitizeDetails(event.details)
    };
    
    // This would be sent to your monitoring service
    // Example: fetch('/api/security-events', { method: 'POST', body: JSON.stringify(sanitizedEvent) });
  }

  private triggerSecurityAlert(event: SecurityEvent): void {
    // In production, this could trigger immediate alerts
    // Example: send to Slack, email, or incident management system
    console.error('[SECURITY ALERT]', event.type, event.details);
  }

  private sanitizeDetails(details: Record<string, any>): Record<string, any> {
    const sanitized = { ...details };
    
    // Remove potentially sensitive information
    delete sanitized.password;
    delete sanitized.token;
    delete sanitized.apiKey;
    delete sanitized.email;
    
    // Truncate long strings
    Object.keys(sanitized).forEach(key => {
      if (typeof sanitized[key] === 'string' && sanitized[key].length > 100) {
        sanitized[key] = sanitized[key].substring(0, 100) + '...';
      }
    });
    
    return sanitized;
  }

  getRecentEvents(count: number = 50): SecurityEvent[] {
    return this.events.slice(-count);
  }

  getEventsByType(type: SecurityEvent['type']): SecurityEvent[] {
    return this.events.filter(event => event.type === type);
  }

  // Check for suspicious patterns
  detectSuspiciousActivity(): boolean {
    const recentEvents = this.getRecentEvents(20);
    const last5Minutes = Date.now() - (5 * 60 * 1000);
    
    const recentHighSeverity = recentEvents.filter(
      event => event.timestamp > last5Minutes && event.severity === 'high'
    );

    // More than 3 high severity events in 5 minutes
    return recentHighSeverity.length > 3;
  }
}

// Global security monitor instance
const securityMonitor = new SecurityMonitor();

// Convenience functions for logging different types of events
export const logRateLimitExceeded = (endpoint: string, identifier: string): void => {
  securityMonitor.logEvent({
    type: 'rate_limit_exceeded',
    severity: 'medium',
    details: { endpoint, identifier }
  });
};

export const logInvalidFileUpload = (filename: string, reason: string): void => {
  securityMonitor.logEvent({
    type: 'invalid_file_upload',
    severity: 'medium',
    details: { filename, reason }
  });
};

export const logSuspiciousActivity = (activity: string, details: Record<string, any>): void => {
  securityMonitor.logEvent({
    type: 'suspicious_activity',
    severity: 'high',
    details: { activity, ...details }
  });
};

export const logAccessDenied = (resource: string, reason: string): void => {
  securityMonitor.logEvent({
    type: 'access_denied',
    severity: 'low',
    details: { resource, reason }
  });
};

// Get monitoring data
export const getSecurityEvents = securityMonitor.getRecentEvents.bind(securityMonitor);
export const getEventsByType = securityMonitor.getEventsByType.bind(securityMonitor);
export const detectSuspiciousActivity = securityMonitor.detectSuspiciousActivity.bind(securityMonitor);
