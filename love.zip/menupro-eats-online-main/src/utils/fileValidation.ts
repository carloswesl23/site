// File upload security validation utilities

interface FileValidationResult {
  isValid: boolean;
  error?: string;
}

// Allowed image types for security
const ALLOWED_IMAGE_TYPES = [
  'image/jpeg',
  'image/jpg', 
  'image/png',
  'image/webp'
];

// Maximum file size (5MB)
const MAX_FILE_SIZE = 5 * 1024 * 1024;

export const validateImageFile = (file: File): FileValidationResult => {
  // Check file type
  if (!ALLOWED_IMAGE_TYPES.includes(file.type)) {
    return {
      isValid: false,
      error: 'Tipo de arquivo não permitido. Use apenas JPEG, PNG ou WebP.'
    };
  }

  // Check file size
  if (file.size > MAX_FILE_SIZE) {
    return {
      isValid: false,
      error: 'Arquivo muito grande. Tamanho máximo: 5MB.'
    };
  }

  // Check file extension matches MIME type
  const fileExtension = file.name.toLowerCase().split('.').pop();
  const validExtensions = ['jpg', 'jpeg', 'png', 'webp'];
  
  if (!fileExtension || !validExtensions.includes(fileExtension)) {
    return {
      isValid: false,
      error: 'Extensão de arquivo inválida.'
    };
  }

  // Additional security: Check for potential malicious content
  if (file.name.includes('..') || file.name.includes('/') || file.name.includes('\\')) {
    return {
      isValid: false,
      error: 'Nome de arquivo contém caracteres inválidos.'
    };
  }

  return { isValid: true };
};

// Generate secure filename
export const generateSecureFilename = (originalName: string, userId: string): string => {
  const timestamp = Date.now();
  const random = Math.random().toString(36).substring(2, 8);
  const extension = originalName.toLowerCase().split('.').pop();
  
  return `${userId}_${timestamp}_${random}.${extension}`;
};

// Validate file content (basic check)
export const validateFileContent = async (file: File): Promise<FileValidationResult> => {
  return new Promise((resolve) => {
    const reader = new FileReader();
    
    reader.onload = (e) => {
      const buffer = e.target?.result as ArrayBuffer;
      if (!buffer) {
        resolve({ isValid: false, error: 'Não foi possível ler o arquivo.' });
        return;
      }

      const uint8Array = new Uint8Array(buffer);
      
      // Check for basic image file signatures
      const signatures = {
        jpeg: [0xFF, 0xD8, 0xFF],
        png: [0x89, 0x50, 0x4E, 0x47],
        webp: [0x52, 0x49, 0x46, 0x46]
      };

      let isValidSignature = false;
      
      for (const [type, signature] of Object.entries(signatures)) {
        if (signature.every((byte, index) => uint8Array[index] === byte)) {
          isValidSignature = true;
          break;
        }
      }

      if (!isValidSignature) {
        resolve({ isValid: false, error: 'Arquivo não é uma imagem válida.' });
        return;
      }

      resolve({ isValid: true });
    };

    reader.onerror = () => {
      resolve({ isValid: false, error: 'Erro ao processar o arquivo.' });
    };

    reader.readAsArrayBuffer(file.slice(0, 12)); // Read first 12 bytes for signature check
  });
};