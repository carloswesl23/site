// Rate limiting utilities for public endpoints

interface RateLimitConfig {
  maxRequests: number;
  windowMs: number;
  identifier: string;
}

interface RateLimitResult {
  allowed: boolean;
  remaining: number;
  resetTime: number;
}

class RateLimiter {
  private requests: Map<string, number[]> = new Map();

  check(config: RateLimitConfig): RateLimitResult {
    const now = Date.now();
    const windowStart = now - config.windowMs;
    
    // Get existing requests for this identifier
    const existingRequests = this.requests.get(config.identifier) || [];
    
    // Filter out old requests outside the window
    const validRequests = existingRequests.filter(time => time > windowStart);
    
    // Check if limit exceeded
    if (validRequests.length >= config.maxRequests) {
      const oldestRequest = Math.min(...validRequests);
      const resetTime = oldestRequest + config.windowMs;
      
      return {
        allowed: false,
        remaining: 0,
        resetTime
      };
    }
    
    // Add current request
    validRequests.push(now);
    this.requests.set(config.identifier, validRequests);
    
    return {
      allowed: true,
      remaining: config.maxRequests - validRequests.length,
      resetTime: now + config.windowMs
    };
  }

  // Clean up old entries periodically
  cleanup(): void {
    const now = Date.now();
    const maxAge = 24 * 60 * 60 * 1000; // 24 hours
    
    for (const [identifier, requests] of this.requests.entries()) {
      const validRequests = requests.filter(time => time > now - maxAge);
      
      if (validRequests.length === 0) {
        this.requests.delete(identifier);
      } else {
        this.requests.set(identifier, validRequests);
      }
    }
  }
}

// Global rate limiter instance
const globalRateLimiter = new RateLimiter();

// Preset configurations
export const RATE_LIMITS = {
  // Public menu access - 60 requests per minute per IP
  PUBLIC_MENU: {
    maxRequests: 60,
    windowMs: 60 * 1000 // 1 minute
  },
  
  // Menu image requests - 120 requests per minute per IP
  MENU_IMAGES: {
    maxRequests: 120,
    windowMs: 60 * 1000 // 1 minute
  },
  
  // Order submissions - 10 requests per 5 minutes per IP
  ORDER_SUBMISSION: {
    maxRequests: 10,
    windowMs: 5 * 60 * 1000 // 5 minutes
  }
};

// Rate limit check for public endpoints
export const checkRateLimit = (
  type: keyof typeof RATE_LIMITS,
  identifier: string
): RateLimitResult => {
  const config = RATE_LIMITS[type];
  
  return globalRateLimiter.check({
    ...config,
    identifier: `${type}_${identifier}`
  });
};

// Get client identifier (IP-based for basic protection)
export const getClientIdentifier = (): string => {
  // In a real environment, this would use the actual client IP
  // For now, we'll use a browser fingerprint approach
  const fingerprint = [
    navigator.userAgent,
    navigator.language,
    screen.width,
    screen.height,
    new Date().getTimezoneOffset()
  ].join('|');
  
  // Simple hash function
  let hash = 0;
  for (let i = 0; i < fingerprint.length; i++) {
    const char = fingerprint.charCodeAt(i);
    hash = ((hash << 5) - hash) + char;
    hash = hash & hash; // Convert to 32-bit integer
  }
  
  return Math.abs(hash).toString();
};

// Setup periodic cleanup
setInterval(() => {
  globalRateLimiter.cleanup();
}, 60 * 60 * 1000); // Every hour