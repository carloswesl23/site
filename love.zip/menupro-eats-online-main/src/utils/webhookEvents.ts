
// Tipos de dados para cada evento
export interface PedidoCriadoData {
  pedido_id: string;
  cliente_nome: string;
  cliente_telefone: string;
  itens: Array<{
    produto: string;
    quantidade: number;
    preco: number;
  }>;
  total: number;
  forma_pagamento: string;
  endereco_entrega?: string;
  observacoes?: string;
}

export interface PagamentoConfirmadoData {
  pedido_id: string;
  valor_pago: number;
  forma_pagamento: string;
  transacao_id?: string;
  pix_txid?: string;
}

export interface PedidoCanceladoData {
  pedido_id: string;
  motivo: string;
  cancelado_por: 'cliente' | 'estabelecimento';
  reembolso_necessario: boolean;
}

export interface NovoClienteData {
  estabelecimento_id: string;
  nome_estabelecimento: string;
  email: string;
  telefone: string;
  cidade: string;
  plano: string;
}

// Tipos de eventos disponíveis
export type WebhookEventType = 'pedido_criado' | 'pagamento_confirmado' | 'pedido_cancelado' | 'novo_cliente';

export interface WebhookEventData {
  event_type: WebhookEventType;
  data: PedidoCriadoData | PagamentoConfirmadoData | PedidoCanceladoData | NovoClienteData;
}

// Hook personalizado para usar o webhook sender nos componentes
export const useWebhookEvents = () => {
  // Este hook deve ser importado e usado nos componentes que precisam disparar webhooks
  // Exemplo de uso nos componentes:
  /*
  import { useWebhookEvents } from '@/utils/webhookEvents';
  
  const MyComponent = () => {
    const { triggerPedidoCriado, triggerPagamentoConfirmado } = useWebhookEvents();
    
    const handleFinalizarPedido = async (pedidoData) => {
      // ... lógica para salvar o pedido
      
      // Disparar webhook
      await triggerPedidoCriado({
        pedido_id: novoPedido.id,
        cliente_nome: cliente.nome,
        cliente_telefone: cliente.telefone,
        itens: pedido.itens,
        total: pedido.total,
        forma_pagamento: pedido.pagamento,
        endereco_entrega: pedido.endereco,
        observacoes: pedido.observacoes
      });
    };
    
    return (
      // ... JSX do componente
    );
  };
  */
  
  return {
    // Funções helper que podem ser usadas nos componentes
    createWebhookData: (eventType: WebhookEventType, data: any): WebhookEventData => ({
      event_type: eventType,
      data
    })
  };
};
