// Production-safe logging utility

type LogLevel = 'debug' | 'info' | 'warn' | 'error';

interface LogEntry {
  level: LogLevel;
  message: string;
  data?: any;
  timestamp: string;
  userAgent?: string;
  path?: string;
}

class Logger {
  private isDevelopment = import.meta.env.DEV;
  private isProduction = import.meta.env.PROD;

  private sanitizeData(data: any): any {
    if (!data) return data;
    
    if (typeof data === 'string') {
      return this.sanitizeString(data);
    }
    
    if (typeof data === 'object') {
      const sanitized = { ...data };
      
      // Remove sensitive fields
      const sensitiveFields = [
        'password', 'token', 'apiKey', 'secret', 'authorization',
        'cookie', 'session', 'csrf', 'jwt', 'auth', 'key'
      ];
      
      sensitiveFields.forEach(field => {
        if (sanitized[field]) {
          sanitized[field] = '[REDACTED]';
        }
      });
      
      // Recursively sanitize nested objects
      Object.keys(sanitized).forEach(key => {
        if (typeof sanitized[key] === 'object' && sanitized[key] !== null) {
          sanitized[key] = this.sanitizeData(sanitized[key]);
        } else if (typeof sanitized[key] === 'string') {
          sanitized[key] = this.sanitizeString(sanitized[key]);
        }
      });
      
      return sanitized;
    }
    
    return data;
  }

  private sanitizeString(str: string): string {
    return str
      .replace(/\b[\w\.-]+@[\w\.-]+\.\w+\b/g, '[EMAIL]')
      .replace(/\b(?:\d{1,3}\.){3}\d{1,3}\b/g, '[IP]')
      .replace(/\b[A-Za-z0-9]{20,}\b/g, '[TOKEN]')
      .substring(0, 1000); // Limit string length
  }

  private createLogEntry(level: LogLevel, message: string, data?: any): LogEntry {
    return {
      level,
      message: this.sanitizeString(message),
      data: this.sanitizeData(data),
      timestamp: new Date().toISOString(),
      userAgent: navigator?.userAgent,
      path: window?.location?.pathname
    };
  }

  private shouldLog(level: LogLevel): boolean {
    if (this.isDevelopment) return true;
    
    // In production, only log warnings and errors
    return level === 'warn' || level === 'error';
  }

  debug(message: string, data?: any): void {
    if (!this.shouldLog('debug')) return;
    
    const entry = this.createLogEntry('debug', message, data);
    console.debug(`[DEBUG] ${entry.message}`, entry.data);
  }

  info(message: string, data?: any): void {
    if (!this.shouldLog('info')) return;
    
    const entry = this.createLogEntry('info', message, data);
    console.info(`[INFO] ${entry.message}`, entry.data);
  }

  warn(message: string, data?: any): void {
    if (!this.shouldLog('warn')) return;
    
    const entry = this.createLogEntry('warn', message, data);
    console.warn(`[WARN] ${entry.message}`, entry.data);
    
    // In production, send warnings to monitoring service
    if (this.isProduction) {
      this.sendToMonitoring(entry);
    }
  }

  error(message: string, data?: any): void {
    if (!this.shouldLog('error')) return;
    
    const entry = this.createLogEntry('error', message, data);
    console.error(`[ERROR] ${entry.message}`, entry.data);
    
    // Always send errors to monitoring in production
    if (this.isProduction) {
      this.sendToMonitoring(entry);
    }
  }

  private sendToMonitoring(entry: LogEntry): void {
    // In production, this would send to your monitoring service
    // For now, we'll prepare the data structure for future integration
    const monitoringPayload = {
      level: entry.level,
      message: entry.message,
      timestamp: entry.timestamp,
      metadata: {
        userAgent: entry.userAgent,
        path: entry.path,
        environment: 'production'
      },
      // Only include non-sensitive data
      data: entry.data ? this.sanitizeData(entry.data) : undefined
    };
    
    // Future: Send to monitoring service
    // fetch('/api/logs', { method: 'POST', body: JSON.stringify(monitoringPayload) });
  }
}

// Export singleton instance
export const logger = new Logger();

// Convenience methods for common use cases
export const logError = (message: string, error?: Error | any) => {
  logger.error(message, error instanceof Error ? {
    name: error.name,
    message: error.message,
    stack: error.stack
  } : error);
};

export const logWarning = (message: string, data?: any) => {
  logger.warn(message, data);
};

export const logInfo = (message: string, data?: any) => {
  logger.info(message, data);
};

export const logDebug = (message: string, data?: any) => {
  logger.debug(message, data);
};