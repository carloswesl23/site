// Production-specific security utilities

import { logSuspiciousActivity, logAccessDenied } from '@/utils/securityMonitoring';
import { logger } from '@/utils/logger';

// Rate limiting for public endpoints
const publicEndpointLimiter = new Map<string, { count: number; resetTime: number }>();

export const checkPublicEndpointRateLimit = (endpoint: string, ip: string, limit: number = 100, windowMs: number = 60000): boolean => {
  if (import.meta.env.DEV) return true; // Skip in development
  
  const key = `${endpoint}_${ip}`;
  const now = Date.now();
  const limiterData = publicEndpointLimiter.get(key);
  
  if (!limiterData || now > limiterData.resetTime) {
    publicEndpointLimiter.set(key, { count: 1, resetTime: now + windowMs });
    return true;
  }
  
  if (limiterData.count >= limit) {
    logSuspiciousActivity('public_endpoint_rate_limit_exceeded', {
      endpoint,
      ip: ip.substring(0, 10) + '...', // Partially hide IP for privacy
      count: limiterData.count,
      limit
    });
    return false;
  }
  
  limiterData.count++;
  return true;
};

// Monitor for suspicious menu access patterns
export const monitorMenuAccess = (slug: string, userAgent: string): void => {
  if (import.meta.env.DEV) return; // Skip in development
  
  // Check for bot-like patterns
  const suspiciousBotPatterns = [
    /curl/i,
    /wget/i,
    /python/i,
    /scrapy/i,
    /bot/i,
    /crawler/i,
    /spider/i
  ];
  
  const isSuspiciousBot = suspiciousBotPatterns.some(pattern => pattern.test(userAgent));
  
  if (isSuspiciousBot) {
    logSuspiciousActivity('suspicious_bot_access', {
      slug,
      userAgent: userAgent.substring(0, 100), // Limit length
      pattern: 'bot_detection'
    });
  }
  
  // Monitor for rapid sequential access
  const accessKey = `menu_access_${slug}`;
  const recentAccess = sessionStorage.getItem(accessKey);
  const now = Date.now();
  
  if (recentAccess) {
    const accessTimes = JSON.parse(recentAccess);
    const recentAccessCount = accessTimes.filter((time: number) => now - time < 10000).length; // 10 seconds
    
    if (recentAccessCount > 10) {
      logSuspiciousActivity('rapid_menu_access', {
        slug,
        accessCount: recentAccessCount,
        timeWindow: '10s'
      });
    }
    
    accessTimes.push(now);
    // Keep only last 20 access times
    sessionStorage.setItem(accessKey, JSON.stringify(accessTimes.slice(-20)));
  } else {
    sessionStorage.setItem(accessKey, JSON.stringify([now]));
  }
};

// Validate establishment data access
export const validateEstablishmentAccess = (slug: string, data: any): boolean => {
  if (!slug || !data) {
    logAccessDenied('establishment_data', 'invalid_parameters');
    return false;
  }
  
  // Check for SQL injection patterns in slug
  const sqlInjectionPatterns = [
    /(\b(SELECT|INSERT|UPDATE|DELETE|DROP|CREATE|ALTER)\b)/i,
    /(UNION|OR|AND)\s+\d+=\d+/i,
    /[';"]\s*(SELECT|INSERT|UPDATE|DELETE)/i,
    /\/\*.*\*\//,
    /--[^\r\n]*/
  ];
  
  const hasSqlInjection = sqlInjectionPatterns.some(pattern => pattern.test(slug));
  
  if (hasSqlInjection) {
    logSuspiciousActivity('sql_injection_attempt', {
      slug: slug.substring(0, 50), // Limit for logging
      pattern: 'establishment_access'
    });
    return false;
  }
  
  return true;
};

// Clean up sensitive data from objects before logging
export const sanitizeForLogging = (obj: any): any => {
  if (!obj) return obj;
  
  const sanitized = { ...obj };
  const sensitiveFields = [
    'password', 'token', 'secret', 'key', 'auth', 'jwt',
    'email', 'phone', 'address', 'customer_phone', 'customer_email'
  ];
  
  sensitiveFields.forEach(field => {
    if (sanitized[field]) {
      sanitized[field] = '[REDACTED]';
    }
  });
  
  return sanitized;
};

// Monitor for XSS attempts in user input
export const detectXSSAttempts = (input: string, fieldName: string): boolean => {
  if (!input || typeof input !== 'string') return false;
  
  const xssPatterns = [
    /<script[^>]*>.*?<\/script>/gi,
    /javascript:/gi,
    /on\w+\s*=/gi,
    /<iframe[^>]*>.*?<\/iframe>/gi,
    /<embed[^>]*>/gi,
    /<object[^>]*>.*?<\/object>/gi,
    /data:text\/html/gi,
    /vbscript:/gi
  ];
  
  const hasXSS = xssPatterns.some(pattern => pattern.test(input));
  
  if (hasXSS) {
    logSuspiciousActivity('xss_attempt', {
      fieldName,
      inputLength: input.length,
      pattern: 'user_input_validation'
    });
    
    logger.warn('XSS attempt detected', {
      field: fieldName,
      inputPreview: input.substring(0, 100)
    });
    
    return true;
  }
  
  return false;
};

// Initialize security monitoring for production
export const initializeProductionSecurity = (): void => {
  if (import.meta.env.DEV) return;
  
  // Monitor for console tampering
  let devtools = { open: false, orientation: null };
  const threshold = 160;
  
  setInterval(() => {
    if (window.outerHeight - window.innerHeight > threshold || 
        window.outerWidth - window.innerWidth > threshold) {
      if (!devtools.open) {
        devtools.open = true;
        logSuspiciousActivity('devtools_opened', {
          windowSize: `${window.innerWidth}x${window.innerHeight}`,
          outerSize: `${window.outerWidth}x${window.outerHeight}`
        });
      }
    } else {
      devtools.open = false;
    }
  }, 500);
  
  // Monitor for right-click disabling attempts
  document.addEventListener('contextmenu', (e) => {
    // Allow normal right-click, but log excessive attempts
    const rightClickCount = sessionStorage.getItem('rightClickCount') || '0';
    const count = parseInt(rightClickCount) + 1;
    
    if (count > 50) { // More than 50 right-clicks in a session
      logSuspiciousActivity('excessive_right_clicks', { count });
    }
    
    sessionStorage.setItem('rightClickCount', count.toString());
  });
  
  logger.info('Production security monitoring initialized');
};
