// Centralized error handling with security considerations

interface ErrorInfo {
  type: 'validation' | 'auth' | 'network' | 'permission' | 'unknown';
  message: string;
  shouldLog: boolean;
  isUserFacing: boolean;
}

export const handleError = (error: any, context?: string): ErrorInfo => {
  // Sanitize error for logging
  const sanitizedError = sanitizeErrorForLogging(error);
  console.error(`Error in ${context || 'application'}:`, sanitizedError);

  // Determine error type and user-facing message
  if (error?.message?.includes('Invalid login credentials')) {
    return {
      type: 'auth',
      message: 'Credenciais inválidas. Verifique email e senha.',
      shouldLog: false, // Don't log sensitive auth errors
      isUserFacing: true
    };
  }

  if (error?.message?.includes('Email not confirmed')) {
    return {
      type: 'auth',
      message: 'Por favor, confirme seu email antes de continuar.',
      shouldLog: false,
      isUserFacing: true
    };
  }

  if (error?.message?.includes('Network')) {
    return {
      type: 'network',
      message: 'Problema de conexão. Tente novamente.',
      shouldLog: true,
      isUserFacing: true
    };
  }

  if (error?.code === 'PERMISSION_DENIED') {
    return {
      type: 'permission',
      message: 'Você não tem permissão para esta ação.',
      shouldLog: true,
      isUserFacing: true
    };
  }

  // Default to generic error message for security
  return {
    type: 'unknown',
    message: 'Ocorreu um erro inesperado. Tente novamente.',
    shouldLog: true,
    isUserFacing: true
  };
};

// Sanitize error messages for logging
export const sanitizeErrorForLogging = (error: any): string => {
  if (typeof error === 'string') {
    return error.replace(/\b[\w\.-]+@[\w\.-]+\.\w+\b/g, '[EMAIL]'); // Remove emails
  }
  
  if (error?.message) {
    return error.message.replace(/\b[\w\.-]+@[\w\.-]+\.\w+\b/g, '[EMAIL]');
  }
  
  return 'Unknown error occurred';
};

// Rate limiting for error reporting
const errorReportLimiter = new Map<string, number>();

export const shouldReportError = (errorType: string, limit: number = 5, windowMs: number = 60000): boolean => {
  const now = Date.now();
  const key = `${errorType}_${Math.floor(now / windowMs)}`;
  
  const count = errorReportLimiter.get(key) || 0;
  if (count >= limit) {
    return false;
  }
  
  errorReportLimiter.set(key, count + 1);
  return true;
};