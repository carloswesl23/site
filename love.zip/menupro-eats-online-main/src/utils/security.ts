// Security utilities for input validation and sanitization

export const validateEmail = (email: string): { isValid: boolean; error?: string } => {
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  const trimmedEmail = email.trim();
  
  if (!trimmedEmail) {
    return { isValid: false, error: "Email é obrigatório" };
  }
  
  if (!emailRegex.test(trimmedEmail)) {
    return { isValid: false, error: "Formato de email inválido" };
  }
  
  if (trimmedEmail.length > 254) {
    return { isValid: false, error: "Email muito longo" };
  }
  
  return { isValid: true };
};

export const validatePhone = (phone: string): { isValid: boolean; error?: string } => {
  const phoneRegex = /^[\+]?[1-9][\d]{0,15}$/;
  const cleanPhone = phone.replace(/[\s\-\(\)]/g, '');
  
  if (!phone.trim()) {
    return { isValid: false, error: "Telefone é obrigatório" };
  }
  
  if (cleanPhone.length < 10 || cleanPhone.length > 16) {
    return { isValid: false, error: "Número de telefone deve ter entre 10 e 16 dígitos" };
  }
  
  if (!phoneRegex.test(cleanPhone)) {
    return { isValid: false, error: "Formato de telefone inválido" };
  }
  
  return { isValid: true };
};

export const validateName = (name: string): { isValid: boolean; error?: string } => {
  const trimmedName = name.trim();
  
  if (!trimmedName) {
    return { isValid: false, error: "Nome é obrigatório" };
  }
  
  if (trimmedName.length < 2) {
    return { isValid: false, error: "Nome deve ter pelo menos 2 caracteres" };
  }
  
  if (trimmedName.length > 100) {
    return { isValid: false, error: "Nome muito longo" };
  }
  
  // Check for potentially malicious characters
  const dangerousChars = /<script|javascript:|on\w+=/i;
  if (dangerousChars.test(trimmedName)) {
    return { isValid: false, error: "Nome contém caracteres inválidos" };
  }
  
  return { isValid: true };
};

export const validateAddress = (address: string): { isValid: boolean; error?: string } => {
  const trimmedAddress = address.trim();
  
  if (!trimmedAddress) {
    return { isValid: false, error: "Endereço é obrigatório" };
  }
  
  if (trimmedAddress.length < 5) {
    return { isValid: false, error: "Endereço deve ter pelo menos 5 caracteres" };
  }
  
  if (trimmedAddress.length > 200) {
    return { isValid: false, error: "Endereço muito longo" };
  }
  
  // Check for potentially malicious characters
  const dangerousChars = /<script|javascript:|on\w+=/i;
  if (dangerousChars.test(trimmedAddress)) {
    return { isValid: false, error: "Endereço contém caracteres inválidos" };
  }
  
  return { isValid: true };
};

export const sanitizeInput = (input: string, preserveSpaces = false): string => {
  let sanitized = input;
  
  if (!preserveSpaces) {
    sanitized = input.trim();
  }
  
  return sanitized
    .replace(/[<>]/g, '') // Remove potential HTML tags
    .replace(/javascript:/gi, '') // Remove javascript: protocol
    .replace(/on\w+=/gi, ''); // Remove event handlers
};

export const validatePassword = (password: string): { isValid: boolean; error?: string } => {
  if (!password) {
    return { isValid: false, error: "Senha é obrigatória" };
  }
  
  if (password.length < 8) {
    return { isValid: false, error: "Senha deve ter pelo menos 8 caracteres" };
  }
  
  if (password.length > 128) {
    return { isValid: false, error: "Senha muito longa" };
  }
  
  // Check for at least one letter and one number
  const hasLetter = /[a-zA-Z]/.test(password);
  const hasNumber = /\d/.test(password);
  
  if (!hasLetter || !hasNumber) {
    return { isValid: false, error: "Senha deve conter pelo menos uma letra e um número" };
  }
  
  return { isValid: true };
};

// Rate limiting helper
export const createRateLimiter = (limit: number, windowMs: number) => {
  const requests = new Map<string, number[]>();
  
  return (identifier: string): boolean => {
    const now = Date.now();
    const windowStart = now - windowMs;
    
    if (!requests.has(identifier)) {
      requests.set(identifier, []);
    }
    
    const userRequests = requests.get(identifier)!;
    
    // Remove old requests outside the window
    const validRequests = userRequests.filter(time => time > windowStart);
    
    if (validRequests.length >= limit) {
      return false; // Rate limit exceeded
    }
    
    validRequests.push(now);
    requests.set(identifier, validRequests);
    
    return true; // Request allowed
  };
};

// Generic error messages to prevent information disclosure
export const getGenericErrorMessage = (type: 'auth' | 'validation' | 'network'): string => {
  switch (type) {
    case 'auth':
      return 'Falha na autenticação. Verifique suas credenciais.';
    case 'validation':
      return 'Dados inválidos. Verifique os campos e tente novamente.';
    case 'network':
      return 'Erro de conexão. Tente novamente em alguns instantes.';
    default:
      return 'Ocorreu um erro inesperado. Tente novamente.';
  }
};