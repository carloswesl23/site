import { supabase } from '@/integrations/supabase/client';

/**
 * Gera uma slug a partir do nome da empresa com código único
 */
export function generateSlugFromName(businessName: string): string {
  const baseSlug = businessName
    .toLowerCase()
    .normalize('NFD') // Remove acentos
    .replace(/[\u0300-\u036f]/g, '')
    .replace(/[^a-z0-9\s-]/g, '') // Remove caracteres especiais
    .replace(/\s+/g, '-') // Substitui espaços por hífens
    .replace(/-+/g, '-') // Remove hífens duplos
    .replace(/^-+|-+$/g, ''); // Remove hífens do início e fim
  
  // Gera um código único de 4 caracteres (letras e números minúsculos)
  const uniqueCode = Math.random().toString(36).substring(2, 6);
  
  return `${baseSlug}-${uniqueCode}`;
}

/**
 * Verifica se uma slug já existe no banco
 */
export async function checkSlugExists(slug: string): Promise<boolean> {
  try {
    const { data, error } = await supabase
      .from('establishment_settings')
      .select('id')
      .eq('online_menu_slug', slug)
      .single();

    if (error && error.code === 'PGRST116') {
      // Slug não encontrada - disponível
      return false;
    }

    return !!data;
  } catch (error) {
    console.error('Error checking slug existence:', error);
    return true; // Em caso de erro, assumir que existe para evitar conflitos
  }
}

/**
 * Gera uma slug única, adicionando sufixo se necessário
 */
export async function generateUniqueSlug(businessName: string): Promise<string> {
  let finalSlug = generateSlugFromName(businessName);
  
  // Verifica se a slug já existe, se existir gera uma nova
  while (await checkSlugExists(finalSlug)) {
    finalSlug = generateSlugFromName(businessName);
  }

  return finalSlug;
}