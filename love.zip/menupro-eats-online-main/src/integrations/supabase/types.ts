export type Json =
  | string
  | number
  | boolean
  | null
  | { [key: string]: Json | undefined }
  | Json[]

export type Database = {
  // Allows to automatically instantiate createClient with right options
  // instead of createClient<Database, { PostgrestVersion: 'XX' }>(URL, KEY)
  __InternalSupabase: {
    PostgrestVersion: "12.2.12 (cd3cf9e)"
  }
  public: {
    Tables: {
      broadcast_jobs: {
        Row: {
          created_at: string | null
          created_by: string | null
          delivered_count: number | null
          error_count: number | null
          id: string
          instance_id: string
          name: string
          read_count: number | null
          scheduled_for: string | null
          segment: Json | null
          sent_count: number | null
          status: string
          template_id: string | null
          template_vars: Json | null
          tenant_id: string | null
          total_recipients: number | null
          updated_at: string | null
          user_id: string
        }
        Insert: {
          created_at?: string | null
          created_by?: string | null
          delivered_count?: number | null
          error_count?: number | null
          id?: string
          instance_id: string
          name: string
          read_count?: number | null
          scheduled_for?: string | null
          segment?: Json | null
          sent_count?: number | null
          status?: string
          template_id?: string | null
          template_vars?: Json | null
          tenant_id?: string | null
          total_recipients?: number | null
          updated_at?: string | null
          user_id: string
        }
        Update: {
          created_at?: string | null
          created_by?: string | null
          delivered_count?: number | null
          error_count?: number | null
          id?: string
          instance_id?: string
          name?: string
          read_count?: number | null
          scheduled_for?: string | null
          segment?: Json | null
          sent_count?: number | null
          status?: string
          template_id?: string | null
          template_vars?: Json | null
          tenant_id?: string | null
          total_recipients?: number | null
          updated_at?: string | null
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "broadcast_jobs_template_id_fkey"
            columns: ["template_id"]
            isOneToOne: false
            referencedRelation: "wa_templates"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "broadcast_jobs_tenant_id_fkey"
            columns: ["tenant_id"]
            isOneToOne: false
            referencedRelation: "whatsapp_instances"
            referencedColumns: ["id"]
          },
        ]
      }
      broadcast_recipients: {
        Row: {
          ack_at: string | null
          created_at: string | null
          delivered_at: string | null
          error_details: string | null
          id: string
          job_id: string
          last_error: string | null
          phone_e164: string
          read_at: string | null
          sent_at: string | null
          status: string
          vars: Json | null
        }
        Insert: {
          ack_at?: string | null
          created_at?: string | null
          delivered_at?: string | null
          error_details?: string | null
          id?: string
          job_id: string
          last_error?: string | null
          phone_e164: string
          read_at?: string | null
          sent_at?: string | null
          status?: string
          vars?: Json | null
        }
        Update: {
          ack_at?: string | null
          created_at?: string | null
          delivered_at?: string | null
          error_details?: string | null
          id?: string
          job_id?: string
          last_error?: string | null
          phone_e164?: string
          read_at?: string | null
          sent_at?: string | null
          status?: string
          vars?: Json | null
        }
        Relationships: [
          {
            foreignKeyName: "broadcast_recipients_job_id_fkey"
            columns: ["job_id"]
            isOneToOne: false
            referencedRelation: "broadcast_jobs"
            referencedColumns: ["id"]
          },
        ]
      }
      category_preparation_times: {
        Row: {
          category_name: string
          created_at: string
          id: string
          preparation_time: number
          updated_at: string
          user_id: string
        }
        Insert: {
          category_name: string
          created_at?: string
          id?: string
          preparation_time: number
          updated_at?: string
          user_id: string
        }
        Update: {
          category_name?: string
          created_at?: string
          id?: string
          preparation_time?: number
          updated_at?: string
          user_id?: string
        }
        Relationships: []
      }
      contacts: {
        Row: {
          created_at: string | null
          id: string
          last_interaction_at: string | null
          last_seen_at: string | null
          name: string | null
          opt_in: boolean | null
          phone_e164: string
          presence_status: string | null
          tags: string[] | null
          updated_at: string | null
          user_id: string
        }
        Insert: {
          created_at?: string | null
          id?: string
          last_interaction_at?: string | null
          last_seen_at?: string | null
          name?: string | null
          opt_in?: boolean | null
          phone_e164: string
          presence_status?: string | null
          tags?: string[] | null
          updated_at?: string | null
          user_id: string
        }
        Update: {
          created_at?: string | null
          id?: string
          last_interaction_at?: string | null
          last_seen_at?: string | null
          name?: string | null
          opt_in?: boolean | null
          phone_e164?: string
          presence_status?: string | null
          tags?: string[] | null
          updated_at?: string | null
          user_id?: string
        }
        Relationships: []
      }
      coupon_usage: {
        Row: {
          coupon_id: string
          created_at: string
          customer_name: string
          customer_phone: string | null
          discount_applied: number
          id: string
          order_id: string
          order_total: number
          user_id: string
        }
        Insert: {
          coupon_id: string
          created_at?: string
          customer_name: string
          customer_phone?: string | null
          discount_applied: number
          id?: string
          order_id: string
          order_total: number
          user_id: string
        }
        Update: {
          coupon_id?: string
          created_at?: string
          customer_name?: string
          customer_phone?: string | null
          discount_applied?: number
          id?: string
          order_id?: string
          order_total?: number
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "coupon_usage_coupon_id_fkey"
            columns: ["coupon_id"]
            isOneToOne: false
            referencedRelation: "discount_coupons"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "coupon_usage_order_id_fkey"
            columns: ["order_id"]
            isOneToOne: false
            referencedRelation: "user_orders"
            referencedColumns: ["id"]
          },
        ]
      }
      couriers: {
        Row: {
          created_at: string
          id: string
          is_available: boolean
          is_default: boolean | null
          name: string
          notes: string | null
          phone: string
          updated_at: string
          user_id: string
          vehicle_type: string | null
        }
        Insert: {
          created_at?: string
          id?: string
          is_available?: boolean
          is_default?: boolean | null
          name: string
          notes?: string | null
          phone: string
          updated_at?: string
          user_id: string
          vehicle_type?: string | null
        }
        Update: {
          created_at?: string
          id?: string
          is_available?: boolean
          is_default?: boolean | null
          name?: string
          notes?: string | null
          phone?: string
          updated_at?: string
          user_id?: string
          vehicle_type?: string | null
        }
        Relationships: []
      }
      customer_addresses: {
        Row: {
          city: string
          complement: string | null
          created_at: string | null
          customer_id: string
          district: string | null
          id: string
          is_default: boolean | null
          label: string | null
          number: string | null
          state: string
          street: string
          tenant_id: string
          zipcode: string | null
        }
        Insert: {
          city: string
          complement?: string | null
          created_at?: string | null
          customer_id: string
          district?: string | null
          id?: string
          is_default?: boolean | null
          label?: string | null
          number?: string | null
          state: string
          street: string
          tenant_id: string
          zipcode?: string | null
        }
        Update: {
          city?: string
          complement?: string | null
          created_at?: string | null
          customer_id?: string
          district?: string | null
          id?: string
          is_default?: boolean | null
          label?: string | null
          number?: string | null
          state?: string
          street?: string
          tenant_id?: string
          zipcode?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "customer_addresses_customer_id_fkey"
            columns: ["customer_id"]
            isOneToOne: false
            referencedRelation: "customers"
            referencedColumns: ["id"]
          },
        ]
      }
      customers: {
        Row: {
          created_at: string | null
          id: string
          name: string | null
          phone_e164: string
          tenant_id: string
          updated_at: string | null
        }
        Insert: {
          created_at?: string | null
          id?: string
          name?: string | null
          phone_e164: string
          tenant_id: string
          updated_at?: string | null
        }
        Update: {
          created_at?: string | null
          id?: string
          name?: string | null
          phone_e164?: string
          tenant_id?: string
          updated_at?: string | null
        }
        Relationships: []
      }
      deliveries: {
        Row: {
          assigned_at: string
          assigned_by: string | null
          canceled_at: string | null
          created_at: string
          delivered_at: string | null
          id: string
          motoboy_id: string
          notes: string | null
          order_id: string
          picked_up_at: string | null
          price_cents: number | null
          status: Database["public"]["Enums"]["delivery_status"]
          updated_at: string
          user_id: string
        }
        Insert: {
          assigned_at?: string
          assigned_by?: string | null
          canceled_at?: string | null
          created_at?: string
          delivered_at?: string | null
          id?: string
          motoboy_id: string
          notes?: string | null
          order_id: string
          picked_up_at?: string | null
          price_cents?: number | null
          status?: Database["public"]["Enums"]["delivery_status"]
          updated_at?: string
          user_id: string
        }
        Update: {
          assigned_at?: string
          assigned_by?: string | null
          canceled_at?: string | null
          created_at?: string
          delivered_at?: string | null
          id?: string
          motoboy_id?: string
          notes?: string | null
          order_id?: string
          picked_up_at?: string | null
          price_cents?: number | null
          status?: Database["public"]["Enums"]["delivery_status"]
          updated_at?: string
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "deliveries_motoboy_id_fkey"
            columns: ["motoboy_id"]
            isOneToOne: false
            referencedRelation: "motoboys"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "deliveries_order_id_fkey"
            columns: ["order_id"]
            isOneToOne: false
            referencedRelation: "user_orders"
            referencedColumns: ["id"]
          },
        ]
      }
      delivery_assignments: {
        Row: {
          accepted_at: string | null
          assigned_at: string | null
          attempts: number | null
          courier_id: string | null
          created_at: string | null
          delivered_at: string | null
          driver_id: string
          id: string
          last_error: string | null
          notes: string | null
          order_id: string
          out_for_delivery_at: string | null
          status: string
          updated_at: string | null
        }
        Insert: {
          accepted_at?: string | null
          assigned_at?: string | null
          attempts?: number | null
          courier_id?: string | null
          created_at?: string | null
          delivered_at?: string | null
          driver_id: string
          id?: string
          last_error?: string | null
          notes?: string | null
          order_id: string
          out_for_delivery_at?: string | null
          status?: string
          updated_at?: string | null
        }
        Update: {
          accepted_at?: string | null
          assigned_at?: string | null
          attempts?: number | null
          courier_id?: string | null
          created_at?: string | null
          delivered_at?: string | null
          driver_id?: string
          id?: string
          last_error?: string | null
          notes?: string | null
          order_id?: string
          out_for_delivery_at?: string | null
          status?: string
          updated_at?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "delivery_assignments_driver_id_fkey"
            columns: ["driver_id"]
            isOneToOne: false
            referencedRelation: "delivery_drivers"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "delivery_assignments_order_id_fkey"
            columns: ["order_id"]
            isOneToOne: false
            referencedRelation: "user_orders"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "fk_delivery_assignments_courier"
            columns: ["courier_id"]
            isOneToOne: false
            referencedRelation: "couriers"
            referencedColumns: ["id"]
          },
        ]
      }
      delivery_drivers: {
        Row: {
          created_at: string | null
          employment_type: string
          id: string
          is_active: boolean | null
          is_default: boolean | null
          name: string
          phone_e164: string
          updated_at: string | null
          user_id: string
        }
        Insert: {
          created_at?: string | null
          employment_type: string
          id?: string
          is_active?: boolean | null
          is_default?: boolean | null
          name: string
          phone_e164: string
          updated_at?: string | null
          user_id: string
        }
        Update: {
          created_at?: string | null
          employment_type?: string
          id?: string
          is_active?: boolean | null
          is_default?: boolean | null
          name?: string
          phone_e164?: string
          updated_at?: string | null
          user_id?: string
        }
        Relationships: []
      }
      discount_coupons: {
        Row: {
          applies_to_categories: string[] | null
          applies_to_products: string[] | null
          applies_to_type: string | null
          auto_apply: boolean
          code: string
          created_at: string
          current_uses: number
          discount_type: string
          discount_value: number
          id: string
          is_active: boolean
          max_uses: number | null
          name: string
          updated_at: string
          user_id: string
          valid_from: string
          valid_until: string | null
        }
        Insert: {
          applies_to_categories?: string[] | null
          applies_to_products?: string[] | null
          applies_to_type?: string | null
          auto_apply?: boolean
          code: string
          created_at?: string
          current_uses?: number
          discount_type: string
          discount_value: number
          id?: string
          is_active?: boolean
          max_uses?: number | null
          name: string
          updated_at?: string
          user_id: string
          valid_from?: string
          valid_until?: string | null
        }
        Update: {
          applies_to_categories?: string[] | null
          applies_to_products?: string[] | null
          applies_to_type?: string | null
          auto_apply?: boolean
          code?: string
          created_at?: string
          current_uses?: number
          discount_type?: string
          discount_value?: number
          id?: string
          is_active?: boolean
          max_uses?: number | null
          name?: string
          updated_at?: string
          user_id?: string
          valid_from?: string
          valid_until?: string | null
        }
        Relationships: []
      }
      establishment_settings: {
        Row: {
          accept_cash: boolean | null
          accept_credit_on_delivery: boolean | null
          auto_print_on_confirm: boolean | null
          auto_print_on_ready: boolean | null
          business_address: string | null
          business_logo: string | null
          business_name: string
          business_phone: string | null
          carrousel_banners: string | null
          checkout_custom_message: string | null
          combine_payment_via_whatsapp: boolean | null
          created_at: string
          id: string
          include_qr_code: boolean | null
          instagram_url: string | null
          is_open: boolean | null
          mobile_layout_mode: string | null
          mp_access_token: string | null
          mp_enabled: boolean | null
          mp_public_key: string | null
          mp_webhook_url: string | null
          online_menu_slug: string | null
          pix_beneficiary_document: string | null
          pix_beneficiary_name: string | null
          pix_enabled: boolean | null
          pix_key: string | null
          primary_color: string | null
          print_customer_copy: boolean | null
          print_establishment_copy: boolean | null
          secondary_color: string | null
          show_qr_pix: boolean | null
          updated_at: string
          user_id: string
          zapi_enabled: boolean | null
          zapi_instance_id: string | null
          zapi_token: string | null
        }
        Insert: {
          accept_cash?: boolean | null
          accept_credit_on_delivery?: boolean | null
          auto_print_on_confirm?: boolean | null
          auto_print_on_ready?: boolean | null
          business_address?: string | null
          business_logo?: string | null
          business_name: string
          business_phone?: string | null
          carrousel_banners?: string | null
          checkout_custom_message?: string | null
          combine_payment_via_whatsapp?: boolean | null
          created_at?: string
          id?: string
          include_qr_code?: boolean | null
          instagram_url?: string | null
          is_open?: boolean | null
          mobile_layout_mode?: string | null
          mp_access_token?: string | null
          mp_enabled?: boolean | null
          mp_public_key?: string | null
          mp_webhook_url?: string | null
          online_menu_slug?: string | null
          pix_beneficiary_document?: string | null
          pix_beneficiary_name?: string | null
          pix_enabled?: boolean | null
          pix_key?: string | null
          primary_color?: string | null
          print_customer_copy?: boolean | null
          print_establishment_copy?: boolean | null
          secondary_color?: string | null
          show_qr_pix?: boolean | null
          updated_at?: string
          user_id: string
          zapi_enabled?: boolean | null
          zapi_instance_id?: string | null
          zapi_token?: string | null
        }
        Update: {
          accept_cash?: boolean | null
          accept_credit_on_delivery?: boolean | null
          auto_print_on_confirm?: boolean | null
          auto_print_on_ready?: boolean | null
          business_address?: string | null
          business_logo?: string | null
          business_name?: string
          business_phone?: string | null
          carrousel_banners?: string | null
          checkout_custom_message?: string | null
          combine_payment_via_whatsapp?: boolean | null
          created_at?: string
          id?: string
          include_qr_code?: boolean | null
          instagram_url?: string | null
          is_open?: boolean | null
          mobile_layout_mode?: string | null
          mp_access_token?: string | null
          mp_enabled?: boolean | null
          mp_public_key?: string | null
          mp_webhook_url?: string | null
          online_menu_slug?: string | null
          pix_beneficiary_document?: string | null
          pix_beneficiary_name?: string | null
          pix_enabled?: boolean | null
          pix_key?: string | null
          primary_color?: string | null
          print_customer_copy?: boolean | null
          print_establishment_copy?: boolean | null
          secondary_color?: string | null
          show_qr_pix?: boolean | null
          updated_at?: string
          user_id?: string
          zapi_enabled?: boolean | null
          zapi_instance_id?: string | null
          zapi_token?: string | null
        }
        Relationships: []
      }
      menu_views: {
        Row: {
          created_at: string
          establishment_slug: string
          id: string
          user_agent: string | null
          user_id: string
          viewer_ip: unknown | null
        }
        Insert: {
          created_at?: string
          establishment_slug: string
          id?: string
          user_agent?: string | null
          user_id: string
          viewer_ip?: unknown | null
        }
        Update: {
          created_at?: string
          establishment_slug?: string
          id?: string
          user_agent?: string | null
          user_id?: string
          viewer_ip?: unknown | null
        }
        Relationships: []
      }
      mercadopago_payments: {
        Row: {
          amount: number
          created_at: string
          currency: string | null
          id: string
          mp_external_reference: string | null
          mp_payment_id: string
          order_id: string
          payment_method: string | null
          status: string
          updated_at: string
          user_id: string
          webhook_data: Json | null
        }
        Insert: {
          amount: number
          created_at?: string
          currency?: string | null
          id?: string
          mp_external_reference?: string | null
          mp_payment_id: string
          order_id: string
          payment_method?: string | null
          status?: string
          updated_at?: string
          user_id: string
          webhook_data?: Json | null
        }
        Update: {
          amount?: number
          created_at?: string
          currency?: string | null
          id?: string
          mp_external_reference?: string | null
          mp_payment_id?: string
          order_id?: string
          payment_method?: string | null
          status?: string
          updated_at?: string
          user_id?: string
          webhook_data?: Json | null
        }
        Relationships: []
      }
      motoboys: {
        Row: {
          active: boolean
          created_at: string
          id: string
          name: string
          notes: string | null
          phone_e164: string
          updated_at: string
          user_id: string
          vehicle_type: string | null
        }
        Insert: {
          active?: boolean
          created_at?: string
          id?: string
          name: string
          notes?: string | null
          phone_e164: string
          updated_at?: string
          user_id: string
          vehicle_type?: string | null
        }
        Update: {
          active?: boolean
          created_at?: string
          id?: string
          name?: string
          notes?: string | null
          phone_e164?: string
          updated_at?: string
          user_id?: string
          vehicle_type?: string | null
        }
        Relationships: []
      }
      order_preparation_tracking: {
        Row: {
          created_at: string
          customer_name: string
          customer_phone: string
          estimated_time: number
          id: string
          order_number: string
          status: string
          updated_at: string
          user_id: string
          whatsapp_sent: boolean
          whatsapp_sent_at: string | null
        }
        Insert: {
          created_at?: string
          customer_name: string
          customer_phone: string
          estimated_time: number
          id?: string
          order_number: string
          status?: string
          updated_at?: string
          user_id: string
          whatsapp_sent?: boolean
          whatsapp_sent_at?: string | null
        }
        Update: {
          created_at?: string
          customer_name?: string
          customer_phone?: string
          estimated_time?: number
          id?: string
          order_number?: string
          status?: string
          updated_at?: string
          user_id?: string
          whatsapp_sent?: boolean
          whatsapp_sent_at?: string | null
        }
        Relationships: []
      }
      order_timeline: {
        Row: {
          created_at: string
          event_data: Json | null
          event_type: string
          id: string
          order_id: string
          user_id: string
        }
        Insert: {
          created_at?: string
          event_data?: Json | null
          event_type: string
          id?: string
          order_id: string
          user_id: string
        }
        Update: {
          created_at?: string
          event_data?: Json | null
          event_type?: string
          id?: string
          order_id?: string
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "fk_order_timeline_order"
            columns: ["order_id"]
            isOneToOne: false
            referencedRelation: "user_orders"
            referencedColumns: ["id"]
          },
        ]
      }
      preparation_time_settings: {
        Row: {
          auto_send_whatsapp: boolean
          created_at: string
          default_preparation_time: number
          id: string
          peak_hours_end: string | null
          peak_hours_extra_time: number | null
          peak_hours_start: string | null
          updated_at: string
          user_id: string
          whatsapp_message_template: string | null
        }
        Insert: {
          auto_send_whatsapp?: boolean
          created_at?: string
          default_preparation_time?: number
          id?: string
          peak_hours_end?: string | null
          peak_hours_extra_time?: number | null
          peak_hours_start?: string | null
          updated_at?: string
          user_id: string
          whatsapp_message_template?: string | null
        }
        Update: {
          auto_send_whatsapp?: boolean
          created_at?: string
          default_preparation_time?: number
          id?: string
          peak_hours_end?: string | null
          peak_hours_extra_time?: number | null
          peak_hours_start?: string | null
          updated_at?: string
          user_id?: string
          whatsapp_message_template?: string | null
        }
        Relationships: []
      }
      security_access_log: {
        Row: {
          accessed_at: string | null
          id: string
          ip_address: unknown | null
          operation: string
          suspicious: boolean | null
          table_name: string
          user_agent: string | null
          user_id: string | null
          user_role: string | null
        }
        Insert: {
          accessed_at?: string | null
          id?: string
          ip_address?: unknown | null
          operation: string
          suspicious?: boolean | null
          table_name: string
          user_agent?: string | null
          user_id?: string | null
          user_role?: string | null
        }
        Update: {
          accessed_at?: string | null
          id?: string
          ip_address?: unknown | null
          operation?: string
          suspicious?: boolean | null
          table_name?: string
          user_agent?: string | null
          user_id?: string | null
          user_role?: string | null
        }
        Relationships: []
      }
      security_rate_limits: {
        Row: {
          action_type: string
          blocked_until: string | null
          created_at: string | null
          id: string
          identifier: string
          request_count: number | null
          window_start: string | null
        }
        Insert: {
          action_type: string
          blocked_until?: string | null
          created_at?: string | null
          id?: string
          identifier: string
          request_count?: number | null
          window_start?: string | null
        }
        Update: {
          action_type?: string
          blocked_until?: string | null
          created_at?: string | null
          id?: string
          identifier?: string
          request_count?: number | null
          window_start?: string | null
        }
        Relationships: []
      }
      subscribers: {
        Row: {
          created_at: string
          email: string
          id: string
          stripe_customer_id: string | null
          subscribed: boolean
          subscription_end: string | null
          subscription_tier: string | null
          updated_at: string
          user_id: string | null
        }
        Insert: {
          created_at?: string
          email: string
          id?: string
          stripe_customer_id?: string | null
          subscribed?: boolean
          subscription_end?: string | null
          subscription_tier?: string | null
          updated_at?: string
          user_id?: string | null
        }
        Update: {
          created_at?: string
          email?: string
          id?: string
          stripe_customer_id?: string | null
          subscribed?: boolean
          subscription_end?: string | null
          subscription_tier?: string | null
          updated_at?: string
          user_id?: string | null
        }
        Relationships: []
      }
      tenants: {
        Row: {
          created_at: string | null
          id: string
          name: string
          owner_user_id: string
          slug: string
        }
        Insert: {
          created_at?: string | null
          id?: string
          name: string
          owner_user_id: string
          slug: string
        }
        Update: {
          created_at?: string | null
          id?: string
          name?: string
          owner_user_id?: string
          slug?: string
        }
        Relationships: []
      }
      upsell_configs: {
        Row: {
          created_at: string
          id: string
          is_active: boolean
          product_id: string
          suggested_products: string[]
          updated_at: string
          user_id: string
        }
        Insert: {
          created_at?: string
          id?: string
          is_active?: boolean
          product_id: string
          suggested_products?: string[]
          updated_at?: string
          user_id: string
        }
        Update: {
          created_at?: string
          id?: string
          is_active?: boolean
          product_id?: string
          suggested_products?: string[]
          updated_at?: string
          user_id?: string
        }
        Relationships: []
      }
      user_categories: {
        Row: {
          created_at: string
          id: string
          name: string
          sort_order: number | null
          updated_at: string
          user_id: string
        }
        Insert: {
          created_at?: string
          id?: string
          name: string
          sort_order?: number | null
          updated_at?: string
          user_id: string
        }
        Update: {
          created_at?: string
          id?: string
          name?: string
          sort_order?: number | null
          updated_at?: string
          user_id?: string
        }
        Relationships: []
      }
      user_customers: {
        Row: {
          created_at: string
          customer_email: string | null
          customer_name: string
          customer_phone: string | null
          delivery_address: string | null
          id: string
          last_order_date: string
          total_orders: number
          total_spent: number
          updated_at: string
          user_id: string
        }
        Insert: {
          created_at?: string
          customer_email?: string | null
          customer_name: string
          customer_phone?: string | null
          delivery_address?: string | null
          id?: string
          last_order_date?: string
          total_orders?: number
          total_spent?: number
          updated_at?: string
          user_id: string
        }
        Update: {
          created_at?: string
          customer_email?: string | null
          customer_name?: string
          customer_phone?: string | null
          delivery_address?: string | null
          id?: string
          last_order_date?: string
          total_orders?: number
          total_spent?: number
          updated_at?: string
          user_id?: string
        }
        Relationships: []
      }
      user_orders: {
        Row: {
          created_at: string
          customer_email: string | null
          customer_id: string | null
          customer_name: string
          customer_phone: string | null
          delivered_at: string | null
          delivery_address: string | null
          fulfillment_method: string | null
          id: string
          items: Json
          notes: string | null
          order_number: string
          out_for_delivery_at: string | null
          payment_method: string | null
          status: string
          total: number
          updated_at: string
          user_id: string
        }
        Insert: {
          created_at?: string
          customer_email?: string | null
          customer_id?: string | null
          customer_name: string
          customer_phone?: string | null
          delivered_at?: string | null
          delivery_address?: string | null
          fulfillment_method?: string | null
          id?: string
          items: Json
          notes?: string | null
          order_number: string
          out_for_delivery_at?: string | null
          payment_method?: string | null
          status?: string
          total: number
          updated_at?: string
          user_id: string
        }
        Update: {
          created_at?: string
          customer_email?: string | null
          customer_id?: string | null
          customer_name?: string
          customer_phone?: string | null
          delivered_at?: string | null
          delivery_address?: string | null
          fulfillment_method?: string | null
          id?: string
          items?: Json
          notes?: string | null
          order_number?: string
          out_for_delivery_at?: string | null
          payment_method?: string | null
          status?: string
          total?: number
          updated_at?: string
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "user_orders_customer_id_fkey"
            columns: ["customer_id"]
            isOneToOne: false
            referencedRelation: "customers"
            referencedColumns: ["id"]
          },
        ]
      }
      user_products: {
        Row: {
          allow_half_half: boolean
          category: string
          created_at: string
          customizable: boolean
          description: string | null
          extras: Json | null
          id: string
          image: string | null
          ingredients: string[] | null
          is_pizza: boolean
          is_promotion: boolean
          max_flavors: number | null
          name: string
          pizza_borders: Json | null
          pizza_flavors: Json | null
          price: number
          promotion_price: number | null
          show_online_menu: boolean
          updated_at: string
          user_id: string
        }
        Insert: {
          allow_half_half?: boolean
          category: string
          created_at?: string
          customizable?: boolean
          description?: string | null
          extras?: Json | null
          id?: string
          image?: string | null
          ingredients?: string[] | null
          is_pizza?: boolean
          is_promotion?: boolean
          max_flavors?: number | null
          name: string
          pizza_borders?: Json | null
          pizza_flavors?: Json | null
          price: number
          promotion_price?: number | null
          show_online_menu?: boolean
          updated_at?: string
          user_id: string
        }
        Update: {
          allow_half_half?: boolean
          category?: string
          created_at?: string
          customizable?: boolean
          description?: string | null
          extras?: Json | null
          id?: string
          image?: string | null
          ingredients?: string[] | null
          is_pizza?: boolean
          is_promotion?: boolean
          max_flavors?: number | null
          name?: string
          pizza_borders?: Json | null
          pizza_flavors?: Json | null
          price?: number
          promotion_price?: number | null
          show_online_menu?: boolean
          updated_at?: string
          user_id?: string
        }
        Relationships: []
      }
      wa_chats: {
        Row: {
          created_at: string
          has_open_order: boolean
          id: string
          is_pinned: boolean
          is_vip: boolean
          last_message: string | null
          last_message_at: string | null
          name: string | null
          phone_e164: string
          tenant_id: string
          unread_count: number
          updated_at: string
        }
        Insert: {
          created_at?: string
          has_open_order?: boolean
          id?: string
          is_pinned?: boolean
          is_vip?: boolean
          last_message?: string | null
          last_message_at?: string | null
          name?: string | null
          phone_e164: string
          tenant_id: string
          unread_count?: number
          updated_at?: string
        }
        Update: {
          created_at?: string
          has_open_order?: boolean
          id?: string
          is_pinned?: boolean
          is_vip?: boolean
          last_message?: string | null
          last_message_at?: string | null
          name?: string | null
          phone_e164?: string
          tenant_id?: string
          unread_count?: number
          updated_at?: string
        }
        Relationships: []
      }
      wa_messages: {
        Row: {
          body: string
          broadcast_job_id: string | null
          created_at: string | null
          direction: string
          error: string | null
          id: string
          is_broadcast: boolean | null
          media_url: string | null
          phone_e164: string
          read_at: string | null
          status: string | null
          tenant_id: string | null
          updated_at: string | null
          user_id: string
          zapi_msg_id: string | null
        }
        Insert: {
          body: string
          broadcast_job_id?: string | null
          created_at?: string | null
          direction: string
          error?: string | null
          id?: string
          is_broadcast?: boolean | null
          media_url?: string | null
          phone_e164: string
          read_at?: string | null
          status?: string | null
          tenant_id?: string | null
          updated_at?: string | null
          user_id: string
          zapi_msg_id?: string | null
        }
        Update: {
          body?: string
          broadcast_job_id?: string | null
          created_at?: string | null
          direction?: string
          error?: string | null
          id?: string
          is_broadcast?: boolean | null
          media_url?: string | null
          phone_e164?: string
          read_at?: string | null
          status?: string | null
          tenant_id?: string | null
          updated_at?: string | null
          user_id?: string
          zapi_msg_id?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "wa_messages_broadcast_job_id_fkey"
            columns: ["broadcast_job_id"]
            isOneToOne: false
            referencedRelation: "broadcast_jobs"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "wa_messages_tenant_id_fkey"
            columns: ["tenant_id"]
            isOneToOne: false
            referencedRelation: "whatsapp_instances"
            referencedColumns: ["id"]
          },
        ]
      }
      wa_presence: {
        Row: {
          created_at: string
          id: string
          last_seen: string | null
          phone_e164: string
          status: string
          tenant_id: string
          updated_at: string
        }
        Insert: {
          created_at?: string
          id?: string
          last_seen?: string | null
          phone_e164: string
          status?: string
          tenant_id: string
          updated_at?: string
        }
        Update: {
          created_at?: string
          id?: string
          last_seen?: string | null
          phone_e164?: string
          status?: string
          tenant_id?: string
          updated_at?: string
        }
        Relationships: []
      }
      wa_templates: {
        Row: {
          body: string
          category: string | null
          created_at: string | null
          id: string
          name: string
          tenant_id: string | null
          updated_at: string | null
          user_id: string
        }
        Insert: {
          body: string
          category?: string | null
          created_at?: string | null
          id?: string
          name: string
          tenant_id?: string | null
          updated_at?: string | null
          user_id: string
        }
        Update: {
          body?: string
          category?: string | null
          created_at?: string | null
          id?: string
          name?: string
          tenant_id?: string | null
          updated_at?: string | null
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "wa_templates_tenant_id_fkey"
            columns: ["tenant_id"]
            isOneToOne: false
            referencedRelation: "whatsapp_instances"
            referencedColumns: ["id"]
          },
        ]
      }
      webhook_configs: {
        Row: {
          created_at: string
          events: Json
          id: string
          is_active: boolean
          secret_token: string
          updated_at: string
          url: string
          user_id: string
        }
        Insert: {
          created_at?: string
          events?: Json
          id?: string
          is_active?: boolean
          secret_token: string
          updated_at?: string
          url: string
          user_id: string
        }
        Update: {
          created_at?: string
          events?: Json
          id?: string
          is_active?: boolean
          secret_token?: string
          updated_at?: string
          url?: string
          user_id?: string
        }
        Relationships: []
      }
      webhook_logs: {
        Row: {
          attempt_count: number
          event_type: string
          id: string
          payload: Json
          response_body: string | null
          response_status: number | null
          sent_at: string
          success: boolean
          webhook_config_id: string
        }
        Insert: {
          attempt_count?: number
          event_type: string
          id?: string
          payload: Json
          response_body?: string | null
          response_status?: number | null
          sent_at?: string
          success?: boolean
          webhook_config_id: string
        }
        Update: {
          attempt_count?: number
          event_type?: string
          id?: string
          payload?: Json
          response_body?: string | null
          response_status?: number | null
          sent_at?: string
          success?: boolean
          webhook_config_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "webhook_logs_webhook_config_id_fkey"
            columns: ["webhook_config_id"]
            isOneToOne: false
            referencedRelation: "webhook_configs"
            referencedColumns: ["id"]
          },
        ]
      }
      whatsapp_events: {
        Row: {
          created_at: string | null
          event_type: string
          id: number
          instance_id: string | null
          payload: Json | null
          tenant_id: string | null
        }
        Insert: {
          created_at?: string | null
          event_type: string
          id?: number
          instance_id?: string | null
          payload?: Json | null
          tenant_id?: string | null
        }
        Update: {
          created_at?: string | null
          event_type?: string
          id?: number
          instance_id?: string | null
          payload?: Json | null
          tenant_id?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "whatsapp_events_instance_id_fkey"
            columns: ["instance_id"]
            isOneToOne: false
            referencedRelation: "whatsapp_instances"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "whatsapp_events_tenant_id_fkey"
            columns: ["tenant_id"]
            isOneToOne: false
            referencedRelation: "tenants"
            referencedColumns: ["id"]
          },
        ]
      }
      whatsapp_instances: {
        Row: {
          captcha_data: string | null
          codigo_verificacao: string | null
          connected_at: string | null
          created_at: string
          disconnected_at: string | null
          events_webhook_url: string | null
          id: string
          inbound_webhook_url: string | null
          instance_id: string
          instance_name: string
          instance_type: string | null
          is_blocked: boolean | null
          last_error: string | null
          mensagens: Json | null
          numero_cliente: string | null
          phone_ddi: string | null
          phone_number: string | null
          qr_code: string | null
          qr_image_base64: string | null
          qr_refreshed_at: string | null
          retry_after: number | null
          session: string | null
          sms_wait_seconds: number | null
          status: string
          tenant_id: string | null
          token_encrypted: boolean | null
          token_instance: string
          updated_at: string
          user_id: string
          verificado_em: string | null
          verification_method: string | null
          versao: string | null
          voice_wait_seconds: number | null
          wa_old_wait_seconds: number | null
          webhook_secret: string | null
          webhook_url: string | null
        }
        Insert: {
          captcha_data?: string | null
          codigo_verificacao?: string | null
          connected_at?: string | null
          created_at?: string
          disconnected_at?: string | null
          events_webhook_url?: string | null
          id?: string
          inbound_webhook_url?: string | null
          instance_id: string
          instance_name: string
          instance_type?: string | null
          is_blocked?: boolean | null
          last_error?: string | null
          mensagens?: Json | null
          numero_cliente?: string | null
          phone_ddi?: string | null
          phone_number?: string | null
          qr_code?: string | null
          qr_image_base64?: string | null
          qr_refreshed_at?: string | null
          retry_after?: number | null
          session?: string | null
          sms_wait_seconds?: number | null
          status?: string
          tenant_id?: string | null
          token_encrypted?: boolean | null
          token_instance: string
          updated_at?: string
          user_id: string
          verificado_em?: string | null
          verification_method?: string | null
          versao?: string | null
          voice_wait_seconds?: number | null
          wa_old_wait_seconds?: number | null
          webhook_secret?: string | null
          webhook_url?: string | null
        }
        Update: {
          captcha_data?: string | null
          codigo_verificacao?: string | null
          connected_at?: string | null
          created_at?: string
          disconnected_at?: string | null
          events_webhook_url?: string | null
          id?: string
          inbound_webhook_url?: string | null
          instance_id?: string
          instance_name?: string
          instance_type?: string | null
          is_blocked?: boolean | null
          last_error?: string | null
          mensagens?: Json | null
          numero_cliente?: string | null
          phone_ddi?: string | null
          phone_number?: string | null
          qr_code?: string | null
          qr_image_base64?: string | null
          qr_refreshed_at?: string | null
          retry_after?: number | null
          session?: string | null
          sms_wait_seconds?: number | null
          status?: string
          tenant_id?: string | null
          token_encrypted?: boolean | null
          token_instance?: string
          updated_at?: string
          user_id?: string
          verificado_em?: string | null
          verification_method?: string | null
          versao?: string | null
          voice_wait_seconds?: number | null
          wa_old_wait_seconds?: number | null
          webhook_secret?: string | null
          webhook_url?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "whatsapp_instances_tenant_id_fkey"
            columns: ["tenant_id"]
            isOneToOne: false
            referencedRelation: "tenants"
            referencedColumns: ["id"]
          },
        ]
      }
      whatsapp_message_configs: {
        Row: {
          auto_messages_enabled: boolean
          created_at: string
          estimated_delivery_time: string | null
          id: string
          new_order_enabled: boolean
          new_order_template: string | null
          out_for_delivery_enabled: boolean
          out_for_delivery_template: string | null
          payment_confirmed_enabled: boolean
          payment_confirmed_template: string | null
          pix_message_enabled: boolean
          pix_message_template: string | null
          updated_at: string
          user_id: string
        }
        Insert: {
          auto_messages_enabled?: boolean
          created_at?: string
          estimated_delivery_time?: string | null
          id?: string
          new_order_enabled?: boolean
          new_order_template?: string | null
          out_for_delivery_enabled?: boolean
          out_for_delivery_template?: string | null
          payment_confirmed_enabled?: boolean
          payment_confirmed_template?: string | null
          pix_message_enabled?: boolean
          pix_message_template?: string | null
          updated_at?: string
          user_id: string
        }
        Update: {
          auto_messages_enabled?: boolean
          created_at?: string
          estimated_delivery_time?: string | null
          id?: string
          new_order_enabled?: boolean
          new_order_template?: string | null
          out_for_delivery_enabled?: boolean
          out_for_delivery_template?: string | null
          payment_confirmed_enabled?: boolean
          payment_confirmed_template?: string | null
          pix_message_enabled?: boolean
          pix_message_template?: string | null
          updated_at?: string
          user_id?: string
        }
        Relationships: []
      }
      whatsapp_message_logs: {
        Row: {
          created_at: string
          error_message: string | null
          id: string
          message_content: string
          message_type: string
          order_id: string
          phone_number: string
          sent_at: string
          status: string
          user_id: string
          whatsapp_message_id: string | null
        }
        Insert: {
          created_at?: string
          error_message?: string | null
          id?: string
          message_content: string
          message_type: string
          order_id: string
          phone_number: string
          sent_at?: string
          status?: string
          user_id: string
          whatsapp_message_id?: string | null
        }
        Update: {
          created_at?: string
          error_message?: string | null
          id?: string
          message_content?: string
          message_type?: string
          order_id?: string
          phone_number?: string
          sent_at?: string
          status?: string
          user_id?: string
          whatsapp_message_id?: string | null
        }
        Relationships: []
      }
    }
    Views: {
      [_ in never]: never
    }
    Functions: {
      check_instance_status_zapi: {
        Args: { p_instance_id: string; p_token: string }
        Returns: Json
      }
      check_rate_limit: {
        Args: {
          p_action_type: string
          p_identifier: string
          p_limit?: number
          p_window_minutes?: number
        }
        Returns: boolean
      }
      create_anonymous_order: {
        Args: {
          customer_data: Json
          establishment_slug: string
          order_data: Json
        }
        Returns: string
      }
      create_anonymous_order_secure: {
        Args: {
          customer_data: Json
          establishment_slug: string
          order_data: Json
        }
        Returns: string
      }
      create_order_with_customer: {
        Args: {
          p_address_data: Json
          p_customer_name: string
          p_customer_phone: string
          p_establishment_slug: string
          p_order_data: Json
        }
        Returns: string
      }
      create_sample_products_for_user: {
        Args: { user_id_param: string }
        Returns: undefined
      }
      get_active_whatsapp_instance: {
        Args: { user_id_param: string }
        Returns: {
          id: string
          instance_id: string
          numero_cliente: string
          qr_code: string
          status: string
          token_instance: string
          updated_at: string
        }[]
      }
      get_customer_data_secure: {
        Args: { customer_id: string; requesting_user_id: string }
        Returns: {
          customer_name: string
          customer_phone: string
          last_order_date: string
          total_orders: number
        }[]
      }
      get_establishment_branding_data: {
        Args: { slug: string }
        Returns: {
          business_logo: string
          business_name: string
          establishment_id: string
          instagram_url: string
          mobile_layout_mode: string
          primary_color: string
          secondary_color: string
        }[]
      }
      get_establishment_branding_secure: {
        Args: { slug_param: string }
        Returns: {
          business_logo: string
          business_name: string
          establishment_id: string
          instagram_url: string
          mobile_layout_mode: string
          primary_color: string
          secondary_color: string
        }[]
      }
      get_establishment_by_slug: {
        Args: { slug: string }
        Returns: {
          business_address: string
          business_logo: string
          business_name: string
          business_phone: string
          establishment_id: string
          instagram_url: string
          mobile_layout_mode: string
          primary_color: string
          secondary_color: string
        }[]
      }
      get_establishment_checkout_data: {
        Args: { establishment_slug: string }
        Returns: {
          accept_cash: boolean
          accept_credit_on_delivery: boolean
          business_name: string
          checkout_custom_message: string
          establishment_id: string
          mp_enabled: boolean
          pix_enabled: boolean
          show_qr_pix: boolean
        }[]
      }
      get_establishment_menu_data: {
        Args: { slug: string }
        Returns: {
          business_logo: string
          business_name: string
          business_phone: string
          checkout_custom_message: string
          establishment_id: string
          instagram_url: string
          mobile_layout_mode: string
          primary_color: string
          secondary_color: string
        }[]
      }
      get_establishment_menu_data_secure: {
        Args: { slug: string }
        Returns: {
          business_logo: string
          business_name: string
          business_phone: string
          checkout_custom_message: string
          establishment_id: string
          instagram_url: string
          mobile_layout_mode: string
          primary_color: string
          secondary_color: string
        }[]
      }
      get_pix_data_for_order: {
        Args: { establishment_slug: string; order_total: number }
        Returns: {
          pix_beneficiary_name: string
          pix_key: string
          total_amount: number
        }[]
      }
      get_public_establishment_data: {
        Args: { slug: string }
        Returns: {
          business_logo: string
          business_name: string
          checkout_custom_message: string
          establishment_id: string
          instagram_url: string
          mobile_layout_mode: string
          online_menu_slug: string
          primary_color: string
          secondary_color: string
        }[]
      }
      get_public_establishment_metrics: {
        Args: Record<PropertyKey, never>
        Returns: {
          access_level: string
          recent_establishments: number
          total_establishments: number
        }[]
      }
      get_safe_whatsapp_instance_data: {
        Args: { instance_id: string }
        Returns: {
          connected_at: string
          id: string
          instance_name: string
          status: string
        }[]
      }
      get_user_conversations: {
        Args: { user_id_param: string }
        Returns: {
          display_name: string
          last_message_at: string
          last_snippet: string
          phone_e164: string
          tenant_id: string
          unread_count: number
        }[]
      }
      log_security_event: {
        Args: { event_details?: Json; event_type: string }
        Returns: undefined
      }
      normalize_phone_e164: {
        Args: { phone: string }
        Returns: string
      }
      normalize_phone_to_e164: {
        Args: { input_phone: string }
        Returns: string
      }
      process_template_variables: {
        Args: { template_text: string; variables: Json }
        Returns: string
      }
      upsert_customer: {
        Args: { p_name: string; p_phone: string; p_tenant_id: string }
        Returns: string
      }
      validate_establishment_slug: {
        Args: { slug: string }
        Returns: boolean
      }
    }
    Enums: {
      delivery_status:
        | "assigned"
        | "picked_up"
        | "on_route"
        | "delivered"
        | "canceled"
    }
    CompositeTypes: {
      [_ in never]: never
    }
  }
}

type DatabaseWithoutInternals = Omit<Database, "__InternalSupabase">

type DefaultSchema = DatabaseWithoutInternals[Extract<keyof Database, "public">]

export type Tables<
  DefaultSchemaTableNameOrOptions extends
    | keyof (DefaultSchema["Tables"] & DefaultSchema["Views"])
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
        DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
      DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])[TableName] extends {
      Row: infer R
    }
    ? R
    : never
  : DefaultSchemaTableNameOrOptions extends keyof (DefaultSchema["Tables"] &
        DefaultSchema["Views"])
    ? (DefaultSchema["Tables"] &
        DefaultSchema["Views"])[DefaultSchemaTableNameOrOptions] extends {
        Row: infer R
      }
      ? R
      : never
    : never

export type TablesInsert<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Insert: infer I
    }
    ? I
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Insert: infer I
      }
      ? I
      : never
    : never

export type TablesUpdate<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Update: infer U
    }
    ? U
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Update: infer U
      }
      ? U
      : never
    : never

export type Enums<
  DefaultSchemaEnumNameOrOptions extends
    | keyof DefaultSchema["Enums"]
    | { schema: keyof DatabaseWithoutInternals },
  EnumName extends DefaultSchemaEnumNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"]
    : never = never,
> = DefaultSchemaEnumNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"][EnumName]
  : DefaultSchemaEnumNameOrOptions extends keyof DefaultSchema["Enums"]
    ? DefaultSchema["Enums"][DefaultSchemaEnumNameOrOptions]
    : never

export type CompositeTypes<
  PublicCompositeTypeNameOrOptions extends
    | keyof DefaultSchema["CompositeTypes"]
    | { schema: keyof DatabaseWithoutInternals },
  CompositeTypeName extends PublicCompositeTypeNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"]
    : never = never,
> = PublicCompositeTypeNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"][CompositeTypeName]
  : PublicCompositeTypeNameOrOptions extends keyof DefaultSchema["CompositeTypes"]
    ? DefaultSchema["CompositeTypes"][PublicCompositeTypeNameOrOptions]
    : never

export const Constants = {
  public: {
    Enums: {
      delivery_status: [
        "assigned",
        "picked_up",
        "on_route",
        "delivered",
        "canceled",
      ],
    },
  },
} as const
