
import { Toaster } from "@/components/ui/toaster";
import { Toaster as Sonner } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { BrowserRouter, Routes, Route } from "react-router-dom";
import { SidebarProvider, SidebarTrigger } from "@/components/ui/sidebar";
import { AppSidebar } from "@/components/AppSidebar";
import { WhatsAppQRSidebar } from "@/components/WhatsAppQRSidebar";
import { SubscriptionGuard } from "@/components/SubscriptionGuard";
import { SecurityErrorBoundary } from "@/components/SecurityErrorBoundary";
import Login from "./pages/Login";
import LandingPage from "./pages/LandingPage";
import Dashboard from "./pages/Dashboard";
import Products from "./pages/Products";
import Orders from "./pages/Orders";
import Reports from "./pages/Reports";
import Customers from "./pages/Customers";
import Settings from "./pages/Settings";
import Upsell from "./pages/Upsell";
import Coupons from "./pages/Coupons";
import Motoboys from "./pages/Motoboys";
import WhatsApp from "./pages/WhatsApp";
import WhatsAppV2 from "./pages/WhatsAppV2";
import OnlineMenu from "./pages/OnlineMenu";
import QRConnect from "./pages/QRConnect";
import QRRecovery from "./pages/QRRecovery";
import QRRecoveryV2 from "./pages/QRRecoveryV2";
import NotFound from "./pages/NotFound";
import Debug from "./pages/Debug";
import OrderPrint from "./pages/OrderPrint";
import PrintTest from "./pages/PrintTest";
import StandaloneMenu from "./standalone-menu/StandaloneMenu";
import LoveZapBubble from "./components/LoveZap/LoveZapBubble";
import LoveZapMiniPanel from "./components/LoveZap/LoveZapMiniPanel";
import { useLoveZapMini } from "./hooks/useLoveZapMini";

const queryClient = new QueryClient();

const App = () => {
  const { 
    isOpen, 
    toggleMiniInbox, 
    closeMiniInbox, 
    isEnabled, 
    selectedPhone, 
    setSelectedPhone 
  } = useLoveZapMini();

  return (
    <QueryClientProvider client={queryClient}>
      <SecurityErrorBoundary>
        <TooltipProvider>
          <Toaster />
          <Sonner />
          <BrowserRouter>
        <Routes>
          <Route path="/" element={
            window.location.hostname === 'localhost' || window.location.hostname.includes('lovable.app') 
              ? <Dashboard /> 
              : <LandingPage />
          } />
          <Route path="/login" element={<Login />} />
          
          <Route path="/dashboard" element={
            <SubscriptionGuard>
              <SidebarProvider>
                <div className="min-h-screen flex w-full">
                  <AppSidebar />
                  <main className="flex-1">
                    <div className="border-b border-gray-200 bg-white p-4">
                      <SidebarTrigger />
                    </div>
                    <Dashboard />
                  </main>
                  <WhatsAppQRSidebar />
                  {isEnabled && (
                    <LoveZapBubble onClick={toggleMiniInbox} isOpen={isOpen} />
                  )}
                </div>
              </SidebarProvider>
            </SubscriptionGuard>
          } />
          <Route path="/products" element={
            <SubscriptionGuard>
              <SidebarProvider>
                <div className="min-h-screen flex w-full">
                  <AppSidebar />
                  <main className="flex-1">
                    <div className="border-b border-gray-200 bg-white p-4">
                      <SidebarTrigger />
                    </div>
                    <Products />
                  </main>
                  <WhatsAppQRSidebar />
                  {isEnabled && (
                    <LoveZapBubble onClick={toggleMiniInbox} isOpen={isOpen} />
                  )}
                </div>
              </SidebarProvider>
            </SubscriptionGuard>
          } />
          <Route path="/orders" element={
            <SubscriptionGuard>
              <SidebarProvider>
                <div className="min-h-screen flex w-full">
                  <AppSidebar />
                  <main className="flex-1">
                    <div className="border-b border-gray-200 bg-white p-4">
                      <SidebarTrigger />
                    </div>
                    <Orders />
                  </main>
                  <WhatsAppQRSidebar />
                  {isEnabled && (
                    <LoveZapBubble onClick={toggleMiniInbox} isOpen={isOpen} />
                  )}
                </div>
              </SidebarProvider>
            </SubscriptionGuard>
          } />
          <Route path="/customers" element={
            <SubscriptionGuard>
              <SidebarProvider>
                <div className="min-h-screen flex w-full">
                  <AppSidebar />
                  <main className="flex-1">
                    <div className="border-b border-gray-200 bg-white p-4">
                      <SidebarTrigger />
                    </div>
                    <Customers />
                  </main>
                  <WhatsAppQRSidebar />
                  {isEnabled && (
                    <LoveZapBubble onClick={toggleMiniInbox} isOpen={isOpen} />
                  )}
                </div>
              </SidebarProvider>
            </SubscriptionGuard>
          } />
          <Route path="/reports" element={
            <SubscriptionGuard>
              <SidebarProvider>
                <div className="min-h-screen flex w-full">
                  <AppSidebar />
                  <main className="flex-1">
                    <div className="border-b border-gray-200 bg-white p-4">
                      <SidebarTrigger />
                    </div>
                    <Reports />
                  </main>
                  <WhatsAppQRSidebar />
                  {isEnabled && (
                    <LoveZapBubble onClick={toggleMiniInbox} isOpen={isOpen} />
                  )}
                </div>
              </SidebarProvider>
            </SubscriptionGuard>
          } />
          <Route path="/upsell" element={
            <SubscriptionGuard>
              <SidebarProvider>
                <div className="min-h-screen flex w-full">
                  <AppSidebar />
                  <main className="flex-1">
                    <div className="border-b border-gray-200 bg-white p-4">
                      <SidebarTrigger />
                    </div>
                    <Upsell />
                  </main>
                  <WhatsAppQRSidebar />
                  {isEnabled && (
                    <LoveZapBubble onClick={toggleMiniInbox} isOpen={isOpen} />
                  )}
                </div>
              </SidebarProvider>
            </SubscriptionGuard>
          } />
          <Route path="/coupons" element={
            <SubscriptionGuard>
              <SidebarProvider>
                <div className="min-h-screen flex w-full">
                  <AppSidebar />
                  <main className="flex-1">
                    <div className="border-b border-gray-200 bg-white p-4">
                      <SidebarTrigger />
                    </div>
                    <Coupons />
                  </main>
                  <WhatsAppQRSidebar />
                  {isEnabled && (
                    <LoveZapBubble onClick={toggleMiniInbox} isOpen={isOpen} />
                  )}
                </div>
              </SidebarProvider>
            </SubscriptionGuard>
          } />
          <Route path="/motoboys" element={
            <SubscriptionGuard>
              <SidebarProvider>
                <div className="min-h-screen flex w-full">
                  <AppSidebar />
                  <main className="flex-1">
                    <div className="border-b border-gray-200 bg-white p-4">
                      <SidebarTrigger />
                    </div>
                    <Motoboys />
                  </main>
                  <WhatsAppQRSidebar />
                  {isEnabled && (
                    <LoveZapBubble onClick={toggleMiniInbox} isOpen={isOpen} />
                  )}
                </div>
              </SidebarProvider>
            </SubscriptionGuard>
          } />
          <Route path="/whatsapp" element={
            <SubscriptionGuard>
              <SidebarProvider>
                <div className="min-h-screen flex w-full">
                  <AppSidebar />
                  <main className="flex-1">
                    <div className="border-b border-gray-200 bg-white p-4">
                      <SidebarTrigger />
                    </div>
                    <WhatsApp />
                  </main>
                  <WhatsAppQRSidebar />
                  {isEnabled && (
                    <LoveZapBubble onClick={toggleMiniInbox} isOpen={isOpen} />
                  )}
                </div>
              </SidebarProvider>
            </SubscriptionGuard>
          } />
          <Route path="/settings" element={
            <SubscriptionGuard>
              <SidebarProvider>
                <div className="min-h-screen flex w-full">
                  <AppSidebar />
                  <main className="flex-1">
                    <div className="border-b border-gray-200 bg-white p-4">
                      <SidebarTrigger />
                    </div>
                    <Settings />
                  </main>
                  <WhatsAppQRSidebar />
                  {isEnabled && (
                    <LoveZapBubble onClick={toggleMiniInbox} isOpen={isOpen} />
                  )}
                </div>
              </SidebarProvider>
            </SubscriptionGuard>
          } />
          <Route path="/online-menu" element={
            <SubscriptionGuard>
              <SidebarProvider>
                <div className="min-h-screen flex w-full">
                  <AppSidebar />
                  <main className="flex-1">
                    <div className="border-b border-gray-200 bg-white p-4">
                      <SidebarTrigger />
                    </div>
                    <OnlineMenu />
                  </main>
                  <WhatsAppQRSidebar />
                  {isEnabled && (
                    <LoveZapBubble onClick={toggleMiniInbox} isOpen={isOpen} />
                  )}
                </div>
              </SidebarProvider>
            </SubscriptionGuard>
          } />
          
          <Route path="/whatsapp-v2" element={
            <SubscriptionGuard>
              <SidebarProvider>
                <div className="min-h-screen flex w-full">
                  <AppSidebar />
                  <main className="flex-1">
                    <div className="border-b border-gray-200 bg-white p-4">
                      <SidebarTrigger />
                    </div>
                    <WhatsAppV2 />
                  </main>
                  <WhatsAppQRSidebar />
                  {isEnabled && (
                    <LoveZapBubble onClick={toggleMiniInbox} isOpen={isOpen} />
                  )}
                </div>
              </SidebarProvider>
            </SubscriptionGuard>
          } />
          
          <Route path="/qr-conexao" element={<QRConnect />} />
          <Route path="/qr-recovery/:slug" element={<QRRecovery />} />
          <Route path="/qr-recovery-v2/:sessionKey" element={<QRRecoveryV2 />} />
          
          <Route path="/debug" element={
            <SubscriptionGuard>
              <SidebarProvider>
                <div className="min-h-screen flex w-full">
                  <AppSidebar />
                  <main className="flex-1">
                    <div className="border-b border-gray-200 bg-white p-4">
                      <SidebarTrigger />
                    </div>
                    <Debug />
                  </main>
                  <WhatsAppQRSidebar />
                  {isEnabled && (
                    <LoveZapBubble onClick={toggleMiniInbox} isOpen={isOpen} />
                  )}
                </div>
              </SidebarProvider>
            </SubscriptionGuard>
          } />
          
          {/* Rotas de impressão - sem sidebar para impressão limpa */}
          <Route path="/orders/:id/print" element={<OrderPrint />} />
          <Route path="/orders/print-test" element={<PrintTest />} />
          
          {/* Rota pública do cardápio online - deve vir ANTES do NotFound */}
          <Route path="/:establishmentSlug" element={<StandaloneMenu />} />
          <Route path="*" element={<NotFound />} />
        </Routes>
        
        {/* LoveZap Mini Panel Global */}
        <LoveZapMiniPanel 
          isOpen={isOpen} 
          onClose={closeMiniInbox} 
          selectedPhone={selectedPhone}
          onPhoneSelect={setSelectedPhone}
        />
        </BrowserRouter>
      </TooltipProvider>
    </SecurityErrorBoundary>
  </QueryClientProvider>
  );
};

export default App;
