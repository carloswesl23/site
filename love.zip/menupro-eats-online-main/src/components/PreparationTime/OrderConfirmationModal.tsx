import { useState } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { Badge } from "@/components/ui/badge";
import { Package, Truck, User, Phone, ChevronDown, Plus } from "lucide-react";
import { useQuery } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { useToast } from "@/hooks/use-toast";

interface Motoboy {
  id: string;
  name: string;
  phone_e164: string;
  active: boolean;
}

interface OrderConfirmationModalProps {
  isOpen: boolean;
  onClose: () => void;
  order: any;
  onConfirm: (motoboyId?: string) => void;
  isLoading?: boolean;
}

export const OrderConfirmationModal = ({
  isOpen,
  onClose,
  order,
  onConfirm,
  isLoading = false
}: OrderConfirmationModalProps) => {
  const [selectedMotoboy, setSelectedMotoboy] = useState<Motoboy | null>(null);
  const [popoverOpen, setPopoverOpen] = useState(false);
  const { toast } = useToast();

  const { data: motoboys = [], isLoading: loadingMotoboys } = useQuery({
    queryKey: ['motoboys'],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('motoboys')
        .select('*')
        .eq('active', true)
        .order('name');
      
      if (error) {
        console.error('Erro ao buscar motoboys:', error);
        throw error;
      }
      
      return data || [];
    },
    enabled: isOpen
  });

  const formatPhone = (phone: string) => {
    if (!phone) return '';
    const cleaned = phone.replace(/\D/g, '');
    if (cleaned.length === 13 && cleaned.startsWith('55')) {
      const number = cleaned.slice(2);
      return `(${number.slice(0, 2)}) ${number.slice(2, 3)} ${number.slice(3, 7)}-${number.slice(7)}`;
    }
    return phone;
  };

  const handleSelectMotoboy = (motoboy: Motoboy) => {
    setSelectedMotoboy(motoboy);
    setPopoverOpen(false);
    toast({
      title: "Entregador selecionado",
      description: `${motoboy.name} foi selecionado para esta entrega.`,
    });
  };

  const handleConfirm = () => {
    onConfirm(selectedMotoboy?.id);
  };

  const handleCreateMotoboy = () => {
    // Link para página de cadastro de motoboys
    window.open('/delivery-drivers', '_blank');
  };

  if (!order) return null;

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-md">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Package className="w-5 h-5" />
            Confirmar Entrega
          </DialogTitle>
        </DialogHeader>

        <div className="space-y-4">
          <div className="bg-muted p-4 rounded-lg">
            <p className="font-medium">Pedido #{order.order_number}</p>
            <p className="text-sm text-muted-foreground">{order.customer_name}</p>
            <p className="text-sm text-muted-foreground">{order.customer_phone}</p>
          </div>

          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <label className="text-sm font-medium">Entregador (opcional)</label>
              
              <Popover open={popoverOpen} onOpenChange={setPopoverOpen}>
                <PopoverTrigger asChild>
                  <Button
                    variant="outline"
                    size="sm"
                    className="w-full max-w-48 justify-between"
                    disabled={loadingMotoboys}
                  >
                    {selectedMotoboy ? (
                      <span className="flex items-center gap-2">
                        <User className="w-4 h-4" />
                        {selectedMotoboy.name}
                      </span>
                    ) : (
                      <span className="flex items-center gap-2">
                        <Plus className="w-4 h-4" />
                        Adicionar motoboy
                      </span>
                    )}
                    <ChevronDown className="w-4 h-4" />
                  </Button>
                </PopoverTrigger>
                
                <PopoverContent className="w-80 p-2">
                  {loadingMotoboys ? (
                    <div className="p-4 text-center text-sm text-muted-foreground">
                      Carregando motoboys...
                    </div>
                  ) : motoboys.length === 0 ? (
                    <div className="p-4 text-center space-y-3">
                      <p className="text-sm text-muted-foreground">
                        Nenhum motoboy cadastrado
                      </p>
                      <Button
                        size="sm"
                        variant="outline"
                        onClick={handleCreateMotoboy}
                        className="w-full"
                      >
                        <Plus className="w-4 h-4 mr-2" />
                        Cadastrar motoboy
                      </Button>
                    </div>
                  ) : (
                    <div className="space-y-1">
                      {selectedMotoboy && (
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => setSelectedMotoboy(null)}
                          className="w-full justify-start text-red-600 hover:text-red-700"
                        >
                          Remover seleção
                        </Button>
                      )}
                      
                      {motoboys.map((motoboy) => (
                        <Button
                          key={motoboy.id}
                          variant="ghost"
                          size="sm"
                          onClick={() => handleSelectMotoboy(motoboy)}
                          className="w-full justify-start p-3 h-auto"
                        >
                          <div className="flex items-center gap-3 w-full">
                            <User className="w-4 h-4" />
                            <div className="flex-1 text-left">
                              <p className="font-medium">{motoboy.name}</p>
                              <p className="text-xs text-muted-foreground flex items-center gap-1">
                                <Phone className="w-3 h-3" />
                                {formatPhone(motoboy.phone_e164)}
                              </p>
                            </div>
                            {selectedMotoboy?.id === motoboy.id && (
                              <Badge variant="secondary" className="text-xs">
                                Selecionado
                              </Badge>
                            )}
                          </div>
                        </Button>
                      ))}
                    </div>
                  )}
                </PopoverContent>
              </Popover>
            </div>

            {selectedMotoboy && (
              <div className="bg-green-50 border border-green-200 p-3 rounded-lg">
                <div className="flex items-center gap-2">
                  <Truck className="w-4 h-4 text-green-600" />
                  <div>
                    <p className="text-sm font-medium text-green-800">
                      Entregador: {selectedMotoboy.name}
                    </p>
                    <p className="text-xs text-green-600">
                      {formatPhone(selectedMotoboy.phone_e164)}
                    </p>
                  </div>
                </div>
              </div>
            )}
          </div>

          <div className="flex gap-2 pt-4">
            <Button
              variant="outline"
              onClick={onClose}
              disabled={isLoading}
              className="flex-1"
            >
              Cancelar
            </Button>
            
            <Button
              onClick={handleConfirm}
              disabled={isLoading}
              className="flex-1 bg-purple-600 hover:bg-purple-700"
            >
              {isLoading ? "Confirmando..." : "Confirmar"}
            </Button>
          </div>

          <p className="text-xs text-muted-foreground text-center">
            {selectedMotoboy 
              ? "O entregador será notificado sobre esta entrega"
              : "Você pode confirmar sem selecionar um entregador"
            }
          </p>
        </div>
      </DialogContent>
    </Dialog>
  );
};