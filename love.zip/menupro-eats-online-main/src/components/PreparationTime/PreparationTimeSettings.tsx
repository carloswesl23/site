
import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { Clock, Plus, Trash2, Save } from "lucide-react";
import { usePreparationTimeSettings } from "@/hooks/usePreparationTimeSettings";

export const PreparationTimeSettings = () => {
  const { 
    settings, 
    categoryTimes, 
    loading, 
    saveSettings, 
    saveCategoryTime, 
    deleteCategoryTime 
  } = usePreparationTimeSettings();

  const [localSettings, setLocalSettings] = useState(settings);
  const [newCategory, setNewCategory] = useState({ category_name: '', preparation_time: 30 });

  const handleSaveSettings = () => {
    saveSettings(localSettings);
  };

  const handleAddCategory = () => {
    if (newCategory.category_name.trim()) {
      saveCategoryTime(newCategory);
      setNewCategory({ category_name: '', preparation_time: 30 });
    }
  };

  if (loading) {
    return <div className="p-4">Carregando configurações...</div>;
  }

  return (
    <div className="space-y-6">
      {/* Configurações Gerais */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Clock className="w-5 h-5" />
            Configurações de Tempo de Preparo
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="defaultTime">Tempo Padrão (minutos)</Label>
              <Input
                id="defaultTime"
                type="number"
                value={localSettings.default_preparation_time}
                onChange={(e) => setLocalSettings(prev => ({
                  ...prev,
                  default_preparation_time: parseInt(e.target.value) || 30
                }))}
                min="1"
                max="180"
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="extraTime">Tempo Extra no Pico (minutos)</Label>
              <Input
                id="extraTime"
                type="number"
                value={localSettings.peak_hours_extra_time || 0}
                onChange={(e) => setLocalSettings(prev => ({
                  ...prev,
                  peak_hours_extra_time: parseInt(e.target.value) || 0
                }))}
                min="0"
                max="60"
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="peakStart">Início do Horário de Pico</Label>
              <Input
                id="peakStart"
                type="time"
                value={localSettings.peak_hours_start || ''}
                onChange={(e) => setLocalSettings(prev => ({
                  ...prev,
                  peak_hours_start: e.target.value
                }))}
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="peakEnd">Fim do Horário de Pico</Label>
              <Input
                id="peakEnd"
                type="time"
                value={localSettings.peak_hours_end || ''}
                onChange={(e) => setLocalSettings(prev => ({
                  ...prev,
                  peak_hours_end: e.target.value
                }))}
              />
            </div>
          </div>

          <div className="flex items-center justify-between">
            <div className="space-y-0.5">
              <Label>Envio Automático via WhatsApp</Label>
              <p className="text-sm text-gray-500">
                Enviar mensagem automaticamente quando o pedido for confirmado
              </p>
            </div>
            <Switch
              checked={localSettings.auto_send_whatsapp}
              onCheckedChange={(checked) => setLocalSettings(prev => ({
                ...prev,
                auto_send_whatsapp: checked
              }))}
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="messageTemplate">Modelo da Mensagem WhatsApp</Label>
            <Textarea
              id="messageTemplate"
              value={localSettings.whatsapp_message_template}
              onChange={(e) => setLocalSettings(prev => ({
                ...prev,
                whatsapp_message_template: e.target.value
              }))}
              placeholder="Use {tempo} para inserir o tempo estimado"
              rows={3}
            />
            <p className="text-xs text-gray-500">
              Use {'{tempo}'} para inserir automaticamente o tempo estimado na mensagem
            </p>
          </div>

          <Button onClick={handleSaveSettings} className="w-full">
            <Save className="w-4 h-4 mr-2" />
            Salvar Configurações
          </Button>
        </CardContent>
      </Card>

      {/* Tempos por Categoria */}
      <Card>
        <CardHeader>
          <CardTitle>Tempos Personalizados por Categoria</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="flex gap-2">
            <Input
              placeholder="Nome da categoria"
              value={newCategory.category_name}
              onChange={(e) => setNewCategory(prev => ({
                ...prev,
                category_name: e.target.value
              }))}
              className="flex-1"
            />
            <Input
              type="number"
              placeholder="Tempo (min)"
              value={newCategory.preparation_time}
              onChange={(e) => setNewCategory(prev => ({
                ...prev,
                preparation_time: parseInt(e.target.value) || 30
              }))}
              className="w-32"
              min="1"
            />
            <Button onClick={handleAddCategory} size="sm">
              <Plus className="w-4 h-4" />
            </Button>
          </div>

          <div className="space-y-2">
            {categoryTimes.map((category) => (
              <div key={category.id} className="flex items-center justify-between p-3 border rounded-lg">
                <div className="flex items-center gap-3">
                  <Badge variant="outline">{category.category_name}</Badge>
                  <span className="text-sm text-gray-600">
                    {category.preparation_time} minutos
                  </span>
                </div>
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={() => category.id && deleteCategoryTime(category.id)}
                >
                  <Trash2 className="w-4 h-4 text-red-500" />
                </Button>
              </div>
            ))}
            {categoryTimes.length === 0 && (
              <p className="text-sm text-gray-500 text-center py-4">
                Nenhum tempo personalizado configurado
              </p>
            )}
          </div>
        </CardContent>
      </Card>
    </div>
  );
};
