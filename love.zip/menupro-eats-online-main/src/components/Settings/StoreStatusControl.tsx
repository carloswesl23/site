import { useState, useEffect } from "react";
import { Switch } from "@/components/ui/switch";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Store, Clock, AlertCircle } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";

export function StoreStatusControl() {
  const [isOpen, setIsOpen] = useState(true);
  const [loading, setLoading] = useState(false);
  const [initialLoading, setInitialLoading] = useState(true);

  // Buscar status atual da loja
  useEffect(() => {
    const fetchStoreStatus = async () => {
      try {
        const { data: { user } } = await supabase.auth.getUser();
        if (!user) return;

        const { data, error } = await supabase
          .from('establishment_settings')
          .select('is_open')
          .eq('user_id', user.id)
          .single();

        if (error) {
          console.error('Error fetching store status:', error);
          return;
        }

        setIsOpen(data?.is_open ?? true);
      } catch (error) {
        console.error('Error fetching store status:', error);
      } finally {
        setInitialLoading(false);
      }
    };

    fetchStoreStatus();
  }, []);

  const handleStatusChange = async (newStatus: boolean) => {
    setLoading(true);
    
    try {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) {
        toast.error("Usuário não autenticado");
        return;
      }

      const { error } = await supabase
        .from('establishment_settings')
        .update({ is_open: newStatus })
        .eq('user_id', user.id);

      if (error) {
        throw error;
      }

      setIsOpen(newStatus);
      toast.success(
        newStatus 
          ? "🟢 Loja aberta! Os clientes podem fazer pedidos normalmente." 
          : "🔴 Loja fechada! Os clientes verão que a loja está temporariamente fechada."
      );
    } catch (error) {
      console.error('Error updating store status:', error);
      toast.error("Erro ao atualizar status da loja");
    } finally {
      setLoading(false);
    }
  };

  if (initialLoading) {
    return (
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Store className="h-5 w-5" />
            Status da Loja
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="flex items-center justify-center py-4">
            <div className="animate-pulse text-gray-500">Carregando...</div>
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Store className="h-5 w-5" />
          Status da Loja
        </CardTitle>
        <p className="text-sm text-muted-foreground">
          Controle se sua loja está aberta para receber pedidos online
        </p>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="flex items-center gap-2">
              {isOpen ? (
                <div className="w-3 h-3 bg-green-500 rounded-full animate-pulse" />
              ) : (
                <div className="w-3 h-3 bg-red-500 rounded-full" />
              )}
              <span className="font-medium">
                {isOpen ? "Loja Aberta" : "Loja Fechada"}
              </span>
            </div>
            <Badge variant={isOpen ? "default" : "destructive"}>
              {isOpen ? "ONLINE" : "OFFLINE"}
            </Badge>
          </div>
          
          <Switch
            checked={isOpen}
            onCheckedChange={handleStatusChange}
            disabled={loading}
          />
        </div>

        <div className="p-4 rounded-lg bg-muted/50">
          <div className="flex items-start gap-3">
            {isOpen ? (
              <Clock className="h-5 w-5 text-green-600 mt-0.5" />
            ) : (
              <AlertCircle className="h-5 w-5 text-red-600 mt-0.5" />
            )}
            <div className="flex-1">
              <p className="text-sm font-medium">
                {isOpen ? "Loja funcionando normalmente" : "Loja temporariamente fechada"}
              </p>
              <p className="text-xs text-muted-foreground mt-1">
                {isOpen 
                  ? "Os clientes podem fazer pedidos normalmente através do cardápio online."
                  : "Os clientes verão uma mensagem informando que a loja está fechada no momento."
                }
              </p>
            </div>
          </div>
        </div>

        <div className="flex gap-2">
          <Button
            size="sm"
            variant={isOpen ? "destructive" : "default"}
            onClick={() => handleStatusChange(!isOpen)}
            disabled={loading}
            className="flex-1"
          >
            {loading ? (
              "Atualizando..."
            ) : isOpen ? (
              "Fechar Loja"
            ) : (
              "Abrir Loja"
            )}
          </Button>
        </div>
      </CardContent>
    </Card>
  );
}