import { useState, useEffect } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Switch } from "@/components/ui/switch";
import { Label } from "@/components/ui/label";
import { Button } from "@/components/ui/button";
import { Printer, Save, TestTube } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { useToast } from "@/hooks/use-toast";

interface PrintSettings {
  auto_print_on_confirm?: boolean;
  auto_print_on_ready?: boolean;
  print_customer_copy?: boolean;
  include_qr_code?: boolean;
  print_establishment_copy?: boolean;
}

export function PrintSettings() {
  const { toast } = useToast();
  const [settings, setSettings] = useState<PrintSettings>({
    auto_print_on_confirm: false,
    auto_print_on_ready: false,
    print_customer_copy: false,
    include_qr_code: true,
    print_establishment_copy: true
  });
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    fetchPrintSettings();
  }, []);

  const fetchPrintSettings = async () => {
    try {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) return;

      const { data, error } = await supabase
        .from('establishment_settings')
        .select('*')
        .eq('user_id', user.id)
        .single();

      if (error) throw error;

      if (data) {
        setSettings({
          auto_print_on_confirm: (data as any).auto_print_on_confirm || false,
          auto_print_on_ready: (data as any).auto_print_on_ready || false,
          print_customer_copy: (data as any).print_customer_copy || false,
          include_qr_code: (data as any).include_qr_code !== false, // Default true
          print_establishment_copy: (data as any).print_establishment_copy !== false // Default true
        });
      }
    } catch (error) {
      console.error('Error fetching print settings:', error);
    }
  };

  const savePrintSettings = async () => {
    setLoading(true);
    try {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) return;

      const { error } = await supabase
        .from('establishment_settings')
        .update(settings)
        .eq('user_id', user.id);

      if (error) throw error;

      toast({
        title: "Configurações salvas!",
        description: "Suas configurações de impressão foram atualizadas.",
      });
    } catch (error) {
      console.error('Error saving print settings:', error);
      toast({
        title: "Erro ao salvar",
        description: "Não foi possível salvar as configurações.",
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  };

  const testPrint = () => {
    // Abrir uma página de teste de impressão
    const testUrl = '/orders/print-test';
    window.open(testUrl, '_blank', 'width=400,height=600');
  };

  const updateSetting = (key: keyof PrintSettings, value: boolean) => {
    setSettings(prev => ({
      ...prev,
      [key]: value
    }));
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Printer className="w-5 h-5" />
          Configurações de Impressão
        </CardTitle>
        <p className="text-sm text-muted-foreground">
          Configure quando e como os pedidos devem ser impressos automaticamente
        </p>
      </CardHeader>
      <CardContent className="space-y-6">
        {/* Impressão Automática */}
        <div className="space-y-4">
          <h3 className="text-sm font-medium">Impressão Automática</h3>
          
          <div className="flex items-center justify-between">
            <div className="space-y-0.5">
              <Label>Imprimir ao Confirmar Pedido</Label>
              <p className="text-sm text-gray-500">
                Imprime automaticamente quando o pedido for confirmado
              </p>
            </div>
            <Switch
              checked={settings.auto_print_on_confirm}
              onCheckedChange={(value) => updateSetting('auto_print_on_confirm', value)}
            />
          </div>

          <div className="flex items-center justify-between">
            <div className="space-y-0.5">
              <Label>Imprimir quando Pronto</Label>
              <p className="text-sm text-gray-500">
                Imprime automaticamente quando o pedido estiver pronto
              </p>
            </div>
            <Switch
              checked={settings.auto_print_on_ready}
              onCheckedChange={(value) => updateSetting('auto_print_on_ready', value)}
            />
          </div>
        </div>

        {/* Conteúdo da Impressão */}
        <div className="space-y-4 border-t pt-4">
          <h3 className="text-sm font-medium">Conteúdo da Impressão</h3>
          
          <div className="flex items-center justify-between">
            <div className="space-y-0.5">
              <Label>Incluir QR Code</Label>
              <p className="text-sm text-gray-500">
                Adiciona QR Code para acompanhamento do pedido
              </p>
            </div>
            <Switch
              checked={settings.include_qr_code}
              onCheckedChange={(value) => updateSetting('include_qr_code', value)}
            />
          </div>

          <div className="flex items-center justify-between">
            <div className="space-y-0.5">
              <Label>Via do Estabelecimento</Label>
              <p className="text-sm text-gray-500">
                Imprime via para controle interno do estabelecimento
              </p>
            </div>
            <Switch
              checked={settings.print_establishment_copy}
              onCheckedChange={(value) => updateSetting('print_establishment_copy', value)}
            />
          </div>

          <div className="flex items-center justify-between">
            <div className="space-y-0.5">
              <Label>Via do Cliente</Label>
              <p className="text-sm text-gray-500">
                Imprime via adicional para entrega ao cliente
              </p>
            </div>
            <Switch
              checked={settings.print_customer_copy}
              onCheckedChange={(value) => updateSetting('print_customer_copy', value)}
            />
          </div>
        </div>

        {/* Configurações de Impressora */}
        <div className="space-y-4 border-t pt-4">
          <h3 className="text-sm font-medium">Configurações da Impressora</h3>
          
          <div className="bg-blue-50 p-4 rounded-lg">
            <h4 className="text-sm font-medium text-blue-900 mb-2">Como configurar a impressão</h4>
            <ul className="text-sm text-blue-800 space-y-1">
              <li>• Configure sua impressora térmica (80mm) como padrão no sistema</li>
              <li>• Use o botão "Teste de Impressão" para verificar a configuração</li>
              <li>• Para impressão automática, mantenha o navegador aberto</li>
              <li>• Certifique-se de que os pop-ups estão liberados para este site</li>
            </ul>
          </div>
        </div>

        {/* Botões de Ação */}
        <div className="flex gap-3 pt-4">
          <Button 
            onClick={savePrintSettings}
            disabled={loading}
            className="flex-1"
          >
            <Save className="w-4 h-4 mr-2" />
            {loading ? "Salvando..." : "Salvar Configurações"}
          </Button>
          
          <Button 
            variant="outline"
            onClick={testPrint}
          >
            <TestTube className="w-4 h-4 mr-2" />
            Teste de Impressão
          </Button>
        </div>
      </CardContent>
    </Card>
  );
}