import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Switch } from "@/components/ui/switch";
import { Textarea } from "@/components/ui/textarea";
import { Save, CreditCard } from "lucide-react";
import { useToast } from "@/hooks/use-toast";

interface CheckoutSettingsProps {
  settings: any;
  onUpdateSettings: (updates: any) => Promise<any>;
}

export const CheckoutSettings = ({ settings, onUpdateSettings }: CheckoutSettingsProps) => {
  const { toast } = useToast();
  const [acceptCash, setAcceptCash] = useState(true);
  const [acceptCreditOnDelivery, setAcceptCreditOnDelivery] = useState(true);
  const [combinePaymentViaWhatsapp, setCombinePaymentViaWhatsapp] = useState(true);
  const [showQrPix, setShowQrPix] = useState(true);
  const [checkoutCustomMessage, setCheckoutCustomMessage] = useState("");

  useEffect(() => {
    if (settings) {
      setAcceptCash(settings.accept_cash ?? true);
      setAcceptCreditOnDelivery(settings.accept_credit_on_delivery ?? true);
      setCombinePaymentViaWhatsapp(settings.combine_payment_via_whatsapp ?? true);
      setShowQrPix(settings.show_qr_pix ?? true);
      setCheckoutCustomMessage(settings.checkout_custom_message || "Obrigado! Aguarde que já vamos preparar seu pedido.");
    }
  }, [settings]);

  const handleSaveCheckoutSettings = async () => {
    try {
      await onUpdateSettings({
        accept_cash: acceptCash,
        accept_credit_on_delivery: acceptCreditOnDelivery,
        combine_payment_via_whatsapp: combinePaymentViaWhatsapp,
        show_qr_pix: showQrPix,
        checkout_custom_message: checkoutCustomMessage
      });
      
      toast({
        title: "Configurações de checkout salvas!",
        description: "As configurações de checkout foram atualizadas com sucesso.",
      });
    } catch (error) {
      console.error('Error saving checkout settings:', error);
      toast({
        title: "Erro ao salvar",
        description: "Não foi possível salvar as configurações de checkout. Tente novamente.",
        variant: "destructive",
      });
    }
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <CreditCard className="w-5 h-5" />
          Configurações de Checkout
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-6">
        <div className="space-y-4">
          <h3 className="text-lg font-medium">Formas de Pagamento Aceitas</h3>
          
          <div className="flex items-center justify-between">
            <div className="space-y-0.5">
              <Label>Aceitar Dinheiro</Label>
              <p className="text-sm text-gray-500">
                Permite que clientes escolham pagar em dinheiro
              </p>
            </div>
            <Switch
              checked={acceptCash}
              onCheckedChange={setAcceptCash}
            />
          </div>

          <div className="flex items-center justify-between">
            <div className="space-y-0.5">
              <Label>Aceitar Cartão na Entrega</Label>
              <p className="text-sm text-gray-500">
                Permite pagamento com cartão no momento da entrega
              </p>
            </div>
            <Switch
              checked={acceptCreditOnDelivery}
              onCheckedChange={setAcceptCreditOnDelivery}
            />
          </div>

          <div className="flex items-center justify-between">
            <div className="space-y-0.5">
              <Label>Combinar Pagamento pelo WhatsApp</Label>
              <p className="text-sm text-gray-500">
                Permite que cliente escolha negociar pagamento via WhatsApp
              </p>
            </div>
            <Switch
              checked={combinePaymentViaWhatsapp}
              onCheckedChange={setCombinePaymentViaWhatsapp}
            />
          </div>

          <div className="flex items-center justify-between">
            <div className="space-y-0.5">
              <Label>Exibir QR Code do PIX</Label>
              <p className="text-sm text-gray-500">
                Mostra o QR Code do PIX na tela de pagamento
              </p>
            </div>
            <Switch
              checked={showQrPix}
              onCheckedChange={setShowQrPix}
            />
          </div>
        </div>

        <div className="space-y-2">
          <Label htmlFor="checkoutMessage">Mensagem Personalizada de Confirmação</Label>
          <Textarea
            id="checkoutMessage"
            value={checkoutCustomMessage}
            onChange={(e) => setCheckoutCustomMessage(e.target.value)}
            placeholder="Obrigado! Aguarde que já vamos preparar seu pedido."
            rows={3}
          />
          <p className="text-sm text-gray-500">
            Esta mensagem aparecerá na tela de confirmação do pedido
          </p>
        </div>

        <Button onClick={handleSaveCheckoutSettings} className="gradient-brand text-white">
          <Save className="w-4 h-4 mr-2" />
          Salvar Configurações de Checkout
        </Button>
      </CardContent>
    </Card>
  );
};