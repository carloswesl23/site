import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Save, Globe } from "lucide-react";
import { useToast } from "@/hooks/use-toast";

interface GeneralSettingsProps {
  settings: any;
  onUpdateSettings: (updates: any) => Promise<any>;
}

export const GeneralSettings = ({ settings, onUpdateSettings }: GeneralSettingsProps) => {
  const { toast } = useToast();
  const [restaurantName, setRestaurantName] = useState("");
  const [email, setEmail] = useState("admin@demo.com");
  const [phone, setPhone] = useState("");
  const [address, setAddress] = useState("");
  const [instagramUrl, setInstagramUrl] = useState("");

  useEffect(() => {
    if (settings) {
      setRestaurantName(settings.business_name || "");
      setPhone(settings.business_phone || "");
      setAddress(settings.business_address || "");
      setInstagramUrl(settings.instagram_url || "");
    }
  }, [settings]);

  const handleSaveSettings = async () => {
    try {
      const result = await onUpdateSettings({
        business_name: restaurantName,
        business_phone: phone,
        business_address: address,
        instagram_url: instagramUrl
      });
      
      toast({
        title: "Configurações salvas!",
        description: "Suas configurações foram atualizadas com sucesso.",
      });
      
      setTimeout(() => {
        window.location.reload();
      }, 1000);
    } catch (error) {
      console.error('Error saving settings:', error);
      toast({
        title: "Erro ao salvar",
        description: "Não foi possível salvar as configurações. Tente novamente.",
        variant: "destructive",
      });
    }
  };

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Globe className="w-5 h-5" />
            Informações do Estabelecimento
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid gap-4 md:grid-cols-2">
            <div className="space-y-2">
              <Label htmlFor="restaurantName">Nome do Estabelecimento</Label>
              <Input
                id="restaurantName"
                value={restaurantName}
                onChange={(e) => setRestaurantName(e.target.value)}
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="email">Email</Label>
              <Input
                id="email"
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="phone">Telefone</Label>
              <Input
                id="phone"
                value={phone}
                onChange={(e) => setPhone(e.target.value)}
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="address">Endereço</Label>
              <Input
                id="address"
                value={address}
                onChange={(e) => setAddress(e.target.value)}
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="instagramUrl">URL do Instagram</Label>
              <Input
                id="instagramUrl"
                type="url"
                value={instagramUrl}
                onChange={(e) => setInstagramUrl(e.target.value)}
                placeholder="https://instagram.com/meurestaurante"
              />
            </div>
          </div>
          
          <Button onClick={handleSaveSettings} className="gradient-brand text-white">
            <Save className="w-4 h-4 mr-2" />
            Salvar Informações Básicas
          </Button>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Globe className="w-5 h-5" />
            Link do Cardápio Online
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="p-4 bg-muted rounded-lg">
            <Label className="text-sm font-medium text-muted-foreground">Seu cardápio está disponível em:</Label>
            <div className="flex items-center gap-2 mt-2">
              <div className="flex-1 p-3 bg-background border rounded-md font-mono text-sm break-all">
                <span className="text-muted-foreground">https://lovemenu.com.br/</span>
                <span className="font-medium text-foreground">{settings?.online_menu_slug || 'carregando...'}</span>
              </div>
              <Badge variant="outline" className="text-green-600 border-green-200">Ativo</Badge>
            </div>
            <p className="text-xs text-muted-foreground mt-2">
              Este link é gerado automaticamente com base no nome do seu estabelecimento.
            </p>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};