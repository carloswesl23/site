
import { useState, useEffect } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Switch } from "@/components/ui/switch";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Save, CreditCard, QrCode } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { supabase } from "@/integrations/supabase/client";

interface PaymentConfigModalProps {
  isOpen: boolean;
  onClose: () => void;
  type: 'pix' | 'mercadopago' | 'facebook';
}

export const PaymentConfigModal = ({ isOpen, onClose, type }: PaymentConfigModalProps) => {
  const { toast } = useToast();
  
  // PIX Configuration
  const [pixKey, setPixKey] = useState("");
  const [pixBeneficiaryName, setPixBeneficiaryName] = useState("");
  const [pixBeneficiaryDocument, setPixBeneficiaryDocument] = useState("");
  const [pixEnabled, setPixEnabled] = useState(false);
  const [isLoading, setIsLoading] = useState(false);

  // Mercado Pago Configuration
  const [mpPublicKey, setMpPublicKey] = useState("");
  const [mpAccessToken, setMpAccessToken] = useState("");
  const [mpWebhookUrl, setMpWebhookUrl] = useState("");
  const [mpEnabled, setMpEnabled] = useState(false);

  // Facebook Pixel Configuration
  const [fbPixelId, setFbPixelId] = useState("");
  const [fbAccessToken, setFbAccessToken] = useState("");
  const [fbEnabled, setFbEnabled] = useState(false);

  // Carregar dados ao abrir o modal
  useEffect(() => {
    if (isOpen) {
      if (type === 'pix') {
        loadPixData();
      } else if (type === 'mercadopago') {
        loadMercadoPagoData();
      }
    }
  }, [isOpen, type]);

  const loadPixData = async () => {
    try {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) return;

      const { data, error } = await supabase
        .from('establishment_settings')
        .select('pix_key, pix_beneficiary_name, pix_beneficiary_document, pix_enabled')
        .eq('user_id', user.id)
        .single();

      if (error && error.code !== 'PGRST116') {
        console.error('Error loading PIX data:', error);
        return;
      }

      if (data) {
        setPixKey(data.pix_key || "");
        setPixBeneficiaryName(data.pix_beneficiary_name || "");
        setPixBeneficiaryDocument(data.pix_beneficiary_document || "");
        setPixEnabled(data.pix_enabled || false);
      }
    } catch (error) {
      console.error('Error loading PIX data:', error);
    }
  };

  const loadMercadoPagoData = async () => {
    try {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) return;

      const { data, error } = await supabase
        .from('establishment_settings')
        .select('mp_public_key, mp_access_token, mp_webhook_url, mp_enabled')
        .eq('user_id', user.id)
        .single();

      if (error && error.code !== 'PGRST116') {
        console.error('Error loading MercadoPago data:', error);
        return;
      }

      if (data) {
        setMpPublicKey(data.mp_public_key || "");
        setMpAccessToken(data.mp_access_token || "");
        setMpWebhookUrl(data.mp_webhook_url || "");
        setMpEnabled(data.mp_enabled || false);
      }
    } catch (error) {
      console.error('Error loading MercadoPago data:', error);
    }
  };

  const handleSave = async () => {
    setIsLoading(true);
    try {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) throw new Error('User not authenticated');

      // Buscar configurações atuais primeiro
      const { data: currentSettings } = await supabase
        .from('establishment_settings')
        .select('*')
        .eq('user_id', user.id)
        .single();

      if (type === 'pix') {
        const { error } = await supabase
          .from('establishment_settings')
          .upsert({
            user_id: user.id,
            business_name: currentSettings?.business_name || 'Meu Negócio',
            pix_key: pixKey.trim(),
            pix_beneficiary_name: pixBeneficiaryName.trim(),
            pix_beneficiary_document: pixBeneficiaryDocument.trim(),
            pix_enabled: pixEnabled
          }, { 
            onConflict: 'user_id',
            ignoreDuplicates: false 
          });

        if (error) throw error;
        
        toast({
          title: "Configuração salva!",
          description: "PIX foi configurado com sucesso.",
        });
      } else if (type === 'mercadopago') {
        const webhookUrl = `https://mzhyxympbmjjergvbwfa.supabase.co/functions/v1/mercadopago-webhook`;
        
        const { error } = await supabase
          .from('establishment_settings')
          .upsert({
            user_id: user.id,
            business_name: currentSettings?.business_name || 'Meu Negócio',
            mp_public_key: mpPublicKey.trim(),
            mp_access_token: mpAccessToken.trim(),
            mp_webhook_url: webhookUrl,
            mp_enabled: mpEnabled
          }, { 
            onConflict: 'user_id',
            ignoreDuplicates: false 
          });

        if (error) throw error;
        
        toast({
          title: "Mercado Pago configurado!",
          description: `Configurações salvas. Configure esta URL no Mercado Pago: ${webhookUrl}`,
        });
      } else {
        toast({
          title: "Em desenvolvimento",
          description: "Esta integração ainda não está disponível.",
        });
        return;
      }

      onClose();
    } catch (error) {
      console.error('Error saving config:', error);
      toast({
        title: "Erro ao salvar",
        description: "Não foi possível salvar a configuração.",
        variant: "destructive",
      });
    } finally {
      setIsLoading(false);
    }
  };

  const getTitle = () => {
    switch (type) {
      case 'pix': return 'PIX';
      case 'mercadopago': return 'Mercado Pago';
      case 'facebook': return 'Facebook Pixel';
      default: return '';
    }
  };

  const renderPixConfig = () => (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <div>
          <Label className="text-base font-medium">Ativar PIX</Label>
          <p className="text-sm text-gray-500">Habilitar pagamentos via PIX</p>
        </div>
        <Switch checked={pixEnabled} onCheckedChange={setPixEnabled} />
      </div>

      <div className="space-y-2">
        <Label htmlFor="pixKey">Chave PIX</Label>
        <Input
          id="pixKey"
          value={pixKey}
          onChange={(e) => setPixKey(e.target.value)}
          placeholder="email@exemplo.com ou CPF/CNPJ"
        />
      </div>

      <div className="space-y-2">
        <Label htmlFor="beneficiaryName">Nome do Beneficiário</Label>
        <Input
          id="beneficiaryName"
          value={pixBeneficiaryName}
          onChange={(e) => setPixBeneficiaryName(e.target.value)}
          placeholder="Nome completo"
        />
      </div>

      <div className="space-y-2">
        <Label htmlFor="beneficiaryDocument">CPF/CNPJ do Beneficiário</Label>
        <Input
          id="beneficiaryDocument"
          value={pixBeneficiaryDocument}
          onChange={(e) => setPixBeneficiaryDocument(e.target.value)}
          placeholder="000.000.000-00"
        />
      </div>

      <div className="bg-blue-50 p-4 rounded-lg">
        <h4 className="font-medium text-blue-800 mb-2">💡 Como funciona</h4>
        <ul className="text-sm text-blue-700 space-y-1">
          <li>• Os clientes poderão pagar via PIX usando sua chave</li>
          <li>• QR Code será gerado automaticamente</li>
          <li>• Confirmação de pagamento via webhook (opcional)</li>
        </ul>
      </div>
    </div>
  );

  const renderMercadoPagoConfig = () => (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <div>
          <Label className="text-base font-medium">Ativar Mercado Pago</Label>
          <p className="text-sm text-gray-500">Habilitar pagamentos com cartão</p>
        </div>
        <Switch checked={mpEnabled} onCheckedChange={setMpEnabled} />
      </div>

      <div className="space-y-2">
        <Label htmlFor="mpPublicKey">Public Key</Label>
        <Input
          id="mpPublicKey"
          value={mpPublicKey}
          onChange={(e) => setMpPublicKey(e.target.value)}
          placeholder="APP_USR-xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxxxx"
        />
      </div>

      <div className="space-y-2">
        <Label htmlFor="mpAccessToken">Access Token</Label>
        <Input
          id="mpAccessToken"
          type="password"
          value={mpAccessToken}
          onChange={(e) => setMpAccessToken(e.target.value)}
          placeholder="APP_USR-xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxxxx"
        />
      </div>

      <div className="space-y-2">
        <Label htmlFor="mpWebhookUrl">Webhook URL</Label>
        <Input
          id="mpWebhookUrl"
          value="https://mzhyxympbmjjergvbwfa.supabase.co/functions/v1/mercadopago-webhook"
          disabled
          className="bg-gray-50"
        />
        <p className="text-xs text-gray-500">
          Configure esta URL nas notificações do seu aplicativo no Mercado Pago (developers.mercadopago.com).
        </p>
      </div>

      <div className="bg-green-50 p-4 rounded-lg">
        <h4 className="font-medium text-green-800 mb-2">📋 Onde encontrar suas credenciais</h4>
        <ul className="text-sm text-green-700 space-y-1">
          <li>• Acesse: developers.mercadopago.com</li>
          <li>• Vá em "Suas integrações" → "Credenciais"</li>
          <li>• Use as credenciais de PRODUÇÃO para ambiente real</li>
        </ul>
      </div>
    </div>
  );

  const renderFacebookConfig = () => (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <div>
          <Label className="text-base font-medium">Ativar Facebook Pixel</Label>
          <p className="text-sm text-gray-500">Rastrear conversões de anúncios</p>
        </div>
        <Switch checked={fbEnabled} onCheckedChange={setFbEnabled} />
      </div>

      <div className="space-y-2">
        <Label htmlFor="fbPixelId">Pixel ID</Label>
        <Input
          id="fbPixelId"
          value={fbPixelId}
          onChange={(e) => setFbPixelId(e.target.value)}
          placeholder="123456789012345"
        />
      </div>

      <div className="space-y-2">
        <Label htmlFor="fbAccessToken">Access Token (Opcional)</Label>
        <Input
          id="fbAccessToken"
          type="password"
          value={fbAccessToken}
          onChange={(e) => setFbAccessToken(e.target.value)}
          placeholder="Para eventos server-side"
        />
      </div>

      <div className="bg-blue-50 p-4 rounded-lg">
        <h4 className="font-medium text-blue-800 mb-2">🎯 Como encontrar seu Pixel ID</h4>
        <ul className="text-sm text-blue-700 space-y-1">
          <li>• Acesse: business.facebook.com</li>
          <li>• Vá em "Gerenciador de Eventos"</li>
          <li>• Selecione seu pixel → o ID aparecerá no topo</li>
        </ul>
      </div>
    </div>
  );

  const renderContent = () => {
    switch (type) {
      case 'pix': return renderPixConfig();
      case 'mercadopago': return renderMercadoPagoConfig();
      case 'facebook': return renderFacebookConfig();
      default: return null;
    }
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-md max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            {type === 'pix' && <QrCode className="w-5 h-5" />}
            {type === 'mercadopago' && <CreditCard className="w-5 h-5" />}
            {type === 'facebook' && <span className="w-5 h-5 bg-blue-600 rounded text-white text-xs flex items-center justify-center font-bold">f</span>}
            Configurar {getTitle()}
          </DialogTitle>
        </DialogHeader>

        <div className="space-y-6">
          {renderContent()}

          <div className="flex gap-2">
            <Button 
              onClick={handleSave} 
              disabled={isLoading}
              className="flex-1 gradient-brand text-white"
            >
              <Save className="w-4 h-4 mr-2" />
              {isLoading ? "Salvando..." : "Salvar Configuração"}
            </Button>
            <Button variant="outline" onClick={onClose} disabled={isLoading}>
              Cancelar
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
};
