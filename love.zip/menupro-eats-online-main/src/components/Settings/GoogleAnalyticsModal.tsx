
import { useState } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { Save, BarChart3 } from "lucide-react";
import { useToast } from "@/hooks/use-toast";

interface GoogleAnalyticsModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const GoogleAnalyticsModal = ({ isOpen, onClose }: GoogleAnalyticsModalProps) => {
  const { toast } = useToast();
  const [measurementId, setMeasurementId] = useState("");
  const [enabled, setEnabled] = useState(false);

  const handleSave = () => {
    console.log('Salvando Google Analytics:', { measurementId, enabled });
    
    toast({
      title: "Google Analytics configurado!",
      description: "Rastreamento ativado com sucesso.",
    });

    onClose();
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-md">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <BarChart3 className="w-5 h-5" />
            Configurar Google Analytics
          </DialogTitle>
        </DialogHeader>

        <div className="space-y-6">
          <div className="flex items-center justify-between">
            <div>
              <Label className="text-base font-medium">Ativar Google Analytics</Label>
              <p className="text-sm text-gray-500">Rastrear visitantes e conversões</p>
            </div>
            <Switch checked={enabled} onCheckedChange={setEnabled} />
          </div>

          <div className="space-y-2">
            <Label htmlFor="measurementId">Measurement ID</Label>
            <Input
              id="measurementId"
              value={measurementId}
              onChange={(e) => setMeasurementId(e.target.value)}
              placeholder="G-XXXXXXXXXX"
            />
          </div>

          <div className="bg-orange-50 p-4 rounded-lg">
            <h4 className="font-medium text-orange-800 mb-2">📊 Como encontrar seu Measurement ID</h4>
            <ul className="text-sm text-orange-700 space-y-1">
              <li>• Acesse: analytics.google.com</li>
              <li>• Vá em Administrador → Propriedade</li>
              <li>• Em "Streams de dados" → selecione seu site</li>
              <li>• Copie o "MEASUREMENT ID" (formato G-XXXXXXXXXX)</li>
            </ul>
          </div>

          <div className="flex gap-2">
            <Button onClick={handleSave} className="flex-1 gradient-brand text-white">
              <Save className="w-4 h-4 mr-2" />
              Salvar Configuração
            </Button>
            <Button variant="outline" onClick={onClose}>
              Cancelar
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
};
