import { useState, useEffect } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { MessageSquare, Save, ExternalLink, CheckCircle, AlertCircle } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { supabase } from "@/integrations/supabase/client";

interface ZAPIConfig {
  zapi_instance_id: string;
  zapi_token: string;
  zapi_enabled: boolean;
}

export const ZAPISettings = () => {
  const { toast } = useToast();
  const [config, setConfig] = useState<ZAPIConfig>({
    zapi_instance_id: '',
    zapi_token: '',
    zapi_enabled: false
  });
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [testing, setTesting] = useState(false);

  useEffect(() => {
    fetchConfig();
  }, []);

  const fetchConfig = async () => {
    try {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) return;

      const { data, error } = await supabase
        .from('establishment_settings')
        .select('zapi_instance_id, zapi_token, zapi_enabled')
        .eq('user_id', user.id)
        .single();

      if (error && error.code !== 'PGRST116') {
        throw error;
      }

      if (data) {
        setConfig({
          zapi_instance_id: data.zapi_instance_id || '',
          zapi_token: data.zapi_token || '',
          zapi_enabled: data.zapi_enabled || false
        });
      }
    } catch (error) {
      console.error('Error fetching Z-API config:', error);
      toast({
        title: "Erro ao carregar configurações",
        description: "Não foi possível carregar as configurações da Z-API.",
        variant: "destructive"
      });
    } finally {
      setLoading(false);
    }
  };

  const saveConfig = async () => {
    setSaving(true);
    try {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) return;

      const { error } = await supabase
        .from('establishment_settings')
        .update({
          zapi_instance_id: config.zapi_instance_id,
          zapi_token: config.zapi_token,
          zapi_enabled: config.zapi_enabled
        })
        .eq('user_id', user.id);

      if (error) throw error;

      toast({
        title: "Configurações salvas!",
        description: "As configurações da Z-API foram salvas com sucesso.",
      });
    } catch (error) {
      console.error('Error saving Z-API config:', error);
      toast({
        title: "Erro ao salvar",
        description: "Não foi possível salvar as configurações.",
        variant: "destructive"
      });
    } finally {
      setSaving(false);
    }
  };

  const testConnection = async () => {
    if (!config.zapi_instance_id || !config.zapi_token) {
      toast({
        title: "Configuração incompleta",
        description: "Preencha o ID da instância e o token antes de testar.",
        variant: "destructive"
      });
      return;
    }

    setTesting(true);
    try {
      // Fazer uma chamada simples à Z-API para testar a conexão
      const response = await fetch(`https://api.z-api.io/instances/${config.zapi_instance_id}/token/${config.zapi_token}/status`, {
        method: 'GET',
        headers: {
          'Content-Type': 'application/json'
        }
      });

      if (response.ok) {
        const result = await response.json();
        if (result.connected) {
          toast({
            title: "Conexão bem-sucedida!",
            description: "Sua instância Z-API está conectada e funcionando.",
          });
        } else {
          toast({
            title: "WhatsApp desconectado",
            description: "A instância existe, mas o WhatsApp não está conectado. Escaneie o QR Code na Z-API.",
            variant: "destructive"
          });
        }
      } else {
        throw new Error('Falha na conexão');
      }
    } catch (error) {
      console.error('Error testing Z-API:', error);
      toast({
        title: "Erro de conexão",
        description: "Não foi possível conectar com a Z-API. Verifique suas credenciais.",
        variant: "destructive"
      });
    } finally {
      setTesting(false);
    }
  };

  if (loading) {
    return (
      <Card>
        <CardContent className="p-6">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary mx-auto"></div>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <MessageSquare className="w-5 h-5" />
          Configuração do LoveZap (WhatsApp)
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-6">
        {/* Info Box */}
        <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
          <div className="flex items-start gap-3">
            <AlertCircle className="w-5 h-5 text-blue-600 mt-0.5" />
            <div>
              <h4 className="font-medium text-blue-900">Como configurar sua Z-API</h4>
              <p className="text-sm text-blue-700 mt-1">
                1. Acesse sua conta na Z-API e crie uma nova instância<br />
                2. Copie o ID da instância e o token de acesso<br />
                3. Cole as informações abaixo e ative a integração<br />
                4. Escaneie o QR Code no painel da Z-API para conectar seu WhatsApp
              </p>
              <a 
                href="https://developer.z-api.io/" 
                target="_blank" 
                rel="noopener noreferrer"
                className="inline-flex items-center gap-1 text-sm text-blue-600 hover:text-blue-800 mt-2"
              >
                Acessar Z-API <ExternalLink className="w-3 h-3" />
              </a>
            </div>
          </div>
        </div>

        {/* Configurações */}
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <div>
              <Label className="text-base font-medium">Ativar Z-API</Label>
              <p className="text-sm text-muted-foreground">
                Habilitar envio automático de mensagens via WhatsApp
              </p>
            </div>
            <Switch
              checked={config.zapi_enabled}
              onCheckedChange={(checked) => 
                setConfig(prev => ({ ...prev, zapi_enabled: checked }))
              }
            />
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <Label htmlFor="instance-id">ID da Instância</Label>
              <Input
                id="instance-id"
                value={config.zapi_instance_id}
                onChange={(e) => 
                  setConfig(prev => ({ ...prev, zapi_instance_id: e.target.value }))
                }
                placeholder="Ex: 3C4..."
                disabled={!config.zapi_enabled}
              />
            </div>

            <div>
              <Label htmlFor="token">Token de Acesso</Label>
              <Input
                id="token"
                type="password"
                value={config.zapi_token}
                onChange={(e) => 
                  setConfig(prev => ({ ...prev, zapi_token: e.target.value }))
                }
                placeholder="Seu token da Z-API"
                disabled={!config.zapi_enabled}
              />
            </div>
          </div>

          {/* Status da Conexão */}
          {config.zapi_enabled && config.zapi_instance_id && config.zapi_token && (
            <div className="border rounded-lg p-4 bg-gray-50">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <CheckCircle className="w-4 h-4 text-green-600" />
                  <span className="text-sm font-medium">Status da Conexão</span>
                </div>
                <Button 
                  variant="outline" 
                  size="sm" 
                  onClick={testConnection}
                  disabled={testing}
                >
                  {testing ? "Testando..." : "Testar Conexão"}
                </Button>
              </div>
            </div>
          )}
        </div>

        <Button 
          onClick={saveConfig} 
          disabled={saving || !config.zapi_enabled || !config.zapi_instance_id || !config.zapi_token} 
          className="w-full"
        >
          <Save className="w-4 h-4 mr-2" />
          {saving ? "Salvando..." : "Salvar Configurações"}
        </Button>
      </CardContent>
    </Card>
  );
};