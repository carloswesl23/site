import { useState, useEffect } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Switch } from "@/components/ui/switch";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { MessageSquare, Settings, Eye, Save } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { supabase } from "@/integrations/supabase/client";

interface WhatsAppConfig {
  id?: string;
  auto_messages_enabled: boolean;
  estimated_delivery_time: string;
  
  new_order_enabled: boolean;
  new_order_template: string;
  
  pix_message_enabled: boolean;
  pix_message_template: string;
  
  payment_confirmed_enabled: boolean;
  payment_confirmed_template: string;
  
  out_for_delivery_enabled: boolean;
  out_for_delivery_template: string;
}

const defaultConfig: WhatsAppConfig = {
  auto_messages_enabled: true,
  estimated_delivery_time: "30-45 minutos",
  
  new_order_enabled: true,
  new_order_template: `🍔 *NOVO PEDIDO - {nome_da_loja}*

📋 *Pedido:* #{codigo_do_pedido}
👤 *Cliente:* {nome_do_cliente}
📱 *Telefone:* {telefone}
📍 *Endereço de Entrega:*
   Rua: {rua}, {numero}
   Bairro: {bairro}
   Cidade: {cidade}
   CEP: {cep}

📋 *ITENS DO PEDIDO:*
{itens_do_pedido}

💰 *Subtotal: R$ {subtotal}*
🚚 *Taxa de entrega: R$ {taxa_entrega}*
💳 *TOTAL: R$ {total}*
💰 *Forma de pagamento:* {metodo_pagamento}

🕒 Aguarde a confirmação do seu pedido!`,

  pix_message_enabled: true,
  pix_message_template: `💸 *Copie e cole o PIX para pagamento:*

🔐 *Chave PIX:* {chave_pix}
👤 *Beneficiário:* {nome_beneficiario}
💰 *Valor:* R$ {total}

📋 *Pedido:* #{codigo_do_pedido}

⏰ Após o pagamento, seu pedido será confirmado automaticamente!`,

  payment_confirmed_enabled: true,
  payment_confirmed_template: `✅ *Pagamento confirmado!*

Seu pedido #{codigo_do_pedido} está sendo preparado.
⏱️ *Tempo estimado:* {tempo_estimado}

Obrigado por escolher o {nome_da_loja}! 🍔`,

  out_for_delivery_enabled: true,
  out_for_delivery_template: `📦 *Seu pedido saiu para entrega!*

🚴 Entregador a caminho.
Aproveite sua refeição e obrigado por comprar com a gente!

💬 Qualquer dúvida, estamos por aqui no WhatsApp.`
};

export const WhatsAppMessageSettings = () => {
  const { toast } = useToast();
  const [config, setConfig] = useState<WhatsAppConfig>(defaultConfig);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [previewData, setPreviewData] = useState({
    nome_da_loja: "Minha Lanchonete",
    codigo_do_pedido: "MP123456",
    nome_do_cliente: "João Silva",
    telefone: "(11) 99999-9999",
    rua: "Rua das Flores",
    numero: "123",
    bairro: "Centro",
    cidade: "São Paulo",
    cep: "01234-567",
    itens_do_pedido: "1x Hambúrguer Clássico - R$ 25,90\n1x Batata Frita - R$ 12,90",
    subtotal: "38,80",
    taxa_entrega: "5,00",
    total: "43,80",
    metodo_pagamento: "PIX",
    chave_pix: "lanchonete@email.com",
    nome_beneficiario: "Minha Lanchonete LTDA",
    tempo_estimado: "30-45 minutos"
  });

  useEffect(() => {
    fetchConfig();
  }, []);

  const fetchConfig = async () => {
    try {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) return;

      const { data, error } = await supabase
        .from('whatsapp_message_configs')
        .select('*')
        .eq('user_id', user.id)
        .single();

      if (error && error.code !== 'PGRST116') {
        throw error;
      }

      if (data) {
        setConfig(data);
      }
    } catch (error) {
      console.error('Error fetching WhatsApp config:', error);
      toast({
        title: "Erro ao carregar configurações",
        description: "Não foi possível carregar as configurações.",
        variant: "destructive"
      });
    } finally {
      setLoading(false);
    }
  };

  const saveConfig = async () => {
    setSaving(true);
    try {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) return;

      const configData = {
        ...config,
        user_id: user.id
      };

      if (config.id) {
        const { error } = await supabase
          .from('whatsapp_message_configs')
          .update(configData)
          .eq('id', config.id);

        if (error) throw error;
      } else {
        const { data, error } = await supabase
          .from('whatsapp_message_configs')
          .insert(configData)
          .select()
          .single();

        if (error) throw error;
        setConfig(data);
      }

      toast({
        title: "Configurações salvas!",
        description: "As configurações de mensagens foram salvas com sucesso.",
      });
    } catch (error) {
      console.error('Error saving WhatsApp config:', error);
      toast({
        title: "Erro ao salvar",
        description: "Não foi possível salvar as configurações.",
        variant: "destructive"
      });
    } finally {
      setSaving(false);
    }
  };

  const renderTemplate = (template: string) => {
    let rendered = template;
    Object.entries(previewData).forEach(([key, value]) => {
      rendered = rendered.replace(new RegExp(`{${key}}`, 'g'), value);
    });
    return rendered;
  };

  if (loading) {
    return (
      <Card>
        <CardContent className="p-6">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary mx-auto"></div>
        </CardContent>
      </Card>
    );
  }

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <MessageSquare className="w-5 h-5" />
            Mensagens Automáticas do WhatsApp
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-6">
          {/* Configurações Gerais */}
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <div>
                <Label className="text-base font-medium">Ativar Mensagens Automáticas</Label>
                <p className="text-sm text-muted-foreground">
                  Enviar mensagens automáticas aos clientes via WhatsApp
                </p>
              </div>
              <Switch
                checked={config.auto_messages_enabled}
                onCheckedChange={(checked) => 
                  setConfig(prev => ({ ...prev, auto_messages_enabled: checked }))
                }
              />
            </div>

            <div>
              <Label htmlFor="delivery-time">Tempo Estimado de Entrega</Label>
              <Input
                id="delivery-time"
                value={config.estimated_delivery_time}
                onChange={(e) => 
                  setConfig(prev => ({ ...prev, estimated_delivery_time: e.target.value }))
                }
                placeholder="Ex: 30-45 minutos"
              />
            </div>
          </div>

          {/* Templates de Mensagens */}
          <Tabs defaultValue="new-order" className="w-full">
            <TabsList className="grid w-full grid-cols-4">
              <TabsTrigger value="new-order">Novo Pedido</TabsTrigger>
              <TabsTrigger value="pix">PIX</TabsTrigger>
              <TabsTrigger value="confirmed">Confirmado</TabsTrigger>
              <TabsTrigger value="delivery">Entrega</TabsTrigger>
            </TabsList>

            {/* Template Novo Pedido */}
            <TabsContent value="new-order" className="space-y-4">
              <div className="flex items-center justify-between">
                <h3 className="text-lg font-medium">Mensagem de Novo Pedido</h3>
                <Switch
                  checked={config.new_order_enabled}
                  onCheckedChange={(checked) => 
                    setConfig(prev => ({ ...prev, new_order_enabled: checked }))
                  }
                />
              </div>
              
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
                <div>
                  <Label>Template da Mensagem</Label>
                  <Textarea
                    value={config.new_order_template}
                    onChange={(e) => 
                      setConfig(prev => ({ ...prev, new_order_template: e.target.value }))
                    }
                    rows={15}
                    className="font-mono text-sm"
                  />
                </div>
                <div>
                  <Label className="flex items-center gap-2">
                    <Eye className="w-4 h-4" />
                    Pré-visualização
                  </Label>
                  <div className="border rounded-md p-3 bg-muted/50 whitespace-pre-wrap text-sm">
                    {renderTemplate(config.new_order_template)}
                  </div>
                </div>
              </div>
            </TabsContent>

            {/* Template PIX */}
            <TabsContent value="pix" className="space-y-4">
              <div className="flex items-center justify-between">
                <h3 className="text-lg font-medium">Mensagem PIX</h3>
                <Switch
                  checked={config.pix_message_enabled}
                  onCheckedChange={(checked) => 
                    setConfig(prev => ({ ...prev, pix_message_enabled: checked }))
                  }
                />
              </div>
              
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
                <div>
                  <Label>Template da Mensagem</Label>
                  <Textarea
                    value={config.pix_message_template}
                    onChange={(e) => 
                      setConfig(prev => ({ ...prev, pix_message_template: e.target.value }))
                    }
                    rows={10}
                    className="font-mono text-sm"
                  />
                </div>
                <div>
                  <Label className="flex items-center gap-2">
                    <Eye className="w-4 h-4" />
                    Pré-visualização
                  </Label>
                  <div className="border rounded-md p-3 bg-muted/50 whitespace-pre-wrap text-sm">
                    {renderTemplate(config.pix_message_template)}
                  </div>
                </div>
              </div>
            </TabsContent>

            {/* Template Confirmado */}
            <TabsContent value="confirmed" className="space-y-4">
              <div className="flex items-center justify-between">
                <h3 className="text-lg font-medium">Mensagem de Confirmação</h3>
                <Switch
                  checked={config.payment_confirmed_enabled}
                  onCheckedChange={(checked) => 
                    setConfig(prev => ({ ...prev, payment_confirmed_enabled: checked }))
                  }
                />
              </div>
              
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
                <div>
                  <Label>Template da Mensagem</Label>
                  <Textarea
                    value={config.payment_confirmed_template}
                    onChange={(e) => 
                      setConfig(prev => ({ ...prev, payment_confirmed_template: e.target.value }))
                    }
                    rows={8}
                    className="font-mono text-sm"
                  />
                </div>
                <div>
                  <Label className="flex items-center gap-2">
                    <Eye className="w-4 h-4" />
                    Pré-visualização
                  </Label>
                  <div className="border rounded-md p-3 bg-muted/50 whitespace-pre-wrap text-sm">
                    {renderTemplate(config.payment_confirmed_template)}
                  </div>
                </div>
              </div>
            </TabsContent>

            {/* Template Entrega */}
            <TabsContent value="delivery" className="space-y-4">
              <div className="flex items-center justify-between">
                <h3 className="text-lg font-medium">Mensagem de Entrega</h3>
                <Switch
                  checked={config.out_for_delivery_enabled}
                  onCheckedChange={(checked) => 
                    setConfig(prev => ({ ...prev, out_for_delivery_enabled: checked }))
                  }
                />
              </div>
              
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
                <div>
                  <Label>Template da Mensagem</Label>
                  <Textarea
                    value={config.out_for_delivery_template}
                    onChange={(e) => 
                      setConfig(prev => ({ ...prev, out_for_delivery_template: e.target.value }))
                    }
                    rows={8}
                    className="font-mono text-sm"
                  />
                </div>
                <div>
                  <Label className="flex items-center gap-2">
                    <Eye className="w-4 h-4" />
                    Pré-visualização
                  </Label>
                  <div className="border rounded-md p-3 bg-muted/50 whitespace-pre-wrap text-sm">
                    {renderTemplate(config.out_for_delivery_template)}
                  </div>
                </div>
              </div>
            </TabsContent>
          </Tabs>

          {/* Variáveis Disponíveis */}
          <Card>
            <CardHeader>
              <CardTitle className="text-base">Variáveis Disponíveis</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-2 md:grid-cols-3 gap-2 text-sm">
                <code>{"{nome_da_loja}"}</code>
                <code>{"{codigo_do_pedido}"}</code>
                <code>{"{nome_do_cliente}"}</code>
                <code>{"{telefone}"}</code>
                <code>{"{rua}"}</code>
                <code>{"{numero}"}</code>
                <code>{"{bairro}"}</code>
                <code>{"{cidade}"}</code>
                <code>{"{cep}"}</code>
                <code>{"{itens_do_pedido}"}</code>
                <code>{"{subtotal}"}</code>
                <code>{"{taxa_entrega}"}</code>
                <code>{"{total}"}</code>
                <code>{"{metodo_pagamento}"}</code>
                <code>{"{chave_pix}"}</code>
                <code>{"{nome_beneficiario}"}</code>
                <code>{"{tempo_estimado}"}</code>
              </div>
            </CardContent>
          </Card>

          <Button onClick={saveConfig} disabled={saving} className="w-full">
            <Save className="w-4 h-4 mr-2" />
            {saving ? "Salvando..." : "Salvar Configurações"}
          </Button>
        </CardContent>
      </Card>
    </div>
  );
};