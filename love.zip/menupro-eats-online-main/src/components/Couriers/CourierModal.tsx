import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Textarea } from "@/components/ui/textarea";
import { Switch } from "@/components/ui/switch";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";

interface Courier {
  id: string;
  name: string;
  phone_e164: string;
  active: boolean;
  created_at: string;
}

interface CourierModalProps {
  isOpen: boolean;
  onClose: () => void;
  courier?: Courier | null;
}

export function CourierModal({ isOpen, onClose, courier }: CourierModalProps) {
  const [formData, setFormData] = useState({
    name: '',
    phone: '',
    is_available: true,
    is_default: false,
    vehicle_type: 'motorcycle',
    notes: ''
  });

  const queryClient = useQueryClient();

  useEffect(() => {
    if (courier) {
      setFormData({
        name: courier.name,
        phone: courier.phone_e164,
        is_available: courier.active,
        is_default: false,
        vehicle_type: 'motorcycle',
        notes: ''
      });
    } else {
      setFormData({
        name: '',
        phone: '',
        is_available: true,
        is_default: false,
        vehicle_type: 'motorcycle',
        notes: ''
      });
    }
  }, [courier]);

  const saveMutation = useMutation({
    mutationFn: async () => {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) throw new Error('Usuário não autenticado');

      // Normalizar telefone
      let normalizedPhone = formData.phone.replace(/\D/g, '');
      if (!normalizedPhone.startsWith('55')) {
        normalizedPhone = `55${normalizedPhone}`;
      }
      if (!normalizedPhone.startsWith('+')) {
        normalizedPhone = `+${normalizedPhone}`;
      }

      const courierData = {
        ...formData,
        phone: normalizedPhone,
        user_id: user.id
      };

      const motoboyData = {
        user_id: user.id,
        name: formData.name,
        phone_e164: normalizedPhone,
        active: formData.is_available
      };

      if (courier) {
        // Update
        const { data, error } = await supabase
          .from('motoboys')
          .update(motoboyData)
          .eq('id', courier.id)
          .select()
          .single();
        
        if (error) throw error;
        return data;
      } else {
        // Create
        const { data, error } = await supabase
          .from('motoboys')
          .insert(motoboyData)
          .select()
          .single();
        
        if (error) throw error;
        return data;
      }
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['motoboys'] });
      toast.success(courier ? 'Motoboy atualizado com sucesso!' : 'Motoboy cadastrado com sucesso!');
      onClose();
    },
    onError: (error) => {
      console.error('Error saving courier:', error);
      toast.error('Erro ao salvar motoboy');
    }
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!formData.name.trim()) {
      toast.error('Nome é obrigatório');
      return;
    }
    
    if (!formData.phone.trim()) {
      toast.error('Telefone é obrigatório');
      return;
    }

    saveMutation.mutate();
  };

  const handleChange = (field: string, value: any) => {
    setFormData(prev => ({ ...prev, [field]: value }));
  };

  const formatPhoneInput = (value: string) => {
    // Remove tudo que não é número
    const numbers = value.replace(/\D/g, '');
    
    // Formata conforme o padrão brasileiro
    if (numbers.length <= 2) {
      return `(${numbers}`;
    } else if (numbers.length <= 7) {
      return `(${numbers.slice(0, 2)}) ${numbers.slice(2)}`;
    } else if (numbers.length <= 11) {
      return `(${numbers.slice(0, 2)}) ${numbers.slice(2, 7)}-${numbers.slice(7)}`;
    } else {
      return `(${numbers.slice(0, 2)}) ${numbers.slice(2, 7)}-${numbers.slice(7, 11)}`;
    }
  };

  const handlePhoneChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const formatted = formatPhoneInput(e.target.value);
    handleChange('phone', formatted);
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle>
            {courier ? 'Editar Motoboy' : 'Adicionar Motoboy'}
          </DialogTitle>
        </DialogHeader>

        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="name">Nome *</Label>
            <Input
              id="name"
              value={formData.name}
              onChange={(e) => handleChange('name', e.target.value)}
              placeholder="Nome do motoboy"
              required
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="phone">Telefone *</Label>
            <Input
              id="phone"
              value={formData.phone}
              onChange={handlePhoneChange}
              placeholder="(11) 99999-9999"
              required
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="vehicle_type">Tipo de Veículo</Label>
            <Select
              value={formData.vehicle_type}
              onValueChange={(value) => handleChange('vehicle_type', value)}
            >
              <SelectTrigger>
                <SelectValue placeholder="Selecione o veículo" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="motorcycle">Moto</SelectItem>
                <SelectItem value="bicycle">Bicicleta</SelectItem>
                <SelectItem value="car">Carro</SelectItem>
                <SelectItem value="walking">A pé</SelectItem>
              </SelectContent>
            </Select>
          </div>

          <div className="space-y-2">
            <Label htmlFor="notes">Observações</Label>
            <Textarea
              id="notes"
              value={formData.notes}
              onChange={(e) => handleChange('notes', e.target.value)}
              placeholder="Informações adicionais sobre o motoboy"
              rows={3}
            />
          </div>

          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <div className="space-y-0.5">
                <Label>Disponível</Label>
                <p className="text-sm text-muted-foreground">
                  Motoboy disponível para entregas
                </p>
              </div>
              <Switch
                checked={formData.is_available}
                onCheckedChange={(checked) => handleChange('is_available', checked)}
              />
            </div>

            <div className="flex items-center justify-between">
              <div className="space-y-0.5">
                <Label>Padrão</Label>
                <p className="text-sm text-muted-foreground">
                  Motoboy selecionado por padrão
                </p>
              </div>
              <Switch
                checked={formData.is_default}
                onCheckedChange={(checked) => handleChange('is_default', checked)}
              />
            </div>
          </div>

          <div className="flex gap-2 pt-4">
            <Button type="button" variant="outline" onClick={onClose} className="flex-1">
              Cancelar
            </Button>
            <Button 
              type="submit" 
              className="flex-1"
              disabled={saveMutation.isPending}
            >
              {saveMutation.isPending ? 'Salvando...' : (courier ? 'Atualizar' : 'Cadastrar')}
            </Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  );
}