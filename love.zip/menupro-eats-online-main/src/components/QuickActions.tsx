
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Plus, Settings, BarChart3, Truck } from "lucide-react";
import { useNavigate } from "react-router-dom";

export function QuickActions() {
  const navigate = useNavigate();

  const actions = [
    {
      title: "Novo Produto",
      description: "Adicione um novo item ao seu cardápio",
      icon: Plus,
      color: "bg-brand-orange hover:bg-orange-600",
      onClick: () => navigate("/products")
    },
    {
      title: "Configurar Frete",
      description: "Configure o valor do frete para entrega",
      icon: Truck,
      color: "bg-blue-600 hover:bg-blue-700",
      onClick: () => navigate("/settings")
    },
    {
      title: "Ver Relatórios",
      description: "Analise suas vendas e performance",
      icon: BarChart3,
      color: "bg-green-600 hover:bg-green-700",
      onClick: () => navigate("/reports")
    },
    {
      title: "Configurações",
      description: "Personalize seu restaurante",
      icon: Settings,
      color: "bg-gray-600 hover:bg-gray-700",
      onClick: () => navigate("/settings")
    }
  ];

  return (
    <Card>
      <CardHeader>
        <CardTitle>Ações Rápidas</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {actions.map((action, index) => (
            <Button
              key={index}
              className={`${action.color} text-white h-auto p-4 flex flex-col items-start gap-2`}
              variant="default"
              onClick={action.onClick}
            >
              <action.icon className="h-5 w-5" />
              <div className="text-left">
                <div className="font-medium">{action.title}</div>
                <div className="text-xs opacity-90">{action.description}</div>
              </div>
            </Button>
          ))}
        </div>
      </CardContent>
    </Card>
  );
}
