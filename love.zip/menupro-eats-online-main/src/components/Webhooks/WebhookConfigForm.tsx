
import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { supabase } from "@/integrations/supabase/client";
import { useToast } from "@/hooks/use-toast";
import { Save, Trash2 } from "lucide-react";

interface WebhookConfig {
  id?: string;
  url: string;
  secret_token: string;
  events: Record<string, boolean>;
  is_active: boolean;
}

interface WebhookConfigFormProps {
  config?: WebhookConfig;
  onSave: () => void;
  onDelete?: () => void;
}

const AVAILABLE_EVENTS = [
  { key: 'pedido_criado', label: 'Pedido Criado', description: 'Quando um novo pedido é finalizado' },
  { key: 'pagamento_confirmado', label: 'Pagamento Confirmado', description: 'Quando o pagamento é confirmado' },
  { key: 'pedido_cancelado', label: 'Pedido Cancelado', description: 'Quando um pedido é cancelado' },
  { key: 'novo_cliente', label: 'Novo Cliente', description: 'Quando um novo estabelecimento se cadastra' }
];

export const WebhookConfigForm = ({ config, onSave, onDelete }: WebhookConfigFormProps) => {
  const { toast } = useToast();
  const [loading, setLoading] = useState(false);
  const [formData, setFormData] = useState<WebhookConfig>({
    url: config?.url || '',
    secret_token: config?.secret_token || '',
    events: config?.events || {},
    is_active: config?.is_active ?? true,
    ...config
  });

  const generateSecretToken = () => {
    const token = crypto.getRandomValues(new Uint8Array(32));
    const tokenHex = Array.from(token, byte => byte.toString(16).padStart(2, '0')).join('');
    setFormData(prev => ({ ...prev, secret_token: tokenHex }));
  };

  const handleEventToggle = (eventKey: string, enabled: boolean) => {
    setFormData(prev => ({
      ...prev,
      events: { ...prev.events, [eventKey]: enabled }
    }));
  };

  const handleSave = async () => {
    if (!formData.url) {
      toast({
        title: "Erro",
        description: "URL é obrigatória",
        variant: "destructive",
      });
      return;
    }

    if (!formData.secret_token) {
      toast({
        title: "Erro", 
        description: "Token secreto é obrigatório",
        variant: "destructive",
      });
      return;
    }

    setLoading(true);
    try {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) throw new Error('Usuário não autenticado');

      const webhookData = {
        user_id: user.id,
        url: formData.url,
        secret_token: formData.secret_token,
        events: formData.events,
        is_active: formData.is_active,
        updated_at: new Date().toISOString()
      };

      if (config?.id) {
        const { error } = await supabase
          .from('webhook_configs')
          .update(webhookData)
          .eq('id', config.id);
        
        if (error) throw error;
        
        toast({
          title: "Sucesso",
          description: "Webhook atualizado com sucesso!",
        });
      } else {
        const { error } = await supabase
          .from('webhook_configs')
          .insert(webhookData);
        
        if (error) throw error;
        
        toast({
          title: "Sucesso", 
          description: "Webhook criado com sucesso!",
        });
      }

      onSave();
    } catch (error) {
      console.error('Error saving webhook:', error);
      toast({
        title: "Erro",
        description: "Erro ao salvar webhook",
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  };

  const handleDelete = async () => {
    if (!config?.id) return;

    setLoading(true);
    try {
      const { error } = await supabase
        .from('webhook_configs')
        .delete()
        .eq('id', config.id);
      
      if (error) throw error;
      
      toast({
        title: "Sucesso",
        description: "Webhook excluído com sucesso!",
      });
      
      onDelete?.();
    } catch (error) {
      console.error('Error deleting webhook:', error);
      toast({
        title: "Erro",
        description: "Erro ao excluir webhook",
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle>{config?.id ? 'Editar Webhook' : 'Novo Webhook'}</CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="space-y-2">
          <Label htmlFor="url">URL de Destino *</Label>
          <Input
            id="url"
            type="url"
            placeholder="https://exemplo.com/webhook"
            value={formData.url}
            onChange={(e) => setFormData(prev => ({ ...prev, url: e.target.value }))}
          />
        </div>

        <div className="space-y-2">
          <Label htmlFor="secret">Token Secreto *</Label>
          <div className="flex gap-2">
            <Input
              id="secret"
              value={formData.secret_token}
              onChange={(e) => setFormData(prev => ({ ...prev, secret_token: e.target.value }))}
              placeholder="Token para validação"
            />
            <Button type="button" variant="outline" onClick={generateSecretToken}>
              Gerar
            </Button>
          </div>
          <p className="text-sm text-gray-500">
            Este token será enviado no header X-LoveMenu-Signature para validação
          </p>
        </div>

        <div className="space-y-3">
          <Label>Eventos</Label>
          {AVAILABLE_EVENTS.map((event) => (
            <div key={event.key} className="flex items-center justify-between p-3 border rounded-lg">
              <div>
                <div className="font-medium">{event.label}</div>
                <div className="text-sm text-gray-500">{event.description}</div>
              </div>
              <Switch
                checked={formData.events[event.key] || false}
                onCheckedChange={(checked) => handleEventToggle(event.key, checked)}
              />
            </div>
          ))}
        </div>

        <div className="flex items-center justify-between">
          <div className="space-y-0.5">
            <Label>Webhook Ativo</Label>
            <p className="text-sm text-gray-500">
              Ativar ou desativar este webhook
            </p>
          </div>
          <Switch
            checked={formData.is_active}
            onCheckedChange={(checked) => setFormData(prev => ({ ...prev, is_active: checked }))}
          />
        </div>

        <div className="flex gap-2 pt-4">
          <Button onClick={handleSave} disabled={loading} className="gradient-brand text-white">
            <Save className="w-4 h-4 mr-2" />
            {loading ? 'Salvando...' : 'Salvar'}
          </Button>
          
          {config?.id && onDelete && (
            <Button onClick={handleDelete} disabled={loading} variant="destructive">
              <Trash2 className="w-4 h-4 mr-2" />
              Excluir
            </Button>
          )}
        </div>
      </CardContent>
    </Card>
  );
};
