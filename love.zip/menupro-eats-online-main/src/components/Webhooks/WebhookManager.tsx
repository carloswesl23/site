
import { useState, useEffect } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { supabase } from "@/integrations/supabase/client";
import { WebhookConfigForm } from "./WebhookConfigForm";
import { WebhookLogViewer } from "./WebhookLogViewer";
import { Plus, Settings, Globe } from "lucide-react";
import type { Database } from "@/integrations/supabase/types";

type WebhookConfigRow = Database['public']['Tables']['webhook_configs']['Row'];

interface WebhookConfig {
  id: string;
  url: string;
  secret_token: string;
  events: Record<string, boolean>;
  is_active: boolean;
  created_at: string;
}

export const WebhookManager = () => {
  const [webhooks, setWebhooks] = useState<WebhookConfig[]>([]);
  const [editingWebhook, setEditingWebhook] = useState<WebhookConfig | null>(null);
  const [showForm, setShowForm] = useState(false);
  const [loading, setLoading] = useState(true);

  const fetchWebhooks = async () => {
    setLoading(true);
    try {
      const { data, error } = await supabase
        .from('webhook_configs')
        .select('*')
        .order('created_at', { ascending: false });

      if (error) throw error;
      
      // Convert database rows to WebhookConfig with proper type casting
      const webhookConfigs: WebhookConfig[] = (data || []).map((row: WebhookConfigRow) => ({
        id: row.id,
        url: row.url,
        secret_token: row.secret_token,
        events: (row.events as Record<string, boolean>) || {},
        is_active: row.is_active,
        created_at: row.created_at,
      }));
      
      setWebhooks(webhookConfigs);
    } catch (error) {
      console.error('Error fetching webhooks:', error);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchWebhooks();
  }, []);

  const handleSave = () => {
    setShowForm(false);
    setEditingWebhook(null);
    fetchWebhooks();
  };

  const handleDelete = () => {
    setShowForm(false);
    setEditingWebhook(null);
    fetchWebhooks();
  };

  const handleEdit = (webhook: WebhookConfig) => {
    setEditingWebhook(webhook);
    setShowForm(true);
  };

  const getActiveEventsCount = (events: Record<string, boolean>) => {
    return Object.values(events).filter(Boolean).length;
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold">Webhooks</h2>
          <p className="text-gray-600">Gerencie suas integrações em tempo real</p>
        </div>
        
        {!showForm && (
          <Button 
            onClick={() => setShowForm(true)} 
            className="gradient-brand text-white"
          >
            <Plus className="w-4 h-4 mr-2" />
            Novo Webhook
          </Button>
        )}
      </div>

      {showForm ? (
        <div className="space-y-4">
          <WebhookConfigForm 
            config={editingWebhook || undefined}
            onSave={handleSave}
            onDelete={editingWebhook ? handleDelete : undefined}
          />
          <Button 
            variant="outline" 
            onClick={() => {
              setShowForm(false);
              setEditingWebhook(null);
            }}
          >
            Cancelar
          </Button>
        </div>
      ) : (
        <>
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Settings className="w-5 h-5" />
                Configurações de Webhook
              </CardTitle>
            </CardHeader>
            <CardContent>
              {loading ? (
                <div className="text-center p-8">Carregando...</div>
              ) : webhooks.length === 0 ? (
                <div className="text-center p-8">
                  <Globe className="w-12 h-12 mx-auto mb-4 text-gray-400" />
                  <h3 className="text-lg font-medium mb-2">Nenhum webhook configurado</h3>
                  <p className="text-gray-500 mb-4">
                    Configure webhooks para receber notificações em tempo real sobre eventos importantes.
                  </p>
                  <Button onClick={() => setShowForm(true)} className="gradient-brand text-white">
                    <Plus className="w-4 h-4 mr-2" />
                    Criar Primeiro Webhook
                  </Button>
                </div>
              ) : (
                <div className="space-y-4">
                  {webhooks.map((webhook) => (
                    <div key={webhook.id} className="border rounded-lg p-4">
                      <div className="flex items-start justify-between">
                        <div className="flex-1">
                          <div className="flex items-center gap-2 mb-2">
                            <h3 className="font-medium">{webhook.url}</h3>
                            <Badge variant={webhook.is_active ? "default" : "secondary"}>
                              {webhook.is_active ? "Ativo" : "Inativo"}
                            </Badge>
                          </div>
                          
                          <div className="text-sm text-gray-500">
                            {getActiveEventsCount(webhook.events)} eventos configurados
                          </div>
                        </div>
                        
                        <Button 
                          variant="outline" 
                          size="sm"
                          onClick={() => handleEdit(webhook)}
                        >
                          Editar
                        </Button>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </CardContent>
          </Card>

          <WebhookLogViewer />
        </>
      )}
    </div>
  );
};
