import React, { Component, ErrorInfo, ReactNode } from 'react';
import { logSuspiciousActivity } from '@/utils/securityMonitoring';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { AlertTriangle, RefreshCw } from 'lucide-react';
import { Button } from '@/components/ui/button';

interface Props {
  children: ReactNode;
  fallback?: ReactNode;
}

interface State {
  hasError: boolean;
  errorId: string;
  retryCount: number;
}

export class SecurityErrorBoundary extends Component<Props, State> {
  private maxRetries = 3;

  constructor(props: Props) {
    super(props);
    this.state = {
      hasError: false,
      errorId: '',
      retryCount: 0
    };
  }

  static getDerivedStateFromError(error: Error): Partial<State> {
    // Generate unique error ID for tracking
    const errorId = `err_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
    
    return {
      hasError: true,
      errorId
    };
  }

  componentDidCatch(error: Error, errorInfo: ErrorInfo) {
    // Log security-relevant errors
    this.logSecurityError(error, errorInfo);
    
    // In development, log full error details
    if (import.meta.env.DEV) {
      console.error('Error Boundary caught an error:', error, errorInfo);
    }
  }

  private logSecurityError(error: Error, errorInfo: ErrorInfo) {
    // Check for potentially suspicious error patterns
    const suspiciousPatterns = [
      /eval\(/i,
      /document\.write/i,
      /innerHTML\s*=/i,
      /script.*src/i,
      /javascript:/i,
      /data:text\/html/i
    ];

    const errorString = `${error.message} ${error.stack} ${errorInfo.componentStack}`;
    const isSuspicious = suspiciousPatterns.some(pattern => pattern.test(errorString));

    if (isSuspicious) {
      logSuspiciousActivity('suspicious_error_pattern', {
        error: this.sanitizeErrorMessage(error.message),
        component: errorInfo.componentStack.split('\n')[1]?.trim(),
        errorId: this.state.errorId,
        userAgent: navigator.userAgent
      });
    }

    // Track excessive errors from same component
    if (this.state.retryCount > this.maxRetries) {
      logSuspiciousActivity('excessive_component_errors', {
        errorId: this.state.errorId,
        retryCount: this.state.retryCount,
        component: errorInfo.componentStack.split('\n')[1]?.trim()
      });
    }
  }

  private sanitizeErrorMessage(message: string): string {
    // Remove potentially sensitive information from error messages
    return message
      .replace(/\b[\w\.-]+@[\w\.-]+\.\w+\b/g, '[EMAIL]')
      .replace(/\b(?:\d{1,3}\.){3}\d{1,3}\b/g, '[IP]')
      .replace(/[a-zA-Z0-9]{20,}/g, '[TOKEN]')
      .substring(0, 200); // Limit length
  }

  private handleRetry = () => {
    if (this.state.retryCount < this.maxRetries) {
      this.setState(prevState => ({
        hasError: false,
        retryCount: prevState.retryCount + 1
      }));
    } else {
      // Redirect to safe page after max retries
      window.location.href = '/';
    }
  };

  private handleReportIssue = () => {
    // In production, this could send to support system
    const reportData = {
      errorId: this.state.errorId,
      timestamp: new Date().toISOString(),
      userAgent: navigator.userAgent,
      path: window.location.pathname
    };

    if (import.meta.env.DEV) {
      console.log('Error report:', reportData);
    }
    
    // Copy error ID to clipboard for user reference
    navigator.clipboard?.writeText(this.state.errorId);
  };

  render() {
    if (this.state.hasError) {
      if (this.props.fallback) {
        return this.props.fallback;
      }

      return (
        <div className="min-h-screen flex items-center justify-center p-4 bg-background">
          <Card className="w-full max-w-md">
            <CardHeader className="text-center">
              <div className="flex justify-center mb-4">
                <AlertTriangle className="w-12 h-12 text-destructive" />
              </div>
              <CardTitle className="text-xl">Oops! Algo deu errado</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <p className="text-sm text-muted-foreground text-center">
                Ocorreu um erro inesperado. Nossa equipe foi notificada automaticamente.
              </p>
              
              <div className="text-xs text-muted-foreground text-center">
                ID do erro: {this.state.errorId}
              </div>

              <div className="flex flex-col gap-2">
                {this.state.retryCount < this.maxRetries ? (
                  <Button 
                    onClick={this.handleRetry}
                    className="w-full"
                    variant="default"
                  >
                    <RefreshCw className="w-4 h-4 mr-2" />
                    Tentar novamente ({this.maxRetries - this.state.retryCount} tentativas restantes)
                  </Button>
                ) : (
                  <Button 
                    onClick={() => window.location.href = '/'}
                    className="w-full"
                    variant="default"
                  >
                    Voltar ao início
                  </Button>
                )}
                
                <Button 
                  onClick={this.handleReportIssue}
                  variant="outline"
                  className="w-full"
                >
                  Reportar problema
                </Button>
              </div>

              {import.meta.env.DEV && (
                <details className="text-xs">
                  <summary className="cursor-pointer text-muted-foreground">
                    Detalhes técnicos (apenas desenvolvimento)
                  </summary>
                  <pre className="mt-2 p-2 bg-muted rounded text-xs overflow-auto">
                    Retry count: {this.state.retryCount}
                  </pre>
                </details>
              )}
            </CardContent>
          </Card>
        </div>
      );
    }

    return this.props.children;
  }
}