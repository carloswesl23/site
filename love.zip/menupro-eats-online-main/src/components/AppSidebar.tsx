
import { Calendar, Home, Package, ShoppingCart, Users, Settings, BarChart3, TrendingUp, Tag, MessageSquare, Truck } from "lucide-react";
import {
  Sidebar,
  SidebarContent,
  SidebarGroup,
  SidebarGroupContent,
  SidebarGroupLabel,
  SidebarMenu,
  SidebarMenuButton,
  SidebarMenuItem,
  SidebarHeader,
  SidebarFooter,
} from "@/components/ui/sidebar";
import { Link, useLocation } from "react-router-dom";
import { Heart } from "lucide-react";

const items = [
  {
    title: "Dashboard",
    url: "/dashboard",
    icon: Home,
  },
  {
    title: "Produtos",
    url: "/products",
    icon: Package,
  },
  {
    title: "Upsell",
    url: "/upsell",
    icon: TrendingUp,
  },
  {
    title: "Cupons",
    url: "/coupons",
    icon: Tag,
  },
  {
    title: "Pedidos",
    url: "/orders",
    icon: ShoppingCart,
  },
  {
    title: "Clientes",
    url: "/customers",
    icon: Users,
  },
    {
      title: "Motoboys",
      url: "/motoboys",
      icon: Truck,
    },
  {
    title: "WhatsApp",
    url: "/whatsapp",
    icon: MessageSquare,
  },
  // {
  //   title: "WhatsApp 2.0",
  //   url: "/whatsapp-v2",
  //   icon: MessageSquare,
  // },
  {
    title: "Relatórios",
    url: "/reports",
    icon: BarChart3,
  },
  {
    title: "Configurações",
    url: "/settings",
    icon: Settings,
  },
];

export function AppSidebar() {
  const location = useLocation();
  const currentPath = location.pathname;

  const isActive = (path: string) => currentPath === path;

  return (
    <Sidebar className="border-r border-gray-200">
      <SidebarHeader className="border-b border-gray-200 p-6">
        <div className="flex items-center space-x-2">
          <div className="w-8 h-8 gradient-brand rounded-lg flex items-center justify-center">
            <Heart className="text-white font-bold text-sm w-4 h-4" />
          </div>
          <h1 className="text-xl font-bold text-brand-dark">LoveMenu</h1>
        </div>
      </SidebarHeader>
      
      <SidebarContent>
        <SidebarGroup>
          <SidebarGroupLabel className="text-gray-500 font-medium">Menu Principal</SidebarGroupLabel>
          <SidebarGroupContent>
            <SidebarMenu>
              {items.map((item) => (
                <SidebarMenuItem key={item.title}>
                  <SidebarMenuButton 
                    asChild 
                    className={`hover:bg-brand-orange hover:text-white transition-colors ${
                      isActive(item.url) ? 'bg-brand-orange text-white' : ''
                    }`}
                  >
                    <Link to={item.url}>
                      <item.icon className="w-4 h-4" />
                      <span>{item.title}</span>
                    </Link>
                  </SidebarMenuButton>
                </SidebarMenuItem>
              ))}
            </SidebarMenu>
          </SidebarGroupContent>
        </SidebarGroup>
      </SidebarContent>
      
      <SidebarFooter className="border-t border-gray-200 p-4">
        <div className="flex items-center space-x-3">
          <div className="w-8 h-8 bg-brand-orange rounded-full flex items-center justify-center">
            <span className="text-white text-sm font-medium">R</span>
          </div>
          <div className="flex-1 min-w-0">
            <p className="text-sm font-medium text-gray-900 truncate">Restaurante Demo</p>
            <p className="text-xs text-gray-500 truncate">admin@demo.com</p>
          </div>
        </div>
      </SidebarFooter>
    </Sidebar>
  );
}
