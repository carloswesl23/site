import { useState, useEffect } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { BarChart3, Users, ShoppingCart, TrendingUp, Percent } from "lucide-react";
import { useCoupons } from "@/hooks/useCoupons";

interface CouponStatsModalProps {
  coupon: any;
  isOpen: boolean;
  onClose: () => void;
}

export const CouponStatsModal = ({ coupon, isOpen, onClose }: CouponStatsModalProps) => {
  const { getCouponStats } = useCoupons();
  const [stats, setStats] = useState<any>(null);
  const [isLoading, setIsLoading] = useState(false);

  useEffect(() => {
    if (coupon && isOpen) {
      loadStats();
    }
  }, [coupon, isOpen]);

  const loadStats = async () => {
    setIsLoading(true);
    try {
      const data = await getCouponStats(coupon.id);
      setStats(data);
    } catch (error) {
      console.error('Erro ao carregar estatísticas:', error);
    } finally {
      setIsLoading(false);
    }
  };

  const formatCurrency = (value: number) => {
    return new Intl.NumberFormat('pt-BR', {
      style: 'currency',
      currency: 'BRL'
    }).format(value);
  };

  const calculateConversionRate = () => {
    if (!stats || stats.total_orders === 0) return 0;
    // Assuming we have some way to track total visits or a baseline
    return ((stats.total_orders / coupon.current_uses) * 100).toFixed(1);
  };

  const formatDiscountValue = (type: string, value: number) => {
    return type === 'percentage' ? `${value}%` : formatCurrency(value);
  };

  if (!coupon) return null;

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-2xl">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <BarChart3 className="w-5 h-5" />
            Estatísticas - {coupon.code}
          </DialogTitle>
        </DialogHeader>

        <div className="space-y-4">
          {/* Informações do Cupom */}
          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="text-lg flex items-center justify-between">
                {coupon.name}
                <Badge variant={coupon.is_active ? "default" : "secondary"}>
                  {coupon.is_active ? "Ativo" : "Inativo"}
                </Badge>
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-3 gap-4 text-sm">
                <div>
                  <p className="text-muted-foreground">Desconto</p>
                  <p className="font-medium text-lg">
                    {formatDiscountValue(coupon.discount_type, coupon.discount_value)}
                  </p>
                </div>
                <div>
                  <p className="text-muted-foreground">Limite de Uso</p>
                  <p className="font-medium text-lg">
                    {coupon.max_uses ? `${coupon.current_uses} / ${coupon.max_uses}` : 'Ilimitado'}
                  </p>
                </div>
                <div>
                  <p className="text-muted-foreground">Aplicação</p>
                  <p className="font-medium text-lg">
                    {coupon.auto_apply ? 'Automática' : 'Manual'}
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Métricas */}
          {isLoading ? (
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
              {[1, 2, 3, 4].map((i) => (
                <Card key={i} className="animate-pulse">
                  <CardContent className="p-4">
                    <div className="space-y-2">
                      <div className="h-4 bg-muted rounded w-1/2"></div>
                      <div className="h-6 bg-muted rounded w-3/4"></div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          ) : stats ? (
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
              <Card>
                <CardContent className="p-4">
                  <div className="flex items-center space-x-2">
                    <ShoppingCart className="w-4 h-4 text-primary" />
                    <div>
                      <p className="text-xs text-muted-foreground">Total de Pedidos</p>
                      <p className="text-xl font-bold">{stats.total_orders}</p>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardContent className="p-4">
                  <div className="flex items-center space-x-2">
                    <TrendingUp className="w-4 h-4 text-green-600" />
                    <div>
                      <p className="text-xs text-muted-foreground">Vendas Geradas</p>
                      <p className="text-xl font-bold">{formatCurrency(stats.total_sales)}</p>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardContent className="p-4">
                  <div className="flex items-center space-x-2">
                    <Users className="w-4 h-4 text-blue-600" />
                    <div>
                      <p className="text-xs text-muted-foreground">Clientes Únicos</p>
                      <p className="text-xl font-bold">{stats.unique_customers}</p>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardContent className="p-4">
                  <div className="flex items-center space-x-2">
                    <Percent className="w-4 h-4 text-orange-600" />
                    <div>
                      <p className="text-xs text-muted-foreground">Desconto Total</p>
                      <p className="text-xl font-bold">{formatCurrency(stats.total_discount_given)}</p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          ) : (
            <Card>
              <CardContent className="flex items-center justify-center py-8">
                <div className="text-center">
                  <BarChart3 className="w-12 h-12 text-muted-foreground mx-auto mb-2" />
                  <p className="text-muted-foreground">Nenhum dado encontrado</p>
                  <p className="text-sm text-muted-foreground">
                    Este cupom ainda não foi utilizado
                  </p>
                </div>
              </CardContent>
            </Card>
          )}

          {/* Informações Adicionais */}
          {stats && stats.total_orders > 0 && (
            <Card>
              <CardHeader>
                <CardTitle className="text-base">Resumo do Desempenho</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-2 gap-4 text-sm">
                  <div>
                    <p className="text-muted-foreground">Ticket Médio</p>
                    <p className="font-medium">
                      {formatCurrency(stats.total_sales / stats.total_orders)}
                    </p>
                  </div>
                  <div>
                    <p className="text-muted-foreground">Desconto Médio</p>
                    <p className="font-medium">
                      {formatCurrency(stats.total_discount_given / stats.total_orders)}
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>
          )}
        </div>
      </DialogContent>
    </Dialog>
  );
};