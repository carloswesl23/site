import { useState, useEffect } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Switch } from "@/components/ui/switch";
import { Checkbox } from "@/components/ui/checkbox";
import { useCoupons } from "@/hooks/useCoupons";
import { supabase } from "@/integrations/supabase/client";

interface CouponModalProps {
  isOpen: boolean;
  onClose: () => void;
  coupon?: any;
}

export const CouponModal = ({ isOpen, onClose, coupon }: CouponModalProps) => {
  const { createCoupon, updateCoupon } = useCoupons();
  const [isLoading, setIsLoading] = useState(false);
  const [categories, setCategories] = useState<any[]>([]);
  const [products, setProducts] = useState<any[]>([]);
  
  const [formData, setFormData] = useState({
    code: "",
    name: "",
    discount_type: "percentage" as "percentage" | "fixed",
    discount_value: 0,
    is_active: true,
    auto_apply: false,
    max_uses: "",
    valid_from: "",
    valid_until: "",
    applies_to_type: "all",
    applies_to_categories: [] as string[],
    applies_to_products: [] as string[]
  });

  // Carregar categorias e produtos do usuário
  useEffect(() => {
    const loadUserData = async () => {
      try {
        const { data: { user } } = await supabase.auth.getUser();
        if (!user) return;

        // Carregar categorias
        const { data: categoriesData } = await supabase
          .from('user_categories')
          .select('*')
          .eq('user_id', user.id)
          .order('sort_order');

        if (categoriesData) setCategories(categoriesData);

        // Carregar produtos
        const { data: productsData } = await supabase
          .from('user_products')
          .select('id, name, category')
          .eq('user_id', user.id)
          .order('name');

        if (productsData) setProducts(productsData);
      } catch (error) {
        console.error('Erro ao carregar dados:', error);
      }
    };

    if (isOpen) {
      loadUserData();
    }
  }, [isOpen]);

  useEffect(() => {
    if (coupon) {
      console.log('📅 Carregando cupom para edição:', {
        valid_from: coupon.valid_from,
        valid_until: coupon.valid_until,
      });

      // Converter as datas UTC para o formato local do input (YYYY-MM-DDTHH:MM)
      let formattedValidFrom = "";
      let formattedValidUntil = "";
      
      if (coupon.valid_from) {
        const fromDate = new Date(coupon.valid_from);
        // Ajustar para o horário local sem conflito de fuso
        const year = fromDate.getFullYear();
        const month = String(fromDate.getMonth() + 1).padStart(2, '0');
        const day = String(fromDate.getDate()).padStart(2, '0');
        const hours = String(fromDate.getHours()).padStart(2, '0');
        const minutes = String(fromDate.getMinutes()).padStart(2, '0');
        formattedValidFrom = `${year}-${month}-${day}T${hours}:${minutes}`;
      }
      
      if (coupon.valid_until) {
        const untilDate = new Date(coupon.valid_until);
        // Ajustar para o horário local sem conflito de fuso
        const year = untilDate.getFullYear();
        const month = String(untilDate.getMonth() + 1).padStart(2, '0');
        const day = String(untilDate.getDate()).padStart(2, '0');
        const hours = String(untilDate.getHours()).padStart(2, '0');
        const minutes = String(untilDate.getMinutes()).padStart(2, '0');
        formattedValidUntil = `${year}-${month}-${day}T${hours}:${minutes}`;
      }

      setFormData({
        code: coupon.code,
        name: coupon.name,
        discount_type: coupon.discount_type,
        discount_value: coupon.discount_value,
        is_active: coupon.is_active,
        auto_apply: coupon.auto_apply,
        max_uses: coupon.max_uses?.toString() || "",
        valid_from: formattedValidFrom,
        valid_until: formattedValidUntil,
        applies_to_type: coupon.applies_to_type || "all",
        applies_to_categories: coupon.applies_to_categories || [],
        applies_to_products: coupon.applies_to_products || []
      });
    } else {
      setFormData({
        code: "",
        name: "",
        discount_type: "percentage",
        discount_value: 0,
        is_active: true,
        auto_apply: false,
        max_uses: "",
        valid_from: "",
        valid_until: "",
        applies_to_type: "all",
        applies_to_categories: [],
        applies_to_products: []
      });
    }
  }, [coupon, isOpen]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);

    try {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) throw new Error('User not authenticated');

      // Processar as datas de início e fim corretamente
      let validFromDate = null;
      let validUntilDate = null;
      
      if (formData.valid_from) {
        // Converter data local para UTC mantendo o horário correto
        const localDate = new Date(formData.valid_from);
        validFromDate = localDate.toISOString();
      }
      
      if (formData.valid_until) {
        // Converter data local para UTC mantendo o horário correto
        const localDate = new Date(formData.valid_until);
        validUntilDate = localDate.toISOString();
      }
        
      console.log('📅 Processando datas do cupom:', {
        valid_from_input: formData.valid_from,
        valid_until_input: formData.valid_until,
        valid_from_iso: validFromDate,
        valid_until_iso: validUntilDate
      });

      const couponData = {
        ...formData,
        code: formData.code.toUpperCase(),
        max_uses: formData.max_uses ? parseInt(formData.max_uses) : null,
        valid_from: validFromDate || new Date().toISOString(),
        valid_until: validUntilDate,
        user_id: user.id
      };

      console.log('💾 Salvando cupom com dados:', {
        ...couponData,
        valid_from_formatted: validFromDate ? new Date(validFromDate).toLocaleString() : null,
        valid_until_formatted: validUntilDate ? new Date(validUntilDate).toLocaleString() : null
      });

      if (coupon) {
        await updateCoupon(coupon.id, couponData);
      } else {
        await createCoupon(couponData);
      }

      onClose();
    } catch (error) {
      // Error handling is done in the hook
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-md">
        <DialogHeader>
          <DialogTitle>
            {coupon ? 'Editar Cupom' : 'Novo Cupom'}
          </DialogTitle>
        </DialogHeader>

        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="code">Código do Cupom</Label>
              <Input
                id="code"
                type="text"
                value={formData.code}
                onChange={(e) => setFormData(prev => ({ 
                  ...prev, 
                  code: e.target.value.toUpperCase().replace(/[^A-Z0-9]/g, '')
                }))}
                placeholder="PROMO10"
                maxLength={20}
                required
                className="uppercase"
              />
            </div>
            
            <div className="space-y-2">
              <Label htmlFor="discount_type">Tipo de Desconto</Label>
              <Select
                value={formData.discount_type}
                onValueChange={(value: "percentage" | "fixed") => 
                  setFormData(prev => ({ ...prev, discount_type: value }))
                }
              >
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="percentage">Percentual (%)</SelectItem>
                  <SelectItem value="fixed">Valor Fixo (R$)</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>

          <div className="space-y-2">
            <Label htmlFor="name">Nome do Cupom</Label>
            <Input
              id="name"
              type="text"
              value={formData.name}
              onChange={(e) => setFormData(prev => ({ ...prev, name: e.target.value }))}
              placeholder="Promoção de 10% de desconto"
              required
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="discount_value">
              Valor do Desconto {formData.discount_type === 'percentage' ? '(%)' : '(R$)'}
            </Label>
            <Input
              id="discount_value"
              type="number"
              min="0"
              max={formData.discount_type === 'percentage' ? "100" : undefined}
              step={formData.discount_type === 'percentage' ? "1" : "0.01"}
              value={formData.discount_value}
              onChange={(e) => setFormData(prev => ({ 
                ...prev, 
                discount_value: parseFloat(e.target.value) || 0 
              }))}
              required
            />
          </div>

          <div className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="max_uses">Limite de Uso</Label>
              <Input
                id="max_uses"
                type="number"
                min="1"
                value={formData.max_uses}
                onChange={(e) => setFormData(prev => ({ ...prev, max_uses: e.target.value }))}
                placeholder="Ilimitado"
              />
            </div>
            
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="valid_from">Data/Hora de Início</Label>
                <Input
                  id="valid_from"
                  type="datetime-local"
                  value={formData.valid_from}
                  onChange={(e) => setFormData(prev => ({ ...prev, valid_from: e.target.value }))}
                  min={(() => {
                    const now = new Date();
                    // Ajustar para o fuso horário local (Brasília GMT-3)
                    now.setMinutes(now.getMinutes() - now.getTimezoneOffset());
                    return now.toISOString().slice(0, 16);
                  })()}
                />
              </div>
              
              <div className="space-y-2">
                <Label htmlFor="valid_until">Data/Hora de Fim</Label>
                <Input
                  id="valid_until"
                  type="datetime-local"
                  value={formData.valid_until}
                  onChange={(e) => setFormData(prev => ({ ...prev, valid_until: e.target.value }))}
                  min={formData.valid_from || (() => {
                    const now = new Date();
                    now.setMinutes(now.getMinutes() - now.getTimezoneOffset());
                    return now.toISOString().slice(0, 16);
                  })()}
                />
              </div>
            </div>
          </div>

          {/* Seção de Aplicação */}
          <div className="space-y-4 border-t pt-4">
            <div className="space-y-2">
              <Label>Aplicar Cupom Em:</Label>
              <Select
                value={formData.applies_to_type}
                onValueChange={(value) => 
                  setFormData(prev => ({ 
                    ...prev, 
                    applies_to_type: value,
                    applies_to_categories: [],
                    applies_to_products: []
                  }))
                }
              >
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">Todos os produtos</SelectItem>
                  <SelectItem value="categories">Categorias específicas</SelectItem>
                  <SelectItem value="products">Produtos específicos</SelectItem>
                </SelectContent>
              </Select>
            </div>

            {formData.applies_to_type === 'categories' && categories.length > 0 && (
              <div className="space-y-2">
                <Label className="text-sm">Selecionar Categorias:</Label>
                <div className="space-y-2 max-h-32 overflow-y-auto border rounded p-2">
                  {categories.map((category) => (
                    <div key={category.id} className="flex items-center space-x-2">
                      <Checkbox
                        id={`cat-${category.id}`}
                        checked={formData.applies_to_categories.includes(category.name)}
                        onCheckedChange={(checked) => {
                          if (checked) {
                            setFormData(prev => ({
                              ...prev,
                              applies_to_categories: [...prev.applies_to_categories, category.name]
                            }));
                          } else {
                            setFormData(prev => ({
                              ...prev,
                              applies_to_categories: prev.applies_to_categories.filter(c => c !== category.name)
                            }));
                          }
                        }}
                      />
                      <Label htmlFor={`cat-${category.id}`} className="text-sm">
                        {category.name}
                      </Label>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {formData.applies_to_type === 'products' && products.length > 0 && (
              <div className="space-y-2">
                <Label className="text-sm">Selecionar Produtos:</Label>
                <div className="space-y-2 max-h-32 overflow-y-auto border rounded p-2">
                  {products.map((product) => (
                    <div key={product.id} className="flex items-center space-x-2">
                      <Checkbox
                        id={`prod-${product.id}`}
                        checked={formData.applies_to_products.includes(product.id)}
                        onCheckedChange={(checked) => {
                          if (checked) {
                            setFormData(prev => ({
                              ...prev,
                              applies_to_products: [...prev.applies_to_products, product.id]
                            }));
                          } else {
                            setFormData(prev => ({
                              ...prev,
                              applies_to_products: prev.applies_to_products.filter(p => p !== product.id)
                            }));
                          }
                        }}
                      />
                      <Label htmlFor={`prod-${product.id}`} className="text-sm">
                        {product.name} 
                        <span className="text-xs text-muted-foreground ml-1">({product.category})</span>
                      </Label>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>

          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <div className="space-y-1">
                <Label>Cupom Ativo</Label>
                <p className="text-xs text-muted-foreground">
                  Permite que o cupom seja usado
                </p>
              </div>
              <Switch
                checked={formData.is_active}
                onCheckedChange={(checked) => 
                  setFormData(prev => ({ ...prev, is_active: checked }))
                }
              />
            </div>

            <div className="flex items-center justify-between">
              <div className="space-y-1">
                <Label>Aplicação Automática</Label>
                <p className="text-xs text-muted-foreground">
                  Aplica automaticamente no checkout
                </p>
              </div>
              <Switch
                checked={formData.auto_apply}
                onCheckedChange={(checked) => 
                  setFormData(prev => ({ ...prev, auto_apply: checked }))
                }
              />
            </div>
          </div>

          <div className="flex gap-2 pt-4">
            <Button
              type="button"
              variant="outline"
              onClick={onClose}
              className="flex-1"
              disabled={isLoading}
            >
              Cancelar
            </Button>
            <Button
              type="submit"
              className="flex-1"
              disabled={isLoading}
            >
              {isLoading ? 'Salvando...' : coupon ? 'Atualizar' : 'Criar Cupom'}
            </Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  );
};