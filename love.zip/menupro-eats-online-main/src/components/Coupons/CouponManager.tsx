import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Plus, Edit, Trash2, BarChart3, Eye, EyeOff } from "lucide-react";
import { useCoupons } from "@/hooks/useCoupons";
import { CouponModal } from "./CouponModal";
import { CouponStatsModal } from "./CouponStatsModal";

export const CouponManager = () => {
  const { coupons, isLoading, updateCoupon, deleteCoupon } = useCoupons();
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingCoupon, setEditingCoupon] = useState<any>(null);
  const [statsModalCoupon, setStatsModalCoupon] = useState<any>(null);

  const handleEdit = (coupon: any) => {
    setEditingCoupon(coupon);
    setIsModalOpen(true);
  };

  const handleCreate = () => {
    setEditingCoupon(null);
    setIsModalOpen(true);
  };

  const toggleCouponStatus = async (id: string, currentStatus: boolean) => {
    await updateCoupon(id, { is_active: !currentStatus });
  };

  const formatDiscountValue = (type: string, value: number) => {
    return type === 'percentage' ? `${value}%` : `R$ ${value.toFixed(2)}`;
  };

  const getStatusBadge = (coupon: any) => {
    if (!coupon.is_active) {
      return <Badge variant="secondary">Inativo</Badge>;
    }
    
    if (coupon.valid_until && new Date(coupon.valid_until) < new Date()) {
      return <Badge variant="destructive">Expirado</Badge>;
    }
    
    if (coupon.max_uses && coupon.current_uses >= coupon.max_uses) {
      return <Badge variant="destructive">Esgotado</Badge>;
    }
    
    return <Badge variant="default" className="bg-green-600">Ativo</Badge>;
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold">Cupons de Desconto</h1>
          <p className="text-muted-foreground">
            Gerencie os cupons de desconto do seu estabelecimento
          </p>
        </div>
        <Button onClick={handleCreate} className="gap-2">
          <Plus className="w-4 h-4" />
          Novo Cupom
        </Button>
      </div>

      {isLoading ? (
        <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
          {[1, 2, 3].map((i) => (
            <Card key={i} className="animate-pulse">
              <CardHeader className="space-y-2">
                <div className="h-4 bg-muted rounded w-1/2"></div>
                <div className="h-3 bg-muted rounded w-3/4"></div>
              </CardHeader>
              <CardContent>
                <div className="space-y-2">
                  <div className="h-3 bg-muted rounded"></div>
                  <div className="h-3 bg-muted rounded w-2/3"></div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      ) : coupons.length === 0 ? (
        <Card>
          <CardContent className="flex flex-col items-center justify-center py-12">
            <div className="text-center space-y-2">
              <h3 className="text-lg font-medium">Nenhum cupom criado</h3>
              <p className="text-muted-foreground">
                Crie seu primeiro cupom de desconto para aumentar as vendas
              </p>
              <Button onClick={handleCreate} className="mt-4 gap-2">
                <Plus className="w-4 h-4" />
                Criar Primeiro Cupom
              </Button>
            </div>
          </CardContent>
        </Card>
      ) : (
        <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
          {coupons.map((coupon) => (
            <Card key={coupon.id} className="relative">
              <CardHeader className="pb-3">
                <div className="flex items-start justify-between">
                  <div>
                    <CardTitle className="text-lg font-bold text-primary">
                      {coupon.code}
                    </CardTitle>
                    <p className="text-sm text-muted-foreground mt-1">
                      {coupon.name}
                    </p>
                  </div>
                  {getStatusBadge(coupon)}
                </div>
              </CardHeader>
              
              <CardContent className="space-y-4">
                <div className="grid grid-cols-2 gap-4 text-sm">
                  <div>
                    <p className="text-muted-foreground">Desconto</p>
                    <p className="font-medium">
                      {formatDiscountValue(coupon.discount_type, coupon.discount_value)}
                    </p>
                  </div>
                  <div>
                    <p className="text-muted-foreground">Usado</p>
                    <p className="font-medium">
                      {coupon.current_uses}
                      {coupon.max_uses && ` / ${coupon.max_uses}`}
                    </p>
                  </div>
                </div>

                {coupon.auto_apply && (
                  <Badge variant="outline" className="w-fit">
                    Aplicação Automática
                  </Badge>
                )}

                {coupon.valid_until && (
                  <div className="text-xs text-muted-foreground">
                    Válido até: {new Date(coupon.valid_until).toLocaleDateString('pt-BR')}
                  </div>
                )}

                <div className="flex gap-2 pt-2">
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => toggleCouponStatus(coupon.id, coupon.is_active)}
                    className="flex-1 gap-1"
                  >
                    {coupon.is_active ? (
                      <>
                        <EyeOff className="w-3 h-3" />
                        Desativar
                      </>
                    ) : (
                      <>
                        <Eye className="w-3 h-3" />
                        Ativar
                      </>
                    )}
                  </Button>
                  
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => setStatsModalCoupon(coupon)}
                    className="gap-1"
                  >
                    <BarChart3 className="w-3 h-3" />
                  </Button>
                  
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => handleEdit(coupon)}
                    className="gap-1"
                  >
                    <Edit className="w-3 h-3" />
                  </Button>
                  
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => deleteCoupon(coupon.id)}
                    className="gap-1 text-red-600 hover:text-red-700"
                  >
                    <Trash2 className="w-3 h-3" />
                  </Button>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      )}

      <CouponModal
        isOpen={isModalOpen}
        onClose={() => {
          setIsModalOpen(false);
          setEditingCoupon(null);
        }}
        coupon={editingCoupon}
      />

      <CouponStatsModal
        coupon={statsModalCoupon}
        isOpen={!!statsModalCoupon}
        onClose={() => setStatsModalCoupon(null)}
      />
    </div>
  );
};