import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Switch } from "@/components/ui/switch";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";

interface DeliveryDriver {
  id: string;
  name: string;
  phone_e164: string;
  active: boolean;
  created_at: string;
}

interface DeliveryDriverModalProps {
  isOpen: boolean;
  onClose: () => void;
  driver?: DeliveryDriver | null;
}

export function DeliveryDriverModal({ isOpen, onClose, driver }: DeliveryDriverModalProps) {
  const [formData, setFormData] = useState({
    name: '',
    phone: '',
    employment_type: 'fixo' as 'fixo' | 'terceirizado',
    is_default: false,
    is_active: true
  });

  const queryClient = useQueryClient();

  useEffect(() => {
    if (driver) {
      setFormData({
        name: driver.name,
        phone: driver.phone_e164,
        employment_type: 'fixo',
        is_default: false,
        is_active: driver.active
      });
    } else {
      setFormData({
        name: '',
        phone: '',
        employment_type: 'fixo',
        is_default: false,
        is_active: true
      });
    }
  }, [driver, isOpen]);

  const saveMutation = useMutation({
    mutationFn: async () => {
      const { data: user } = await supabase.auth.getUser();
      if (!user.user) throw new Error('User not authenticated');

      // Normalizar telefone para E.164
      let normalizedPhone = formData.phone.replace(/\D/g, '');
      if (!normalizedPhone.startsWith('55')) {
        normalizedPhone = `55${normalizedPhone}`;
      }
      if (!normalizedPhone.startsWith('+')) {
        normalizedPhone = `+${normalizedPhone}`;
      }

      const payload = {
        user_id: user.user.id,
        name: formData.name.trim(),
        phone_e164: normalizedPhone,
        active: formData.is_active
      };

      if (driver) {
        const { error } = await supabase
          .from('motoboys')
          .update(payload)
          .eq('id', driver.id);
        
        if (error) throw error;
      } else {
        const { error } = await supabase
          .from('motoboys')
          .insert(payload);
        
        if (error) throw error;
      }
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['motoboys'] });
      toast.success(driver ? 'Motoboy atualizado!' : 'Motoboy cadastrado!');
      onClose();
    },
    onError: (error) => {
      console.error('Error saving driver:', error);
      toast.error('Erro ao salvar entregador');
    }
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!formData.name.trim()) {
      toast.error('Nome é obrigatório');
      return;
    }
    
    if (!formData.phone.trim()) {
      toast.error('Telefone é obrigatório');
      return;
    }

    saveMutation.mutate();
  };

  const formatPhoneInput = (value: string) => {
    // Remove tudo que não é dígito
    const digits = value.replace(/\D/g, '');
    
    // Aplica formatação brasileira
    if (digits.length <= 2) {
      return `(${digits}`;
    } else if (digits.length <= 7) {
      return `(${digits.slice(0, 2)}) ${digits.slice(2)}`;
    } else {
      return `(${digits.slice(0, 2)}) ${digits.slice(2, 7)}-${digits.slice(7, 11)}`;
    }
  };

  const handlePhoneChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const formatted = formatPhoneInput(e.target.value);
    setFormData(prev => ({ ...prev, phone: formatted }));
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle>
            {driver ? 'Editar Entregador' : 'Novo Entregador'}
          </DialogTitle>
        </DialogHeader>

        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="name">Nome *</Label>
            <Input
              id="name"
              value={formData.name}
              onChange={(e) => setFormData(prev => ({ ...prev, name: e.target.value }))}
              placeholder="Nome completo do entregador"
              required
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="phone">WhatsApp *</Label>
            <Input
              id="phone"
              value={formData.phone}
              onChange={handlePhoneChange}
              placeholder="(00) 00000-0000"
              required
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="employment_type">Tipo</Label>
            <Select
              value={formData.employment_type}
              onValueChange={(value: 'fixo' | 'terceirizado') => 
                setFormData(prev => ({ ...prev, employment_type: value }))
              }
            >
              <SelectTrigger>
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="fixo">Fixo</SelectItem>
                <SelectItem value="terceirizado">Terceirizado</SelectItem>
              </SelectContent>
            </Select>
          </div>

          <div className="flex items-center justify-between">
            <Label htmlFor="is_default">Entregador padrão</Label>
            <Switch
              id="is_default"
              checked={formData.is_default}
              onCheckedChange={(checked) => 
                setFormData(prev => ({ ...prev, is_default: checked }))
              }
            />
          </div>

          <div className="flex items-center justify-between">
            <Label htmlFor="is_active">Ativo</Label>
            <Switch
              id="is_active"
              checked={formData.is_active}
              onCheckedChange={(checked) => 
                setFormData(prev => ({ ...prev, is_active: checked }))
              }
            />
          </div>

          <div className="flex gap-2 pt-4">
            <Button type="button" variant="outline" onClick={onClose} className="flex-1">
              Cancelar
            </Button>
            <Button 
              type="submit" 
              className="flex-1"
              disabled={saveMutation.isPending}
            >
              {saveMutation.isPending ? 'Salvando...' : (driver ? 'Atualizar' : 'Cadastrar')}
            </Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  );
}