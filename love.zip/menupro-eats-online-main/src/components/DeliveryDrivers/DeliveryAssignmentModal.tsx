import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Textarea } from "@/components/ui/textarea";
import { Input } from "@/components/ui/input";
import { Search, Truck, Phone, Plus } from "lucide-react";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";
import { Link } from "react-router-dom";

interface Motoboy {
  id: string;
  name: string;
  phone_e164: string;
  active: boolean;
  vehicle_type?: string;
  notes?: string;
}

interface Order {
  id: string;
  order_number: string;
  customer_name: string;
  customer_phone: string;
  delivery_address: string;
  total: number;
  payment_method: string;
  items: any[];
}

interface DeliveryAssignmentModalProps {
  isOpen: boolean;
  onClose: () => void;
  order: Order | null;
  onDeliveryAssigned?: (driverName: string) => void;
  onSkipDriver?: () => void;
}

export function DeliveryAssignmentModal({ isOpen, onClose, order, onDeliveryAssigned, onSkipDriver }: DeliveryAssignmentModalProps) {
  const [selectedDriverId, setSelectedDriverId] = useState('');
  const [notes, setNotes] = useState('');
  const [searchTerm, setSearchTerm] = useState('');
  const queryClient = useQueryClient();

  // Buscar motoboys ativos da nova tabela
  const { data: motoboys, isLoading, error } = useQuery({
    queryKey: ['motoboys-active', isOpen],
    queryFn: async () => {
      console.log('🔍 Buscando motoboys ativos...');
      
      const { data: { user } } = await supabase.auth.getUser();
      let userId: string | null = null;
      
      // Em desenvolvimento, usar user_id fixo
      const isDevelopment = window.location.hostname === 'localhost' || window.location.hostname.includes('lovable.app');
      
      if (isDevelopment) {
        userId = 'd9fe8eb8-8c97-49db-8df6-cc0d64bace0d';
        console.log('🔧 Ambiente de desenvolvimento - usando user_id fixo:', userId);
      } else {
        if (!user) {
          console.error('❌ Usuário não autenticado');
          throw new Error('User not authenticated');
        }
        userId = user.id;
        console.log('👤 User ID atual:', userId);
      }

      const { data, error } = await supabase
        .from('motoboys')
        .select('*')
        .eq('user_id', userId)
        .eq('active', true)
        .order('name');
      
      if (error) {
        console.error('❌ Erro ao buscar motoboys:', error);
        throw error;
      }
      
      console.log('📋 Motoboys encontrados:', data);
      
      return data as Motoboy[];
    },
    enabled: isOpen,
    retry: 1,
    staleTime: 0
  });

  // Filtrar motoboys baseado no termo de busca
  const filteredMotoboys = motoboys?.filter(motoboy => 
    motoboy.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
    motoboy.phone_e164.includes(searchTerm)
  ) || [];

  useEffect(() => {
    if (motoboys && motoboys.length > 0 && !selectedDriverId) {
      // Selecionar o primeiro motoboy como padrão
      setSelectedDriverId(motoboys[0].id);
    }
  }, [motoboys, selectedDriverId]);

  const assignMutation = useMutation({
    mutationFn: async () => {
      if (!order || !selectedDriverId) return;

      const selectedMotoboy = motoboys?.find(m => m.id === selectedDriverId);
      if (!selectedMotoboy) throw new Error('Motoboy não encontrado');

      console.log('🚚 Iniciando atribuição de entrega via nova API...', {
        orderId: order.id,
        motoboyId: selectedDriverId,
        motoboyName: selectedMotoboy.name
      });

      try {
        // Usar o novo endpoint transacional
        const { data, error } = await supabase.functions.invoke('assign-delivery', {
          body: {
            order_id: order.id,
            motoboy_id: selectedDriverId,
            notes: notes.trim() || undefined
          }
        });

        console.log('📡 Resposta da API assign-delivery:', { data, error });

        if (error) {
          console.error('❌ Erro na API de atribuição:', error);
          throw new Error(error.message || 'Erro ao atribuir entrega');
        }

        if (!data?.success) {
          console.error('❌ API retornou erro:', data);
          throw new Error(data?.error || 'Erro desconhecido na atribuição');
        }

        console.log('✅ Entrega atribuída com sucesso:', data);
        return selectedMotoboy;
      } catch (err) {
        console.error('❌ Erro na chamada da API:', err);
        throw err;
      }
    },
    onSuccess: (selectedMotoboy) => {
      queryClient.invalidateQueries({ queryKey: ['user-orders'] });
      queryClient.invalidateQueries({ queryKey: ['orders'] });
      queryClient.invalidateQueries({ queryKey: ['deliveries'] });
      
      toast.success(`Entrega atribuída para ${selectedMotoboy?.name}!`);
      
      if (onDeliveryAssigned && selectedMotoboy) {
        onDeliveryAssigned(selectedMotoboy.name);
      }
      
      onClose();
      setSelectedDriverId('');
      setNotes('');
      setSearchTerm('');
    },
    onError: (error) => {
      console.error('❌ Erro ao atribuir entrega:', error);
      toast.error(`Erro: ${error.message}`);
    }
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!selectedDriverId) {
      toast.error('Selecione um motoboy para continuar');
      return;
    }

    console.log('🚀 Confirmando atribuição de entrega...', selectedDriverId);
    assignMutation.mutate();
  };

  const formatPhone = (phone: string) => {
    const numbers = phone.replace(/\D/g, '');
    if (numbers.length === 13 && numbers.startsWith('55')) {
      const areaCode = numbers.slice(2, 4);
      const firstPart = numbers.slice(4, 9);
      const secondPart = numbers.slice(9);
      return `(${areaCode}) ${firstPart}-${secondPart}`;
    }
    return phone;
  };

  console.log('🚪 Modal DeliveryAssignmentModal renderizado:', { 
    isOpen, 
    orderNumber: order?.order_number, 
    motoboysCount: motoboys?.length, 
    isLoading, 
    error: error?.message,
    selectedDriverId
  });
  
  // Log adicional quando o modal abre
  useEffect(() => {
    if (isOpen) {
      console.log('✨ Modal ABERTO! Estado atual:', {
        isOpen,
        order: order?.order_number,
        hasOrder: !!order
      });
    } else {
      console.log('❌ Modal FECHADO');
    }
  }, [isOpen, order]);

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle>Selecione um motoboy</DialogTitle>
        </DialogHeader>

        {order && (
          <div className="space-y-4">
            {/* Informações do pedido */}
            <div className="bg-muted p-3 rounded-lg space-y-2">
              <h4 className="font-medium">Pedido #{order.order_number}</h4>
              <p className="text-sm text-muted-foreground">
                Cliente: {order.customer_name}
              </p>
              <p className="text-sm text-muted-foreground">
                Total: R$ {order.total.toFixed(2)}
              </p>
            </div>

            {isLoading ? (
              <div className="text-center py-4">
                <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary mx-auto mb-2"></div>
                <p className="text-muted-foreground">Carregando motoboys...</p>
              </div>
            ) : error ? (
              <div className="text-center py-4">
                <p className="text-red-500">Erro ao carregar motoboys</p>
                <p className="text-sm text-muted-foreground mt-1">
                  {error.message}
                </p>
              </div>
            ) : !motoboys || motoboys.length === 0 ? (
              <div className="text-center py-6">
                <Truck className="w-12 h-12 text-muted-foreground mx-auto mb-3" />
                <p className="text-muted-foreground font-medium">Nenhum motoboy ativo</p>
                <p className="text-sm text-muted-foreground mt-1 mb-4">
                  Cadastre motoboys para usar esta funcionalidade
                </p>
                <Link to="/couriers">
                  <Button size="sm">
                    <Plus className="w-4 h-4 mr-2" />
                    Ir para Cadastros
                  </Button>
                </Link>
              </div>
            ) : (
              <form onSubmit={handleSubmit} className="space-y-4">
                {/* Busca de motoboys */}
                {motoboys.length > 3 && (
                  <div className="space-y-2">
                    <Label>Buscar Motoboy</Label>
                    <div className="relative">
                      <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground w-4 h-4" />
                      <Input
                        placeholder="Buscar por nome ou telefone..."
                        value={searchTerm}
                        onChange={(e) => setSearchTerm(e.target.value)}
                        className="pl-10"
                      />
                    </div>
                  </div>
                )}

                {/* Seleção de motoboy */}
                <div className="space-y-2">
                  <Label htmlFor="driver">Selecionar Entregador *</Label>
                  <Select
                    value={selectedDriverId}
                    onValueChange={setSelectedDriverId}
                    required
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="Escolha um motoboy" />
                    </SelectTrigger>
                    <SelectContent>
                      {filteredMotoboys.map((motoboy) => (
                        <SelectItem key={motoboy.id} value={motoboy.id}>
                          <div className="flex items-center gap-2">
                            <div className="flex flex-col">
                              <span className="font-medium">{motoboy.name}</span>
                              <div className="flex items-center gap-2 text-xs text-muted-foreground">
                                <Phone className="w-3 h-3" />
                                <span>{formatPhone(motoboy.phone_e164)}</span>
                                {motoboy.vehicle_type && (
                                  <>
                                    <span>•</span>
                                    <span className="capitalize">{motoboy.vehicle_type}</span>
                                  </>
                                )}
                              </div>
                            </div>
                          </div>
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                  {searchTerm && filteredMotoboys.length === 0 && (
                    <p className="text-sm text-muted-foreground">
                      Nenhum motoboy encontrado com "{searchTerm}"
                    </p>
                  )}
                </div>

                {/* Observações */}
                <div className="space-y-2">
                  <Label htmlFor="notes">Observações (opcional)</Label>
                  <Textarea
                    id="notes"
                    value={notes}
                    onChange={(e) => setNotes(e.target.value)}
                    placeholder="Observações sobre a entrega..."
                    rows={3}
                  />
                </div>

                {/* Ações */}
                <div className="flex gap-2 pt-4">
                  <Button 
                    type="button" 
                    variant="outline" 
                    onClick={() => {
                      console.log('🏃‍♂️ Pulando seleção de motoboy...');
                      if (onSkipDriver) {
                        onSkipDriver();
                      }
                      onClose();
                    }} 
                    className="flex-1"
                  >
                    PULAR
                  </Button>
                  <Button 
                    type="submit" 
                    className="flex-1 bg-green-600 hover:bg-green-700"
                    disabled={assignMutation.isPending || !selectedDriverId}
                  >
                    {assignMutation.isPending ? (
                      <>
                        <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white mr-2"></div>
                        Despachando...
                      </>
                    ) : (
                      'DESPACHAR'
                    )}
                  </Button>
                </div>
              </form>
            )}
          </div>
        )}
      </DialogContent>
    </Dialog>
  );
}