import { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Shield, AlertTriangle, Activity, RefreshCw } from 'lucide-react';
import { getSecurityEvents, getEventsByType, detectSuspiciousActivity } from '@/utils/securityMonitoring';

export const SecurityMonitorPanel = () => {
  const [events, setEvents] = useState<any[]>([]);
  const [suspicious, setSuspicious] = useState(false);

  const refreshData = () => {
    const recentEvents = getSecurityEvents(20);
    setEvents(recentEvents);
    setSuspicious(detectSuspiciousActivity());
  };

  useEffect(() => {
    refreshData();
    
    // Refresh every 30 seconds
    const interval = setInterval(refreshData, 30000);
    return () => clearInterval(interval);
  }, []);

  const getSeverityColor = (severity: string) => {
    switch (severity) {
      case 'high': return 'destructive';
      case 'medium': return 'secondary';
      case 'low': return 'outline';
      default: return 'outline';
    }
  };

  const getTypeIcon = (type: string) => {
    switch (type) {
      case 'rate_limit_exceeded': return '🚦';
      case 'invalid_file_upload': return '📁';
      case 'suspicious_activity': return '⚠️';
      case 'access_denied': return '🔒';
      default: return '🔍';
    }
  };

  return (
    <Card className="w-full">
      <CardHeader className="flex flex-row items-center justify-between">
        <div className="flex items-center gap-2">
          <Shield className="w-5 h-5" />
          <CardTitle>Monitor de Segurança</CardTitle>
          {suspicious && (
            <Badge variant="destructive" className="flex items-center gap-1">
              <AlertTriangle className="w-3 h-3" />
              Atividade Suspeita
            </Badge>
          )}
        </div>
        <Button variant="outline" size="sm" onClick={refreshData}>
          <RefreshCw className="w-4 h-4 mr-2" />
          Atualizar
        </Button>
      </CardHeader>
      
      <CardContent>
        <div className="space-y-4">
          {/* Summary Stats */}
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
            <div className="text-center p-3 bg-muted rounded-lg">
              <div className="text-2xl font-bold">{events.length}</div>
              <div className="text-sm text-muted-foreground">Eventos Recentes</div>
            </div>
            <div className="text-center p-3 bg-muted rounded-lg">
              <div className="text-2xl font-bold">
                {getEventsByType('rate_limit_exceeded').length}
              </div>
              <div className="text-sm text-muted-foreground">Rate Limits</div>
            </div>
            <div className="text-center p-3 bg-muted rounded-lg">
              <div className="text-2xl font-bold">
                {getEventsByType('invalid_file_upload').length}
              </div>
              <div className="text-sm text-muted-foreground">Uploads Inválidos</div>
            </div>
            <div className="text-center p-3 bg-muted rounded-lg">
              <div className="text-2xl font-bold">
                {events.filter(e => e.severity === 'high').length}
              </div>
              <div className="text-sm text-muted-foreground">Alta Severidade</div>
            </div>
          </div>

          {/* Recent Events */}
          <div>
            <h3 className="text-lg font-semibold mb-3 flex items-center gap-2">
              <Activity className="w-4 h-4" />
              Eventos Recentes
            </h3>
            
            {events.length === 0 ? (
              <div className="text-center py-8 text-muted-foreground">
                Nenhum evento de segurança registrado
              </div>
            ) : (
              <div className="space-y-2 max-h-96 overflow-y-auto">
                {events.map((event, index) => (
                  <div
                    key={index}
                    className="flex items-center justify-between p-3 border rounded-lg"
                  >
                    <div className="flex items-center gap-3">
                      <span className="text-lg">{getTypeIcon(event.type)}</span>
                      <div>
                        <div className="font-medium">
                          {event.type.replace(/_/g, ' ').replace(/\b\w/g, l => l.toUpperCase())}
                        </div>
                        <div className="text-sm text-muted-foreground">
                          {new Date(event.timestamp).toLocaleString('pt-BR')}
                        </div>
                        <div className="text-xs text-muted-foreground">
                          {event.path} • {event.details ? Object.entries(event.details).map(([k, v]) => `${k}: ${v}`).join(', ') : 'N/A'}
                        </div>
                      </div>
                    </div>
                    <Badge variant={getSeverityColor(event.severity)}>
                      {event.severity}
                    </Badge>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
      </CardContent>
    </Card>
  );
};