import { z } from "zod";

export const productSchema = z.object({
  name: z.string().min(1, "Nome é obrigatório"),
  description: z.string().optional(),
  price: z.number().min(0.01, "Preço deve ser maior que zero"),
  category: z.string().min(1, "Categoria é obrigatória"),
  image: z.string().url("URL da imagem deve ser válida").optional().or(z.literal("")),
  is_promotion: z.boolean().default(false),
  promotion_price: z.number().optional(),
  show_online_menu: z.boolean().default(true),
  customizable: z.boolean().default(false),
  is_pizza: z.boolean().default(false),
  allow_half_half: z.boolean().default(false),
  ingredients: z.array(z.string()).default([]),
  extras: z.array(z.object({
    name: z.string(),
    price: z.number(),
    is_free: z.boolean().default(false)
  })).default([]),
  max_flavors: z.number().min(1).default(1),
  pizza_flavors: z.array(z.object({
    name: z.string(),
    price: z.number(),
    ingredients: z.array(z.string()).default([])
  })).default([]),
  pizza_borders: z.array(z.object({
    name: z.string(),
    price: z.number(),
    is_free: z.boolean().default(false)
  })).default([]),
});

export type ProductFormData = z.infer<typeof productSchema>;