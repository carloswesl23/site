import React from "react";
import { FormControl, FormField, FormItem, FormLabel } from "@/components/ui/form";
import { Switch } from "@/components/ui/switch";
import { UseFormReturn } from "react-hook-form";
import { ProductFormData } from "./schema";

interface ProductTogglesProps {
  form: UseFormReturn<ProductFormData>;
}

export const ProductToggles = ({ form }: ProductTogglesProps) => {
  return (
    <div className="space-y-4">
      <FormField
        control={form.control}
        name="show_online_menu"
        render={({ field }) => (
          <FormItem className="flex items-center justify-between">
            <FormLabel>Exibir no cardápio online</FormLabel>
            <FormControl>
              <Switch 
                checked={field.value}
                onCheckedChange={field.onChange}
              />
            </FormControl>
          </FormItem>
        )}
      />

      <FormField
        control={form.control}
        name="is_promotion"
        render={({ field }) => (
          <FormItem className="flex items-center justify-between">
            <FormLabel>Produto em promoção</FormLabel>
            <FormControl>
              <Switch 
                checked={field.value}
                onCheckedChange={field.onChange}
              />
            </FormControl>
          </FormItem>
        )}
      />

      <FormField
        control={form.control}
        name="customizable"
        render={({ field }) => (
          <FormItem className="flex items-center justify-between">
            <FormLabel>Produto personalizável</FormLabel>
            <FormControl>
              <Switch 
                checked={field.value}
                onCheckedChange={field.onChange}
              />
            </FormControl>
          </FormItem>
        )}
      />

      <FormField
        control={form.control}
        name="is_pizza"
        render={({ field }) => (
          <FormItem className="flex items-center justify-between">
            <FormLabel>É uma pizza</FormLabel>
            <FormControl>
              <Switch 
                checked={field.value}
                onCheckedChange={field.onChange}
              />
            </FormControl>
          </FormItem>
        )}
      />
    </div>
  );
};