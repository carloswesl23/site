import React from "react";
import { FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Plus, Minus, X } from "lucide-react";
import { Checkbox } from "@/components/ui/checkbox";
import { UseFormReturn } from "react-hook-form";

interface Extra {
  name: string;
  price: number;
  is_free?: boolean;
}

interface PizzaFlavor {
  name: string;
  price: number;
  ingredients: string[];
}

interface PizzaBorder {
  name: string;
  price: number;
  is_free?: boolean;
}

interface CustomizableFieldsProps {
  form: UseFormReturn<any>;
  isPizza: boolean;
}

export const CustomizableFields = ({ form, isPizza }: CustomizableFieldsProps) => {
  const ingredients = form.watch("ingredients") || [];
  const extras = form.watch("extras") || [];
  const pizzaFlavors = form.watch("pizza_flavors") || [];
  const pizzaBorders = form.watch("pizza_borders") || [];

  const addIngredient = () => {
    const currentIngredients = form.getValues("ingredients") || [];
    form.setValue("ingredients", [...currentIngredients, ""]);
  };

  const removeIngredient = (index: number) => {
    const currentIngredients = form.getValues("ingredients") || [];
    form.setValue("ingredients", currentIngredients.filter((_, i) => i !== index));
  };

  const updateIngredient = (index: number, value: string) => {
    const currentIngredients = form.getValues("ingredients") || [];
    const updatedIngredients = [...currentIngredients];
    updatedIngredients[index] = value;
    form.setValue("ingredients", updatedIngredients);
  };

  const addExtra = () => {
    const currentExtras = form.getValues("extras") || [];
    form.setValue("extras", [...currentExtras, { name: "", price: 0, is_free: false }]);
  };

  const removeExtra = (index: number) => {
    const currentExtras = form.getValues("extras") || [];
    form.setValue("extras", currentExtras.filter((_, i) => i !== index));
  };

  const updateExtra = (index: number, field: "name" | "price" | "is_free", value: string | number | boolean) => {
    const currentExtras = form.getValues("extras") || [];
    const updatedExtras = [...currentExtras];
    updatedExtras[index] = { ...updatedExtras[index], [field]: value };
    form.setValue("extras", updatedExtras);
  };

  const addPizzaFlavor = () => {
    const currentFlavors = form.getValues("pizza_flavors") || [];
    form.setValue("pizza_flavors", [...currentFlavors, { name: "", price: 0, ingredients: [] }]);
  };

  const removePizzaFlavor = (index: number) => {
    const currentFlavors = form.getValues("pizza_flavors") || [];
    form.setValue("pizza_flavors", currentFlavors.filter((_, i) => i !== index));
  };

  const updatePizzaFlavor = (index: number, field: "name" | "price", value: string | number) => {
    const currentFlavors = form.getValues("pizza_flavors") || [];
    const updatedFlavors = [...currentFlavors];
    updatedFlavors[index] = { ...updatedFlavors[index], [field]: value };
    form.setValue("pizza_flavors", updatedFlavors);
  };

  const addPizzaBorder = () => {
    const currentBorders = form.getValues("pizza_borders") || [];
    form.setValue("pizza_borders", [...currentBorders, { name: "", price: 0, is_free: false }]);
  };

  const removePizzaBorder = (index: number) => {
    const currentBorders = form.getValues("pizza_borders") || [];
    form.setValue("pizza_borders", currentBorders.filter((_, i) => i !== index));
  };

  const updatePizzaBorder = (index: number, field: "name" | "price" | "is_free", value: string | number | boolean) => {
    const currentBorders = form.getValues("pizza_borders") || [];
    const updatedBorders = [...currentBorders];
    updatedBorders[index] = { ...updatedBorders[index], [field]: value };
    form.setValue("pizza_borders", updatedBorders);
  };

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle className="text-lg">Opções de Personalização</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          {/* Allow Half and Half */}
          <FormField
            control={form.control}
            name="allow_half_half"
            render={({ field }) => (
              <FormItem className="flex flex-row items-center justify-between rounded-lg border p-4">
                <div className="space-y-0.5">
                  <FormLabel className="text-base">
                    Permitir ao cliente escolher 2 sabores?
                  </FormLabel>
                  <div className="text-sm text-muted-foreground">
                    Cliente poderá escolher entre pizza inteira ou meia a meia
                  </div>
                </div>
                <FormControl>
                  <Checkbox
                    checked={field.value}
                    onCheckedChange={field.onChange}
                  />
                </FormControl>
              </FormItem>
            )}
          />

          {/* Maximum Flavors */}
          <FormField
            control={form.control}
            name="max_flavors"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Número máximo de sabores</FormLabel>
                <FormControl>
                  <Input 
                    type="number" 
                    min="1"
                    max="4"
                    placeholder="2"
                    {...field}
                    onChange={(e) => field.onChange(parseInt(e.target.value) || 2)}
                  />
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />

          {/* Ingredients */}
          <div>
            <div className="flex items-center justify-between mb-2">
              <FormLabel>Ingredientes removíveis</FormLabel>
              <Button type="button" variant="outline" size="sm" onClick={addIngredient}>
                <Plus className="w-4 h-4 mr-1" />
                Adicionar
              </Button>
            </div>
            <div className="space-y-2">
              {ingredients.map((ingredient: string, index: number) => (
                <div key={index} className="flex gap-2">
                  <Input
                    placeholder="Ex: Cebola, Tomate, Picles"
                    value={ingredient}
                    onChange={(e) => updateIngredient(index, e.target.value)}
                  />
                  <Button
                    type="button"
                    variant="outline"
                    size="sm"
                    onClick={() => removeIngredient(index)}
                  >
                    <X className="w-4 h-4" />
                  </Button>
                </div>
              ))}
            </div>
          </div>

          {/* Extras */}
          <div>
            <div className="flex items-center justify-between mb-2">
              <FormLabel>Extras opcionais</FormLabel>
              <Button type="button" variant="outline" size="sm" onClick={addExtra}>
                <Plus className="w-4 h-4 mr-1" />
                Adicionar Extra
              </Button>
            </div>
            <div className="space-y-3">
              {extras.map((extra: Extra, index: number) => (
                <div key={index} className="p-3 border rounded-lg bg-muted/20">
                  <div className="grid grid-cols-12 gap-2 items-center">
                    <div className="col-span-5">
                      <Label className="text-xs font-medium mb-1 block">Nome do Extra</Label>
                      <Input
                        placeholder="Ex: Bacon, Queijo Extra"
                        value={extra.name}
                        onChange={(e) => updateExtra(index, "name", e.target.value)}
                      />
                    </div>
                    <div className="col-span-3">
                      <Label className="text-xs font-medium mb-1 block">Valor (R$)</Label>
                      <Input
                        type="number"
                        step="0.01"
                        min="0"
                        placeholder="0,00"
                        value={extra.price || ''}
                        onChange={(e) => updateExtra(index, "price", parseFloat(e.target.value) || 0)}
                        disabled={extra.is_free}
                      />
                    </div>
                    <div className="col-span-3 flex items-center justify-center">
                      <div className="flex items-center space-x-2">
                        <Checkbox
                          id={`extra-free-${index}`}
                          checked={extra.is_free || false}
                          onCheckedChange={(checked) => {
                            updateExtra(index, "is_free", checked);
                            if (checked) {
                              updateExtra(index, "price", 0);
                            }
                          }}
                        />
                        <Label htmlFor={`extra-free-${index}`} className="text-xs font-medium">
                          Sem Custo
                        </Label>
                      </div>
                    </div>
                    <div className="col-span-1 flex justify-end">
                      <Button
                        type="button"
                        variant="outline"
                        size="sm"
                        onClick={() => removeExtra(index)}
                      >
                        <X className="w-4 h-4" />
                      </Button>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Pizza-specific fields */}
      {isPizza && (
        <Card>
          <CardHeader>
            <CardTitle className="text-lg">Opções específicas para Pizza</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            {/* Pizza Flavors */}
            <div>
              <div className="flex items-center justify-between mb-2">
                <FormLabel>Sabores disponíveis</FormLabel>
                <Button type="button" variant="outline" size="sm" onClick={addPizzaFlavor}>
                  <Plus className="w-4 h-4 mr-1" />
                  Adicionar Sabor
                </Button>
              </div>
              <div className="space-y-3">
                {pizzaFlavors.map((flavor: PizzaFlavor, index: number) => (
                  <div key={index} className="p-3 border rounded-lg space-y-2">
                    <div className="flex gap-2">
                      <Input
                        placeholder="Nome do sabor"
                        value={flavor.name}
                        onChange={(e) => updatePizzaFlavor(index, "name", e.target.value)}
                      />
                      <Input
                        type="number"
                        step="0.01"
                        placeholder="Preço"
                        value={flavor.price}
                        onChange={(e) => updatePizzaFlavor(index, "price", parseFloat(e.target.value) || 0)}
                        className="w-32"
                      />
                      <Button
                        type="button"
                        variant="outline"
                        size="sm"
                        onClick={() => removePizzaFlavor(index)}
                      >
                        <X className="w-4 h-4" />
                      </Button>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* Pizza Borders */}
            <div>
              <div className="flex items-center justify-between mb-2">
                <FormLabel>Bordas disponíveis</FormLabel>
                <Button type="button" variant="outline" size="sm" onClick={addPizzaBorder}>
                  <Plus className="w-4 h-4 mr-1" />
                  Adicionar Borda
                </Button>
              </div>
              <div className="space-y-3">
                {pizzaBorders.map((border: PizzaBorder, index: number) => (
                  <div key={index} className="p-3 border rounded-lg bg-muted/20">
                    <div className="grid grid-cols-12 gap-2 items-center">
                      <div className="col-span-5">
                        <Label className="text-xs font-medium mb-1 block">Nome da Borda</Label>
                        <Input
                          placeholder="Ex: Borda de Catupiry, Cheddar"
                          value={border.name}
                          onChange={(e) => updatePizzaBorder(index, "name", e.target.value)}
                        />
                      </div>
                      <div className="col-span-3">
                        <Label className="text-xs font-medium mb-1 block">Valor (R$)</Label>
                        <Input
                          type="number"
                          step="0.01"
                          min="0"
                          placeholder="0,00"
                          value={border.price || ''}
                          onChange={(e) => updatePizzaBorder(index, "price", parseFloat(e.target.value) || 0)}
                          disabled={border.is_free}
                        />
                      </div>
                      <div className="col-span-3 flex items-center justify-center">
                        <div className="flex items-center space-x-2">
                          <Checkbox
                            id={`border-free-${index}`}
                            checked={border.is_free || false}
                            onCheckedChange={(checked) => {
                              updatePizzaBorder(index, "is_free", checked);
                              if (checked) {
                                updatePizzaBorder(index, "price", 0);
                              }
                            }}
                          />
                          <Label htmlFor={`border-free-${index}`} className="text-xs font-medium">
                            Grátis
                          </Label>
                        </div>
                      </div>
                      <div className="col-span-1 flex justify-end">
                        <Button
                          type="button"
                          variant="outline"
                          size="sm"
                          onClick={() => removePizzaBorder(index)}
                        >
                          <X className="w-4 h-4" />
                        </Button>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
};