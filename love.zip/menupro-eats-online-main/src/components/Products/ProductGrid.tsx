import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Switch } from "@/components/ui/switch";
import { Label } from "@/components/ui/label";
import { Star, Globe, Edit, Trash2, Package, Plus } from "lucide-react";

interface UserProduct {
  id: string;
  name: string;
  description: string | null;
  price: number;
  image: string | null;
  category: string;
  is_promotion: boolean;
  promotion_price: number | null;
  show_online_menu: boolean;
}

interface ProductGridProps {
  products: UserProduct[];
  isLoading: boolean;
  searchTerm: string;
  selectedCategory: string;
  onToggleOnlineMenu: (productId: string) => void;
  onEditProduct: (productId: string) => void;
  onDeleteProduct: (productId: string) => void;
  onNewProduct: () => void;
}

export const ProductGrid = ({
  products,
  isLoading,
  searchTerm,
  selectedCategory,
  onToggleOnlineMenu,
  onEditProduct,
  onDeleteProduct,
  onNewProduct
}: ProductGridProps) => {
  if (isLoading) {
    return (
      <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
        {[1, 2, 3].map((i) => (
          <Card key={i} className="animate-pulse">
            <div className="h-48 bg-gray-200 rounded-t-lg"></div>
            <CardContent className="p-4">
              <div className="h-4 bg-gray-200 rounded mb-2"></div>
              <div className="h-3 bg-gray-200 rounded mb-3"></div>
              <div className="h-8 bg-gray-200 rounded"></div>
            </CardContent>
          </Card>
        ))}
      </div>
    );
  }

  if (products.length === 0) {
    return (
      <div className="text-center py-12 text-gray-500">
        <div className="flex flex-col items-center gap-3">
          <Package className="h-16 w-16 text-gray-300" />
          <h3 className="text-lg font-medium">Nenhum produto encontrado</h3>
          <p className="text-sm">
            {searchTerm || selectedCategory !== "Todas Categorias" 
              ? "Tente ajustar os filtros de busca" 
              : "Comece adicionando produtos ao seu cardápio"
            }
          </p>
          {!searchTerm && selectedCategory === "Todas Categorias" && (
            <Button onClick={onNewProduct} className="mt-4">
              <Plus className="w-4 h-4 mr-2" />
              Adicionar Primeiro Produto
            </Button>
          )}
        </div>
      </div>
    );
  }

  return (
    <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
      {products.map((product) => (
        <Card key={product.id} className="hover:shadow-lg transition-shadow">
          <CardHeader className="p-0">
            <div className="relative">
              <img
                src={product.image || "/placeholder.svg"}
                alt={product.name}
                className="w-full h-48 object-cover rounded-t-lg"
              />
              {product.is_promotion && (
                <Badge className="absolute top-2 left-2 bg-brand-red text-white">
                  <Star className="w-3 h-3 mr-1" />
                  Promoção
                </Badge>
              )}
              {product.show_online_menu && (
                <Badge className="absolute top-2 right-2 bg-blue-500 text-white">
                  <Globe className="w-3 h-3 mr-1" />
                  Online
                </Badge>
              )}
            </div>
          </CardHeader>
          <CardContent className="p-4">
            <div className="flex justify-between items-start mb-2">
              <h3 className="font-semibold text-brand-dark">{product.name}</h3>
              <Badge variant="outline">{product.category}</Badge>
            </div>
            <p className="text-sm text-gray-600 mb-3">{product.description || "Sem descrição"}</p>
            
            <div className="flex items-center justify-between mb-3 p-2 bg-gray-50 rounded-lg">
              <Label htmlFor={`online-${product.id}`} className="text-sm">
                Exibir no cardápio online
              </Label>
              <Switch
                id={`online-${product.id}`}
                checked={product.show_online_menu}
                onCheckedChange={() => onToggleOnlineMenu(product.id)}
              />
            </div>
            
            <div className="flex justify-between items-center">
              <div className="flex items-center gap-2">
                {product.is_promotion && product.promotion_price ? (
                  <>
                    <span className="text-lg font-bold text-brand-orange">
                      R$ {product.promotion_price.toFixed(2).replace('.', ',')}
                    </span>
                    <span className="text-sm text-gray-500 line-through">
                      R$ {product.price.toFixed(2).replace('.', ',')}
                    </span>
                  </>
                ) : (
                  <span className="text-lg font-bold text-brand-dark">
                    R$ {product.price.toFixed(2).replace('.', ',')}
                  </span>
                )}
              </div>
              <div className="flex gap-1">
                <Button 
                  type="button"
                  size="sm" 
                  variant="outline"
                  onClick={() => onEditProduct(product.id)}
                >
                  <Edit className="w-3 h-3" />
                </Button>
                <Button 
                  type="button"
                  size="sm" 
                  variant="outline" 
                  className="text-red-600 hover:text-red-700"
                  onClick={() => onDeleteProduct(product.id)}
                >
                  <Trash2 className="w-3 h-3" />
                </Button>
              </div>
            </div>
          </CardContent>
        </Card>
      ))}
    </div>
  );
};