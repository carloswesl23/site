import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Plus, Edit, Globe, ExternalLink, FolderPlus } from "lucide-react";
import { CategoryEditor } from "@/components/OnlineMenu/CategoryEditor";
import { useToast } from "@/hooks/use-toast";
import { useNavigate } from "react-router-dom";

interface ProductActionsProps {
  categories: { id: string; name: string; sort_order: number }[];
  settings: { online_menu_slug?: string | null } | null;
  onNewProduct: () => void;
}

export const ProductActions = ({ categories, settings, onNewProduct }: ProductActionsProps) => {
  const { toast } = useToast();
  const navigate = useNavigate();

  const handleCopyLink = async () => {
    if (!settings?.online_menu_slug) {
      toast({
        title: "Link não disponível",
        description: "Configure primeiro o slug do seu estabelecimento.",
        variant: "destructive"
      });
      return;
    }
    
    const onlineMenuUrl = `https://lovemenu.com.br/${settings.online_menu_slug}`;
    navigator.clipboard.writeText(onlineMenuUrl);
    toast({
      title: "Link copiado!",
      description: "O link do cardápio foi copiado para a área de transferência.",
    });
  };

  const handleOpenOnlineMenu = () => {
    if (!settings?.online_menu_slug) {
      toast({
        title: "Link não disponível",
        description: "Configure primeiro o slug do seu estabelecimento.",
        variant: "destructive"
      });
      return;
    }
    
    const onlineMenuUrl = `https://lovemenu.com.br/${settings.online_menu_slug}`;
    window.open(onlineMenuUrl, '_blank');
  };

  const handleEditOnlineMenu = () => {
    if (!settings?.online_menu_slug) {
      toast({
        title: "Erro",
        description: "Slug do cardápio não encontrada. Tente novamente.",
        variant: "destructive"
      });
      return;
    }
    
    const editUrl = `/online-menu?edit=true&slug=${settings.online_menu_slug}`;
    navigate(editUrl);
  };


  return (
    <div className="flex gap-2 mt-4 md:mt-0">
      <Dialog>
        <DialogTrigger asChild>
          <Button 
            type="button"
            variant="outline"
            className="text-green-600 border-green-200 hover:bg-green-50"
          >
            <FolderPlus className="w-4 h-4 mr-2" />
            Gerenciar Categorias
          </Button>
        </DialogTrigger>
        <DialogContent className="max-w-2xl max-h-[80vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>Gerenciar Categorias do Cardápio</DialogTitle>
          </DialogHeader>
          <CategoryEditor categories={categories} />
        </DialogContent>
      </Dialog>
      <Button 
        type="button"
        variant="outline"
        onClick={handleEditOnlineMenu}
        className="text-purple-600 border-purple-200 hover:bg-purple-50"
      >
        <Edit className="w-4 h-4 mr-2" />
        Editar Cardápio
      </Button>
      <Button 
        type="button"
        variant="outline"
        onClick={handleOpenOnlineMenu}
        className="text-blue-600 border-blue-200 hover:bg-blue-50"
      >
        <Globe className="w-4 h-4 mr-2" />
        Ver Cardápio Online
        <ExternalLink className="w-3 h-3 ml-2" />
      </Button>
      <Button 
        type="button"
        onClick={onNewProduct}
        className="gradient-brand text-white"
      >
        <Plus className="w-4 h-4 mr-2" />
        Novo Produto
      </Button>
    </div>
  );
};