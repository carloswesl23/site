import React, { useEffect } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { Form } from "@/components/ui/form";
import { CustomizableFields } from "./CustomizableFields";
import { ProductBasicFields } from "./ProductBasicFields";
import { ProductToggles } from "./ProductToggles";
import { productSchema, ProductFormData } from "./schema";
import { UserProduct, ProductModalProps } from "./types";

export const ProductModal = ({ 
  isOpen, 
  onClose, 
  onSubmit, 
  product, 
  categories,
  loading = false 
}: ProductModalProps) => {
  const form = useForm<ProductFormData>({
    resolver: zodResolver(productSchema),
    defaultValues: {
      name: "",
      description: "",
      price: 0,
      category: "",
      image: "",
      is_promotion: false,
      promotion_price: undefined,
      show_online_menu: true,
      customizable: false,
      is_pizza: false,
      allow_half_half: false,
      ingredients: [],
      extras: [],
      max_flavors: 1,
      pizza_flavors: [],
      pizza_borders: [],
    },
  });

  // Atualizar formulário quando o produto mudar
  useEffect(() => {
    if (product) {
      form.reset({
        name: product.name || "",
        description: product.description || "",
        price: product.price || 0,
        category: product.category || "",
        image: product.image || "",
        is_promotion: product.is_promotion || false,
        promotion_price: product.promotion_price || undefined,
        show_online_menu: product.show_online_menu ?? true,
        customizable: product.customizable || false,
        is_pizza: product.is_pizza || false,
        allow_half_half: product.allow_half_half || false,
        ingredients: product.ingredients || [],
        extras: product.extras || [],
        max_flavors: product.max_flavors || 1,
        pizza_flavors: product.pizza_flavors || [],
        pizza_borders: product.pizza_borders || [],
      });
    } else {
      // Resetar para valores padrão quando não há produto (novo produto)
      form.reset({
        name: "",
        description: "",
        price: 0,
        category: "",
        image: "",
        is_promotion: false,
        promotion_price: undefined,
        show_online_menu: true,
        customizable: false,
        is_pizza: false,
        allow_half_half: false,
        ingredients: [],
        extras: [],
        max_flavors: 1,
        pizza_flavors: [],
        pizza_borders: [],
      });
    }
  }, [product, form]);

  const handleSubmit = async (data: ProductFormData) => {
    try {
      await onSubmit(data);
      form.reset();
      onClose();
    } catch (error) {
      console.error('Error submitting product:', error);
    }
  };

  const handleClose = () => {
    form.reset();
    onClose();
  };

  const isPromotion = form.watch("is_promotion");
  const isCustomizable = form.watch("customizable");
  const isPizza = form.watch("is_pizza");

  return (
    <Dialog open={isOpen} onOpenChange={handleClose}>
      <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>
            {product ? `Editar Produto: ${product.name}` : "Novo Produto"}
          </DialogTitle>
        </DialogHeader>

        <Form {...form}>
          <form onSubmit={form.handleSubmit(handleSubmit)} className="space-y-4">
            <ProductBasicFields 
              form={form} 
              categories={categories} 
              isPromotion={isPromotion} 
            />

            <ProductToggles form={form} />

            {/* Customizable Fields */}
            {isCustomizable && (
              <CustomizableFields form={form} isPizza={isPizza} />
            )}

            <div className="flex justify-end gap-2 pt-4">
              <Button type="button" variant="outline" onClick={handleClose}>
                Cancelar
              </Button>
              <Button type="submit" disabled={loading}>
                {loading ? "Salvando..." : product ? "Atualizar" : "Criar"}
              </Button>
            </div>
          </form>
        </Form>
      </DialogContent>
    </Dialog>
  );
};