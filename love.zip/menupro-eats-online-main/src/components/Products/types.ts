export interface UserProduct {
  id: string;
  name: string;
  description: string | null;
  price: number;
  image: string | null;
  category: string;
  is_promotion: boolean;
  promotion_price: number | null;
  show_online_menu: boolean;
  customizable: boolean;
  is_pizza: boolean;
  allow_half_half?: boolean;
  ingredients?: string[];
  extras?: { name: string; price: number; is_free?: boolean }[];
  max_flavors?: number;
  pizza_flavors?: { name: string; price: number; ingredients: string[] }[];
  pizza_borders?: { name: string; price: number; is_free?: boolean }[];
}

export interface ProductModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSubmit: (data: any) => Promise<void>;
  product?: UserProduct | null;
  categories: string[];
  loading?: boolean;
}