import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Separator } from "@/components/ui/separator";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Plus, Minus, X, Edit, Save, User, Phone, MapPin, CreditCard, Package } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { useToast } from "@/hooks/use-toast";

interface OrderItem {
  id?: string;
  name: string;
  quantity: number;
  price: number;
  total: number;
}

interface Order {
  id: string;
  order_number: string;
  customer_name: string;
  customer_phone: string | null;
  customer_email: string | null;
  delivery_address: string | null;
  payment_method: string | null;
  total: number;
  status: string;
  items: OrderItem[];
  notes: string | null;
  created_at: string;
}

interface OrderDetailsModalProps {
  isOpen: boolean;
  onClose: () => void;
  order: Order | null;
  onOrderUpdated?: (updatedOrder: Order) => void;
}

export function OrderDetailsModal({ isOpen, onClose, order, onOrderUpdated }: OrderDetailsModalProps) {
  const [isEditing, setIsEditing] = useState(false);
  const [editedOrder, setEditedOrder] = useState<Order | null>(null);
  const [availableProducts, setAvailableProducts] = useState<any[]>([]);
  const { toast } = useToast();

  useEffect(() => {
    if (order) {
      setEditedOrder({ ...order });
    }
  }, [order]);

  useEffect(() => {
    fetchAvailableProducts();
  }, []);

  const fetchAvailableProducts = async () => {
    try {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) return;

      const { data, error } = await supabase
        .from('user_products')
        .select('id, name, price')
        .eq('user_id', user.id)
        .eq('show_online_menu', true);

      if (error) throw error;
      setAvailableProducts(data || []);
    } catch (error) {
      console.error('Erro ao buscar produtos:', error);
    }
  };

  const handleSaveOrder = async () => {
    if (!editedOrder) return;

    try {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) return;

      const { error } = await supabase
        .from('user_orders')
        .update({
          customer_name: editedOrder.customer_name,
          customer_phone: editedOrder.customer_phone,
          customer_email: editedOrder.customer_email,
          delivery_address: editedOrder.delivery_address,
          payment_method: editedOrder.payment_method,
          items: editedOrder.items as any,
          total: editedOrder.total,
          notes: editedOrder.notes
        })
        .eq('id', editedOrder.id)
        .eq('user_id', user.id);

      if (error) throw error;

      toast({
        title: "Pedido atualizado!",
        description: "As alterações foram salvas com sucesso.",
      });

      setIsEditing(false);
      if (onOrderUpdated) {
        onOrderUpdated(editedOrder);
      }
    } catch (error) {
      console.error('Erro ao atualizar pedido:', error);
      toast({
        title: "Erro ao atualizar",
        description: "Não foi possível salvar as alterações.",
        variant: "destructive"
      });
    }
  };

  const addProductToOrder = (productId: string) => {
    const product = availableProducts.find(p => p.id === productId);
    if (!product || !editedOrder) return;

    const existingItem = editedOrder.items.find(item => item.name === product.name);
    
    if (existingItem) {
      updateItemQuantity(editedOrder.items.indexOf(existingItem), existingItem.quantity + 1);
    } else {
      const newItem: OrderItem = {
        name: product.name,
        quantity: 1,
        price: product.price,
        total: product.price
      };

      const updatedItems = [...editedOrder.items, newItem];
      const newTotal = updatedItems.reduce((sum, item) => sum + item.total, 0);

      setEditedOrder({
        ...editedOrder,
        items: updatedItems,
        total: newTotal
      });
    }
  };

  const updateItemQuantity = (index: number, newQuantity: number) => {
    if (!editedOrder || newQuantity < 1) return;

    const updatedItems = [...editedOrder.items];
    updatedItems[index] = {
      ...updatedItems[index],
      quantity: newQuantity,
      total: updatedItems[index].price * newQuantity
    };

    const newTotal = updatedItems.reduce((sum, item) => sum + item.total, 0);

    setEditedOrder({
      ...editedOrder,
      items: updatedItems,
      total: newTotal
    });
  };

  const removeItem = (index: number) => {
    if (!editedOrder) return;

    const updatedItems = editedOrder.items.filter((_, i) => i !== index);
    const newTotal = updatedItems.reduce((sum, item) => sum + item.total, 0);

    setEditedOrder({
      ...editedOrder,
      items: updatedItems,
      total: newTotal
    });
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'pending': return 'bg-blue-100 text-blue-800';
      case 'preparing': return 'bg-yellow-100 text-yellow-800';
      case 'delivery': return 'bg-green-100 text-green-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  const getStatusText = (status: string) => {
    switch (status) {
      case 'pending': return 'Aguardando Pagamento';
      case 'preparing': return 'Em Preparo';
      case 'delivery': return 'Em Entrega';
      default: return 'Desconhecido';
    }
  };

  if (!order) return null;

  const currentOrder = editedOrder || order;

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <div className="flex items-center justify-between">
            <DialogTitle className="flex items-center gap-2">
              <Package className="w-5 h-5" />
              Pedido #{order.order_number}
            </DialogTitle>
            <div className="flex items-center gap-2">
              <Badge className={getStatusColor(order.status)}>
                {getStatusText(order.status)}
              </Badge>
              {!isEditing && (
                <Button size="sm" variant="outline" onClick={() => setIsEditing(true)}>
                  <Edit className="w-4 h-4 mr-1" />
                  Editar
                </Button>
              )}
            </div>
          </div>
        </DialogHeader>

        <div className="grid gap-6 md:grid-cols-2">
          {/* Informações do Cliente */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <User className="w-4 h-4" />
                Informações do Cliente
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              {isEditing ? (
                <>
                  <div>
                    <Label htmlFor="customer_name">Nome</Label>
                    <Input
                      id="customer_name"
                      value={currentOrder.customer_name}
                      onChange={(e) => setEditedOrder({
                        ...currentOrder,
                        customer_name: e.target.value
                      })}
                    />
                  </div>
                  <div>
                    <Label htmlFor="customer_phone">Telefone</Label>
                    <Input
                      id="customer_phone"
                      value={currentOrder.customer_phone || ''}
                      onChange={(e) => setEditedOrder({
                        ...currentOrder,
                        customer_phone: e.target.value
                      })}
                    />
                  </div>
                  <div>
                    <Label htmlFor="customer_email">E-mail</Label>
                    <Input
                      id="customer_email"
                      value={currentOrder.customer_email || ''}
                      onChange={(e) => setEditedOrder({
                        ...currentOrder,
                        customer_email: e.target.value
                      })}
                    />
                  </div>
                </>
              ) : (
                <>
                  <div className="flex items-center gap-2">
                    <User className="w-4 h-4 text-gray-500" />
                    <span>{order.customer_name}</span>
                  </div>
                  {order.customer_phone && (
                    <div className="flex items-center gap-2">
                      <Phone className="w-4 h-4 text-gray-500" />
                      <span>{order.customer_phone}</span>
                    </div>
                  )}
                  {order.customer_email && (
                    <div className="flex items-center gap-2">
                      <span className="text-sm">📧 {order.customer_email}</span>
                    </div>
                  )}
                </>
              )}
            </CardContent>
          </Card>

          {/* Informações de Entrega */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <MapPin className="w-4 h-4" />
                Entrega e Pagamento
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              {isEditing ? (
                <>
                  <div>
                    <Label htmlFor="delivery_address">Endereço</Label>
                    <Textarea
                      id="delivery_address"
                      value={currentOrder.delivery_address || ''}
                      onChange={(e) => setEditedOrder({
                        ...currentOrder,
                        delivery_address: e.target.value
                      })}
                      rows={3}
                    />
                  </div>
                  <div>
                    <Label htmlFor="payment_method">Forma de Pagamento</Label>
                    <Input
                      id="payment_method"
                      value={currentOrder.payment_method || ''}
                      onChange={(e) => setEditedOrder({
                        ...currentOrder,
                        payment_method: e.target.value
                      })}
                    />
                  </div>
                </>
              ) : (
                <>
                  {order.delivery_address && (
                    <div className="flex items-start gap-2">
                      <MapPin className="w-4 h-4 text-gray-500 mt-1" />
                      <span className="text-sm">{order.delivery_address}</span>
                    </div>
                  )}
                  {order.payment_method && (
                    <div className="flex items-center gap-2">
                      <CreditCard className="w-4 h-4 text-gray-500" />
                      <span>{order.payment_method}</span>
                    </div>
                  )}
                </>
              )}
            </CardContent>
          </Card>
        </div>

        {/* Itens do Pedido */}
        <Card>
          <CardHeader>
            <div className="flex items-center justify-between">
              <CardTitle>Itens do Pedido</CardTitle>
              {isEditing && (
                <Select onValueChange={addProductToOrder}>
                  <SelectTrigger className="w-[200px]">
                    <SelectValue placeholder="Adicionar produto" />
                  </SelectTrigger>
                  <SelectContent>
                    {availableProducts.map((product) => (
                      <SelectItem key={product.id} value={product.id}>
                        {product.name} - R$ {product.price.toFixed(2)}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              )}
            </div>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              {currentOrder.items.map((item, index) => (
                <div key={index} className="flex items-center justify-between p-3 border rounded-lg">
                  <div className="flex-1">
                    <span className="font-medium">{item.name}</span>
                    <div className="text-sm text-gray-500">
                      R$ {item.price.toFixed(2)} cada
                    </div>
                  </div>
                  
                  {isEditing ? (
                    <div className="flex items-center gap-2">
                      <Button
                        size="sm"
                        variant="outline"
                        onClick={() => updateItemQuantity(index, item.quantity - 1)}
                        disabled={item.quantity <= 1}
                      >
                        <Minus className="w-3 h-3" />
                      </Button>
                      <span className="min-w-8 text-center">{item.quantity}</span>
                      <Button
                        size="sm"
                        variant="outline"
                        onClick={() => updateItemQuantity(index, item.quantity + 1)}
                      >
                        <Plus className="w-3 h-3" />
                      </Button>
                      <Button
                        size="sm"
                        variant="outline"
                        onClick={() => removeItem(index)}
                        className="text-red-600 hover:text-red-700"
                      >
                        <X className="w-3 h-3" />
                      </Button>
                    </div>
                  ) : (
                    <div className="text-right">
                      <div className="font-medium">
                        {item.quantity}x R$ {item.total.toFixed(2)}
                      </div>
                    </div>
                  )}
                </div>
              ))}
            </div>
            
            <Separator className="my-4" />
            
            <div className="flex justify-between items-center font-bold text-lg">
              <span>Total:</span>
              <span>R$ {currentOrder.total.toFixed(2)}</span>
            </div>
          </CardContent>
        </Card>

        {/* Observações */}
        <Card>
          <CardHeader>
            <CardTitle>Observações</CardTitle>
          </CardHeader>
          <CardContent>
            {isEditing ? (
              <Textarea
                value={currentOrder.notes || ''}
                onChange={(e) => setEditedOrder({
                  ...currentOrder,
                  notes: e.target.value
                })}
                placeholder="Observações do pedido..."
                rows={3}
              />
            ) : (
              <p className="text-sm text-gray-600">
                {order.notes || 'Nenhuma observação'}
              </p>
            )}
          </CardContent>
        </Card>

        <DialogFooter>
          {isEditing ? (
            <div className="flex gap-2">
              <Button variant="outline" onClick={() => {
                setIsEditing(false);
                setEditedOrder({ ...order });
              }}>
                Cancelar
              </Button>
              <Button onClick={handleSaveOrder}>
                <Save className="w-4 h-4 mr-1" />
                Salvar Alterações
              </Button>
            </div>
          ) : (
            <Button variant="outline" onClick={onClose}>
              Fechar
            </Button>
          )}
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}