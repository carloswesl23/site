import { Card, CardContent } from "@/components/ui/card";
import { Star, TrendingUp, MessageCircle, DollarSign } from "lucide-react";

export const TestimonialsSection = () => {
  const testimonials = [
    {
      name: "Carlos - Pizzaria do Bairro",
      location: "São Paulo, SP",
      result: "+150% vendas",
      quote: "Em 2 meses, minhas vendas aumentaram 150%. O WhatsApp automático é incrível! Não preciso mais do iFood.",
      rating: 5,
      metric: "De R$ 8.000 para R$ 20.000/mês"
    },
    {
      name: "Marina - Burger House",
      location: "Rio de Janeiro, RJ",
      result: "Zero taxas",
      quote: "Economizo R$ 3.500 por mês em taxas do iFood. A LoveMenu já se pagou no primeiro mês!",
      rating: 5,
      metric: "R$ 3.500 economizados/mês"
    },
    {
      name: "Roberto - Lanchonete Central", 
      location: "Belo Horizonte, MG",
      result: "+200 pedidos/mês",
      quote: "Meus clientes adoram pedir pelo WhatsApp. As mensagens automáticas dão um toque profissional.",
      rating: 5,
      metric: "200+ pedidos mensais pelo WhatsApp"
    }
  ];

  const socialProof = [
    { icon: TrendingUp, value: "500+", label: "Restaurantes ativos" },
    { icon: MessageCircle, value: "50K+", label: "Mensagens automáticas/mês" },
    { icon: DollarSign, value: "R$ 2M+", label: "Vendas processadas" }
  ];

  return (
    <section className="py-20 bg-muted/30">
      <div className="container mx-auto px-4">
        <div className="max-w-4xl mx-auto text-center mb-16">
          <h2 className="text-4xl md:text-5xl font-bold text-foreground mb-6">
            Veja os resultados{" "}
            <span className="text-primary">reais dos nossos clientes</span>
          </h2>
          <p className="text-xl text-muted-foreground">
            Estes são apenas alguns dos restaurantes que já transformaram suas vendas:
          </p>
        </div>

        {/* Social proof numbers */}
        <div className="grid md:grid-cols-3 gap-8 max-w-4xl mx-auto mb-16">
          {socialProof.map((item, index) => (
            <div key={index} className="text-center">
              <div className="bg-primary/10 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
                <item.icon className="h-8 w-8 text-primary" />
              </div>
              <div className="text-3xl font-bold text-foreground mb-2">{item.value}</div>
              <div className="text-muted-foreground">{item.label}</div>
            </div>
          ))}
        </div>

        {/* Testimonials */}
        <div className="grid md:grid-cols-3 gap-8 max-w-7xl mx-auto">
          {testimonials.map((testimonial, index) => (
            <Card key={index} className="border-primary/20 hover:border-primary/40 transition-colors duration-300">
              <CardContent className="p-6">
                <div className="space-y-4">
                  {/* Rating */}
                  <div className="flex items-center space-x-1">
                    {[...Array(testimonial.rating)].map((_, i) => (
                      <Star key={i} className="h-4 w-4 fill-yellow-400 text-yellow-400" />
                    ))}
                  </div>
                  
                  {/* Quote */}
                  <p className="text-muted-foreground italic leading-relaxed">
                    "{testimonial.quote}"
                  </p>
                  
                  {/* Result badge */}
                  <div className="inline-flex items-center px-3 py-1 bg-primary/10 text-primary rounded-full text-sm font-semibold">
                    {testimonial.result}
                  </div>
                  
                  {/* Author */}
                  <div className="border-t pt-4">
                    <div className="font-semibold text-foreground">{testimonial.name}</div>
                    <div className="text-sm text-muted-foreground">{testimonial.location}</div>
                    <div className="text-sm font-medium text-primary mt-1">{testimonial.metric}</div>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        <div className="text-center mt-16">
          <div className="inline-flex items-center px-6 py-3 bg-primary/10 text-primary rounded-full">
            <Star className="h-5 w-5 mr-2 fill-current" />
            <span className="font-semibold">98% dos clientes recomendam a LoveMenu</span>
          </div>
        </div>
      </div>
    </section>
  );
};