import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion";

export const FAQSection = () => {
  const faqs = [
    {
      question: "Como funciona o pagamento?",
      answer: "Você paga uma mensalidade fixa de R$ 197/mês. Não cobramos taxa por pedido, diferente dos aplicativos tradicionais. O pagamento é feito via PIX, cartão ou boleto, sempre no início do mês."
    },
    {
      question: "Posso usar o número do meu WhatsApp?",
      answer: "Sim! A LoveMenu funciona com o seu número de WhatsApp atual. Você não precisa mudar de número nem criar uma conta nova. Nosso sistema se integra com sua conta existente."
    },
    {
      question: "Preciso contratar outra ferramenta?",
      answer: "Não! A LoveMenu é uma solução completa. Já incluímos: cardápio digital, sistema de pedidos, integração WhatsApp, pagamentos PIX/cartão, relatórios e mensagens automáticas. Tudo em um só lugar."
    },
    {
      question: "E se eu não vender?",
      answer: "Oferecemos garantia de 7 dias. Se você não estiver satisfeito, devolvemos seu dinheiro. Mas nossa experiência mostra que 98% dos clientes aumentam as vendas já no primeiro mês."
    },
    {
      question: "Como funciona a integração com o WhatsApp?",
      answer: "Nossa integração é feita de forma segura e confiável com o WhatsApp. As mensagens automáticas são enviadas do seu número oficial, mantendo a confiança dos clientes."
    },
    {
      question: "Vocês dão suporte técnico?",
      answer: "Sim! Temos suporte brasileiro via WhatsApp de segunda a sexta, das 9h às 18h. Além disso, fazemos todo o setup inicial da sua conta em até 24 horas."
    },
    {
      question: "Posso cancelar a qualquer momento?",
      answer: "Sim, sem fidelidade! Você pode cancelar quando quiser, sem multas ou taxas de cancelamento. Acreditamos que você vai ficar porque o sistema realmente funciona."
    },
    {
      question: "Meus clientes vão continuar vindo pelos apps?",
      answer: "Muitos restaurantes mantêm os apps e adicionam a LoveMenu para vender direto. Com o tempo, a maioria dos clientes prefere pedir pelo WhatsApp pela facilidade e rapidez."
    }
  ];

  return (
    <section className="py-20">
      <div className="container mx-auto px-4">
        <div className="max-w-4xl mx-auto">
          <div className="text-center mb-16">
            <h2 className="text-4xl md:text-5xl font-bold text-foreground mb-6">
              Dúvidas{" "}
              <span className="text-primary">frequentes</span>
            </h2>
            <p className="text-xl text-muted-foreground">
              Todas as respostas que você precisa para começar hoje mesmo:
            </p>
          </div>

          <Accordion type="single" collapsible className="space-y-4">
            {faqs.map((faq, index) => (
              <AccordionItem 
                key={index} 
                value={`item-${index}`}
                className="border border-border rounded-lg px-6 data-[state=open]:border-primary/40"
              >
                <AccordionTrigger className="text-left hover:no-underline py-6">
                  <span className="text-lg font-semibold text-foreground pr-4">
                    {faq.question}
                  </span>
                </AccordionTrigger>
                <AccordionContent className="pb-6">
                  <p className="text-muted-foreground leading-relaxed">
                    {faq.answer}
                  </p>
                </AccordionContent>
              </AccordionItem>
            ))}
          </Accordion>

          <div className="text-center mt-12">
            <p className="text-lg text-muted-foreground mb-4">
              Ainda tem dúvidas? Fale conosco diretamente:
            </p>
            <button 
              className="inline-flex items-center px-6 py-3 bg-green-600 hover:bg-green-700 text-white rounded-lg font-semibold transition-colors duration-200"
              onClick={() => {
                if (typeof window !== 'undefined' && (window as any).gtag) {
                  (window as any).gtag('event', 'click_support', {
                    event_category: 'engagement',
                    event_label: 'faq_whatsapp'
                  });
                }
                window.open('https://wa.me/5511999999999?text=Tenho%20dúvidas%20sobre%20a%20LoveMenu', '_blank');
              }}
            >
              💬 WhatsApp: (11) 99999-9999
            </button>
          </div>
        </div>
      </div>
    </section>
  );
};