import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Clock, TrendingUp, Users, Zap, ArrowRight } from "lucide-react";
import { useState, useEffect } from "react";

export const UrgencySection = () => {
  const [timeLeft, setTimeLeft] = useState({
    hours: 23,
    minutes: 59,
    seconds: 59
  });

  useEffect(() => {
    const timer = setInterval(() => {
      setTimeLeft(prev => {
        if (prev.seconds > 0) {
          return { ...prev, seconds: prev.seconds - 1 };
        } else if (prev.minutes > 0) {
          return { ...prev, minutes: prev.minutes - 1, seconds: 59 };
        } else if (prev.hours > 0) {
          return { hours: prev.hours - 1, minutes: 59, seconds: 59 };
        } else {
          return { hours: 23, minutes: 59, seconds: 59 };
        }
      });
    }, 1000);

    return () => clearInterval(timer);
  }, []);

  const benefits = [
    {
      icon: TrendingUp,
      title: "Primeira semana grátis",
      description: "Teste por 7 dias sem pagar nada"
    },
    {
      icon: Users,
      title: "Setup prioritário",
      description: "Configuração em menos de 24h"
    },
    {
      icon: Zap,
      title: "Suporte VIP",
      description: "Atendimento direto no WhatsApp"
    }
  ];

  return (
    <section className="py-20 bg-gradient-to-b from-red-50 to-orange-50 relative overflow-hidden">
      {/* Background decorations */}
      <div className="absolute inset-0 bg-grid-pattern opacity-5"></div>
      <div className="absolute top-10 right-10 w-40 h-40 bg-red-200/30 rounded-full blur-3xl floating-animation"></div>
      <div className="absolute bottom-10 left-10 w-56 h-56 bg-orange-200/30 rounded-full blur-3xl floating-animation" style={{animationDelay: '3s'}}></div>
      
      <div className="container mx-auto px-4 relative z-10">
        <div className="max-w-4xl mx-auto text-center mb-12">
          <div className="inline-flex items-center px-6 py-3 bg-red-100 border-2 border-red-200 rounded-2xl shadow-lg mb-8 pulse-glow">
            <Clock className="w-6 h-6 text-red-600 mr-3" />
            <span className="text-red-800 font-bold text-lg">
              ⚡ OFERTA ESPECIAL POR TEMPO LIMITADO!
            </span>
          </div>

          <h2 className="text-4xl md:text-6xl font-bold text-gray-900 mb-6 slide-up">
            <span className="text-red-600">50% OFF</span> no primeiro mês!
          </h2>
          
          <p className="text-xl md:text-2xl text-gray-700 mb-8 fade-in-delay">
            🔥 De R$ 397 por apenas <span className="font-bold text-orange-600">R$ 197/mês</span>
          </p>

          {/* Countdown Timer */}
          <div className="bg-white/90 backdrop-blur-sm rounded-3xl p-8 shadow-2xl mb-12">
            <h3 className="text-2xl font-bold text-gray-900 mb-6">
              ⏰ Esta oferta expira em:
            </h3>
            
            <div className="grid grid-cols-3 gap-4 max-w-md mx-auto">
              <div className="bg-gradient-to-b from-red-500 to-red-600 rounded-2xl p-4 text-white">
                <div className="text-3xl font-bold">{String(timeLeft.hours).padStart(2, '0')}</div>
                <div className="text-sm">Horas</div>
              </div>
              <div className="bg-gradient-to-b from-orange-500 to-orange-600 rounded-2xl p-4 text-white">
                <div className="text-3xl font-bold">{String(timeLeft.minutes).padStart(2, '0')}</div>
                <div className="text-sm">Minutos</div>
              </div>
              <div className="bg-gradient-to-b from-yellow-500 to-yellow-600 rounded-2xl p-4 text-white">
                <div className="text-3xl font-bold">{String(timeLeft.seconds).padStart(2, '0')}</div>
                <div className="text-sm">Segundos</div>
              </div>
            </div>
          </div>
        </div>

        {/* Benefits */}
        <div className="grid md:grid-cols-3 gap-8 max-w-4xl mx-auto mb-12">
          {benefits.map((benefit, index) => (
            <Card key={index} className="border-2 border-orange-200 bg-white/80 hover:shadow-xl transition-all duration-300 transform hover:scale-105">
              <CardContent className="p-6 text-center">
                <div className="bg-gradient-to-r from-orange-400 to-red-500 w-16 h-16 rounded-2xl flex items-center justify-center mx-auto mb-4">
                  <benefit.icon className="h-8 w-8 text-white" />
                </div>
                <h3 className="text-xl font-bold text-gray-900 mb-2">
                  {benefit.title}
                </h3>
                <p className="text-gray-700">
                  {benefit.description}
                </p>
              </CardContent>
            </Card>
          ))}
        </div>

        {/* Call to Action */}
        <div className="text-center">
          <Button 
            size="lg" 
            className="bg-gradient-to-r from-red-500 to-orange-500 text-white px-12 py-8 text-2xl font-bold shadow-2xl hover:shadow-3xl transform hover:scale-110 transition-all duration-300 pulse-glow"
            onClick={() => window.open('https://wa.me/5511999999999?text=Quero%20aproveitar%20a%20oferta%20de%2050%25%20OFF%20da%20LoveMenu!', '_blank')}
          >
            🚀 QUERO APROVEITAR A OFERTA!
            <ArrowRight className="ml-3 h-8 w-8" />
          </Button>
          
          <p className="text-gray-600 mt-6 text-lg">
            ✅ Sem fidelidade • ✅ Cancele quando quiser • ✅ Garantia de 7 dias
          </p>
          
          <div className="mt-8 text-center">
            <div className="inline-flex items-center text-red-600 font-bold text-lg">
              ⚠️ Últimas 12 vagas disponíveis para este mês!
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};