import { Button } from "@/components/ui/button";
import { NavigationMenu, NavigationMenuItem, NavigationMenuLink, NavigationMenuList } from "@/components/ui/navigation-menu";
import { useState } from "react";
import { Menu, X } from "lucide-react";

export const Navigation = () => {
  const [isMenuOpen, setIsMenuOpen] = useState(false);

  const scrollToSection = (sectionId: string) => {
    const element = document.getElementById(sectionId);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
    setIsMenuOpen(false);
  };

  const handleLogin = () => {
    // Track login click
    if (typeof window !== 'undefined' && (window as any).gtag) {
      (window as any).gtag('event', 'click_login', {
        event_category: 'navigation',
        event_label: 'header_login'
      });
    }
    if (typeof window !== 'undefined' && (window as any).fbq) {
      (window as any).fbq('track', 'Lead');
    }
    
    // Redirect to login page
    window.location.href = '/login';
  };

  const navigationItems = [
    { label: 'Home', href: 'hero-section' },
    { label: 'Recursos', href: 'solutions-section' },
    { label: 'Como Funciona', href: 'demo-section' },
    { label: 'Planos', href: 'pricing-section' },
    { label: 'Depoimentos', href: 'testimonials-section' },
  ];

  return (
    <header className="fixed top-0 left-0 right-0 bg-background/95 backdrop-blur-md border-b border-border/50 z-50">
      <div className="container mx-auto px-4">
        <div className="flex items-center justify-between h-16">
          {/* Logo */}
          <div className="flex items-center">
            <button
              onClick={() => scrollToSection('hero-section')}
              className="text-2xl font-bold text-primary hover:text-primary/90 transition-colors"
            >
              LoveMenu
            </button>
          </div>

          {/* Desktop Navigation */}
          <div className="hidden md:flex items-center space-x-8">
            <NavigationMenu>
              <NavigationMenuList className="space-x-6">
                {navigationItems.map((item) => (
                  <NavigationMenuItem key={item.label}>
                    <NavigationMenuLink
                      className="text-sm font-medium text-muted-foreground hover:text-foreground transition-colors cursor-pointer"
                      onClick={() => scrollToSection(item.href)}
                    >
                      {item.label}
                    </NavigationMenuLink>
                  </NavigationMenuItem>
                ))}
              </NavigationMenuList>
            </NavigationMenu>

            {/* Login Button */}
            <Button 
              onClick={handleLogin}
              className="bg-primary text-primary-foreground hover:bg-primary/90 font-medium"
            >
              Entrar
            </Button>
          </div>

          {/* Mobile Menu Button */}
          <button
            className="md:hidden p-2 text-muted-foreground hover:text-foreground"
            onClick={() => setIsMenuOpen(!isMenuOpen)}
          >
            {isMenuOpen ? <X size={24} /> : <Menu size={24} />}
          </button>
        </div>

        {/* Mobile Navigation */}
        {isMenuOpen && (
          <div className="md:hidden bg-background border-t border-border/50">
            <div className="py-4 space-y-4">
              {navigationItems.map((item) => (
                <button
                  key={item.label}
                  onClick={() => scrollToSection(item.href)}
                  className="block w-full text-left px-4 py-2 text-sm font-medium text-muted-foreground hover:text-foreground transition-colors"
                >
                  {item.label}
                </button>
              ))}
              <div className="px-4 pt-2">
                <Button 
                  onClick={handleLogin}
                  className="w-full bg-primary text-primary-foreground hover:bg-primary/90 font-medium"
                >
                  Entrar
                </Button>
              </div>
            </div>
          </div>
        )}
      </div>
    </header>
  );
};