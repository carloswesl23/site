import { Card, CardContent } from "@/components/ui/card";
import { Check, X, AlertTriangle } from "lucide-react";

export const FeatureComparisonSection = () => {
  const features = [
    {
      feature: "Taxa por pedido",
      ifood: { value: "20% a 30%", icon: X, color: "text-red-600" },
      lovemenu: { value: "0%", icon: Check, color: "text-green-600" }
    },
    {
      feature: "Dados dos clientes",
      ifood: { value: "Não tem acesso", icon: X, color: "text-red-600" },
      lovemenu: { value: "Acesso total", icon: Check, color: "text-green-600" }
    },
    {
      feature: "Mensagens automáticas",
      ifood: { value: "Não tem", icon: X, color: "text-red-600" },
      lovemenu: { value: "WhatsApp integrado", icon: Check, color: "text-green-600" }
    },
    {
      feature: "Personalização",
      ifood: { value: "Limitada", icon: AlertTriangle, color: "text-yellow-600" },
      lovemenu: { value: "Total", icon: Check, color: "text-green-600" }
    },
    {
      feature: "Dependência de terceiros",
      ifood: { value: "Total", icon: X, color: "text-red-600" },
      lovemenu: { value: "Zero", icon: Check, color: "text-green-600" }
    },
    {
      feature: "Suporte brasileiro",
      ifood: { value: "Limitado", icon: AlertTriangle, color: "text-yellow-600" },
      lovemenu: { value: "Direto no WhatsApp", icon: Check, color: "text-green-600" }
    }
  ];

  return (
    <section className="py-12 sm:py-16 lg:py-20 bg-gradient-to-b from-gray-50 to-white">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="max-w-5xl mx-auto text-center mb-12 sm:mb-16">
          <h2 className="text-2xl sm:text-3xl md:text-4xl lg:text-6xl font-bold text-gray-900 mb-4 sm:mb-6 slide-up">
            LoveMenu vs. iFood:{" "}
            <span className="text-orange-600">A diferença é gritante!</span>
          </h2>
          <p className="text-lg sm:text-xl lg:text-2xl text-gray-700 fade-in-delay">
            🔥 Veja como você sai perdendo com os apps tradicionais:
          </p>
        </div>

        <div className="max-w-4xl mx-auto">
          <Card className="overflow-hidden shadow-2xl border-2 border-gray-200">
            <CardContent className="p-0">
              <div className="grid grid-cols-3 bg-gradient-to-r from-red-500 to-orange-500 text-white font-bold">
                <div className="p-3 sm:p-4 lg:p-6 text-center"></div>
                <div className="p-3 sm:p-4 lg:p-6 text-center border-l border-white/20">
                  <div className="text-lg sm:text-xl lg:text-2xl">😤 iFood</div>
                  <div className="text-xs sm:text-sm mt-1 sm:mt-2">Apps tradicionais</div>
                </div>
                <div className="p-3 sm:p-4 lg:p-6 text-center border-l border-white/20">
                  <div className="text-lg sm:text-xl lg:text-2xl">🚀 LoveMenu</div>
                  <div className="text-xs sm:text-sm mt-1 sm:mt-2">Independência total</div>
                </div>
              </div>

              {features.map((item, index) => (
                <div key={index} className={`grid grid-cols-3 ${index % 2 === 0 ? 'bg-gray-50' : 'bg-white'} hover:bg-blue-50 transition-colors duration-300`}>
                  <div className="p-3 sm:p-4 lg:p-6 font-medium text-gray-900 border-r border-gray-200 text-sm sm:text-base">
                    {item.feature}
                  </div>
                  <div className="p-3 sm:p-4 lg:p-6 text-center border-r border-gray-200">
                    <div className={`flex items-center justify-center gap-1 sm:gap-2 ${item.ifood.color}`}>
                      <item.ifood.icon className="w-4 sm:w-5 h-4 sm:h-5" />
                      <span className="font-medium text-xs sm:text-sm lg:text-base">{item.ifood.value}</span>
                    </div>
                  </div>
                  <div className="p-3 sm:p-4 lg:p-6 text-center">
                    <div className={`flex items-center justify-center gap-1 sm:gap-2 ${item.lovemenu.color}`}>
                      <item.lovemenu.icon className="w-4 sm:w-5 h-4 sm:h-5" />
                      <span className="font-medium text-xs sm:text-sm lg:text-base">{item.lovemenu.value}</span>
                    </div>
                  </div>
                </div>
              ))}

              <div className="bg-gradient-to-r from-green-500 to-blue-500 text-white p-4 sm:p-6 lg:p-8 text-center">
                <h3 className="text-lg sm:text-xl lg:text-2xl font-bold mb-1 sm:mb-2">💰 Economia anual estimada</h3>
                <div className="text-2xl sm:text-3xl lg:text-4xl font-bold">R$ 36.000,00</div>
                <p className="text-sm sm:text-base lg:text-lg mt-1 sm:mt-2">em taxas que você para de pagar!</p>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </section>
  );
};