import { Button } from "@/components/ui/button";
import { ArrowRight, Play, Star, Users, Zap, TrendingUp } from "lucide-react";
import { useState, useEffect } from "react";
import happyOwnerImage from "@/assets/happy-restaurant-owner.jpg";

export const HeroSection = () => {
  const [restaurantCount, setRestaurantCount] = useState(0);
  const [orderCount, setOrderCount] = useState(0);

  useEffect(() => {
    // Animate counters
    const restaurantTimer = setInterval(() => {
      setRestaurantCount(prev => prev < 500 ? prev + 15 : 500);
    }, 50);
    
    const orderTimer = setInterval(() => {
      setOrderCount(prev => prev < 25000 ? prev + 750 : 25000);
    }, 50);

    return () => {
      clearInterval(restaurantTimer);
      clearInterval(orderTimer);
    };
  }, []);

  const handleStartNow = () => {
    // Track conversion event
    if (typeof window !== 'undefined' && (window as any).gtag) {
      (window as any).gtag('event', 'click_start_now', {
        event_category: 'conversion',
        event_label: 'hero_cta'
      });
    }
    if (typeof window !== 'undefined' && (window as any).fbq) {
      (window as any).fbq('track', 'Lead');
    }
    
    // Redirect to WhatsApp or signup
    window.open('https://wa.me/5511999999999?text=Quero%20começar%20com%20a%20LoveMenu', '_blank');
  };

  const handleDemo = () => {
    // Track demo click
    if (typeof window !== 'undefined' && (window as any).gtag) {
      (window as any).gtag('event', 'click_demo', {
        event_category: 'engagement',
        event_label: 'hero_demo'
      });
    }
    
    document.getElementById('demo-section')?.scrollIntoView({ behavior: 'smooth' });
  };

  return (
    <section className="relative min-h-screen flex items-center justify-center bg-gradient-to-br from-orange-50 via-white to-red-50 overflow-hidden">
      {/* Background decoration */}
      <div className="absolute inset-0 bg-grid-pattern opacity-5"></div>
      
      <div className="container mx-auto px-4 sm:px-6 lg:px-8 py-12 sm:py-16 lg:py-20 relative z-10">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 lg:gap-12 items-center max-w-7xl mx-auto">
          {/* Left side - Content */}
          <div className="space-y-6 sm:space-y-8 text-center lg:text-left order-2 lg:order-1">
            {/* Main headline */}
            <h1 className="text-3xl sm:text-4xl md:text-5xl lg:text-6xl font-bold text-gray-900 leading-tight slide-up">
              Transforme seu restaurante em uma{" "}
              <span className="text-orange-600 font-bold">
                máquina de vendas!
              </span>
            </h1>
          
            {/* Subheadline */}
            <p className="text-base sm:text-lg md:text-xl text-gray-700 leading-relaxed fade-in-delay">
              Tenha seu próprio cardápio digital com sistema de pedidos e mensagens automáticas no WhatsApp — 
              <strong className="text-orange-600 font-bold"> sem taxas absurdas como iFood!</strong>
            </p>
          
            {/* CTAs */}
            <div className="flex flex-col items-center justify-center lg:justify-start gap-4 pt-6 sm:pt-8 fade-in-delay">
              <Button 
                size="lg" 
                className="w-full sm:w-auto text-base sm:text-lg px-6 sm:px-10 py-4 sm:py-7 bg-orange-500 hover:bg-orange-600 text-white shadow-2xl hover:shadow-3xl transform hover:scale-105 transition-all duration-300 group"
                onClick={handleStartNow}
              >
                🚀 Comece agora por R$197/mês
                <ArrowRight className="ml-2 sm:ml-3 h-5 sm:h-6 w-5 sm:w-6 group-hover:translate-x-2 transition-transform" />
              </Button>
              
              <Button 
                variant="outline" 
                size="lg" 
                className="w-full sm:w-auto text-base sm:text-lg px-6 sm:px-10 py-4 sm:py-7 border-2 border-gray-400 text-gray-700 hover:bg-gray-50 hover:scale-105 transition-all duration-300 group"
                onClick={() => window.open('https://wa.me/5511999999999?text=Preciso%20de%20suporte%20com%20a%20LoveMenu', '_blank')}
              >
                📞 Entrar em contato com o suporte
              </Button>
            </div>
          
            {/* Trust indicators */}
            <div className="pt-8 sm:pt-12 text-center lg:text-left fade-in-delay">
              <p className="text-base sm:text-lg text-gray-600 mb-4 sm:mb-6 font-medium">🏆 Já escolhido por centenas de restaurantes brasileiros</p>
              
              {/* Feature badges */}
              <div className="flex flex-wrap items-center justify-center lg:justify-start gap-2 sm:gap-4 text-xs sm:text-sm">
                <div className="flex items-center px-3 sm:px-4 py-2 bg-green-100 text-green-800 rounded-full font-medium">
                  ✅ Zero taxas por pedido
                </div>
                <div className="flex items-center px-3 sm:px-4 py-2 bg-blue-100 text-blue-800 rounded-full font-medium">
                  📱 WhatsApp integrado
                </div>
                <div className="flex items-center px-3 sm:px-4 py-2 bg-purple-100 text-purple-800 rounded-full font-medium">
                  ⚡ Setup em 24h
                </div>
              </div>
            </div>
          </div>

          {/* Right side - Image */}
          <div className="relative order-1 lg:order-2">
            <div className="relative rounded-3xl overflow-hidden shadow-2xl transform hover:scale-105 transition-all duration-500">
              <img 
                src={happyOwnerImage} 
                alt="Empresário feliz em seu restaurante de sucesso"
                className="w-full h-[300px] sm:h-[400px] lg:h-[500px] object-cover"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black/20 to-transparent"></div>
              
              {/* Floating stats */}
              <div className="absolute top-3 sm:top-6 left-3 sm:left-6 bg-white/90 backdrop-blur-sm rounded-xl sm:rounded-2xl p-3 sm:p-4 shadow-lg">
                <div className="flex items-center mb-1 sm:mb-2">
                  <Users className="w-4 sm:w-5 h-4 sm:h-5 text-orange-600 mr-1 sm:mr-2" />
                  <span className="text-lg sm:text-2xl font-bold stats-counter">{restaurantCount}</span>
                </div>
                <p className="text-xs sm:text-sm text-gray-700 font-medium">Restaurantes ativos</p>
              </div>
              
              <div className="absolute bottom-3 sm:bottom-6 right-3 sm:right-6 bg-white/90 backdrop-blur-sm rounded-xl sm:rounded-2xl p-3 sm:p-4 shadow-lg">
                <div className="flex items-center mb-1 sm:mb-2">
                  <TrendingUp className="w-4 sm:w-5 h-4 sm:h-5 text-green-600 mr-1 sm:mr-2" />
                  <span className="text-lg sm:text-2xl font-bold stats-counter">{orderCount.toLocaleString()}</span>
                </div>
                <p className="text-xs sm:text-sm text-gray-700 font-medium">Pedidos processados</p>
              </div>
            </div>
            
            {/* Decorative elements */}
            <div className="absolute -top-4 -right-4 w-20 h-20 bg-orange-200/30 rounded-full blur-2xl floating-animation"></div>
            <div className="absolute -bottom-4 -left-4 w-32 h-32 bg-red-200/30 rounded-full blur-3xl floating-animation" style={{animationDelay: '2s'}}></div>
          </div>
        </div>
      </div>
    </section>
  );
};