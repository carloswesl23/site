import { useEffect } from 'react';

export const TrackingPixels = () => {
  useEffect(() => {
    // Google Analytics 4
    const gtagScript = document.createElement('script');
    gtagScript.async = true;
    gtagScript.src = 'https://www.googletagmanager.com/gtag/js?id=GA_MEASUREMENT_ID';
    document.head.appendChild(gtagScript);

    gtagScript.onload = () => {
      // Initialize Google Analytics
      (window as any).dataLayer = (window as any).dataLayer || [];
      function gtag(...args: any[]) {
        (window as any).dataLayer.push(args);
      }
      (window as any).gtag = gtag;
      
      gtag('js', new Date());
      gtag('config', 'GA_MEASUREMENT_ID', {
        page_title: 'LoveMenu - Landing Page',
        page_location: window.location.href,
        custom_map: { dimension1: 'landing_visitor' }
      });

      // Track page view
      gtag('event', 'page_view', {
        page_title: 'LoveMenu Landing Page',
        page_location: window.location.href,
        content_group1: 'Landing'
      });
    };

    // Facebook Pixel
    const fbScript = document.createElement('script');
    fbScript.innerHTML = `
      !function(f,b,e,v,n,t,s)
      {if(f.fbq)return;n=f.fbq=function(){n.callMethod?
      n.callMethod.apply(n,arguments):n.queue.push(arguments)};
      if(!f._fbq)f._fbq=n;n.push=n;n.loaded=!0;n.version='2.0';
      n.queue=[];t=b.createElement(e);t.async=!0;
      t.src=v;s=b.getElementsByTagName(e)[0];
      s.parentNode.insertBefore(t,s)}(window, document,'script',
      'https://connect.facebook.net/en_US/fbevents.js');
      fbq('init', 'FACEBOOK_PIXEL_ID');
      fbq('track', 'PageView');
      fbq('track', 'ViewContent', {
        content_name: 'LoveMenu Landing Page',
        content_category: 'Restaurant Solution'
      });
    `;
    document.head.appendChild(fbScript);

    // Cleanup
    return () => {
      document.head.removeChild(gtagScript);
      document.head.removeChild(fbScript);
    };
  }, []);

  return (
    <>
      {/* Facebook Pixel noscript */}
      <noscript>
        <img 
          height="1" 
          width="1" 
          style={{ display: 'none' }}
          src="https://www.facebook.com/tr?id=FACEBOOK_PIXEL_ID&ev=PageView&noscript=1"
          alt=""
        />
      </noscript>
    </>
  );
};