import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Check, ArrowRight, Zap } from "lucide-react";

export const PricingSection = () => {
  const features = [
    "Cardápio digital completo",
    "Integração com WhatsApp",
    "Painel com CRM dos clientes",
    "Mensagens automáticas",
    "Pixel do Facebook e Google",
    "Sistema de upsell e combos",
    "Relatórios de vendas",
    "Suporte via WhatsApp",
    "Atualizações gratuitas",
    "Zero taxas por pedido"
  ];

  const handleSubscribe = () => {
    // Track conversion event
    if (typeof window !== 'undefined' && (window as any).gtag) {
      (window as any).gtag('event', 'click_subscribe', {
        event_category: 'conversion',
        event_label: 'pricing_cta',
        value: 197
      });
    }
    if (typeof window !== 'undefined' && (window as any).fbq) {
      (window as any).fbq('track', 'Purchase', {
        value: 197,
        currency: 'BRL'
      });
    }
    
    window.open('https://wa.me/5511999999999?text=Quero%20começar%20com%20a%20LoveMenu%20por%20R$197/mês', '_blank');
  };

  return (
    <section className="py-20">
      <div className="container mx-auto px-4">
        <div className="max-w-4xl mx-auto text-center mb-16">
          <h2 className="text-4xl md:text-5xl font-bold text-foreground mb-6">
            Plano único –{" "}
            <span className="text-primary">R$ 197/mês</span>
          </h2>
          <p className="text-xl text-muted-foreground">
            Um valor fixo, simples e direto. Sem surpresas, sem taxas por pedido.
          </p>
        </div>

        <div className="max-w-2xl mx-auto">
          <Card className="border-primary/20 shadow-xl relative overflow-hidden">
            {/* Popular badge */}
            <div className="absolute top-0 right-0 bg-primary text-primary-foreground px-6 py-2 text-sm font-semibold">
              MAIS ESCOLHIDO
            </div>
            
            <CardContent className="p-8 md:p-12">
              <div className="text-center mb-8">
                <div className="flex items-center justify-center mb-4">
                  <Zap className="h-8 w-8 text-primary mr-2" />
                  <h3 className="text-2xl font-bold text-foreground">LoveMenu Completo</h3>
                </div>
                
                <div className="mb-6">
                  <span className="text-5xl md:text-6xl font-bold text-foreground">R$ 197</span>
                  <span className="text-xl text-muted-foreground">/mês</span>
                </div>
                
                <p className="text-muted-foreground">
                  Tudo que você precisa para vender online sem taxas abusivas
                </p>
              </div>

              <div className="space-y-4 mb-8">
                {features.map((feature, index) => (
                  <div key={index} className="flex items-center space-x-3">
                    <div className="bg-primary/10 rounded-full p-1">
                      <Check className="h-4 w-4 text-primary" />
                    </div>
                    <span className="text-foreground">{feature}</span>
                  </div>
                ))}
              </div>

              <Button 
                size="lg" 
                className="w-full text-lg py-6 group shadow-lg hover:shadow-xl transition-all duration-300"
                onClick={handleSubscribe}
              >
                Quero começar agora
                <ArrowRight className="ml-2 h-5 w-5 group-hover:translate-x-1 transition-transform" />
              </Button>

              <div className="text-center mt-6 space-y-2">
                <p className="text-sm text-muted-foreground">
                  ✅ Sem fidelidade • ✅ Cancele quando quiser • ✅ Suporte incluído
                </p>
                <p className="text-xs text-muted-foreground">
                  * Primeiro mês com 50% de desconto para novos clientes
                </p>
              </div>
            </CardContent>
          </Card>
        </div>

        <div className="text-center mt-12">
          <div className="inline-flex items-center space-x-8 text-sm text-muted-foreground">
            <div className="flex items-center">
              <div className="w-2 h-2 bg-green-500 rounded-full mr-2"></div>
              <span>Setup em 24h</span>
            </div>
            <div className="flex items-center">
              <div className="w-2 h-2 bg-green-500 rounded-full mr-2"></div>
              <span>Garantia de 7 dias</span>
            </div>
            <div className="flex items-center">
              <div className="w-2 h-2 bg-green-500 rounded-full mr-2"></div>
              <span>Suporte brasileiro</span>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};