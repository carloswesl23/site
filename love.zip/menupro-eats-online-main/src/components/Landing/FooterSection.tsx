import { MessageCircle, Instagram, Mail, MapPin } from "lucide-react";

export const FooterSection = () => {
  return (
    <footer className="bg-foreground text-background py-16">
      <div className="container mx-auto px-4">
        <div className="grid md:grid-cols-4 gap-8 max-w-6xl mx-auto">
          {/* Logo and description */}
          <div className="md:col-span-2 space-y-4">
            <h3 className="text-2xl font-bold text-primary">LoveMenu</h3>
            <p className="text-muted text-lg leading-relaxed">
              A solução completa para restaurantes venderem online pelo WhatsApp, 
              sem taxas abusivas e com total controle sobre seus clientes.
            </p>
            <div className="flex items-center space-x-2 text-sm text-muted">
              <MapPin className="h-4 w-4" />
              <span>São Paulo, Brasil</span>
            </div>
          </div>

          {/* Quick links */}
          <div>
            <h4 className="font-semibold mb-4 text-primary">Links Rápidos</h4>
            <div className="space-y-2">
              <a href="#hero" className="block text-muted hover:text-background transition-colors">
                Início
              </a>
              <a href="#demo-section" className="block text-muted hover:text-background transition-colors">
                Demonstração
              </a>
              <a href="#" className="block text-muted hover:text-background transition-colors">
                Planos
              </a>
              <a href="#" className="block text-muted hover:text-background transition-colors">
                Suporte
              </a>
            </div>
          </div>

          {/* Contact */}
          <div>
            <h4 className="font-semibold mb-4 text-primary">Contato</h4>
            <div className="space-y-3">
              <a 
                href="https://wa.me/5511999999999" 
                target="_blank" 
                rel="noopener noreferrer"
                className="flex items-center space-x-2 text-muted hover:text-background transition-colors"
              >
                <MessageCircle className="h-4 w-4" />
                <span>(11) 99999-9999</span>
              </a>
              <a 
                href="https://instagram.com/lovemenu" 
                target="_blank" 
                rel="noopener noreferrer"
                className="flex items-center space-x-2 text-muted hover:text-background transition-colors"
              >
                <Instagram className="h-4 w-4" />
                <span>@lovemenu</span>
              </a>
              <a 
                href="mailto:contato@lovemenu.com.br"
                className="flex items-center space-x-2 text-muted hover:text-background transition-colors"
              >
                <Mail className="h-4 w-4" />
                <span>contato@lovemenu.com.br</span>
              </a>
            </div>
          </div>
        </div>

        {/* Bottom section */}
        <div className="border-t border-muted/20 mt-12 pt-8">
          <div className="flex flex-col md:flex-row justify-between items-center space-y-4 md:space-y-0">
            <div className="text-sm text-muted">
              © 2024 LoveMenu. Todos os direitos reservados.
            </div>
            <div className="flex items-center space-x-6 text-sm">
              <a href="#" className="text-muted hover:text-background transition-colors">
                Termos de Uso
              </a>
              <a href="#" className="text-muted hover:text-background transition-colors">
                Política de Privacidade
              </a>
              <a href="#" className="text-muted hover:text-background transition-colors">
                LGPD
              </a>
            </div>
          </div>
        </div>
      </div>
    </footer>
  );
};