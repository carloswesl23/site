import { Card, CardContent } from "@/components/ui/card";
import { ArrowRight, Clock, Smartphone, Rocket, CheckCircle } from "lucide-react";

export const ProcessSection = () => {
  const steps = [
    {
      number: "01",
      title: "Cadastre-se",
      description: "Entre em contato pelo WhatsApp e defina os detalhes do seu restaurante",
      icon: Smartphone,
      color: "from-blue-400 to-blue-600",
      time: "5 minutos"
    },
    {
      number: "02", 
      title: "Configuração",
      description: "Nossa equipe configura seu cardápio e integra com o WhatsApp",
      icon: Clock,
      color: "from-purple-400 to-purple-600",
      time: "24 horas"
    },
    {
      number: "03",
      title: "Lançamento",
      description: "Seu restaurante online está pronto para receber pedidos!",
      icon: Rocket,
      color: "from-green-400 to-green-600", 
      time: "Imediato"
    },
    {
      number: "04",
      title: "Vendas",
      description: "Comece a vender sem taxas e com mensagens automáticas",
      icon: CheckCircle,
      color: "from-orange-400 to-orange-600",
      time: "Para sempre"
    }
  ];

  return (
    <section className="py-20 bg-gradient-to-b from-blue-50 to-purple-50 relative overflow-hidden">
      {/* Background decorations */}
      <div className="absolute top-10 left-10 w-32 h-32 bg-blue-200/30 rounded-full blur-2xl floating-animation"></div>
      <div className="absolute bottom-10 right-10 w-48 h-48 bg-purple-200/30 rounded-full blur-3xl floating-animation" style={{animationDelay: '2s'}}></div>
      
      <div className="container mx-auto px-4 relative z-10">
        <div className="max-w-4xl mx-auto text-center mb-16">
          <h2 className="text-4xl md:text-6xl font-bold text-gray-900 mb-6 slide-up">
            Como funciona?{" "}
            <span className="bg-gradient-to-r from-blue-600 to-purple-600 bg-clip-text text-transparent">
              É mais fácil do que imagina!
            </span>
          </h2>
          <p className="text-xl md:text-2xl text-gray-700 fade-in-delay">
            ⚡ Em apenas 4 passos simples, você está vendendo online:
          </p>
        </div>

        <div className="max-w-6xl mx-auto">
          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
            {steps.map((step, index) => (
              <div key={index} className="relative">
                {/* Connector line */}
                {index < steps.length - 1 && (
                  <div className="hidden lg:block absolute top-1/2 -right-4 w-8 h-0.5 bg-gray-300 z-0">
                    <ArrowRight className="absolute -top-2 right-0 w-4 h-4 text-gray-400" />
                  </div>
                )}
                
                <Card className="h-full border-2 border-gray-200 hover:border-blue-300 hover:shadow-2xl transition-all duration-500 transform hover:scale-105 group fade-in-delay" style={{animationDelay: `${index * 0.2}s`}}>
                  <CardContent className="p-8 text-center h-full flex flex-col">
                    {/* Step number */}
                    <div className={`w-16 h-16 rounded-full bg-gradient-to-r ${step.color} text-white text-2xl font-bold flex items-center justify-center mx-auto mb-6 group-hover:scale-110 transition-transform duration-300 shadow-lg`}>
                      {step.number}
                    </div>

                    {/* Icon */}
                    <div className="mb-4">
                      <step.icon className="w-12 h-12 text-gray-600 mx-auto group-hover:text-blue-600 transition-colors duration-300" />
                    </div>

                    {/* Content */}
                    <div className="flex-1">
                      <h3 className="text-xl font-bold text-gray-900 mb-3 group-hover:text-blue-700 transition-colors">
                        {step.title}
                      </h3>
                      
                      <p className="text-gray-700 leading-relaxed mb-4">
                        {step.description}
                      </p>
                    </div>

                    {/* Time badge */}
                    <div className={`inline-flex items-center px-3 py-1 bg-gradient-to-r ${step.color} text-white rounded-full text-sm font-bold`}>
                      <Clock className="w-4 h-4 mr-2" />
                      {step.time}
                    </div>
                  </CardContent>
                </Card>
              </div>
            ))}
          </div>
        </div>

        <div className="text-center mt-16">
          <div className="bg-white/80 backdrop-blur-sm rounded-3xl p-8 shadow-2xl max-w-2xl mx-auto">
            <h3 className="text-2xl font-bold text-gray-900 mb-4">
              ⏰ Pronto em menos de 24 horas!
            </h3>
            <p className="text-gray-700 mb-6">
              Enquanto outros demoram semanas, você está vendendo amanhã mesmo
            </p>
            <div className="text-4xl">🚀💨</div>
          </div>
        </div>
      </div>
    </section>
  );
};