import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Play, Smartphone, MessageCircle, BarChart3 } from "lucide-react";

export const DemoSection = () => {
  const features = [
    "Cadastro de produtos em 30 segundos",
    "Recebimento automático no WhatsApp",
    "Painel de controle intuitivo",
    "Mensagens automáticas personalizadas"
  ];

  return (
    <section id="demo-section" className="py-20 bg-muted/30">
      <div className="container mx-auto px-4">
        <div className="max-w-6xl mx-auto">
          <div className="text-center mb-16">
            <h2 className="text-4xl md:text-5xl font-bold text-foreground mb-6">
              Veja como é{" "}
              <span className="text-primary">simples e poderoso</span>
            </h2>
            <p className="text-xl text-muted-foreground">
              Em poucos minutos você terá seu restaurante online vendendo pelo WhatsApp
            </p>
          </div>

          <div className="grid lg:grid-cols-2 gap-12 items-center">
            {/* Demo Video/Image */}
            <div className="relative">
              <Card className="overflow-hidden">
                <CardContent className="p-0">
                  <div className="aspect-video bg-gradient-to-br from-primary/10 to-secondary/10 flex items-center justify-center relative group cursor-pointer">
                    <div className="absolute inset-0 bg-black/20 group-hover:bg-black/30 transition-colors duration-300"></div>
                    <Button 
                      size="lg" 
                      className="relative z-10 rounded-full w-16 h-16 group-hover:scale-110 transition-transform duration-300"
                    >
                      <Play className="h-6 w-6" />
                    </Button>
                    
                    {/* Mock interface */}
                    <div className="absolute inset-4 bg-background rounded-lg opacity-80 flex flex-col">
                      <div className="h-8 bg-primary/10 rounded-t-lg flex items-center px-4">
                        <div className="flex space-x-2">
                          <div className="w-3 h-3 bg-red-400 rounded-full"></div>
                          <div className="w-3 h-3 bg-yellow-400 rounded-full"></div>
                          <div className="w-3 h-3 bg-green-400 rounded-full"></div>
                        </div>
                      </div>
                      <div className="flex-1 p-4 space-y-3">
                        <div className="h-4 bg-muted rounded w-3/4"></div>
                        <div className="h-3 bg-muted rounded w-1/2"></div>
                        <div className="h-8 bg-primary/20 rounded"></div>
                        <div className="h-3 bg-muted rounded w-2/3"></div>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
              
              {/* Floating elements */}
              <div className="absolute -top-4 -right-4 bg-background border-2 border-primary/20 rounded-full p-3 shadow-lg">
                <Smartphone className="h-6 w-6 text-primary" />
              </div>
              <div className="absolute -bottom-4 -left-4 bg-background border-2 border-primary/20 rounded-full p-3 shadow-lg">
                <MessageCircle className="h-6 w-6 text-primary" />
              </div>
            </div>

            {/* Features List */}
            <div className="space-y-8">
              <div>
                <h3 className="text-2xl font-bold text-foreground mb-4">
                  Demonstração ao vivo:
                </h3>
                <p className="text-muted-foreground text-lg">
                  Veja na prática como funciona o cadastro de produtos, 
                  recebimento de pedidos e envio automático de mensagens.
                </p>
              </div>

              <div className="space-y-4">
                {features.map((feature, index) => (
                  <div key={index} className="flex items-center space-x-3">
                    <div className="bg-primary/10 rounded-full p-1">
                      <BarChart3 className="h-4 w-4 text-primary" />
                    </div>
                    <span className="text-foreground font-medium">{feature}</span>
                  </div>
                ))}
              </div>

              <Button 
                size="lg" 
                className="w-full sm:w-auto px-8 py-6 text-lg"
                onClick={() => {
                  if (typeof window !== 'undefined' && (window as any).gtag) {
                    (window as any).gtag('event', 'click_demo_cta', {
                      event_category: 'engagement',
                      event_label: 'demo_section'
                    });
                  }
                  window.open('https://wa.me/5511999999999?text=Quero%20ver%20uma%20demonstração%20da%20LoveMenu', '_blank');
                }}
              >
                <Play className="mr-2 h-5 w-5" />
                Agendar demonstração gratuita
              </Button>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};