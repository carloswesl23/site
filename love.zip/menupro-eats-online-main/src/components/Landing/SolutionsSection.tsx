import { Target, TrendingUp, ShoppingCart, BarChart3, Bot, DollarSign, Package, CheckCircle } from "lucide-react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { useState } from "react";

export const SolutionsSection = () => {
  const [activeCard, setActiveCard] = useState<number | null>(null);

  const solutions = [
    {
      icon: Target,
      title: "Venda direta pelo WhatsApp",
      description: "Seus clientes fazem pedidos direto no seu WhatsApp, sem intermediários.",
      color: "text-green-600",
      bgColor: "bg-green-50",
      borderColor: "border-green-200",
      benefit: "100% dos lucros para você",
      gradient: "from-green-400 to-emerald-500"
    },
    {
      icon: TrendingUp,
      title: "Checkout com Pix, Cartão e Dinheiro",
      description: "Aceite todas as formas de pagamento com segurança total.",
      color: "text-blue-600",
      bgColor: "bg-blue-50",
      borderColor: "border-blue-200",
      benefit: "Conversão 40% maior",
      gradient: "from-blue-400 to-cyan-500"
    },
    {
      icon: ShoppingCart,
      title: "Sistema de Upsell inteligente",
      description: "Aumente o ticket médio automaticamente com sugestões personalizadas.",
      color: "text-purple-600",
      bgColor: "bg-purple-50",
      borderColor: "border-purple-200",
      benefit: "+35% no ticket médio",
      gradient: "from-purple-400 to-pink-500"
    },
    {
      icon: BarChart3,
      title: "Painel com relatórios de vendas",
      description: "Controle total sobre suas vendas, clientes e performance.",
      color: "text-orange-600",
      bgColor: "bg-orange-50",
      borderColor: "border-orange-200",
      benefit: "Decisões inteligentes",
      gradient: "from-orange-400 to-red-500"
    },
    {
      icon: Bot,
      title: "Mensagens automáticas no WhatsApp",
      description: "Confirmação, preparo e entrega automáticos via WhatsApp.",
      color: "text-emerald-600",
      bgColor: "bg-emerald-50",
      borderColor: "border-emerald-200",
      benefit: "Atendimento 24/7",
      gradient: "from-emerald-400 to-teal-500"
    },
    {
      icon: DollarSign,
      title: "Zero taxas por pedido",
      description: "Pague apenas a mensalidade fixa. Todo o resto é seu!",
      color: "text-yellow-600",
      bgColor: "bg-yellow-50",
      borderColor: "border-yellow-200",
      benefit: "Economia de milhares",
      gradient: "from-yellow-400 to-orange-500"
    }
  ];

  return (
    <section className="py-12 sm:py-16 lg:py-20 bg-gradient-to-b from-green-50 to-blue-50 relative overflow-hidden">
      {/* Background decorations */}
      <div className="absolute top-20 right-10 w-40 h-40 bg-green-200/20 rounded-full blur-3xl floating-animation"></div>
      <div className="absolute bottom-20 left-10 w-56 h-56 bg-blue-200/20 rounded-full blur-3xl floating-animation" style={{animationDelay: '2s'}}></div>
      
      <div className="container mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        <div className="max-w-5xl mx-auto text-center mb-12 sm:mb-16">
          <h2 className="text-2xl sm:text-3xl md:text-4xl lg:text-6xl font-bold text-gray-900 mb-4 sm:mb-6 slide-up">
            Com a LoveMenu, você tem{" "}
            <span className="bg-gradient-to-r from-green-600 to-blue-600 bg-clip-text text-transparent">
              liberdade, vendas e controle total.
            </span>
          </h2>
          <p className="text-lg sm:text-xl lg:text-2xl text-gray-700 fade-in-delay">
            ✨ Tudo que você precisa para vender mais, sem depender de ninguém:
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 sm:gap-8 max-w-7xl mx-auto mb-12 sm:mb-16">
          {solutions.map((solution, index) => (
            <Card 
              key={index} 
              className={`${solution.borderColor} ${solution.bgColor} border-2 hover:shadow-2xl transition-all duration-500 transform hover:scale-110 group cursor-pointer fade-in-delay ${
                activeCard === index ? 'scale-105 shadow-2xl' : ''
              }`}
              style={{animationDelay: `${index * 0.1}s`}}
              onMouseEnter={() => setActiveCard(index)}
              onMouseLeave={() => setActiveCard(null)}
            >
              <CardContent className="p-4 sm:p-6 lg:p-8 h-full">
                <div className="space-y-4 sm:space-y-6 h-full flex flex-col">
                  <div className="flex items-center justify-between">
                    <div className={`bg-gradient-to-r ${solution.gradient} w-12 sm:w-14 lg:w-16 h-12 sm:h-14 lg:h-16 rounded-xl sm:rounded-2xl flex items-center justify-center group-hover:scale-110 transition-transform duration-300 shadow-lg`}>
                      <solution.icon className="h-6 sm:h-7 lg:h-8 w-6 sm:w-7 lg:w-8 text-white" />
                    </div>
                    <div className={`px-2 sm:px-3 py-1 bg-gradient-to-r ${solution.gradient} text-white rounded-full text-xs font-bold shadow-md`}>
                      {solution.benefit}
                    </div>
                  </div>
                  
                  <div className="flex-1">
                    <h3 className="text-lg sm:text-xl font-bold text-gray-900 mb-2 sm:mb-3 group-hover:text-gray-700 transition-colors">
                      {solution.title}
                    </h3>
                    
                    <p className="text-sm sm:text-base text-gray-700 leading-relaxed">
                      {solution.description}
                    </p>
                  </div>

                  <div className="flex items-center text-xs sm:text-sm font-medium text-green-700">
                    <CheckCircle className="w-3 sm:w-4 h-3 sm:h-4 mr-1 sm:mr-2" />
                    Incluído no plano
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        <div className="text-center">
          <div className="bg-white/80 backdrop-blur-sm rounded-2xl sm:rounded-3xl p-4 sm:p-6 lg:p-8 shadow-2xl max-w-2xl mx-auto">
            <h3 className="text-lg sm:text-xl lg:text-2xl font-bold text-gray-900 mb-3 sm:mb-4">
              🚀 Sua independência começa aqui!
            </h3>
            <p className="text-sm sm:text-base text-gray-700 mb-4 sm:mb-6">
              Pare de pagar taxas abusivas e tenha controle total do seu negócio
            </p>
            <Button 
              size="lg" 
              className="w-full sm:w-auto bg-gradient-to-r from-green-500 to-blue-500 text-white px-6 sm:px-8 py-3 sm:py-4 text-base sm:text-lg font-bold shadow-xl hover:shadow-2xl transform hover:scale-105 transition-all duration-300"
              onClick={() => window.open('https://wa.me/5511999999999?text=Quero%20ter%20independência%20total%20com%20a%20LoveMenu', '_blank')}
            >
              Começar agora mesmo
              <Target className="ml-2 h-4 sm:h-5 w-4 sm:w-5" />
            </Button>
          </div>
        </div>
      </div>
    </section>
  );
};