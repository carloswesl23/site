import { AlertTriangle, TrendingDown, Users, Wifi, X, Timer, CreditCard } from "lucide-react";
import { Card, CardContent } from "@/components/ui/card";
import { useState, useEffect } from "react";

export const ProblemsSection = () => {
  const [lostMoney, setLostMoney] = useState(0);
  
  useEffect(() => {
    const timer = setInterval(() => {
      setLostMoney(prev => prev + 147); // Simula dinheiro perdido em tempo real
    }, 100);
    
    return () => clearInterval(timer);
  }, []);

  const problems = [
    {
      icon: TrendingDown,
      title: "Taxas de 20% a 30% por pedido?",
      description: "Apps como iFood cobram comissões altíssimas que destroem sua margem de lucro.",
      color: "text-red-600",
      bgColor: "bg-red-50",
      borderColor: "border-red-200",
      stat: "Até R$ 3.000/mês em taxas"
    },
    {
      icon: Users,
      title: "Nenhum controle sobre seus clientes?",
      description: "Você não tem acesso aos dados dos seus clientes para fidelização.",
      color: "text-orange-600", 
      bgColor: "bg-orange-50",
      borderColor: "border-orange-200",
      stat: "0% de dados dos clientes"
    },
    {
      icon: X,
      title: "Não consegue fazer promoções?",
      description: "Impossível criar campanhas diretas para seus clientes fiéis.",
      color: "text-purple-600",
      bgColor: "bg-purple-50", 
      borderColor: "border-purple-200",
      stat: "Oportunidades perdidas"
    },
    {
      icon: Timer,
      title: "Pedidos param quando o app cai?",
      description: "Dependência total de plataformas terceiras que podem falhar.",
      color: "text-blue-600",
      bgColor: "bg-blue-50",
      borderColor: "border-blue-200", 
      stat: "Vendas perdidas por instabilidade"
    }
  ];

  return (
    <section className="py-12 sm:py-16 lg:py-20 bg-gradient-to-b from-red-50 to-orange-50 relative overflow-hidden">
      {/* Background elements */}
      <div className="absolute top-10 left-10 w-32 h-32 bg-red-200/20 rounded-full blur-2xl floating-animation"></div>
      <div className="absolute bottom-10 right-10 w-48 h-48 bg-orange-200/20 rounded-full blur-3xl floating-animation" style={{animationDelay: '3s'}}></div>
      
      <div className="container mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        {/* Money counter */}
        <div className="text-center mb-8 sm:mb-12">
          <div className="inline-flex items-center px-4 sm:px-6 py-3 sm:py-4 bg-red-100 border-2 border-red-200 rounded-2xl shadow-lg">
            <CreditCard className="w-5 sm:w-6 h-5 sm:h-6 text-red-600 mr-2 sm:mr-3" />
            <span className="text-red-800 font-bold text-sm sm:text-base lg:text-lg">
              Restaurantes brasileiros já perderam: R$ {lostMoney.toLocaleString()},00 em taxas hoje
            </span>
          </div>
        </div>

        <div className="max-w-5xl mx-auto text-center mb-12 sm:mb-16">
          <h2 className="text-2xl sm:text-3xl md:text-4xl lg:text-6xl font-bold text-gray-900 mb-4 sm:mb-6 slide-up">
            Você ainda depende de aplicativos que{" "}
            <span className="text-red-600 underline decoration-wavy">cobram altas taxas?</span>
          </h2>
          <p className="text-lg sm:text-xl lg:text-2xl text-gray-700 fade-in-delay">
            ⚠️ Pare de dar seus lucros para intermediários. Veja os principais problemas:
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 sm:gap-8 max-w-6xl mx-auto">
          {problems.map((problem, index) => (
            <Card key={index} className={`${problem.borderColor} ${problem.bgColor} border-2 hover:shadow-2xl transition-all duration-500 transform hover:scale-105 group fade-in-delay`} style={{animationDelay: `${index * 0.2}s`}}>
              <CardContent className="p-4 sm:p-6 lg:p-8">
                <div className="space-y-3 sm:space-y-4">
                  <div className="flex items-center justify-between">
                    <div className={`${problem.bgColor} p-3 sm:p-4 rounded-xl sm:rounded-2xl group-hover:scale-110 transition-transform duration-300`}>
                      <problem.icon className={`h-6 sm:h-8 w-6 sm:w-8 ${problem.color}`} />
                    </div>
                    <div className={`px-2 sm:px-3 py-1 ${problem.bgColor} ${problem.color} rounded-full text-xs sm:text-sm font-bold border ${problem.borderColor}`}>
                      {problem.stat}
                    </div>
                  </div>
                  
                  <h3 className="text-lg sm:text-xl font-bold text-gray-900 group-hover:text-red-700 transition-colors">
                    {problem.title}
                  </h3>
                  
                  <p className="text-sm sm:text-base text-gray-700 leading-relaxed">
                    {problem.description}
                  </p>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        <div className="text-center mt-12 sm:mt-16">
          <div className="inline-flex items-center px-4 sm:px-6 lg:px-8 py-3 sm:py-4 bg-gradient-to-r from-red-500 to-orange-500 text-white rounded-2xl shadow-xl pulse-glow">
            <AlertTriangle className="h-5 sm:h-6 w-5 sm:w-6 mr-2 sm:mr-3" />
            <span className="font-bold text-sm sm:text-base lg:text-lg">🔥 É hora de ter independência total!</span>
          </div>
        </div>
      </div>
    </section>
  );
};