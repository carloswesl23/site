import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Separator } from "@/components/ui/separator";
import { Switch } from "@/components/ui/switch";
import { Label } from "@/components/ui/label";
import { useToast } from "@/hooks/use-toast";
import { supabase } from "@/integrations/supabase/client";
import { 
  MessageCircle, 
  Search, 
  Send, 
  Phone, 
  CheckCheck,
  Check,
  Clock,
  RefreshCw,
  Users,
  Bell,
  BellOff
} from "lucide-react";

interface WhatsAppInstance {
  id: string;
  instance_id: string;
  token_instance: string;
  status: string;
}

interface Chat {
  id: string;
  chat_id: string;
  display_name: string;
  last_message_preview: string;
  last_message_at: string;
  unread_count: number;
}

interface Message {
  id: string;
  chat_id: string;
  direction: 'in' | 'out';
  type: string;
  body: string;
  media_url?: string;
  status: string;
  created_at: string;
}

interface WhatsAppInboxProps {
  instance: WhatsAppInstance | null;
}

export const WhatsAppInbox: React.FC<WhatsAppInboxProps> = ({ instance }) => {
  const [chats, setChats] = useState<Chat[]>([]);
  const [messages, setMessages] = useState<Message[]>([]);
  const [selectedChat, setSelectedChat] = useState<Chat | null>(null);
  const [searchTerm, setSearchTerm] = useState('');
  const [newMessage, setNewMessage] = useState('');
  const [loading, setLoading] = useState(false);
  const [sending, setSending] = useState(false);
  const [syncing, setSyncing] = useState(false);
  const [notificationsEnabled, setNotificationsEnabled] = useState(false);
  const { toast } = useToast();
  const messagesEndRef = React.useRef<HTMLDivElement>(null);

  // Request notification permission on component mount
  useEffect(() => {
    if ("Notification" in window) {
      if (Notification.permission === "granted") {
        setNotificationsEnabled(true);
      } else if (Notification.permission === "default") {
        Notification.requestPermission().then((permission) => {
          setNotificationsEnabled(permission === "granted");
        });
      }
    }
  }, []);

  // Play notification sound with custom alarm tone
  const playNotificationSound = () => {
    try {
      // Custom alarm sound - high pitched beep sequence
      const audioContext = new (window.AudioContext || (window as any).webkitAudioContext)();
      const oscillator = audioContext.createOscillator();
      const gainNode = audioContext.createGain();
      
      oscillator.connect(gainNode);
      gainNode.connect(audioContext.destination);
      
      oscillator.frequency.setValueAtTime(880, audioContext.currentTime); // High A note
      oscillator.frequency.setValueAtTime(1108.73, audioContext.currentTime + 0.1); // High C# note
      oscillator.frequency.setValueAtTime(880, audioContext.currentTime + 0.2); // High A note
      
      gainNode.gain.setValueAtTime(0.3, audioContext.currentTime);
      gainNode.gain.exponentialRampToValueAtTime(0.01, audioContext.currentTime + 0.5);
      
      oscillator.start(audioContext.currentTime);
      oscillator.stop(audioContext.currentTime + 0.5);
    } catch (error) {
      // Fallback to default audio
      const audio = new Audio('data:audio/wav;base64,UklGRnoGAABXQVZFZm10IBAAAAABAAEAQB8AAEAfAAABAAgAZGF0YQoGAACBhYqFbF1fdJivrJBhNjVgodDbq2EcBj+a2/LDciUFLIHO8tiJNwgZaLvt559NEAxQp+PwtmMcBjiR1/LMeSwFJHfH8N2QQAoUXrTp66hVFApGn+DyvWIdBjeG0fPTgjMFLYDJ8diJOAg');
      audio.volume = 0.5;
      audio.play().catch(() => {});
    }
  };

  // Show browser notification
  const showBrowserNotification = (title: string, body: string, senderName: string) => {
    if (!notificationsEnabled || !("Notification" in window) || Notification.permission !== "granted") {
      return;
    }

    try {
      const notification = new Notification(title, {
        body: body,
        icon: '/favicon.ico',
        badge: '/favicon.ico',
        tag: 'whatsapp-message',
        requireInteraction: false,
        silent: false
      });

      // Auto close after 5 seconds
      setTimeout(() => {
        notification.close();
      }, 5000);

      // Focus window when clicked
      notification.onclick = () => {
        window.focus();
        notification.close();
      };
    } catch (error) {
      console.error('Error showing notification:', error);
    }
  };

  // Toggle notifications
  const toggleNotifications = async () => {
    console.log('🔔 Toggle notifications called, current state:', notificationsEnabled);
    
    if (!("Notification" in window)) {
      console.error('❌ Notifications not supported in this browser');
      toast({
        title: "Notificações não suportadas",
        description: "Seu navegador não suporta notificações",
        variant: "destructive"
      });
      return;
    }

    if (notificationsEnabled) {
      setNotificationsEnabled(false);
      console.log('🔕 Notifications disabled');
      toast({
        title: "Notificações desativadas",
        description: "Você não receberá mais notificações de mensagens"
      });
    } else {
      console.log('🔔 Requesting notification permission...');
      const permission = await Notification.requestPermission();
      console.log('📝 Permission result:', permission);
      
      if (permission === "granted") {
        setNotificationsEnabled(true);
        console.log('✅ Notifications enabled');
        
        // Test notification immediately
        console.log('🔊 Testing notification sound and popup...');
        playNotificationSound();
        showBrowserNotification(
          "🔔 LoveZap Ativado",
          "Notificações de mensagens ativadas com sucesso!",
          "Sistema"
        );
        
        toast({
          title: "Notificações ativadas",
          description: "Você receberá notificações de novas mensagens"
        });
      } else {
        console.error('❌ Notification permission denied');
        toast({
          title: "Permissão negada",
          description: "Ative as notificações nas configurações do navegador",
          variant: "destructive"
        });
      }
    }
  };

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  };

  // Load chats from database and Z-API
  const loadChats = async () => {
    if (!instance || instance.status !== 'connected') {
      console.log('Instance not connected, skipping chat load');
      return;
    }

    setLoading(true);
    try {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) throw new Error("User not authenticated");

      console.log('Loading chats for user:', user.id);

      // Load conversations with message data directly from database
      const { data: conversations, error: convError } = await supabase
        .rpc('get_user_conversations', { user_id_param: user.id });

      if (convError) {
        console.error('Error loading conversations:', convError);
        throw convError;
      }

      console.log('Database conversations:', conversations);

      // Convert to our Chat format and sort by last message time
      const allChats: Chat[] = conversations.map((conv: any) => {
        // Normalize phone number
        let phone = conv.phone_e164;
        if (!phone.startsWith('+')) {
          phone = '+' + phone;
        }

        // Create display name - prioritize contact name over phone
        let displayName = conv.display_name || phone;
        
        return {
          id: conv.tenant_id + '-' + phone,
          chat_id: phone,
          display_name: displayName,
          last_message_preview: conv.last_snippet || 'Nenhuma mensagem',
          last_message_at: conv.last_message_at || new Date().toISOString(),
          unread_count: parseInt(conv.unread_count) || 0
        };
      });

      // Sort by last message time, most recent first (moved here for clarity)
      const sortedChats = allChats.sort((a, b) => {
        const timeA = new Date(a.last_message_at).getTime();
        const timeB = new Date(b.last_message_at).getTime();
        return timeB - timeA; // Most recent first
      });

      console.log('Processed and sorted chats:', sortedChats);
      setChats(sortedChats);

    } catch (error) {
      console.error('Error loading chats:', error);
      toast({
        title: "Erro",
        description: "Erro ao carregar conversas",
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  };

  // Sync contacts with Z-API
  const syncContacts = async () => {
    if (!instance || instance.status !== 'connected') {
      toast({
        title: "Erro",
        description: "WhatsApp não está conectado",
        variant: "destructive",
      });
      return;
    }

    setSyncing(true);
    try {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) throw new Error("User not authenticated");

      const { data, error } = await supabase.functions.invoke('wa-sync-contacts', {
        body: {
          userId: user.id,
          instanceId: instance.instance_id,
          tokenInstance: instance.token_instance
        }
      });

      if (error) throw error;

      toast({
        title: "Sincronização concluída",
        description: `${data.contactsSynced} contatos sincronizados`,
      });

      // Recarregar chats após sincronização
      await loadChats();
    } catch (error) {
      console.error("Error syncing contacts:", error);
      toast({
        title: "Erro",
        description: "Falha ao sincronizar contatos",
        variant: "destructive",
      });
    } finally {
      setSyncing(false);
    }
  };

  // Load complete message history for selected chat
  const loadMessages = async (chatId: string) => {
    if (!instance || instance.status !== 'connected') {
      console.log('Instance not connected, skipping message load');
      return;
    }

    console.log('Loading complete message history for chat:', chatId);
    setLoading(true);
    
    try {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) throw new Error("User not authenticated");

      // Use the new comprehensive chat history function
      const { data: historyData, error: historyError } = await supabase.functions.invoke('wa-chat-history', {
        body: {
          instanceId: instance.instance_id,
          tokenInstance: instance.token_instance,
          phone: chatId,
          userId: user.id
        }
      });

      if (historyError) {
        console.error('Error loading chat history:', historyError);
        throw historyError;
      }

      console.log('Chat history loaded:', historyData);

      // Convert messages to our format
      const messages: Message[] = [];
      
      if (historyData?.messages && historyData.messages.length > 0) {
        historyData.messages.forEach((msg: any) => {
          // Handle different message formats (database vs Z-API)
          const messageBody = msg.text?.message || msg.body || msg.messageBody || '[Mídia]';
          
          messages.push({
            id: msg.id || msg.messageId,
            chat_id: chatId,
            direction: msg.fromMe ? 'out' : (msg.direction?.toLowerCase() === 'out' ? 'out' : 'in'),
            type: msg.type || 'text',
            body: messageBody,
            status: msg.status?.toLowerCase() || 'received',
            created_at: msg.created_at || new Date(msg.moment || Date.now()).toISOString(),
            media_url: msg.media_url || msg.mediaUrl || msg.image?.imageUrl || msg.document?.documentUrl || msg.audio?.audioUrl
          });
        });
        
        console.log(`Loaded ${messages.length} messages from history for ${chatId}`);
        
        if (historyData.sources) {
          console.log('Message sources:', historyData.sources);
        }
      } else {
        console.log(`No messages found for ${chatId}`);
        // Show info message if no messages found
        messages.push({
          id: 'info-msg',
          chat_id: chatId,
          direction: 'in',
          type: 'text',
          body: 'Nenhuma mensagem encontrada. Inicie uma conversa ou aguarde novas mensagens.',
          status: 'received',
          created_at: new Date().toISOString()
        });
      }

      console.log('Final messages for display:', messages);
      setMessages(messages);
      
    } catch (error) {
      console.error('Error loading messages:', error);
      toast({
        title: "Erro",
        description: "Erro ao carregar histórico de mensagens",
        variant: "destructive",
      });
      
      // Fallback to show empty state
      setMessages([{
        id: 'error-msg',
        chat_id: chatId,
        direction: 'in',
        type: 'text',
        body: 'Erro ao carregar mensagens. Tente novamente.',
        status: 'received',
        created_at: new Date().toISOString()
      }]);
    } finally {
      setLoading(false);
    }
  };

  // Send message
  const sendMessage = async () => {
    if (!newMessage.trim() || !selectedChat || !instance || sending) return;

    setSending(true);
    try {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) throw new Error("User not authenticated");

      const { error } = await supabase.functions.invoke('wa-send', {
        body: {
          userId: user.id,
          instanceId: instance.instance_id,
          tokenInstance: instance.token_instance,
          chatId: selectedChat.chat_id,
          type: 'text',
          body: { text: newMessage }
        }
      });

      if (error) throw error;

      // Add message to local state
      const newMsg: Message = {
        id: Date.now().toString(),
        chat_id: selectedChat.chat_id,
        direction: 'out',
        type: 'text',
        body: newMessage,
        status: 'sent',
        created_at: new Date().toISOString()
      };
      setMessages([...messages, newMsg]);
      setNewMessage('');
      
      // Scroll to bottom after adding message
      setTimeout(scrollToBottom, 100);

      toast({
        title: "Mensagem enviada",
        description: "Sua mensagem foi enviada com sucesso"
      });
    } catch (error) {
      console.error("Error sending message:", error);
      toast({
        title: "Erro",
        description: "Erro ao enviar mensagem",
        variant: "destructive"
      });
    } finally {
      setSending(false);
    }
  };

  // Load chats when instance changes
  useEffect(() => {
    if (instance && instance.status === 'connected') {
      loadChats();
    } else {
      setChats([]);
      setMessages([]);
      setSelectedChat(null);
    }
  }, [instance]);

  // Mark messages as read when chat is selected
  const markMessagesAsRead = async (chatId: string) => {
    try {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) return;

      // Mark all messages in this chat as read
      const { error } = await supabase
        .from('wa_messages')
        .update({ status: 'read' })
        .eq('user_id', user.id)
        .eq('phone_e164', chatId)
        .eq('direction', 'in')
        .neq('status', 'read');

      if (error) {
        console.error('Error marking messages as read:', error);
      } else {
        console.log('Messages marked as read for chat:', chatId);
        
        // Update unread count in chats
        setChats(prevChats => 
          prevChats.map(chat => 
            chat.chat_id === chatId 
              ? { ...chat, unread_count: 0 }
              : chat
          )
        );
      }
    } catch (error) {
      console.error('Error in markMessagesAsRead:', error);
    }
  };

  // Load messages when chat is selected
  useEffect(() => {
    if (selectedChat) {
      loadMessages(selectedChat.chat_id);
      markMessagesAsRead(selectedChat.chat_id);
      setTimeout(scrollToBottom, 100);
    }
  }, [selectedChat]);

  // Auto scroll when messages change
  useEffect(() => {
    if (messages.length > 0) {
      setTimeout(scrollToBottom, 100);
    }
  }, [messages]);

  // Real-time message notifications and chat sync
  useEffect(() => {
    if (!instance || instance.status !== 'connected') return;

    const setupRealtime = () => {
      const setupAsync = async () => {
        const { data: { user } } = await supabase.auth.getUser();
        if (!user) return () => {};

        console.log('Setting up real-time message notifications and chat sync');

        // Auto refresh chats every 2 minutes for better sync (reduced frequency)
        const chatSyncInterval = setInterval(() => {
          console.log('Auto-syncing chats for better WhatsApp synchronization');
          loadChats();
        }, 120000);

    // Listen for new messages
    const messageChannel = supabase
      .channel('wa_messages_changes')
      .on(
        'postgres_changes',
        {
          event: 'INSERT',
          schema: 'public',
          table: 'wa_messages',
          filter: `user_id=eq.${user.id}`
        },
        (payload) => {
          console.log('New message received via realtime:', payload);
          
          const newMessage = payload.new as any;
          
          // If this message is for the currently selected chat, add it to the messages
          if (selectedChat && newMessage.phone_e164 === selectedChat.chat_id) {
            const messageToAdd: Message = {
              id: newMessage.id,
              chat_id: newMessage.phone_e164,
              direction: newMessage.direction.toLowerCase() as 'in' | 'out',
              type: 'text',
              body: newMessage.body || '',
              status: newMessage.status?.toLowerCase() || 'received',
              created_at: newMessage.created_at,
              media_url: newMessage.media_url
            };

            setMessages(prevMessages => {
              // Check if message already exists
              const exists = prevMessages.find(msg => msg.id === messageToAdd.id);
              if (exists) return prevMessages;
              
              return [...prevMessages.filter(msg => msg.id !== 'info-msg' && msg.id !== 'error-msg'), messageToAdd];
            });

            // Auto-mark as read if the chat is currently open
            if (newMessage.direction.toLowerCase() === 'in') {
              markMessagesAsRead(selectedChat.chat_id);
            }

            // Scroll to bottom for new messages
            setTimeout(scrollToBottom, 100);
          }

          // Update chat list with new message info and reorder
          setChats(prevChats => {
            const updatedChats = prevChats.map(chat => {
              if (chat.chat_id === newMessage.phone_e164) {
                return {
                  ...chat,
                  last_message_preview: newMessage.body?.substring(0, 50) || '[Mídia]',
                  last_message_at: newMessage.created_at,
                  unread_count: newMessage.direction === 'in' && selectedChat?.chat_id !== chat.chat_id 
                    ? chat.unread_count + 1 
                    : chat.unread_count
                };
              }
              return chat;
            });

            // Create a new chat if it doesn't exist
            const chatExists = updatedChats.some(chat => chat.chat_id === newMessage.phone_e164);
            if (!chatExists) {
              const newChat: Chat = {
                id: `new-${newMessage.phone_e164}`,
                chat_id: newMessage.phone_e164,
                display_name: newMessage.phone_e164,
                last_message_preview: newMessage.body?.substring(0, 50) || '[Mídia]',
                last_message_at: newMessage.created_at,
                unread_count: newMessage.direction === 'in' ? 1 : 0
              };
              updatedChats.push(newChat);
            }

            // Sort by last message time, most recent first - ensure proper order
            const sortedChats = updatedChats.sort((a, b) => {
              const timeA = new Date(a.last_message_at).getTime();
              const timeB = new Date(b.last_message_at).getTime();
              return timeB - timeA; // Most recent conversations at top
            });
            
            console.log('Updated chat order:', sortedChats.map(c => ({ 
              name: c.display_name, 
              lastMsg: c.last_message_at,
              unread: c.unread_count 
            })));
            
            return sortedChats;
          });

          // Show notification for incoming messages (when chat is not selected or different chat)
          if (newMessage.direction.toLowerCase() === 'in' && 
              (!selectedChat || selectedChat.chat_id !== newMessage.phone_e164)) {
            
            console.log('🔔 Processing notification for incoming message:', {
              direction: newMessage.direction,
              selectedChat: selectedChat?.chat_id,
              messagePhone: newMessage.phone_e164,
              notificationsEnabled,
              body: newMessage.body
            });
            
            // Find contact name for better notification
            const senderChat = chats.find(chat => chat.chat_id === newMessage.phone_e164);
            const senderName = senderChat?.display_name || newMessage.phone_e164;
            
            // Play notification sound if enabled
            if (notificationsEnabled) {
              console.log('🔊 Playing notification sound for message from:', senderName);
              playNotificationSound();
              
              // Show browser notification
              showBrowserNotification(
                "💬 Nova mensagem LoveZap",
                `${senderName}: ${newMessage.body?.substring(0, 60) || '[Arquivo de mídia]'}`,
                senderName
              );
            } else {
              console.log('🔕 Notifications disabled, skipping sound');
            }
            
            // Always show toast notification
            toast({
              title: "💬 Nova mensagem WhatsApp",
              description: `${senderName}: ${newMessage.body?.substring(0, 60) || '[Arquivo de mídia]'}`,
              duration: 5000,
            });
          } else {
            console.log('⏭️ Skipping notification - conditions not met:', {
              direction: newMessage.direction,
              isCurrentChat: selectedChat?.chat_id === newMessage.phone_e164
            });
          }
        }
      )
      .on(
        'postgres_changes',
        {
          event: 'UPDATE',
          schema: 'public',
          table: 'wa_messages',
          filter: `user_id=eq.${user.id}`
        },
        (payload) => {
          console.log('Message status updated via realtime:', payload);
          
          const updatedMessage = payload.new as any;
          
          // Update message status in current chat
          if (selectedChat && updatedMessage.phone_e164 === selectedChat.chat_id) {
            setMessages(prevMessages => {
              return prevMessages.map(msg => {
                if (msg.id === updatedMessage.id) {
                  return {
                    ...msg,
                    status: updatedMessage.status?.toLowerCase() || msg.status
                  };
                }
                return msg;
              });
            });
          }
        }
      )
      .subscribe();

        // Cleanup function
        return () => {
          clearInterval(chatSyncInterval);
          messageChannel.unsubscribe();
        };
      };

      return setupAsync();
    };

    setupRealtime().then(cleanup => {
      if (cleanup) {
        return () => cleanup();
      }
    });
  }, [instance, selectedChat, toast, chats]);

  // Select chat and load messages
  const selectChat = async (chat: Chat) => {
    setSelectedChat(chat);
    // Mark messages as read immediately when selecting chat
    await markMessagesAsRead(chat.chat_id);
  };

  const filteredChats = chats.filter(chat =>
    chat.display_name.toLowerCase().includes(searchTerm.toLowerCase()) ||
    chat.chat_id.includes(searchTerm)
  );

  const getMessageStatusIcon = (status: string) => {
    switch (status) {
      case 'sent':
        return <Check className="w-3 h-3" />;
      case 'delivered':
      case 'read':
        return <CheckCheck className="w-3 h-3" />;
      default:
        return <Clock className="w-3 h-3" />;
    }
  };

  if (!instance || instance.status !== 'connected') {
    return (
      <Card className="bg-gradient-to-br from-background via-background to-muted/20 border-border/50 shadow-lg">
        <CardHeader className="text-center pb-4">
          <div className="w-16 h-16 bg-gradient-to-br from-destructive/20 to-destructive/10 rounded-2xl flex items-center justify-center mx-auto mb-4">
            <MessageCircle className="w-8 h-8 text-destructive/60" />
          </div>
          <CardTitle className="text-xl">WhatsApp não conectado</CardTitle>
        </CardHeader>
        <CardContent className="text-center">
          <p className="text-muted-foreground mb-4">
            Conecte seu WhatsApp primeiro para usar o inbox e gerenciar suas conversas.
          </p>
          <Button variant="outline" className="bg-background/50">
            <Phone className="w-4 h-4 mr-2" />
            Ir para Conexão
          </Button>
        </CardContent>
      </Card>
    );
  }

  return (
    <div className="flex h-[calc(100vh-12rem)] bg-gradient-to-br from-background via-background to-muted/20 rounded-xl border border-border/50 shadow-lg overflow-hidden">
      {/* Chat List Sidebar */}
      <div className="w-80 bg-card/80 backdrop-blur-sm border-r border-border/50 flex flex-col">
        {/* Header */}
        <div className="p-4 border-b border-border/30 bg-gradient-to-r from-primary/5 to-secondary/5">
          <div className="flex items-center justify-between mb-3">
            <div className="flex items-center gap-2">
              <div className="w-10 h-10 bg-primary rounded-xl flex items-center justify-center">
                <MessageCircle className="w-5 h-5 text-primary-foreground" />
              </div>
              <div>
                <h2 className="text-lg font-semibold text-foreground">Conversas</h2>
                <p className="text-xs text-muted-foreground">{chats.length} contatos</p>
              </div>
            </div>
            <div className="flex items-center gap-2">
              <Button
                variant="outline"
                size="sm"
                onClick={toggleNotifications}
                className={`h-8 w-8 p-0 border-border/50 transition-all duration-200 ${
                  notificationsEnabled 
                    ? 'bg-primary/10 border-primary/20 text-primary hover:bg-primary/20' 
                    : 'bg-background/50 hover:bg-muted/50'
                }`}
                title={notificationsEnabled ? 'Desativar notificações' : 'Ativar notificações'}
              >
                {notificationsEnabled ? (
                  <Bell className="w-3.5 h-3.5" />
                ) : (
                  <BellOff className="w-3.5 h-3.5" />
                )}
              </Button>
              <Button
                variant="outline"
                size="sm"
                onClick={syncContacts}
                disabled={syncing}
                className="h-8 w-8 p-0 bg-background/50 border-border/50 hover:bg-primary/10 hover:border-primary/20"
                title="Sincronizar contatos"
              >
                <RefreshCw className={`w-3.5 h-3.5 ${syncing ? 'animate-spin' : ''}`} />
              </Button>
            </div>
          </div>

          {/* Notification Toggle */}
          <div className="flex items-center justify-between p-2 bg-background/30 rounded-lg border border-border/20 mb-3">
            <div className="flex items-center gap-2">
              {notificationsEnabled ? (
                <Bell className="w-4 h-4 text-primary" />
              ) : (
                <BellOff className="w-4 h-4 text-muted-foreground" />
              )}
              <div>
                <Label htmlFor="notifications-toggle" className="text-sm font-medium">
                  Notificações
                </Label>
                <p className="text-xs text-muted-foreground">
                  {notificationsEnabled ? 'Som ativo' : 'Desativadas'}
                </p>
              </div>
            </div>
            <Switch
              id="notifications-toggle"
              checked={notificationsEnabled}
              onCheckedChange={toggleNotifications}
              className="data-[state=checked]:bg-primary"
            />
          </div>
          
          {/* Search Bar */}
          <div className="relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-muted-foreground" />
            <Input
              placeholder="Buscar conversas..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pl-10 h-9 bg-background/60 border-border/30 focus:bg-background focus:border-primary/30 transition-all duration-200"
            />
          </div>
        </div>

        {/* Chat List */}
        <ScrollArea className="flex-1">
          <div className="p-2 space-y-1">
            {loading ? (
              <div className="flex items-center justify-center py-8">
                <div className="flex flex-col items-center gap-2">
                  <div className="w-8 h-8 border-2 border-primary/20 border-t-primary rounded-full animate-spin" />
                  <p className="text-sm text-muted-foreground">Carregando conversas...</p>
                </div>
              </div>
            ) : filteredChats.length > 0 ? (
              filteredChats.map((chat) => (
                <div
                  key={chat.id}
                  onClick={() => selectChat(chat)}
                  className={`p-3 rounded-lg cursor-pointer transition-all duration-200 hover:bg-muted/50 group ${
                    selectedChat?.id === chat.id 
                      ? 'bg-gradient-to-r from-primary/10 to-secondary/5 border border-primary/20 shadow-sm' 
                      : 'hover:shadow-sm'
                  }`}
                >
                  <div className="flex items-start gap-3">
                    <div className="relative">
                      <Avatar className="w-11 h-11 border-2 border-background shadow-sm">
                        <AvatarFallback className="bg-primary/20 text-primary font-medium">
                          {chat.display_name.charAt(0).toUpperCase()}
                        </AvatarFallback>
                      </Avatar>
                      {chat.unread_count > 0 && (
                        <div className="absolute -top-1 -right-1 w-5 h-5 bg-red-500 rounded-full flex items-center justify-center shadow-lg">
                          <span className="text-xs font-bold text-white">
                            {chat.unread_count > 9 ? '9+' : chat.unread_count}
                          </span>
                        </div>
                      )}
                    </div>
                    
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center justify-between mb-1">
                        <h3 className="font-medium text-foreground truncate group-hover:text-primary transition-colors">
                          {chat.display_name}
                        </h3>
                        <span className="text-xs text-muted-foreground">
                          {chat.last_message_at ? new Date(chat.last_message_at).toLocaleTimeString('pt-BR', { 
                            hour: '2-digit', 
                            minute: '2-digit' 
                          }) : ''}
                        </span>
                      </div>
                      <p className="text-sm text-muted-foreground truncate">
                        {chat.last_message_preview || 'Nenhuma mensagem'}
                      </p>
                    </div>
                  </div>
                </div>
              ))
            ) : (
              <div className="flex flex-col items-center justify-center py-12 text-center">
                <div className="w-16 h-16 bg-gradient-to-br from-muted to-muted/50 rounded-2xl flex items-center justify-center mb-4">
                  <Users className="w-8 h-8 text-muted-foreground" />
                </div>
                <h3 className="font-medium text-foreground mb-2">Nenhuma conversa</h3>
                <p className="text-sm text-muted-foreground mb-4 max-w-48">
                  {searchTerm ? 'Nenhuma conversa encontrada' : 'Sincronize seus contatos para começar'}
                </p>
                {!searchTerm && (
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={syncContacts}
                    disabled={syncing}
                    className="bg-background/50"
                  >
                    <RefreshCw className={`w-4 h-4 mr-2 ${syncing ? 'animate-spin' : ''}`} />
                    Sincronizar Contatos
                  </Button>
                )}
              </div>
            )}
          </div>
        </ScrollArea>
      </div>

      {/* Chat Window */}
      <div className="flex-1 flex flex-col bg-background/60 backdrop-blur-sm">
        {selectedChat ? (
          <>
            {/* Chat Header */}
            <div className="p-4 border-b border-border/30 bg-gradient-to-r from-card to-card/50 backdrop-blur-sm">
              <div className="flex items-center gap-3">
                <Avatar className="w-10 h-10 border-2 border-background shadow-sm">
                  <AvatarFallback className="bg-primary/20 text-primary font-medium">
                    {selectedChat.display_name.charAt(0).toUpperCase()}
                  </AvatarFallback>
                </Avatar>
                <div className="flex-1">
                  <h3 className="font-semibold text-foreground">{selectedChat.display_name}</h3>
                  <div className="flex items-center gap-1 text-xs text-muted-foreground">
                    <Phone className="w-3 h-3" />
                    <span>{selectedChat.chat_id}</span>
                  </div>
                </div>
              </div>
            </div>

            {/* Messages Area */}
            <div className="flex-1 flex flex-col min-h-0">
              <ScrollArea className="flex-1 min-h-0" style={{
                backgroundImage: `url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='100' height='100' viewBox='0 0 100 100'%3E%3Cg fill-opacity='0.03'%3E%3Cpolygon fill='%23075e54' points='50 0 60 40 100 50 60 60 50 100 40 60 0 50 40 40'/%3E%3C/g%3E%3C/svg%3E")`,
                backgroundColor: '#e5ddd5'
              }}>
                <div className="p-4 min-h-full">
                  {loading ? (
                    <div className="flex items-center justify-center h-full min-h-[400px]">
                      <div className="flex flex-col items-center gap-3">
                        <div className="w-10 h-10 border-3 border-primary/20 border-t-primary rounded-full animate-spin" />
                        <p className="text-sm text-muted-foreground">Carregando mensagens...</p>
                      </div>
                    </div>
                  ) : (
                    <div className="space-y-4 pb-4">
                      {messages.map((message) => (
                        <div
                          key={message.id}
                          className={`flex ${message.direction === 'out' ? 'justify-end' : 'justify-start'} animate-fade-in`}
                        >
                          <div
                            className={`max-w-xs lg:max-w-md px-4 py-3 rounded-2xl shadow-sm relative ${
                              message.direction === 'out'
                                ? 'bg-primary text-primary-foreground rounded-br-md'
                                : 'bg-background border border-border/30 text-foreground rounded-bl-md shadow-md'
                            }`}
                          >
                            {message.media_url && (
                              <div className="mb-2">
                                <img 
                                  src={message.media_url} 
                                  alt="Mídia" 
                                  className="rounded-lg max-w-full h-auto shadow-sm"
                                  onError={(e) => {
                                    e.currentTarget.style.display = 'none';
                                  }}
                                />
                              </div>
                            )}
                            <p className="text-sm whitespace-pre-wrap break-words">{message.body}</p>
                            <div className={`flex items-center justify-end gap-1 mt-1 ${
                              message.direction === 'out' ? 'text-primary-foreground/70' : 'text-muted-foreground'
                            }`}>
                              <span className="text-xs">
                                {new Date(message.created_at).toLocaleTimeString('pt-BR', { 
                                  hour: '2-digit', 
                                  minute: '2-digit' 
                                })}
                              </span>
                              {message.direction === 'out' && (
                                <div className="text-xs opacity-80">
                                  {getMessageStatusIcon(message.status)}
                                </div>
                              )}
                            </div>
                          </div>
                        </div>
                      ))}
                      <div ref={messagesEndRef} />
                    </div>
                  )}
                </div>
              </ScrollArea>

              {/* Message Input */}
              <div className="p-4 border-t border-border/30 bg-gradient-to-r from-card/50 to-background/50 backdrop-blur-sm shrink-0">
                <div className="flex gap-2">
                  <div className="flex-1 relative">
                    <Input
                      placeholder="Digite sua mensagem..."
                      value={newMessage}
                      onChange={(e) => setNewMessage(e.target.value)}
                      onKeyPress={(e) => e.key === 'Enter' && sendMessage()}
                      className="pr-12 bg-background/80 border-border/30 focus:bg-background focus:border-primary/30 transition-all duration-200"
                      disabled={sending}
                    />
                    <Button
                      onClick={sendMessage}
                      disabled={!newMessage.trim() || sending}
                      size="sm"
                      className="absolute right-1 top-1 h-7 w-7 p-0 bg-primary hover:bg-primary/90 shadow-sm"
                    >
                      <Send className="w-3.5 h-3.5" />
                    </Button>
                  </div>
                </div>
              </div>
            </div>
          </>
        ) : (
          /* No Chat Selected */
          <div className="flex-1 flex items-center justify-center">
            <div className="text-center max-w-sm">
              <div className="w-20 h-20 bg-gradient-to-br from-primary/10 to-secondary/10 rounded-3xl flex items-center justify-center mx-auto mb-6 shadow-sm">
                <MessageCircle className="w-10 h-10 text-primary/60" />
              </div>
              <h3 className="text-xl font-semibold text-foreground mb-2">Bem-vindo ao WhatsApp</h3>
              <p className="text-muted-foreground mb-6">
                Selecione uma conversa para começar a trocar mensagens com seus clientes
              </p>
              {chats.length === 0 && (
                <Button
                  variant="outline"
                  onClick={syncContacts}
                  disabled={syncing}
                  className="bg-background/50"
                >
                  <RefreshCw className={`w-4 h-4 mr-2 ${syncing ? 'animate-spin' : ''}`} />
                  Sincronizar Contatos
                </Button>
              )}
            </div>
          </div>
        )}
      </div>
    </div>
  );
};