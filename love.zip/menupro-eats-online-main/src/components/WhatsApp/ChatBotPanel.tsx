import { useState, useRef, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { MessageCircle, Send, Bot, User } from 'lucide-react';
import { useWhatsAppInstances, type WhatsAppInstance } from '@/hooks/useWhatsAppInstances';
import { useToast } from '@/hooks/use-toast';
import { supabase } from '@/integrations/supabase/client';

interface Message {
  id: string;
  content: string;
  sender: 'user' | 'contact' | 'system';
  timestamp: string;
  phoneNumber?: string;
}

interface ChatBotPanelProps {
  instance: WhatsAppInstance;
}

export const ChatBotPanel = ({ instance }: ChatBotPanelProps) => {
  const [messages, setMessages] = useState<Message[]>([]);
  const [newMessage, setNewMessage] = useState('');
  const [targetPhone, setTargetPhone] = useState('');
  const [sending, setSending] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const { toast } = useToast();

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  useEffect(() => {
    // Carregar mensagens do histórico da instância
    if (instance.mensagens && Array.isArray(instance.mensagens)) {
      setMessages(instance.mensagens);
    }
  }, [instance.mensagens]);

  const sendMessage = async () => {
    if (!newMessage.trim() || !targetPhone.trim()) {
      toast({
        title: "Campos obrigatórios",
        description: "Preencha o número e a mensagem",
        variant: "destructive"
      });
      return;
    }

    setSending(true);
    try {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) throw new Error("User not authenticated");

      // Enviar mensagem via Z-API usando nossa edge function
      const { data, error } = await supabase.functions.invoke('wa-send', {
        body: {
          userId: user.id,
          instanceId: instance.instance_id,
          tokenInstance: instance.token_instance,
          chatId: targetPhone,
          type: 'text',
          body: { text: newMessage }
        }
      });

      if (error) throw error;

      const messageId = Date.now().toString();
      const message: Message = {
        id: messageId,
        content: newMessage,
        sender: 'user',
        timestamp: new Date().toISOString(),
        phoneNumber: targetPhone
      };

      setMessages(prev => [...prev, message]);
      setNewMessage('');

      toast({
        title: "Mensagem enviada",
        description: "Mensagem enviada com sucesso via WhatsApp",
      });

      // Se houver resposta do webhook, será capturada automaticamente
      if (data?.success) {
        const systemMessage: Message = {
          id: (Date.now() + 1).toString(),
          content: `✅ Mensagem entregue - ID: ${data.messageId || 'N/A'}`,
          sender: 'system',
          timestamp: new Date().toISOString()
        };
        setMessages(prev => [...prev, systemMessage]);
      }

    } catch (error: any) {
      console.error('Erro ao enviar mensagem:', error);
      toast({
        title: "Erro",
        description: error.message || "Erro ao enviar mensagem",
        variant: "destructive"
      });
    } finally {
      setSending(false);
    }
  };

  const getMessageIcon = (sender: string) => {
    switch (sender) {
      case 'user':
        return <User className="w-4 h-4" />;
      case 'contact':
        return <MessageCircle className="w-4 h-4" />;
      case 'system':
        return <Bot className="w-4 h-4" />;
      default:
        return <MessageCircle className="w-4 h-4" />;
    }
  };

  const getMessageStyle = (sender: string) => {
    switch (sender) {
      case 'user':
        return 'bg-blue-500 text-white ml-auto';
      case 'contact':
        return 'bg-gray-100 text-gray-900';
      case 'system':
        return 'bg-yellow-50 text-yellow-800 border border-yellow-200';
      default:
        return 'bg-gray-100 text-gray-900';
    }
  };

  return (
    <Card className="h-[600px] flex flex-col">
      <CardHeader className="pb-3">
        <CardTitle className="flex items-center gap-2">
          <MessageCircle className="w-5 h-5" />
          ChatBot - {instance.instance_name}
          <Badge variant={instance.status === 'connected' ? 'default' : 'secondary'}>
            {instance.status === 'connected' ? 'Online' : 'Offline'}
          </Badge>
        </CardTitle>
      </CardHeader>
      
      <CardContent className="flex-1 flex flex-col gap-4 p-4">
        {/* Área de mensagens */}
        <div className="flex-1 border rounded-lg p-4 overflow-y-auto bg-gray-50 min-h-[300px]">
          {messages.length === 0 ? (
            <div className="flex items-center justify-center h-full text-gray-500">
              <div className="text-center">
                <Bot className="w-12 h-12 mx-auto mb-2 opacity-50" />
                <p>Nenhuma mensagem ainda</p>
                <p className="text-sm">Digite um número e envie sua primeira mensagem</p>
              </div>
            </div>
          ) : (
            <div className="space-y-3">
              {messages.map((message) => (
                <div
                  key={message.id}
                  className={`flex ${message.sender === 'user' ? 'justify-end' : 'justify-start'}`}
                >
                  <div className={`max-w-xs lg:max-w-md px-3 py-2 rounded-lg ${getMessageStyle(message.sender)}`}>
                    <div className="flex items-center gap-2 mb-1">
                      {getMessageIcon(message.sender)}
                      <span className="text-xs opacity-75">
                        {message.phoneNumber && `${message.phoneNumber} • `}
                        {new Date(message.timestamp).toLocaleTimeString()}
                      </span>
                    </div>
                    <p className="text-sm">{message.content}</p>
                  </div>
                </div>
              ))}
              <div ref={messagesEndRef} />
            </div>
          )}
        </div>

        {/* Área de envio */}
        <div className="space-y-3">
          <div className="flex gap-2">
            <Input
              placeholder="Número do WhatsApp (5511999999999)"
              value={targetPhone}
              onChange={(e) => setTargetPhone(e.target.value)}
              className="flex-1"
            />
          </div>
          
          <div className="flex gap-2">
            <Input
              placeholder="Digite sua mensagem..."
              value={newMessage}
              onChange={(e) => setNewMessage(e.target.value)}
              onKeyPress={(e) => e.key === 'Enter' && !sending && sendMessage()}
              className="flex-1"
              disabled={sending}
            />
            <Button 
              onClick={sendMessage}
              disabled={sending || !newMessage.trim() || !targetPhone.trim()}
              size="icon"
            >
              <Send className="w-4 h-4" />
            </Button>
          </div>
          
          {instance.status !== 'connected' ? (
            <p className="text-sm text-amber-600">
              ⚠️ WhatsApp desconectado - mensagens podem falhar
            </p>
          ) : (
            <p className="text-sm text-green-600">
              ✅ WhatsApp conectado - pronto para enviar
            </p>
          )}
          
          <div className="text-xs text-gray-500 p-2 bg-gray-50 rounded">
            💡 <strong>ChatBot Funcional:</strong> As mensagens são enviadas via Z-API em tempo real.
            Configure as secrets da Z-API nas configurações para o funcionamento completo.
          </div>
        </div>
      </CardContent>
    </Card>
  );
};