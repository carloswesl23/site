import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { useToast } from "@/hooks/use-toast";
import { supabase } from "@/integrations/supabase/client";
import { QrCode, Smartphone, Battery, Wifi, RefreshCw, Phone } from "lucide-react";

interface WhatsAppInstance {
  id: string;
  instance_id: string;
  token_instance: string;
  status: string;
  qr_code?: string;
  numero_cliente?: string;
  device_pushname?: string;
  device_phone?: string;
  device_battery?: string;
  device_plugged?: string;
  device_platform?: string;
  updated_at: string;
}

interface WhatsAppConnectionProps {
  instance: WhatsAppInstance | null;
  onInstanceUpdate: () => void;
}

export const WhatsAppConnection: React.FC<WhatsAppConnectionProps> = ({
  instance,
  onInstanceUpdate
}) => {
  const [loading, setLoading] = useState(false);
  const [qrLoading, setQrLoading] = useState(false);
  const { toast } = useToast();

  // Auto-refresh status when QR is shown
  useEffect(() => {
    if (instance?.status === 'qrcode') {
      const interval = setInterval(() => {
        refreshStatus();
      }, 7000);

      return () => clearInterval(interval);
    }
  }, [instance?.status]);

  const generateQR = async () => {
    if (!instance) return;
    
    setQrLoading(true);
    try {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) throw new Error("User not authenticated");

      const { data, error } = await supabase.functions.invoke('gerar-qr-code', {
        body: {
          userId: user.id,
          instanceId: instance.instance_id,
          tokenInstance: instance.token_instance
        }
      });

      if (error) throw error;

      toast({
        title: "QR Code gerado",
        description: "Escaneie o código com seu WhatsApp"
      });

      onInstanceUpdate();
    } catch (error) {
      console.error("Error generating QR:", error);
      toast({
        title: "Erro",
        description: "Erro ao gerar QR Code",
        variant: "destructive"
      });
    } finally {
      setQrLoading(false);
    }
  };

  const refreshStatus = async () => {
    if (!instance) return;
    
    setLoading(true);
    try {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) throw new Error("User not authenticated");

      const { error } = await supabase.functions.invoke('wa-instance-status-sync', {
        body: {
          userId: user.id,
          instanceId: instance.instance_id,
          tokenInstance: instance.token_instance
        }
      });

      if (error) throw error;
      onInstanceUpdate();
    } catch (error) {
      console.error("Error refreshing status:", error);
      toast({
        title: "Erro",
        description: "Erro ao atualizar status",
        variant: "destructive"
      });
    } finally {
      setLoading(false);
    }
  };

  const updateDeviceInfo = async () => {
    if (!instance) return;
    
    setLoading(true);
    try {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) throw new Error("User not authenticated");

      const { error } = await supabase.functions.invoke('wa-device-info', {
        body: {
          userId: user.id,
          instanceId: instance.instance_id,
          tokenInstance: instance.token_instance
        }
      });

      if (error) throw error;

      toast({
        title: "Dados atualizados",
        description: "Informações do dispositivo atualizadas"
      });

      onInstanceUpdate();
    } catch (error) {
      console.error("Error updating device info:", error);
      toast({
        title: "Erro",
        description: "Erro ao atualizar dados do dispositivo",
        variant: "destructive"
      });
    } finally {
      setLoading(false);
    }
  };

  if (!instance) {
    return (
      <Card>
        <CardHeader>
          <CardTitle>Nenhuma instância encontrada</CardTitle>
        </CardHeader>
        <CardContent>
          <p className="text-muted-foreground">
            Configure uma instância do WhatsApp primeiro.
          </p>
        </CardContent>
      </Card>
    );
  }

  return (
    <div className="space-y-6">
      {/* Status Card */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Smartphone className="w-5 h-5" />
              Status da Conexão
            </div>
            <Button
              variant="outline"
              size="sm"
              onClick={refreshStatus}
              disabled={loading}
            >
              <RefreshCw className={`w-4 h-4 mr-2 ${loading ? 'animate-spin' : ''}`} />
              Atualizar
            </Button>
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <span>Status:</span>
              <Badge variant={instance.status === 'connected' ? 'default' : 'secondary'}>
                {instance.status === 'connected' ? 'Conectado' : 
                 instance.status === 'qrcode' ? 'Aguardando QR' :
                 instance.status === 'disconnected' ? 'Desconectado' : instance.status}
              </Badge>
            </div>
            
            {instance.numero_cliente && (
              <div className="flex items-center justify-between">
                <span>Número:</span>
                <div className="flex items-center gap-2">
                  <Phone className="w-4 h-4" />
                  {instance.numero_cliente}
                </div>
              </div>
            )}

            <div className="flex items-center justify-between text-sm text-muted-foreground">
              <span>Última atualização:</span>
              <span>{new Date(instance.updated_at).toLocaleString()}</span>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Device Info Card */}
      {instance.status === 'connected' && (
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Smartphone className="w-5 h-5" />
                Dados do Celular
              </div>
              <Button
                variant="outline"
                size="sm"
                onClick={updateDeviceInfo}
                disabled={loading}
              >
                <RefreshCw className={`w-4 h-4 mr-2 ${loading ? 'animate-spin' : ''}`} />
                Atualizar Dados
              </Button>
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-2 gap-4">
              {instance.device_pushname && (
                <div>
                  <span className="text-sm text-muted-foreground">Nome:</span>
                  <p className="font-medium">{instance.device_pushname}</p>
                </div>
              )}
              
              {instance.device_platform && (
                <div>
                  <span className="text-sm text-muted-foreground">Plataforma:</span>
                  <p className="font-medium">{instance.device_platform}</p>
                </div>
              )}
              
              {instance.device_battery && (
                <div>
                  <span className="text-sm text-muted-foreground">Bateria:</span>
                  <div className="flex items-center gap-2">
                    <Battery className="w-4 h-4" />
                    <span className="font-medium">{instance.device_battery}%</span>
                  </div>
                </div>
              )}
              
              {instance.device_plugged && (
                <div>
                  <span className="text-sm text-muted-foreground">Carregando:</span>
                  <p className="font-medium">{instance.device_plugged === 'true' ? 'Sim' : 'Não'}</p>
                </div>
              )}
            </div>
          </CardContent>
        </Card>
      )}

      {/* QR Code Card */}
      {instance.status !== 'connected' && (
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <QrCode className="w-5 h-5" />
              Conectar WhatsApp
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {instance.qr_code ? (
                <div className="flex flex-col items-center space-y-4">
                  <div className="bg-white p-4 rounded-lg border shadow-lg">
                    <img 
                      src={instance.qr_code.startsWith('data:') ? instance.qr_code : `data:image/png;base64,${instance.qr_code}`}
                      alt="QR Code WhatsApp"
                      className="w-64 h-64 object-contain"
                      onError={(e) => {
                        console.error('QR Code image error:', e);
                        console.log('QR Code data:', instance.qr_code?.substring(0, 100));
                      }}
                    />
                  </div>
                  <div className="text-center">
                    <p className="font-medium">Escaneie com seu WhatsApp</p>
                    <p className="text-sm text-muted-foreground">
                      WhatsApp → Configurações → Aparelhos conectados → Conectar aparelho
                    </p>
                  </div>
                  <div className="flex gap-2">
                    <Button
                      variant="outline"
                      onClick={generateQR}
                      disabled={qrLoading}
                    >
                      <RefreshCw className={`w-4 h-4 mr-2 ${qrLoading ? 'animate-spin' : ''}`} />
                      Novo QR
                    </Button>
                  </div>
                </div>
              ) : (
                <div className="text-center space-y-4">
                  <p className="text-muted-foreground">
                    Clique no botão abaixo para gerar um QR Code e conectar seu WhatsApp
                  </p>
                  <Button onClick={generateQR} disabled={qrLoading}>
                    <QrCode className={`w-4 h-4 mr-2 ${qrLoading ? 'animate-spin' : ''}`} />
                    Gerar QR Code
                  </Button>
                </div>
              )}
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
};