import React, { useState, useEffect } from 'react';
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { useToast } from "@/hooks/use-toast";
import { supabase } from "@/integrations/supabase/client";
import { useWhatsAppInstances, type WhatsAppInstance } from "@/hooks/useWhatsAppInstances";
import { useWhatsAppStatus } from "@/hooks/useWhatsAppStatus";
import { 
  Bot, 
  MessageCircle, 
  Send, 
  BarChart3, 
  Settings,
  Wifi,
  WifiOff,
  RefreshCw
} from "lucide-react";
import lovezapMascot from "@/assets/lovezap-mascot.jpg";

// Import existing components
import { WhatsAppConnection } from './WhatsAppConnection';
import { WhatsAppInbox } from './WhatsAppInbox';
import { WhatsAppBroadcast } from './WhatsAppBroadcast';
import { ChatBotPanel } from './ChatBotPanel';
import { ZAPIWebhookSetup } from './ZAPIWebhookSetup';

export const WhatsAppBot: React.FC = () => {
  const [activeTab, setActiveTab] = useState('connection');
  const { instances, loading: instancesLoading, refetch } = useWhatsAppInstances();
  const activeInstance = instances?.[0] || null;
  const { connectionStatus, phoneNumber, isChecking, refreshStatus } = useWhatsAppStatus(activeInstance);
  const { toast } = useToast();

  // Get current user
  const [user, setUser] = useState<any>(null);
  
  useEffect(() => {
    const getUser = async () => {
      const { data: { user } } = await supabase.auth.getUser();
      setUser(user);
    };
    getUser();
  }, []);

  // Auto-switch to inbox when connected
  useEffect(() => {
    if (connectionStatus === 'connected' && activeTab === 'connection') {
      setActiveTab('inbox');
    }
  }, [connectionStatus, activeTab]);

  const getStatusBadge = (status: string) => {
    switch (status) {
      case 'connected':
        return <Badge className="bg-green-600 hover:bg-green-700"><Wifi className="w-3 h-3 mr-1" />Conectado</Badge>;
      case 'qrcode':
        return <Badge variant="secondary">QR Code</Badge>;
      case 'disconnected':
        return <Badge variant="destructive"><WifiOff className="w-3 h-3 mr-1" />Desconectado</Badge>;
      default:
        return <Badge variant="outline">Verificando...</Badge>;
    }
  };

  const refreshAll = async () => {
    await Promise.all([
      refetch(),
      refreshStatus()
    ]);
    toast({
      title: "Atualizado",
      description: "Status e dados atualizados com sucesso"
    });
  };

  const updateWebhooks = async () => {
    if (!activeInstance || !user) return;

    try {
      console.log('🔧 Updating webhooks for instance:', activeInstance.instance_id);
      
      const { data, error } = await supabase.functions.invoke('zapi-manager', {
        body: {
          action: 'update-webhooks',
          instanceId: activeInstance.instance_id,
          userId: user.id
        }
      });

      if (error) {
        console.error('❌ Error updating webhooks:', error);
        toast({
          title: "Erro ao atualizar webhooks",
          description: error.message,
          variant: "destructive"
        });
        return;
      }

      console.log('✅ Webhooks updated successfully:', data);
      toast({
        title: "Webhooks atualizados",
        description: "Notificações configuradas com sucesso"
      });
    } catch (error) {
      console.error('❌ Failed to update webhooks:', error);
      toast({
        title: "Erro interno",
        description: "Falha ao atualizar notificações",
        variant: "destructive"
      });
    }
  };

  return (
    <div className="container mx-auto py-6 space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold flex items-center gap-3">
            <img src={lovezapMascot} alt="LoveZap Mascot" className="w-10 h-10 rounded-full" />
            LoveZap - Atendente Virtual
          </h1>
          <p className="text-muted-foreground mt-1">
            O atendente virtual que vende com amor
          </p>
        </div>
        <div className="flex items-center gap-4">
          {activeInstance && (
            <div className="text-right">
              <div className="flex items-center gap-2">
                {getStatusBadge(connectionStatus)}
                <Button
                  variant="outline"
                  size="sm"
                  onClick={refreshAll}
                  disabled={isChecking}
                >
                  <RefreshCw className={`w-4 h-4 ${isChecking ? 'animate-spin' : ''}`} />
                </Button>
              </div>
              {phoneNumber && (
                <p className="text-sm text-muted-foreground mt-1">
                  📱 {phoneNumber}
                </p>
              )}
            </div>
          )}
        </div>
      </div>

      {/* Main Bot Interface */}
      <Card className="border-2 border-primary/20">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <MessageCircle className="w-5 h-5" />
            Central do Bot
          </CardTitle>
        </CardHeader>
        <CardContent>
          <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
            <TabsList className="grid w-full grid-cols-5 text-xs">
              <TabsTrigger value="connection" className="flex items-center gap-1">
                <Settings className="w-3 h-3" />
                Conexão
              </TabsTrigger>
              <TabsTrigger 
                value="chatbot" 
                disabled={connectionStatus !== 'connected'}
                className="flex items-center gap-1"
              >
                <Bot className="w-3 h-3" />
                ChatBot
              </TabsTrigger>
              <TabsTrigger 
                value="inbox" 
                disabled={connectionStatus !== 'connected'}
                className="flex items-center gap-1"
              >
                <MessageCircle className="w-3 h-3" />
                Inbox
              </TabsTrigger>
              <TabsTrigger 
                value="broadcast" 
                disabled={connectionStatus !== 'connected'}
                className="flex items-center gap-1"
              >
                <Send className="w-3 h-3" />
                Disparos
              </TabsTrigger>
              <TabsTrigger 
                value="reports" 
                disabled={connectionStatus !== 'connected'}
                className="flex items-center gap-1"
              >
                <BarChart3 className="w-3 h-3" />
                Relatórios
              </TabsTrigger>
            </TabsList>

            <TabsContent value="connection" className="mt-6">
              <div className="space-y-6">
                <WhatsAppConnection 
                  instance={activeInstance} 
                  onInstanceUpdate={() => refetch()} 
                />
                
                {/* Configuração de Webhooks Z-API */}
                {activeInstance && connectionStatus === 'connected' && (
                  <ZAPIWebhookSetup
                    instanceId={activeInstance.instance_id}
                    tokenInstance={activeInstance.token_instance}
                    onSetupComplete={() => {
                      toast({
                        title: "Configuração completa!",
                        description: "Agora você receberá mensagens enviadas via WhatsApp Web/celular no LoveZap Mini",
                      });
                    }}
                  />
                )}
              </div>
            </TabsContent>

            <TabsContent value="chatbot" className="mt-6">
              {activeInstance ? (
                <ChatBotPanel instance={activeInstance} />
              ) : (
                <Card>
                  <CardContent className="text-center py-12">
                    <Bot className="w-16 h-16 mx-auto mb-4 text-muted-foreground" />
                    <h3 className="text-lg font-semibold mb-2">Conecte o WhatsApp</h3>
                    <p className="text-muted-foreground">
                      Primeiro conecte sua conta do WhatsApp para usar o ChatBot
                    </p>
                  </CardContent>
                </Card>
              )}
            </TabsContent>

            <TabsContent value="inbox" className="mt-6">
              <WhatsAppInbox instance={activeInstance} />
            </TabsContent>

            <TabsContent value="broadcast" className="mt-6">
              <WhatsAppBroadcast instance={activeInstance} />
            </TabsContent>

            <TabsContent value="reports" className="mt-6">
              <Card>
                <CardHeader>
                  <CardTitle>Relatórios e Métricas</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                    <Card>
                      <CardContent className="p-6 text-center">
                        <Send className="w-8 h-8 mx-auto mb-2 text-blue-600" />
                        <h3 className="font-semibold">Mensagens Enviadas</h3>
                        <p className="text-2xl font-bold text-blue-600">1,234</p>
                        <p className="text-sm text-muted-foreground">Este mês</p>
                      </CardContent>
                    </Card>
                    
                    <Card>
                      <CardContent className="p-6 text-center">
                        <MessageCircle className="w-8 h-8 mx-auto mb-2 text-green-600" />
                        <h3 className="font-semibold">Mensagens Recebidas</h3>
                        <p className="text-2xl font-bold text-green-600">856</p>
                        <p className="text-sm text-muted-foreground">Este mês</p>
                      </CardContent>
                    </Card>
                    
                    <Card>
                      <CardContent className="p-6 text-center">
                        <BarChart3 className="w-8 h-8 mx-auto mb-2 text-purple-600" />
                        <h3 className="font-semibold">Taxa de Resposta</h3>
                        <p className="text-2xl font-bold text-purple-600">69%</p>
                        <p className="text-sm text-muted-foreground">Últimos 30 dias</p>
                      </CardContent>
                    </Card>
                  </div>
                  
                  <div className="mt-8">
                    <h4 className="font-semibold mb-4">Campanhas Recentes</h4>
                    <div className="space-y-2">
                      <div className="flex justify-between items-center p-3 border rounded">
                        <span>Promoção Black Friday</span>
                        <div className="flex items-center gap-2">
                          <Badge>Concluída</Badge>
                          <span className="text-sm text-muted-foreground">95% entregues</span>
                        </div>
                      </div>
                      <div className="flex justify-between items-center p-3 border rounded">
                        <span>Lançamento Novo Cardápio</span>
                        <div className="flex items-center gap-2">
                          <Badge variant="secondary">Agendada</Badge>
                          <span className="text-sm text-muted-foreground">Amanhã 09:00</span>
                        </div>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>
          </Tabs>
        </CardContent>
      </Card>

      {/* Status Footer */}
      {activeInstance && (
        <Card className="bg-muted/30">
          <CardContent className="p-4">
            <div className="flex items-center justify-between text-sm">
              <div className="flex items-center gap-4">
                <span className="font-medium">Status da Instância:</span>
                {getStatusBadge(connectionStatus)}
                <span className="text-muted-foreground">
                  Instância: {activeInstance.instance_name}
                </span>
              </div>
              <div className="text-muted-foreground">
                ✅ LoveZap ativo e funcionando
              </div>
              <Button
                onClick={updateWebhooks}
                variant="outline"
                size="sm"
                disabled={!activeInstance || !user}
              >
                🔧 Atualizar Notificações
              </Button>
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
};