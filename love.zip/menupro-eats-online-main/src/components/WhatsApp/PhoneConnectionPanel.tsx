import { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import { Smartphone, CheckCircle, Clock, AlertCircle, ExternalLink, RefreshCw } from 'lucide-react';
import { useWhatsAppInstances, type WhatsAppInstance } from '@/hooks/useWhatsAppInstances';
import { useToast } from '@/hooks/use-toast';
import { Link } from 'react-router-dom';

interface PhoneConnectionPanelProps {
  onInstanceCreated?: () => void;
}

export const PhoneConnectionPanel = ({ onInstanceCreated }: PhoneConnectionPanelProps) => {
  const [phoneNumber, setPhoneNumber] = useState('');
  const [instanceName, setInstanceName] = useState('');
  const [verificationCode, setVerificationCode] = useState('');
  const [showRefreshButton, setShowRefreshButton] = useState<{ [key: string]: boolean }>({});
  const { 
    createInstance, 
    instances, 
    creating, 
    verifyPhoneCode, 
    syncInstanceStatus, 
    updating 
  } = useWhatsAppInstances();
  const { toast } = useToast();

  // Timer para mostrar botão de refresh após 20 segundos
  useEffect(() => {
    const qrInstances = instances.filter(inst => 
      inst.status === 'qrcode' && inst.qr_code
    );

    qrInstances.forEach(instance => {
      if (!showRefreshButton[instance.id]) {
        const timer = setTimeout(() => {
          setShowRefreshButton(prev => ({
            ...prev,
            [instance.id]: true
          }));
        }, 20000); // 20 segundos

        return () => clearTimeout(timer);
      }
    });
  }, [instances, showRefreshButton]);

  // Auto-polling para status em instâncias com QR code
  useEffect(() => {
    const qrInstances = instances.filter(inst => 
      inst.status === 'qrcode' && inst.qr_code
    );

    if (qrInstances.length > 0) {
      const interval = setInterval(() => {
        qrInstances.forEach(instance => {
          syncInstanceStatus(instance.instance_id).catch(console.error);
        });
      }, 7000); // Check a cada 7 segundos

      return () => clearInterval(interval);
    }
  }, [instances, syncInstanceStatus]);

  const handleCreateInstance = async () => {
    if (!phoneNumber || !instanceName) {
      toast({
        title: "Campos obrigatórios",
        description: "Preencha o número de telefone e nome da instância",
        variant: "destructive"
      });
      return;
    }

    try {
      await createInstance(instanceName, phoneNumber);
      onInstanceCreated?.();
    } catch (error) {
      console.error('Erro ao criar instância:', error);
    }
  };

  const handleVerifyCode = async (instance: WhatsAppInstance) => {
    if (!verificationCode) {
      toast({
        title: "Código obrigatório",
        description: "Digite o código recebido no WhatsApp",
        variant: "destructive"
      });
      return;
    }

    try {
      await verifyPhoneCode(instance.id, verificationCode);
      setVerificationCode('');
    } catch (error) {
      console.error('Erro ao verificar código:', error);
    }
  };

  const pendingInstances = instances.filter(
    inst => inst.versao === 'v2' && inst.status !== 'connected'
  );

  const getStatusBadge = (status: string) => {
    switch (status) {
      case 'connected':
        return <Badge variant="default" className="bg-green-100 text-green-800"><CheckCircle className="w-3 h-3 mr-1" />Conectado</Badge>;
      case 'qrcode':
        return <Badge variant="default" className="bg-blue-100 text-blue-800"><Clock className="w-3 h-3 mr-1" />QR Code</Badge>;
      case 'aguardando_codigo':
        return <Badge variant="secondary"><Clock className="w-3 h-3 mr-1" />Aguardando código</Badge>;
      case 'disconnected':
        return <Badge variant="outline"><AlertCircle className="w-3 h-3 mr-1" />Desconectado</Badge>;
      case 'expired':
        return <Badge variant="destructive"><AlertCircle className="w-3 h-3 mr-1" />Expirado</Badge>;
      default:
        return <Badge variant="secondary">{status}</Badge>;
    }
  };

  const handleRefreshStatus = async (instance: WhatsAppInstance) => {
    try {
      await syncInstanceStatus(instance.instance_id);
      
      // Reset timer do botão
      setShowRefreshButton(prev => ({
        ...prev,
        [instance.id]: false
      }));
    } catch (error) {
      console.error('Erro ao atualizar status:', error);
    }
  };

  return (
    <div className="space-y-6">
      {/* Formulário para criar nova instância */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Smartphone className="w-5 h-5" />
            Conectar WhatsApp via Código
          </CardTitle>
          <CardDescription>
            Novo método sem QR Code - mais prático e rápido
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="phone">Número do WhatsApp</Label>
              <Input
                id="phone"
                type="tel"
                placeholder="5511999999999"
                value={phoneNumber}
                onChange={(e) => setPhoneNumber(e.target.value)}
                disabled={creating}
              />
              <p className="text-sm text-muted-foreground">
                Digite com código do país e DDD (ex: 5511999999999)
              </p>
            </div>
            <div className="space-y-2">
              <Label htmlFor="instanceName">Nome da Instância</Label>
              <Input
                id="instanceName"
                placeholder="Meu WhatsApp Business"
                value={instanceName}
                onChange={(e) => setInstanceName(e.target.value)}
                disabled={creating}
              />
            </div>
          </div>
          
          <div className="flex gap-3">
            <Button 
              onClick={handleCreateInstance} 
              disabled={creating || !phoneNumber || !instanceName}
              className="flex-1"
            >
              {creating ? 'Criando...' : 'Conectar WhatsApp'}
            </Button>
            
            <Link to="/qr-conexao">
              <Button variant="outline" className="flex items-center gap-2">
                <ExternalLink className="w-4 h-4" />
                QR Direto
              </Button>
            </Link>
          </div>
          
          <div className="p-4 bg-blue-50 rounded-lg border border-blue-200">
            <h4 className="font-medium text-blue-900 mb-2">Como funciona:</h4>
            <ol className="text-sm text-blue-800 space-y-1 list-decimal list-inside">
              <li>Digite seu número do WhatsApp</li>
              <li>O sistema enviará um código para seu WhatsApp</li>
              <li>Digite o código no campo abaixo para confirmar</li>
              <li>Pronto! Seu WhatsApp estará conectado</li>
            </ol>
          </div>
        </CardContent>
      </Card>

      {/* Lista de instâncias aguardando código */}
      {pendingInstances.length > 0 && (
        <Card>
          <CardHeader>
            <CardTitle>Instâncias Pendentes</CardTitle>
            <CardDescription>
              Instâncias aguardando código de verificação
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            {pendingInstances.map((instance) => (
              <div key={instance.id} className="p-4 border rounded-lg space-y-3">
                <div className="flex items-center justify-between">
                  <div>
                    <h4 className="font-medium">{instance.instance_name}</h4>
                    <p className="text-sm text-muted-foreground">
                      ID: {instance.instance_id}
                      {instance.numero_cliente && ` • ${instance.numero_cliente}`}
                    </p>
                  </div>
                  <div className="flex items-center gap-2">
                    {getStatusBadge(instance.status)}
                    {showRefreshButton[instance.id] && instance.status === 'qrcode' && (
                      <Button
                        size="sm"
                        variant="outline"
                        onClick={() => handleRefreshStatus(instance)}
                        disabled={updating}
                        className="h-6 px-2"
                      >
                        <RefreshCw className="w-3 h-3" />
                      </Button>
                    )}
                  </div>
                </div>
                
                {/* Exibir QR Code automaticamente quando disponível */}
                {instance.qr_code && (instance.status === 'qrcode' || instance.status === 'initializing') && (
                  <div className="space-y-3">
                    <div className="p-3 bg-blue-50 rounded border border-blue-200">
                      <p className="text-sm text-blue-800 text-center font-medium">
                        📱 Escaneie o QR Code com seu WhatsApp
                      </p>
                    </div>
                    
                    <div className="flex justify-center">
                      <img 
                        src={instance.qr_code} 
                        alt="QR Code WhatsApp" 
                        className="w-48 h-48 border-2 border-gray-300 rounded-lg shadow-md"
                      />
                    </div>
                    
                    <div className="text-center text-xs text-muted-foreground space-y-1">
                      <p>1. Abra o WhatsApp no seu celular</p>
                      <p>2. Vá em Dispositivos conectados</p>
                      <p>3. Toque em "Conectar dispositivo"</p>
                      <p>4. Escaneie este QR Code</p>
                    </div>
                  </div>
                )}

                {instance.status === 'aguardando_codigo' && (
                  <div className="space-y-3">
                    <div className="p-3 bg-yellow-50 rounded border border-yellow-200">
                      <p className="text-sm text-yellow-800">
                        📱 Código enviado para seu WhatsApp! Digite o código recebido abaixo:
                      </p>
                    </div>
                    
                    <div className="flex gap-2">
                      <Input
                        placeholder="Digite o código do WhatsApp"
                        value={verificationCode}
                        onChange={(e) => setVerificationCode(e.target.value)}
                        className="flex-1"
                      />
                      <Button 
                        onClick={() => handleVerifyCode(instance)}
                        disabled={!verificationCode}
                      >
                        Verificar
                      </Button>
                    </div>
                  </div>
                )}
                
                {instance.status === 'connected' && (
                  <div className="p-3 bg-green-50 rounded border border-green-200">
                    <p className="text-sm text-green-800">
                      ✅ WhatsApp conectado com sucesso!
                    </p>
                  </div>
                )}
              </div>
            ))}
          </CardContent>
        </Card>
      )}
    </div>
  );
};