import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { useToast } from "@/hooks/use-toast";
import { supabase } from "@/integrations/supabase/client";
import { 
  BarChart3, 
  MessageCircle, 
  Send, 
  Clock, 
  CheckCircle,
  XCircle,
  TrendingUp,
  Download
} from "lucide-react";

interface WhatsAppInstance {
  id: string;
  instance_id: string;
  token_instance: string;
  status: string;
}

interface ReportData {
  totalMessages: number;
  sentMessages: number;
  failedMessages: number;
  totalChats: number;
  messagesPerDay: Array<{ date: string; count: number }>;
  campaignStats: Array<{
    name: string;
    sent: number;
    failed: number;
    responses: number;
  }>;
}

interface WhatsAppReportsProps {
  instance: WhatsAppInstance | null;
}

export const WhatsAppReports: React.FC<WhatsAppReportsProps> = ({ instance }) => {
  const [reportData, setReportData] = useState<ReportData>({
    totalMessages: 0,
    sentMessages: 0,
    failedMessages: 0,
    totalChats: 0,
    messagesPerDay: [],
    campaignStats: []
  });
  const [loading, setLoading] = useState(true);
  const [dateRange, setDateRange] = useState('7'); // days
  const { toast } = useToast();

  // Mock data for demonstration since tables don't exist yet
  const mockReportData: ReportData = {
    totalMessages: 245,
    sentMessages: 230,
    failedMessages: 15,
    totalChats: 45,
    messagesPerDay: [
      { date: '2024-01-08', count: 35 },
      { date: '2024-01-09', count: 42 },
      { date: '2024-01-10', count: 28 },
      { date: '2024-01-11', count: 51 },
      { date: '2024-01-12', count: 38 },
      { date: '2024-01-13', count: 46 },
      { date: '2024-01-14', count: 5 }
    ],
    campaignStats: [
      { name: 'Campanha Black Friday', sent: 95, failed: 5, responses: 12 },
      { name: 'Novo cardápio', sent: 80, failed: 3, responses: 18 },
      { name: 'Promoção pizza', sent: 55, failed: 7, responses: 8 }
    ]
  };

  // Load report data - temporarily use mock data
  const loadReportData = async () => {
    setLoading(true);
    try {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) return;

      // TODO: Replace with actual queries when tables exist
      // For now, use mock data with some randomization based on date range
      const multiplier = parseInt(dateRange) / 7;
      
      setReportData({
        ...mockReportData,
        totalMessages: Math.floor(mockReportData.totalMessages * multiplier),
        sentMessages: Math.floor(mockReportData.sentMessages * multiplier),
        failedMessages: Math.floor(mockReportData.failedMessages * multiplier),
        messagesPerDay: mockReportData.messagesPerDay.slice(0, Math.min(parseInt(dateRange), 7))
      });
    } catch (error) {
      console.error("Error loading report data:", error);
      toast({
        title: "Erro",
        description: "Erro ao carregar relatórios",
        variant: "destructive"
      });
    } finally {
      setLoading(false);
    }
  };

  // Export data to CSV
  const exportToCsv = () => {
    const csvData = [
      ['Data', 'Mensagens Enviadas'],
      ...reportData.messagesPerDay.map(item => [item.date, item.count.toString()])
    ];

    const csvContent = csvData.map(row => row.join(',')).join('\n');
    const blob = new Blob([csvContent], { type: 'text/csv' });
    const url = window.URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `whatsapp-report-${new Date().toISOString().split('T')[0]}.csv`;
    a.click();
    window.URL.revokeObjectURL(url);

    toast({
      title: "Export concluído",
      description: "Relatório exportado com sucesso"
    });
  };

  useEffect(() => {
    loadReportData();
  }, [dateRange]);

  if (!instance || instance.status !== 'connected') {
    return (
      <Card>
        <CardHeader>
          <CardTitle>WhatsApp não conectado</CardTitle>
        </CardHeader>
        <CardContent>
          <p className="text-muted-foreground">
            Conecte seu WhatsApp primeiro para ver os relatórios.
          </p>
        </CardContent>
      </Card>
    );
  }

  const successRate = reportData.totalMessages > 0 
    ? ((reportData.sentMessages / reportData.totalMessages) * 100).toFixed(1)
    : '0';

  return (
    <div className="space-y-6">
      {/* Date Range Selector */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <BarChart3 className="w-5 h-5" />
              Relatórios WhatsApp
            </div>
            <div className="flex items-center gap-2">
              <select
                value={dateRange}
                onChange={(e) => setDateRange(e.target.value)}
                className="px-3 py-1 border rounded-md text-sm"
              >
                <option value="7">Últimos 7 dias</option>
                <option value="30">Últimos 30 dias</option>
                <option value="90">Últimos 90 dias</option>
              </select>
              <Button variant="outline" size="sm" onClick={exportToCsv}>
                <Download className="w-4 h-4 mr-2" />
                Exportar CSV
              </Button>
            </div>
          </CardTitle>
        </CardHeader>
      </Card>

      {/* KPI Cards */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Total de Mensagens</p>
                <p className="text-2xl font-bold">{reportData.totalMessages}</p>
              </div>
              <MessageCircle className="w-8 h-8 text-blue-500" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Enviadas com Sucesso</p>
                <p className="text-2xl font-bold text-green-600">{reportData.sentMessages}</p>
              </div>
              <CheckCircle className="w-8 h-8 text-green-500" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Falharam</p>
                <p className="text-2xl font-bold text-red-600">{reportData.failedMessages}</p>
              </div>
              <XCircle className="w-8 h-8 text-red-500" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Taxa de Sucesso</p>
                <p className="text-2xl font-bold text-blue-600">{successRate}%</p>
              </div>
              <TrendingUp className="w-8 h-8 text-blue-500" />
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Messages per Day Chart */}
      <Card>
        <CardHeader>
          <CardTitle>Mensagens por Dia</CardTitle>
        </CardHeader>
        <CardContent>
          {loading ? (
            <div className="flex items-center justify-center h-64">
              <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div>
            </div>
          ) : (
            <div className="space-y-4">
              {reportData.messagesPerDay.length > 0 ? (
                <div className="space-y-2">
                  {reportData.messagesPerDay.map((item, index) => (
                    <div key={index} className="flex items-center justify-between py-2">
                      <span className="text-sm">
                        {new Date(item.date).toLocaleDateString()}
                      </span>
                      <div className="flex items-center gap-2">
                        <div 
                          className="bg-primary h-4 rounded"
                          style={{ 
                            width: `${Math.max((item.count / Math.max(...reportData.messagesPerDay.map(d => d.count))) * 200, 4)}px` 
                          }}
                        />
                        <span className="text-sm font-medium w-8 text-right">
                          {item.count}
                        </span>
                      </div>
                    </div>
                  ))}
                </div>
              ) : (
                <div className="text-center py-8 text-muted-foreground">
                  <BarChart3 className="w-8 h-8 mx-auto mb-2 opacity-50" />
                  <p>Nenhum dado encontrado para o período selecionado</p>
                </div>
              )}
            </div>
          )}
        </CardContent>
      </Card>

      {/* Campaign Performance */}
      <Card>
        <CardHeader>
          <CardTitle>Performance das Campanhas</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {reportData.campaignStats.length > 0 ? (
              reportData.campaignStats.map((campaign, index) => (
                <div key={index} className="p-4 border rounded-lg">
                  <div className="flex items-center justify-between mb-2">
                    <h4 className="font-medium">{campaign.name}</h4>
                    <Badge variant="outline">
                      {((campaign.sent / (campaign.sent + campaign.failed)) * 100).toFixed(1)}% sucesso
                    </Badge>
                  </div>
                  <div className="grid grid-cols-3 gap-4 text-sm">
                    <div>
                      <span className="text-muted-foreground">Enviadas:</span>
                      <span className="ml-2 font-medium text-green-600">{campaign.sent}</span>
                    </div>
                    <div>
                      <span className="text-muted-foreground">Falharam:</span>
                      <span className="ml-2 font-medium text-red-600">{campaign.failed}</span>
                    </div>
                    <div>
                      <span className="text-muted-foreground">Respostas:</span>
                      <span className="ml-2 font-medium text-blue-600">{campaign.responses}</span>
                    </div>
                  </div>
                </div>
              ))
            ) : (
              <div className="text-center py-8 text-muted-foreground">
                <Send className="w-8 h-8 mx-auto mb-2 opacity-50" />
                <p>Nenhuma campanha encontrada</p>
              </div>
            )}
          </div>
        </CardContent>
      </Card>

      {/* Contact Stats */}
      <Card>
        <CardHeader>
          <CardTitle>Estatísticas de Contatos</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-2 gap-4">
            <div className="text-center p-4 border rounded-lg">
              <div className="text-2xl font-bold text-blue-600">{reportData.totalChats}</div>
              <div className="text-sm text-muted-foreground">Total de Conversas</div>
            </div>
            <div className="text-center p-4 border rounded-lg">
              <div className="text-2xl font-bold text-green-600">
                {reportData.messagesPerDay.length > 0 ? 
                  Math.round(reportData.totalMessages / reportData.messagesPerDay.length) : 0
                }
              </div>
              <div className="text-sm text-muted-foreground">Mensagens por Dia (média)</div>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};