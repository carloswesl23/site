import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { Checkbox } from "@/components/ui/checkbox";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useToast } from "@/hooks/use-toast";
import { supabase } from "@/integrations/supabase/client";
import { useSecureFileUpload } from "@/hooks/useSecureFileUpload";
import { 
  Send, 
  Users, 
  Calendar, 
  Play, 
  Pause, 
  BarChart3,
  Plus,
  Trash2,
  Upload,
  X,
  Image
} from "lucide-react";

interface WhatsAppInstance {
  id: string;
  instance_id: string;
  token_instance: string;
  status: string;
}

interface Template {
  id: string;
  name: string;
  type: string;
  content: any;
}

interface BroadcastJob {
  id: string;
  name: string;
  status: string;
  counters: any;
  schedule_at?: string;
  created_at: string;
}

interface WhatsAppBroadcastProps {
  instance: WhatsAppInstance | null;
}

export const WhatsAppBroadcast: React.FC<WhatsAppBroadcastProps> = ({ instance }) => {
  const [templates, setTemplates] = useState<Template[]>([]);
  const [jobs, setJobs] = useState<BroadcastJob[]>([]);
  const [selectedTemplate, setSelectedTemplate] = useState<string>('');
  const [campaignName, setCampaignName] = useState('');
  const [messageText, setMessageText] = useState('');
  const [audience, setAudience] = useState<string[]>([]);
  const [scheduleType, setScheduleType] = useState<'now' | 'scheduled'>('now');
  const [scheduleDate, setScheduleDate] = useState('');
  const [scheduleTime, setScheduleTime] = useState('');
  const [selectedImage, setSelectedImage] = useState<File | null>(null);
  const [imagePreview, setImagePreview] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);
  const { toast } = useToast();
  const { uploadFile, uploading } = useSecureFileUpload({ bucket: 'media-files', folder: 'broadcast' });

  // Mock templates for demonstration
  const mockTemplates: Template[] = [
    {
      id: '1',
      name: 'Boas-vindas',
      type: 'text',
      content: { text: 'Olá {{nome}}! Bem-vindo ao nosso restaurante. Como posso ajudar você hoje?' }
    },
    {
      id: '2', 
      name: 'Promoção',
      type: 'text',
      content: { text: '🍕 Promoção especial! 20% de desconto em todos os pratos. Use o cupom: PROMO20' }
    }
  ];

  // Mock jobs for demonstration
  const mockJobs: BroadcastJob[] = [
    {
      id: '1',
      name: 'Campanha Black Friday',
      status: 'done',
      counters: { total: 100, sent: 95, failed: 5, responses: 12 },
      created_at: new Date(Date.now() - 86400000).toISOString()
    },
    {
      id: '2',
      name: 'Novo cardápio',
      status: 'scheduled', 
      counters: { total: 0, sent: 0, failed: 0, responses: 0 },
      schedule_at: new Date(Date.now() + 3600000).toISOString(),
      created_at: new Date().toISOString()
    }
  ];

  // Load templates - temporarily use existing table
  const loadTemplates = async () => {
    try {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) return;

      // Use existing wa_templates table if available, otherwise use mock data
      try {
        const { data, error } = await supabase
          .from("wa_templates" as any)
          .select("*")
          .eq("user_id", user.id)
          .order("created_at", { ascending: false });

        if (error) throw error;
        
        setTemplates((data || []).map((item: any) => ({
          id: item.id,
          name: item.name,
          type: item.body ? 'text' : 'unknown',
          content: { text: item.body || '' }
        })));
      } catch {
        // Fallback to mock data if table doesn't exist
        setTemplates(mockTemplates);
      }
    } catch (error) {
      console.error("Error loading templates:", error);
      setTemplates(mockTemplates);
    }
  };

  // Load broadcast jobs - temporarily use mock data
  const loadJobs = async () => {
    try {
      // TODO: Use actual broadcast_jobs table when available
      setJobs(mockJobs);
    } catch (error) {
      console.error("Error loading jobs:", error);
      setJobs(mockJobs);
    }
  };

  // Create template
  const createTemplate = async () => {
    if (!messageText.trim()) return;

    try {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) throw new Error("User not authenticated");

      try {
        const { data, error } = await supabase
          .from("wa_templates" as any)
          .insert({
            user_id: user.id,
            name: `Template ${new Date().toLocaleDateString()}`,
            body: messageText
          })
          .select()
          .single();

        if (error) throw error;

        const templateData = data as any;
        const newTemplate = {
          id: templateData?.id || Date.now().toString(),
          name: templateData?.name || `Template ${new Date().toLocaleDateString()}`,
          type: 'text',
          content: { text: templateData?.body || messageText }
        };
        setTemplates([newTemplate, ...templates]);
      } catch {
        // Fallback to local storage if table doesn't exist
        const newTemplate = {
          id: Date.now().toString(),
          name: `Template ${new Date().toLocaleDateString()}`,
          type: 'text',
          content: { text: messageText }
        };
        setTemplates([newTemplate, ...templates]);
      }

      toast({
        title: "Template criado",
        description: "Template salvo com sucesso"
      });
    } catch (error) {
      console.error("Error creating template:", error);
      toast({
        title: "Erro",
        description: "Erro ao criar template",
        variant: "destructive"
      });
    }
  };

  // Create broadcast job using Z-API integration
  const createBroadcast = async () => {
    if (!campaignName.trim() || !messageText.trim() || audience.length === 0) {
      toast({
        title: "Erro",
        description: "Preencha todos os campos obrigatórios",
        variant: "destructive"
      });
      return;
    }

    if (!instance || instance.status !== 'connected') {
      toast({
        title: "Erro",
        description: "WhatsApp deve estar conectado para enviar campanhas",
        variant: "destructive"
      });
      return;
    }

    setLoading(true);
    try {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) throw new Error("User not authenticated");

      let scheduledFor = null;
      if (scheduleType === 'scheduled' && scheduleDate && scheduleTime) {
        scheduledFor = new Date(`${scheduleDate}T${scheduleTime}`).toISOString();
      }

      // Upload image if selected
      let imageUrl = null;
      if (selectedImage) {
        const uploadResult = await uploadFile(selectedImage, user.id);
        if (uploadResult.error) {
          throw new Error('Erro ao fazer upload da imagem: ' + uploadResult.error);
        }
        imageUrl = uploadResult.url;
      }

      // Create bulk campaign via our edge function
      const { data, error } = await supabase.functions.invoke('wa-send-bulk', {
        body: {
          userId: user.id,
          instanceId: instance.instance_id,
          tokenInstance: instance.token_instance,
          message: messageText,
          imageUrl,
          audienceType: audience[0], // Use first selected audience type
          scheduledFor,
          campaignName
        }
      });

      if (error) throw error;

      // Add new job to local state
      const newJob = {
        id: data.jobId,
        name: campaignName,
        status: data.status,
        counters: { 
          total: data.totalRecipients, 
          sent: 0, 
          failed: 0, 
          responses: 0 
        },
        schedule_at: scheduledFor,
        created_at: new Date().toISOString()
      };
      
      setJobs([newJob, ...jobs]);
      
      // Reset form
      setCampaignName('');
      setMessageText('');
      setSelectedImage(null);
      setImagePreview(null);
      setAudience([]);
      setScheduleType('now');
      setScheduleDate('');
      setScheduleTime('');

      toast({
        title: "Campanha criada",
        description: `${data.totalRecipients} destinatários - ${scheduledFor ? 'Agendada' : 'Processando'}`
      });
    } catch (error) {
      console.error("Error creating broadcast:", error);
      toast({
        title: "Erro",
        description: error.message || "Erro ao criar campanha",
        variant: "destructive"
      });
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadTemplates();
    loadJobs();
  }, []);

  // Handle template selection
  const handleTemplateSelect = (templateId: string) => {
    const template = templates.find(t => t.id === templateId);
    if (template && template.content.text) {
      setMessageText(template.content.text);
    }
    setSelectedTemplate(templateId);
  };

  // Handle audience selection
  const handleAudienceChange = (value: string, checked: boolean) => {
    if (checked) {
      setAudience([...audience, value]);
    } else {
      setAudience(audience.filter(a => a !== value));
    }
  };

  const getJobStatusBadge = (status: string) => {
    const variants: { [key: string]: "default" | "secondary" | "destructive" | "outline" } = {
      'scheduled': 'secondary',
      'running': 'default',
      'done': 'outline',
      'failed': 'destructive',
      'canceled': 'destructive'
    };

    return (
      <Badge variant={variants[status] || 'secondary'}>
        {status}
      </Badge>
    );
  };

  if (!instance || instance.status !== 'connected') {
    return (
      <Card>
        <CardHeader>
          <CardTitle>WhatsApp não conectado</CardTitle>
        </CardHeader>
        <CardContent>
          <p className="text-muted-foreground">
            Conecte seu WhatsApp primeiro para usar os disparos.
          </p>
        </CardContent>
      </Card>
    );
  }

  return (
    <div className="space-y-6">
      {/* Create Broadcast Card */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Send className="w-5 h-5" />
            Nova Campanha
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-6">
          {/* Campaign Name */}
          <div className="space-y-2">
            <Label htmlFor="campaign-name">Nome da Campanha *</Label>
            <Input
              id="campaign-name"
              placeholder="Ex: Promoção Black Friday"
              value={campaignName}
              onChange={(e) => setCampaignName(e.target.value)}
            />
          </div>

          {/* Template Selection */}
          <div className="space-y-2">
            <Label>Template (Opcional)</Label>
            <Select value={selectedTemplate} onValueChange={handleTemplateSelect}>
              <SelectTrigger>
                <SelectValue placeholder="Selecione um template" />
              </SelectTrigger>
              <SelectContent>
                {templates.map((template) => (
                  <SelectItem key={template.id} value={template.id}>
                    {template.name}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          {/* Message Text */}
          <div className="space-y-2">
            <Label htmlFor="message">Mensagem *</Label>
            <Textarea
              id="message"
              placeholder="Digite sua mensagem... Você pode usar variáveis como {{nome}}, {{link_pagamento}}"
              value={messageText}
              onChange={(e) => setMessageText(e.target.value)}
              rows={4}
            />
            <div className="flex gap-2">
              <Button
                variant="outline"
                size="sm"
                onClick={createTemplate}
                disabled={!messageText.trim()}
              >
                <Plus className="w-4 h-4 mr-2" />
                Salvar como Template
              </Button>
            </div>
          </div>

          {/* Image Upload */}
          <div className="space-y-2">
            <Label>Imagem (Opcional)</Label>
            <div className="border-2 border-dashed border-border rounded-lg p-6">
              {imagePreview ? (
                <div className="space-y-4">
                  <div className="relative inline-block">
                    <img 
                      src={imagePreview} 
                      alt="Preview" 
                      className="max-w-xs max-h-48 rounded-lg object-cover"
                    />
                    <Button
                      variant="destructive"
                      size="sm"
                      className="absolute -top-2 -right-2 rounded-full w-6 h-6 p-0"
                      onClick={() => {
                        setSelectedImage(null);
                        setImagePreview(null);
                      }}
                    >
                      <X className="w-3 h-3" />
                    </Button>
                  </div>
                  <p className="text-sm text-muted-foreground">
                    {selectedImage?.name} ({(selectedImage?.size / 1024 / 1024).toFixed(2)} MB)
                  </p>
                </div>
              ) : (
                <div className="text-center">
                  <Image className="w-12 h-12 mx-auto mb-4 text-muted-foreground" />
                  <div className="space-y-2">
                    <p className="text-sm text-muted-foreground">
                      Envie uma imagem junto com sua mensagem
                    </p>
                    <Button
                      variant="outline"
                      onClick={() => document.getElementById('image-upload')?.click()}
                    >
                      <Upload className="w-4 h-4 mr-2" />
                      Selecionar Imagem
                    </Button>
                  </div>
                  <input
                    id="image-upload"
                    type="file"
                    accept="image/*"
                    className="hidden"
                    onChange={(e) => {
                      const file = e.target.files?.[0];
                      if (file) {
                        setSelectedImage(file);
                        const reader = new FileReader();
                        reader.onload = (e) => setImagePreview(e.target?.result as string);
                        reader.readAsDataURL(file);
                      }
                    }}
                  />
                </div>
              )}
            </div>
          </div>

          {/* Audience Selection */}
          <div className="space-y-2">
            <Label>Público Alvo *</Label>
            <div className="grid grid-cols-2 gap-4">
              <div className="flex items-center space-x-2">
                <Checkbox
                  id="all"
                  checked={audience.includes('all')}
                  onCheckedChange={(checked) => handleAudienceChange('all', checked as boolean)}
                />
                <Label htmlFor="all">Todos os contatos</Label>
              </div>
              <div className="flex items-center space-x-2">
                <Checkbox
                  id="abandoned"
                  checked={audience.includes('abandoned')}
                  onCheckedChange={(checked) => handleAudienceChange('abandoned', checked as boolean)}
                />
                <Label htmlFor="abandoned">Carrinho abandonado</Label>
              </div>
              <div className="flex items-center space-x-2">
                <Checkbox
                  id="vip"
                  checked={audience.includes('vip')}
                  onCheckedChange={(checked) => handleAudienceChange('vip', checked as boolean)}
                />
                <Label htmlFor="vip">Clientes VIP</Label>
              </div>
              <div className="flex items-center space-x-2">
                <Checkbox
                  id="recent"
                  checked={audience.includes('recent')}
                  onCheckedChange={(checked) => handleAudienceChange('recent', checked as boolean)}
                />
                <Label htmlFor="recent">Clientes recentes</Label>
              </div>
            </div>
          </div>

          {/* Schedule */}
          <div className="space-y-4">
            <Label>Agendamento</Label>
            <RadioGroup value={scheduleType} onValueChange={(value: 'now' | 'scheduled') => setScheduleType(value)}>
              <div className="flex items-center space-x-2">
                <RadioGroupItem value="now" id="now" />
                <Label htmlFor="now">Enviar agora</Label>
              </div>
              <div className="flex items-center space-x-2">
                <RadioGroupItem value="scheduled" id="scheduled" />
                <Label htmlFor="scheduled">Agendar para</Label>
              </div>
            </RadioGroup>

            {scheduleType === 'scheduled' && (
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="date">Data</Label>
                  <Input
                    id="date"
                    type="date"
                    value={scheduleDate}
                    onChange={(e) => setScheduleDate(e.target.value)}
                  />
                </div>
                <div>
                  <Label htmlFor="time">Hora</Label>
                  <Input
                    id="time"
                    type="time"
                    value={scheduleTime}
                    onChange={(e) => setScheduleTime(e.target.value)}
                  />
                </div>
              </div>
            )}
          </div>

          <Button onClick={createBroadcast} disabled={loading || uploading} className="w-full">
            <Send className={`w-4 h-4 mr-2 ${(loading || uploading) ? 'animate-pulse' : ''}`} />
            {uploading ? 'Enviando imagem...' : (scheduleType === 'now' ? 'Enviar Agora' : 'Agendar Campanha')}
          </Button>
        </CardContent>
      </Card>

      {/* Campaign History */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <BarChart3 className="w-5 h-5" />
            Histórico de Campanhas
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {jobs.map((job) => (
              <div key={job.id} className="flex items-center justify-between p-4 border rounded-lg">
                <div className="space-y-1">
                  <h4 className="font-medium">{job.name}</h4>
                  <div className="flex items-center gap-4 text-sm text-muted-foreground">
                    <span>
                      📊 {job.counters?.sent || 0} enviados / {job.counters?.failed || 0} falhas
                    </span>
                    <span>
                      📅 {new Date(job.created_at).toLocaleDateString()}
                    </span>
                  </div>
                </div>
                <div className="flex items-center gap-2">
                  {getJobStatusBadge(job.status)}
                </div>
              </div>
            ))}

            {jobs.length === 0 && (
              <div className="text-center py-8 text-muted-foreground">
                <Send className="w-8 h-8 mx-auto mb-2 opacity-50" />
                <p>Nenhuma campanha criada ainda</p>
              </div>
            )}
          </div>
        </CardContent>
      </Card>
    </div>
  );
};