import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { useToast } from '@/components/ui/use-toast';
import { supabase } from '@/integrations/supabase/client';
import { Webhook, CheckCircle, AlertCircle, Loader2 } from 'lucide-react';

interface ZAPIWebhookSetupProps {
  instanceId: string;
  tokenInstance: string;
  onSetupComplete?: () => void;
}

export const ZAPIWebhookSetup: React.FC<ZAPIWebhookSetupProps> = ({
  instanceId,
  tokenInstance,
  onSetupComplete
}) => {
  const [isConfiguring, setIsConfiguring] = useState(false);
  const [configResult, setConfigResult] = useState<any>(null);
  const { toast } = useToast();

  const configureWebhooks = async () => {
    try {
      setIsConfiguring(true);
      setConfigResult(null);

      const { data: { user } } = await supabase.auth.getUser();
      if (!user) throw new Error("Usuário não autenticado");

      const { data, error } = await supabase.functions.invoke('zapi-configure-webhooks', {
        body: {
          instanceId,
          tokenInstance,
          userId: user.id
        }
      });

      if (error) throw error;

      setConfigResult(data);
      
      toast({
        title: "Sucesso!",
        description: "Webhooks configurados para capturar mensagens enviadas fora do painel",
      });

      if (onSetupComplete) {
        onSetupComplete();
      }

    } catch (error) {
      console.error('Erro ao configurar webhooks:', error);
      toast({
        title: "Erro",
        description: error.message || "Erro ao configurar webhooks",
        variant: "destructive"
      });
    } finally {
      setIsConfiguring(false);
    }
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Webhook className="h-5 w-5" />
          Configuração de Webhooks Z-API
        </CardTitle>
        <CardDescription>
          Configure os webhooks para capturar mensagens enviadas via WhatsApp Web/celular
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="bg-muted/50 p-4 rounded-lg">
          <h4 className="font-medium mb-2">O que será configurado:</h4>
          <ul className="text-sm space-y-1 text-muted-foreground">
            <li>• Webhook para mensagens recebidas + "enviadas por mim"</li>
            <li>• Webhook para status de mensagens</li>
            <li>• Webhook para mensagens enviadas</li>
            <li>• Notificações em tempo real no LoveZap Mini</li>
          </ul>
        </div>

        {configResult && (
          <div className="space-y-2">
            <h4 className="font-medium">Resultado da Configuração:</h4>
            <div className="grid grid-cols-1 gap-2">
              <div className="flex items-center gap-2">
                {configResult.configured?.receivedDelivery ? (
                  <CheckCircle className="h-4 w-4 text-green-500" />
                ) : (
                  <AlertCircle className="h-4 w-4 text-red-500" />
                )}
                <span className="text-sm">Mensagens recebidas + enviadas por mim</span>
                <Badge variant={configResult.configured?.receivedDelivery ? "default" : "destructive"}>
                  {configResult.configured?.receivedDelivery ? "OK" : "Erro"}
                </Badge>
              </div>
              <div className="flex items-center gap-2">
                {configResult.configured?.messageStatus ? (
                  <CheckCircle className="h-4 w-4 text-green-500" />
                ) : (
                  <AlertCircle className="h-4 w-4 text-yellow-500" />
                )}
                <span className="text-sm">Status de mensagens</span>
                <Badge variant={configResult.configured?.messageStatus ? "default" : "secondary"}>
                  {configResult.configured?.messageStatus ? "OK" : "Opcional"}
                </Badge>
              </div>
              <div className="flex items-center gap-2">
                {configResult.configured?.sent ? (
                  <CheckCircle className="h-4 w-4 text-green-500" />
                ) : (
                  <AlertCircle className="h-4 w-4 text-yellow-500" />
                )}
                <span className="text-sm">Mensagens enviadas</span>
                <Badge variant={configResult.configured?.sent ? "default" : "secondary"}>
                  {configResult.configured?.sent ? "OK" : "Opcional"}
                </Badge>
              </div>
            </div>
          </div>
        )}

        <Button 
          onClick={configureWebhooks} 
          disabled={isConfiguring}
          className="w-full"
        >
          {isConfiguring ? (
            <>
              <Loader2 className="mr-2 h-4 w-4 animate-spin" />
              Configurando...
            </>
          ) : (
            'Configurar Webhooks'
          )}
        </Button>
      </CardContent>
    </Card>
  );
};