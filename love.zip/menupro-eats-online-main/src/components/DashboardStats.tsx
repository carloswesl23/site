import { TrendingUp, TrendingDown, ShoppingCart, Package, Users } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { useNavigate } from "react-router-dom";
import { useState, useEffect } from "react";
import { supabase } from "@/integrations/supabase/client";

interface StatCardProps {
  title: string;
  value: string;
  change: string;
  changeType: 'increase' | 'decrease';
  icon: React.ComponentType<any>;
  onClick?: () => void;
}

const StatCard = ({ title, value, change, changeType, icon: Icon, onClick }: StatCardProps) => (
  <Card 
    className={`hover:shadow-lg transition-shadow ${onClick ? 'cursor-pointer hover:bg-gray-50' : ''}`}
    onClick={onClick}
  >
    <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
      <CardTitle className="text-sm font-medium text-gray-600">{title}</CardTitle>
      <Icon className="h-4 w-4 text-brand-orange" />
    </CardHeader>
    <CardContent>
      <div className="text-2xl font-bold text-brand-dark">{value}</div>
      <div className="flex items-center text-xs">
        {changeType === 'increase' ? (
          <TrendingUp className="h-3 w-3 text-green-500 mr-1" />
        ) : (
          <TrendingDown className="h-3 w-3 text-red-500 mr-1" />
        )}
        <span className={changeType === 'increase' ? 'text-green-600' : 'text-red-600'}>
          {change}
        </span>
        <span className="text-gray-500 ml-1">desde ontem</span>
      </div>
    </CardContent>
  </Card>
);

export function DashboardStats() {
  const navigate = useNavigate();
  const [stats, setStats] = useState<{
    title: string;
    value: string;
    change: string;
    changeType: 'increase' | 'decrease';
    icon: React.ComponentType<any>;
    onClick: () => void;
  }[]>([
    {
      title: "Vendas Hoje",
      value: "R$ 0,00",
      change: "0%",
      changeType: 'increase' as const,
      icon: TrendingUp,
      onClick: () => navigate("/reports")
    },
    {
      title: "Pedidos",
      value: "0",
      change: "0%",
      changeType: 'increase' as const,
      icon: ShoppingCart,
      onClick: () => navigate("/orders")
    },
    {
      title: "Produtos Ativos",
      value: "0",
      change: "0",
      changeType: 'increase' as const,
      icon: Package,
      onClick: () => navigate("/products")
    },
    {
      title: "Clientes",
      value: "0",
      change: "0",
      changeType: 'increase' as const,
      icon: Users,
      onClick: () => navigate("/customers")
    }
  ]);

  useEffect(() => {
    const fetchUserStats = async () => {
      try {
        const { data: { user } } = await supabase.auth.getUser();
        if (!user) return;

        // Buscar estatísticas do usuário atual
        const today = new Date();
        const startOfDay = new Date(today.setHours(0, 0, 0, 0));
        const yesterday = new Date(today.getTime() - 24 * 60 * 60 * 1000);
        const startOfYesterday = new Date(yesterday.setHours(0, 0, 0, 0));
        const endOfYesterday = new Date(yesterday.setHours(23, 59, 59, 999));

        // Vendas de hoje
        const { data: todayOrders } = await supabase
          .from('user_orders')
          .select('total')
          .eq('user_id', user.id)
          .gte('created_at', startOfDay.toISOString());

        // Vendas de ontem
        const { data: yesterdayOrders } = await supabase
          .from('user_orders')
          .select('total')
          .eq('user_id', user.id)
          .gte('created_at', startOfYesterday.toISOString())
          .lte('created_at', endOfYesterday.toISOString());

        // Produtos ativos
        const { count: productsCount } = await supabase
          .from('user_products')
          .select('*', { count: 'exact', head: true })
          .eq('user_id', user.id)
          .eq('show_online_menu', true);

        // Pedidos de hoje
        const { count: todayOrdersCount } = await supabase
          .from('user_orders')
          .select('*', { count: 'exact', head: true })
          .eq('user_id', user.id)
          .gte('created_at', startOfDay.toISOString());

        // Pedidos de ontem
        const { count: yesterdayOrdersCount } = await supabase
          .from('user_orders')
          .select('*', { count: 'exact', head: true })
          .eq('user_id', user.id)
          .gte('created_at', startOfYesterday.toISOString())
          .lte('created_at', endOfYesterday.toISOString());

        // Clientes únicos da nova tabela user_customers
        const { count: customersCount } = await supabase
          .from('user_customers')
          .select('*', { count: 'exact', head: true })
          .eq('user_id', user.id);

        const todaySales = todayOrders?.reduce((sum, order) => sum + Number(order.total), 0) || 0;
        const yesterdaySales = yesterdayOrders?.reduce((sum, order) => sum + Number(order.total), 0) || 0;
        
        const salesChange = yesterdaySales > 0 
          ? ((todaySales - yesterdaySales) / yesterdaySales * 100).toFixed(0)
          : "0";

        const ordersChange = (yesterdayOrdersCount || 0) > 0
          ? ((todayOrdersCount || 0) - (yesterdayOrdersCount || 0))
          : 0;

        setStats([
          {
            title: "Vendas Hoje",
            value: `R$ ${todaySales.toFixed(2).replace('.', ',')}`,
            change: `${salesChange}%`,
            changeType: Number(salesChange) >= 0 ? 'increase' as const : 'decrease' as const,
            icon: TrendingUp,
            onClick: () => navigate("/reports")
          },
          {
            title: "Pedidos",
            value: String(todayOrdersCount || 0),
            change: `${ordersChange >= 0 ? '+' : ''}${ordersChange}`,
            changeType: ordersChange >= 0 ? 'increase' as const : 'decrease' as const,
            icon: ShoppingCart,
            onClick: () => navigate("/orders")
          },
          {
            title: "Produtos Ativos",
            value: String(productsCount || 0),
            change: "0",
            changeType: 'increase' as const,
            icon: Package,
            onClick: () => navigate("/products")
          },
          {
            title: "Clientes",
            value: String(customersCount || 0),
            change: "0",
            changeType: 'increase' as const,
            icon: Users,
            onClick: () => navigate("/customers")
          }
        ]);

      } catch (error) {
        console.error('Error fetching user stats:', error);
      }
    };

    fetchUserStats();
    
    // Configurar realtime updates para user_orders
    const ordersChannel = supabase
      .channel('dashboard-orders-changes')
      .on(
        'postgres_changes',
        {
          event: '*',
          schema: 'public',
          table: 'user_orders'
        },
        () => {
          console.log('Orders updated, refreshing dashboard stats...');
          fetchUserStats();
        }
      )
      .subscribe();

    // Configurar realtime updates para user_customers
    const customersChannel = supabase
      .channel('dashboard-customers-changes')
      .on(
        'postgres_changes',
        {
          event: '*',
          schema: 'public',
          table: 'user_customers'
        },
        () => {
          console.log('Customers updated, refreshing dashboard stats...');
          fetchUserStats();
        }
      )
      .subscribe();

    // Configurar realtime updates para user_products
    const productsChannel = supabase
      .channel('dashboard-products-changes')
      .on(
        'postgres_changes',
        {
          event: '*',
          schema: 'public',
          table: 'user_products'
        },
        () => {
          console.log('Products updated, refreshing dashboard stats...');
          fetchUserStats();
        }
      )
      .subscribe();
    
    // Atualizar dados a cada 60 segundos como fallback
    const interval = setInterval(fetchUserStats, 60000);
    
    return () => {
      clearInterval(interval);
      supabase.removeChannel(ordersChannel);
      supabase.removeChannel(customersChannel);
      supabase.removeChannel(productsChannel);
    };
  }, [navigate]);

  return (
    <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
      {stats.map((stat, index) => (
        <StatCard key={index} {...stat} />
      ))}
    </div>
  );
}