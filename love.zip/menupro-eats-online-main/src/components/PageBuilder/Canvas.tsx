
import { useDroppable } from '@dnd-kit/core';
import { PageElement } from '@/types/pageBuilder';
import { ElementRenderer } from './ElementRenderer';

interface CanvasProps {
  elements: PageElement[];
  settings: any;
  selectedElement: string | null;
  onSelectElement: (id: string | null) => void;
  onUpdateElement: (id: string, updates: Partial<PageElement>) => void;
  onDeleteElement: (id: string) => void;
  previewMode: 'desktop' | 'mobile';
}

export const Canvas = ({
  elements,
  settings,
  selectedElement,
  onSelectElement,
  onUpdateElement,
  onDeleteElement,
  previewMode
}: CanvasProps) => {
  const { setNodeRef, isOver } = useDroppable({
    id: 'canvas'
  });

  const canvasWidth = previewMode === 'desktop' ? '100%' : '375px';
  const canvasHeight = '800px';

  return (
    <div className="p-8 h-full">
      <div className="flex justify-center">
        <div
          ref={setNodeRef}
          className={`relative bg-white shadow-lg transition-all duration-300 ${
            isOver ? 'ring-2 ring-blue-400' : ''
          }`}
          style={{
            width: canvasWidth,
            minHeight: canvasHeight,
            backgroundColor: settings.backgroundColor,
            fontFamily: settings.fontFamily
          }}
          onClick={() => onSelectElement(null)}
        >
          {elements.length === 0 && (
            <div className="absolute inset-0 flex items-center justify-center text-gray-400">
              <div className="text-center">
                <p className="text-lg mb-2">Arraste elementos aqui</p>
                <p className="text-sm">Comece construindo sua landing page</p>
              </div>
            </div>
          )}

          {elements.map((element) => (
            <ElementRenderer
              key={element.id}
              element={element}
              isSelected={selectedElement === element.id}
              onSelect={() => onSelectElement(element.id)}
              onUpdate={(updates) => onUpdateElement(element.id, updates)}
              onDelete={() => onDeleteElement(element.id)}
            />
          ))}
        </div>
      </div>
    </div>
  );
};
