
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { PageData } from '@/types/pageBuilder';
import { ElementRenderer } from './ElementRenderer';
import { Monitor, Smartphone, X } from 'lucide-react';
import { useState } from 'react';

interface PreviewModalProps {
  pageData: PageData;
  onClose: () => void;
}

export const PreviewModal = ({ pageData, onClose }: PreviewModalProps) => {
  const [previewMode, setPreviewMode] = useState<'desktop' | 'mobile'>('desktop');

  const canvasWidth = previewMode === 'desktop' ? '100%' : '375px';
  const canvasHeight = '600px';

  return (
    <Dialog open={true} onOpenChange={onClose}>
      <DialogContent className="max-w-6xl max-h-[90vh]">
        <DialogHeader>
          <div className="flex items-center justify-between">
            <DialogTitle>Preview - {pageData.title}</DialogTitle>
            <div className="flex items-center gap-2">
              <div className="flex border border-gray-200 rounded-md">
                <Button
                  variant={previewMode === 'desktop' ? 'default' : 'ghost'}
                  size="sm"
                  onClick={() => setPreviewMode('desktop')}
                  className="rounded-r-none"
                >
                  <Monitor className="w-4 h-4" />
                </Button>
                <Button
                  variant={previewMode === 'mobile' ? 'default' : 'ghost'}
                  size="sm"
                  onClick={() => setPreviewMode('mobile')}
                  className="rounded-l-none"
                >
                  <Smartphone className="w-4 h-4" />
                </Button>
              </div>
              <Button variant="ghost" size="sm" onClick={onClose}>
                <X className="w-4 h-4" />
              </Button>
            </div>
          </div>
        </DialogHeader>
        
        <div className="flex justify-center bg-gray-100 p-8 rounded-lg overflow-auto">
          <div
            className="relative bg-white shadow-lg"
            style={{
              width: canvasWidth,
              minHeight: canvasHeight,
              backgroundColor: pageData.settings.backgroundColor,
              fontFamily: pageData.settings.fontFamily
            }}
          >
            {pageData.elements.length === 0 && (
              <div className="absolute inset-0 flex items-center justify-center text-gray-400">
                <div className="text-center">
                  <p className="text-lg mb-2">Página vazia</p>
                  <p className="text-sm">Adicione elementos para ver o preview</p>
                </div>
              </div>
            )}

            {pageData.elements.map((element) => (
              <div
                key={element.id}
                style={{
                  position: 'absolute',
                  left: element.styles.position.x,
                  top: element.styles.position.y,
                  width: element.styles.size.width,
                  height: element.styles.size.height,
                  backgroundColor: element.styles.backgroundColor,
                  color: element.styles.color,
                  fontSize: element.styles.fontSize,
                  fontFamily: element.styles.fontFamily,
                  padding: element.styles.padding,
                  margin: element.styles.margin,
                  borderRadius: element.styles.borderRadius,
                  textAlign: element.styles.textAlign,
                  pointerEvents: 'none'
                }}
              >
                {element.type === 'text' && (
                  <div className="whitespace-pre-wrap">{element.content}</div>
                )}
                {element.type === 'image' && (
                  <img
                    src={element.content}
                    alt="Preview"
                    className="w-full h-full object-cover"
                  />
                )}
                {element.type === 'button' && (
                  <button className="w-full h-full flex items-center justify-center font-medium">
                    {element.content}
                  </button>
                )}
                {element.type === 'video' && (
                  <iframe
                    src={element.content}
                    className="w-full h-full border-0"
                    allowFullScreen
                  />
                )}
                {element.type === 'counter' && (
                  <div className="w-full h-full flex items-center justify-center font-bold">
                    {element.content.endValue}{element.content.suffix}
                  </div>
                )}
                {element.type === 'container' && (
                  <div className="w-full h-full border-2 border-dashed border-gray-300" />
                )}
              </div>
            ))}
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
};
