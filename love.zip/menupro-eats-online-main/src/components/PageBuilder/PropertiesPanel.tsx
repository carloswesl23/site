
import { PageElement } from '@/types/pageBuilder';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Label } from '@/components/ui/label';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Separator } from '@/components/ui/separator';

interface PropertiesPanelProps {
  selectedElement: string | null;
  elements: PageElement[];
  settings: any;
  onUpdateElement: (id: string, updates: Partial<PageElement>) => void;
  onUpdateSettings: (settings: any) => void;
}

export const PropertiesPanel = ({
  selectedElement,
  elements,
  settings,
  onUpdateElement,
  onUpdateSettings
}: PropertiesPanelProps) => {
  const element = elements.find(el => el.id === selectedElement);

  if (!selectedElement || !element) {
    return (
      <div className="p-4">
        <Card>
          <CardHeader>
            <CardTitle className="text-sm">Configurações da Página</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div>
              <Label htmlFor="bg-color">Cor de Fundo</Label>
              <Input
                id="bg-color"
                type="color"
                value={settings.backgroundColor}
                onChange={(e) => onUpdateSettings({
                  ...settings,
                  backgroundColor: e.target.value
                })}
              />
            </div>
            <div>
              <Label htmlFor="primary-color">Cor Primária</Label>
              <Input
                id="primary-color"
                type="color"
                value={settings.primaryColor}
                onChange={(e) => onUpdateSettings({
                  ...settings,
                  primaryColor: e.target.value
                })}
              />
            </div>
            <div>
              <Label htmlFor="font-family">Fonte</Label>
              <select
                id="font-family"
                value={settings.fontFamily}
                onChange={(e) => onUpdateSettings({
                  ...settings,
                  fontFamily: e.target.value
                })}
                className="w-full p-2 border rounded"
              >
                <option value="Inter">Inter</option>
                <option value="Arial">Arial</option>
                <option value="Helvetica">Helvetica</option>
                <option value="Georgia">Georgia</option>
              </select>
            </div>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="p-4 space-y-4">
      <Card>
        <CardHeader>
          <CardTitle className="text-sm">Propriedades do Elemento</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div>
            <Label>Tipo: {element.type}</Label>
          </div>
          
          <Separator />
          
          <div className="space-y-3">
            <h4 className="text-sm font-medium">Posição e Tamanho</h4>
            <div className="grid grid-cols-2 gap-2">
              <div>
                <Label htmlFor="x">X</Label>
                <Input
                  id="x"
                  type="number"
                  value={element.styles.position.x}
                  onChange={(e) => onUpdateElement(element.id, {
                    styles: {
                      ...element.styles,
                      position: { ...element.styles.position, x: parseInt(e.target.value) }
                    }
                  })}
                />
              </div>
              <div>
                <Label htmlFor="y">Y</Label>
                <Input
                  id="y"
                  type="number"
                  value={element.styles.position.y}
                  onChange={(e) => onUpdateElement(element.id, {
                    styles: {
                      ...element.styles,
                      position: { ...element.styles.position, y: parseInt(e.target.value) }
                    }
                  })}
                />
              </div>
              <div>
                <Label htmlFor="width">Largura</Label>
                <Input
                  id="width"
                  type="number"
                  value={element.styles.size.width}
                  onChange={(e) => onUpdateElement(element.id, {
                    styles: {
                      ...element.styles,
                      size: { ...element.styles.size, width: parseInt(e.target.value) }
                    }
                  })}
                />
              </div>
              <div>
                <Label htmlFor="height">Altura</Label>
                <Input
                  id="height"
                  type="number"
                  value={element.styles.size.height}
                  onChange={(e) => onUpdateElement(element.id, {
                    styles: {
                      ...element.styles,
                      size: { ...element.styles.size, height: parseInt(e.target.value) }
                    }
                  })}
                />
              </div>
            </div>
          </div>
          
          <Separator />
          
          <div className="space-y-3">
            <h4 className="text-sm font-medium">Estilo</h4>
            {element.styles.backgroundColor !== undefined && (
              <div>
                <Label htmlFor="bg-color">Cor de Fundo</Label>
                <Input
                  id="bg-color"
                  type="color"
                  value={element.styles.backgroundColor || '#ffffff'}
                  onChange={(e) => onUpdateElement(element.id, {
                    styles: {
                      ...element.styles,
                      backgroundColor: e.target.value
                    }
                  })}
                />
              </div>
            )}
            {element.styles.color !== undefined && (
              <div>
                <Label htmlFor="text-color">Cor do Texto</Label>
                <Input
                  id="text-color"
                  type="color"
                  value={element.styles.color || '#000000'}
                  onChange={(e) => onUpdateElement(element.id, {
                    styles: {
                      ...element.styles,
                      color: e.target.value
                    }
                  })}
                />
              </div>
            )}
            {element.styles.fontSize !== undefined && (
              <div>
                <Label htmlFor="font-size">Tamanho da Fonte</Label>
                <Input
                  id="font-size"
                  type="number"
                  value={element.styles.fontSize || 16}
                  onChange={(e) => onUpdateElement(element.id, {
                    styles: {
                      ...element.styles,
                      fontSize: parseInt(e.target.value)
                    }
                  })}
                />
              </div>
            )}
          </div>
        </CardContent>
      </Card>
    </div>
  );
};
