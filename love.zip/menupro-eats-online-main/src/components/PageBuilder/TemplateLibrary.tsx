
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { PageTemplate } from '@/types/pageBuilder';

const templates: PageTemplate[] = [
  {
    id: 'combo-semana',
    name: 'Combo da Semana',
    description: 'Template para promoções de combos especiais',
    category: 'Promoção',
    thumbnail: 'https://images.unsplash.com/photo-1568901346375-23c9450c58cd?w=300&h=200&fit=crop',
    elements: [
      {
        id: 'title-1',
        type: 'text',
        content: 'COMBO DA SEMANA',
        styles: {
          position: { x: 50, y: 50 },
          size: { width: 400, height: 60 },
          fontSize: 32,
          color: '#ff6b35',
          textAlign: 'center'
        }
      },
      {
        id: 'subtitle-1',
        type: 'text',
        content: '2 Hambúrgueres + Batata + Refrigerante',
        styles: {
          position: { x: 50, y: 120 },
          size: { width: 400, height: 40 },
          fontSize: 18,
          color: '#1a1a1a',
          textAlign: 'center'
        }
      },
      {
        id: 'price-1',
        type: 'text',
        content: 'Apenas R$ 35,90',
        styles: {
          position: { x: 50, y: 180 },
          size: { width: 400, height: 50 },
          fontSize: 24,
          color: '#ff6b35',
          textAlign: 'center'
        }
      },
      {
        id: 'button-1',
        type: 'button',
        content: 'PEÇA AGORA',
        styles: {
          position: { x: 175, y: 250 },
          size: { width: 150, height: 50 },
          backgroundColor: '#ff6b35',
          color: '#ffffff',
          borderRadius: 8,
          textAlign: 'center'
        }
      }
    ]
  },
  {
    id: 'desconto-relampago',
    name: 'Desconto Relâmpago',
    description: 'Template para ofertas por tempo limitado',
    category: 'Promoção',
    thumbnail: 'https://images.unsplash.com/photo-1571091718767-18b5b1457add?w=300&h=200&fit=crop',
    elements: [
      {
        id: 'title-2',
        type: 'text',
        content: 'DESCONTO RELÂMPAGO',
        styles: {
          position: { x: 50, y: 50 },
          size: { width: 400, height: 60 },
          fontSize: 28,
          color: '#dc2626',
          textAlign: 'center'
        }
      },
      {
        id: 'discount-2',
        type: 'text',
        content: '50% OFF',
        styles: {
          position: { x: 50, y: 120 },
          size: { width: 400, height: 80 },
          fontSize: 48,
          color: '#dc2626',
          textAlign: 'center'
        }
      },
      {
        id: 'timer-2',
        type: 'counter',
        content: { startValue: 0, endValue: 24, duration: 1000, suffix: 'h restantes' },
        styles: {
          position: { x: 50, y: 220 },
          size: { width: 400, height: 60 },
          fontSize: 24,
          color: '#dc2626',
          textAlign: 'center'
        }
      }
    ]
  },
  {
    id: 'novidade-cardapio',
    name: 'Novidade do Cardápio',
    description: 'Template para lançamento de novos produtos',
    category: 'Lançamento',
    thumbnail: 'https://images.unsplash.com/photo-1594212699903-ec8a3eca50f5?w=300&h=200&fit=crop',
    elements: [
      {
        id: 'title-3',
        type: 'text',
        content: 'NOVIDADE NO CARDÁPIO',
        styles: {
          position: { x: 50, y: 50 },
          size: { width: 400, height: 60 },
          fontSize: 26,
          color: '#059669',
          textAlign: 'center'
        }
      },
      {
        id: 'image-3',
        type: 'image',
        content: 'https://images.unsplash.com/photo-1594212699903-ec8a3eca50f5?w=400&h=300&fit=crop',
        styles: {
          position: { x: 75, y: 120 },
          size: { width: 350, height: 250 },
          borderRadius: 12
        }
      },
      {
        id: 'description-3',
        type: 'text',
        content: 'Hambúrguer Gourmet com ingredientes selecionados',
        styles: {
          position: { x: 50, y: 390 },
          size: { width: 400, height: 40 },
          fontSize: 16,
          color: '#1a1a1a',
          textAlign: 'center'
        }
      }
    ]
  }
];

interface TemplateLibraryProps {
  onSelectTemplate: (template: PageTemplate) => void;
}

export const TemplateLibrary = ({ onSelectTemplate }: TemplateLibraryProps) => {
  return (
    <div className="space-y-4">
      <h3 className="text-sm font-medium text-gray-700 mb-3">Templates</h3>
      
      {templates.map((template) => (
        <Card key={template.id} className="hover:shadow-md transition-shadow cursor-pointer">
          <CardHeader className="pb-2">
            <div className="aspect-video bg-gray-100 rounded-lg mb-2 overflow-hidden">
              <img 
                src={template.thumbnail} 
                alt={template.name}
                className="w-full h-full object-cover"
              />
            </div>
            <CardTitle className="text-sm">{template.name}</CardTitle>
            <Badge variant="secondary" className="w-fit">
              {template.category}
            </Badge>
          </CardHeader>
          <CardContent>
            <p className="text-xs text-gray-600 mb-3">{template.description}</p>
            <Button 
              size="sm" 
              className="w-full"
              onClick={() => onSelectTemplate(template)}
            >
              Usar Template
            </Button>
          </CardContent>
        </Card>
      ))}
    </div>
  );
};
