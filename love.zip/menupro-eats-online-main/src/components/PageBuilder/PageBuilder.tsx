
import { useState, useCallback } from 'react';
import { DndContext, DragEndEvent, DragOverlay, DragStartEvent } from '@dnd-kit/core';
import { Button } from '@/components/ui/button';
import { Card } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { ElementToolbox } from './ElementToolbox';
import { Canvas } from './Canvas';
import { PropertiesPanel } from './PropertiesPanel';
import { TemplateLibrary } from './TemplateLibrary';
import { AIAssistant } from './AIAssistant';
import { PreviewModal } from './PreviewModal';
import { PageElement, PageData } from '@/types/pageBuilder';
import { Eye, Save, Smartphone, Monitor, Wand2 } from 'lucide-react';

interface PageBuilderProps {
  initialData?: PageData;
  onSave: (data: PageData) => void;
}

export const PageBuilder = ({ initialData, onSave }: PageBuilderProps) => {
  const [pageData, setPageData] = useState<PageData>(initialData || {
    id: '',
    title: 'Nova Landing Page',
    elements: [],
    settings: {
      backgroundColor: '#ffffff',
      fontFamily: 'Inter',
      primaryColor: '#ff6b35',
      secondaryColor: '#1a1a1a'
    }
  });

  const [selectedElement, setSelectedElement] = useState<string | null>(null);
  const [draggedElement, setDraggedElement] = useState<PageElement | null>(null);
  const [previewMode, setPreviewMode] = useState<'desktop' | 'mobile'>('desktop');
  const [showPreview, setShowPreview] = useState(false);
  const [showAI, setShowAI] = useState(false);

  const handleDragStart = useCallback((event: DragStartEvent) => {
    const { active } = event;
    if (active.data.current?.element) {
      setDraggedElement(active.data.current.element);
    }
  }, []);

  const handleDragEnd = useCallback((event: DragEndEvent) => {
    const { active, over } = event;
    
    if (over && over.id === 'canvas') {
      const element = active.data.current?.element;
      if (element) {
        const newElement: PageElement = {
          ...element,
          id: `${element.type}-${Date.now()}`,
          styles: {
            ...element.styles,
            position: { x: 100, y: 100 }
          }
        };
        
        setPageData(prev => ({
          ...prev,
          elements: [...prev.elements, newElement]
        }));
      }
    }
    
    setDraggedElement(null);
  }, []);

  const updateElement = useCallback((id: string, updates: Partial<PageElement>) => {
    setPageData(prev => ({
      ...prev,
      elements: prev.elements.map(el => 
        el.id === id ? { ...el, ...updates } : el
      )
    }));
  }, []);

  const deleteElement = useCallback((id: string) => {
    setPageData(prev => ({
      ...prev,
      elements: prev.elements.filter(el => el.id !== id)
    }));
    setSelectedElement(null);
  }, []);

  const handleSave = () => {
    onSave(pageData);
  };

  const loadTemplate = useCallback((template: any) => {
    setPageData(prev => ({
      ...prev,
      elements: template.elements,
      title: template.name
    }));
  }, []);

  return (
    <div className="h-screen flex flex-col bg-gray-50">
      {/* Header */}
      <div className="bg-white border-b border-gray-200 p-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-4">
            <h1 className="text-xl font-semibold text-gray-900">Page Builder</h1>
            <input
              type="text"
              value={pageData.title}
              onChange={(e) => setPageData(prev => ({ ...prev, title: e.target.value }))}
              className="text-lg font-medium bg-transparent border-none outline-none"
            />
          </div>
          
          <div className="flex items-center gap-2">
            <Button
              variant="outline"
              size="sm"
              onClick={() => setShowAI(true)}
              className="text-purple-600 border-purple-200 hover:bg-purple-50"
            >
              <Wand2 className="w-4 h-4 mr-2" />
              IA Assistant
            </Button>
            
            <div className="flex border border-gray-200 rounded-md">
              <Button
                variant={previewMode === 'desktop' ? 'default' : 'ghost'}
                size="sm"
                onClick={() => setPreviewMode('desktop')}
                className="rounded-r-none"
              >
                <Monitor className="w-4 h-4" />
              </Button>
              <Button
                variant={previewMode === 'mobile' ? 'default' : 'ghost'}
                size="sm"
                onClick={() => setPreviewMode('mobile')}
                className="rounded-l-none"
              >
                <Smartphone className="w-4 h-4" />
              </Button>
            </div>
            
            <Button
              variant="outline"
              size="sm"
              onClick={() => setShowPreview(true)}
            >
              <Eye className="w-4 h-4 mr-2" />
              Preview
            </Button>
            
            <Button size="sm" onClick={handleSave} className="gradient-brand text-white">
              <Save className="w-4 h-4 mr-2" />
              Salvar
            </Button>
          </div>
        </div>
      </div>

      {/* Main Content */}
      <div className="flex-1 flex overflow-hidden">
        <DndContext onDragStart={handleDragStart} onDragEnd={handleDragEnd}>
          {/* Left Sidebar */}
          <div className="w-80 bg-white border-r border-gray-200 overflow-y-auto">
            <Tabs defaultValue="elements" className="h-full">
              <TabsList className="grid w-full grid-cols-2 m-4">
                <TabsTrigger value="elements">Elementos</TabsTrigger>
                <TabsTrigger value="templates">Templates</TabsTrigger>
              </TabsList>
              
              <TabsContent value="elements" className="p-4 pt-0">
                <ElementToolbox />
              </TabsContent>
              
              <TabsContent value="templates" className="p-4 pt-0">
                <TemplateLibrary onSelectTemplate={loadTemplate} />
              </TabsContent>
            </Tabs>
          </div>

          {/* Canvas Area */}
          <div className="flex-1 bg-gray-100 overflow-auto">
            <Canvas
              elements={pageData.elements}
              settings={pageData.settings}
              selectedElement={selectedElement}
              onSelectElement={setSelectedElement}
              onUpdateElement={updateElement}
              onDeleteElement={deleteElement}
              previewMode={previewMode}
            />
          </div>

          {/* Right Sidebar */}
          <div className="w-80 bg-white border-l border-gray-200 overflow-y-auto">
            <PropertiesPanel
              selectedElement={selectedElement}
              elements={pageData.elements}
              settings={pageData.settings}
              onUpdateElement={updateElement}
              onUpdateSettings={(settings) => setPageData(prev => ({ ...prev, settings }))}
            />
          </div>

          <DragOverlay>
            {draggedElement && (
              <Card className="p-4 bg-white shadow-lg opacity-90">
                {draggedElement.type}
              </Card>
            )}
          </DragOverlay>
        </DndContext>
      </div>

      {/* Modals */}
      {showPreview && (
        <PreviewModal
          pageData={pageData}
          onClose={() => setShowPreview(false)}
        />
      )}

      {showAI && (
        <AIAssistant
          pageData={pageData}
          onApplyChanges={(newPageData) => setPageData(newPageData)}
          onClose={() => setShowAI(false)}
        />
      )}
    </div>
  );
};
