
import { useState, useRef, useEffect } from 'react';
import { PageElement } from '@/types/pageBuilder';
import { Button } from '@/components/ui/button';
import { Trash2, Move } from 'lucide-react';

interface ElementRendererProps {
  element: PageElement;
  isSelected: boolean;
  onSelect: () => void;
  onUpdate: (updates: Partial<PageElement>) => void;
  onDelete: () => void;
}

export const ElementRenderer = ({
  element,
  isSelected,
  onSelect,
  onUpdate,
  onDelete
}: ElementRendererProps) => {
  const [isDragging, setIsDragging] = useState(false);
  const [isEditing, setIsEditing] = useState(false);
  const elementRef = useRef<HTMLDivElement>(null);

  const handleMouseDown = (e: React.MouseEvent) => {
    if (e.detail === 2) { // Double click
      setIsEditing(true);
      return;
    }
    
    onSelect();
    setIsDragging(true);
    
    const startX = e.clientX - element.styles.position.x;
    const startY = e.clientY - element.styles.position.y;

    const handleMouseMove = (e: MouseEvent) => {
      const newX = e.clientX - startX;
      const newY = e.clientY - startY;
      
      onUpdate({
        styles: {
          ...element.styles,
          position: { x: Math.max(0, newX), y: Math.max(0, newY) }
        }
      });
    };

    const handleMouseUp = () => {
      setIsDragging(false);
      document.removeEventListener('mousemove', handleMouseMove);
      document.removeEventListener('mouseup', handleMouseUp);
    };

    document.addEventListener('mousemove', handleMouseMove);
    document.addEventListener('mouseup', handleMouseUp);
  };

  const handleContentChange = (newContent: any) => {
    onUpdate({ content: newContent });
    setIsEditing(false);
  };

  const renderElement = () => {
    const style = {
      position: 'absolute' as const,
      left: element.styles.position.x,
      top: element.styles.position.y,
      width: element.styles.size.width,
      height: element.styles.size.height,
      backgroundColor: element.styles.backgroundColor,
      color: element.styles.color,
      fontSize: element.styles.fontSize,
      fontFamily: element.styles.fontFamily,
      padding: element.styles.padding,
      margin: element.styles.margin,
      borderRadius: element.styles.borderRadius,
      textAlign: element.styles.textAlign,
      cursor: isDragging ? 'grabbing' : 'grab'
    };

    switch (element.type) {
      case 'text':
        return isEditing ? (
          <textarea
            style={style}
            value={element.content}
            onChange={(e) => handleContentChange(e.target.value)}
            onBlur={() => setIsEditing(false)}
            onKeyDown={(e) => e.key === 'Enter' && e.shiftKey === false && setIsEditing(false)}
            className="resize-none border-none outline-none bg-transparent"
            autoFocus
          />
        ) : (
          <div style={style} className="whitespace-pre-wrap">
            {element.content}
          </div>
        );

      case 'image':
        return (
          <img
            src={element.content}
            alt="Landing page element"
            style={style}
            className="object-cover"
          />
        );

      case 'button':
        return (
          <button
            style={style}
            className="flex items-center justify-center font-medium hover:opacity-90 transition-opacity"
            onClick={(e) => e.preventDefault()}
          >
            {element.content}
          </button>
        );

      case 'video':
        return (
          <iframe
            src={element.content}
            style={style}
            className="border-0"
            allowFullScreen
          />
        );

      case 'counter':
        return (
          <div style={style} className="flex items-center justify-center font-bold">
            {element.content.endValue}{element.content.suffix}
          </div>
        );

      case 'container':
        return (
          <div style={style} className="border-2 border-dashed border-gray-300">
            {/* Container pode ter elementos filhos no futuro */}
          </div>
        );

      default:
        return null;
    }
  };

  return (
    <div
      ref={elementRef}
      className={`group ${isSelected ? 'z-10' : 'z-0'}`}
      onMouseDown={handleMouseDown}
      onClick={(e) => e.stopPropagation()}
    >
      {renderElement()}
      
      {isSelected && (
        <>
          {/* Selection outline */}
          <div
            className="absolute border-2 border-blue-400 pointer-events-none"
            style={{
              left: element.styles.position.x - 2,
              top: element.styles.position.y - 2,
              width: element.styles.size.width + 4,
              height: element.styles.size.height + 4
            }}
          />
          
          {/* Action buttons */}
          <div
            className="absolute flex gap-1"
            style={{
              left: element.styles.position.x,
              top: element.styles.position.y - 32
            }}
          >
            <Button
              size="sm"
              variant="outline"
              className="h-6 w-6 p-0 bg-white"
              onClick={onDelete}
            >
              <Trash2 className="w-3 h-3" />
            </Button>
            <div className="h-6 px-2 bg-blue-500 text-white text-xs flex items-center rounded">
              <Move className="w-3 h-3 mr-1" />
              {element.type}
            </div>
          </div>
        </>
      )}
    </div>
  );
};
