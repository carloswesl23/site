
import { useState } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { PageData } from '@/types/pageBuilder';
import { Wand2, Sparkles } from 'lucide-react';

interface AIAssistantProps {
  pageData: PageData;
  onApplyChanges: (newPageData: PageData) => void;
  onClose: () => void;
}

const suggestions = [
  {
    title: 'Combo Promocional',
    description: 'Criar uma página para promoção de combo com desconto especial',
    prompt: 'Crie uma página promocional para um combo de hambúrguer com batata e refrigerante por R$ 29,90'
  },
  {
    title: 'Lançamento de Produto',
    description: 'Página para apresentar um novo item do cardápio',
    prompt: 'Crie uma página para lançamento de um novo hambúrguer gourmet artesanal'
  },
  {
    title: 'Desconto por Tempo Limitado',
    description: 'Página de oferta relâmpago com contador regressivo',
    prompt: 'Crie uma página de desconto de 40% por tempo limitado até meia-noite'
  },
  {
    title: 'Evento Especial',
    description: 'Página para promoção de data comemorativa',
    prompt: 'Crie uma página especial para o Dia dos Namorados com menu romântico'
  }
];

export const AIAssistant = ({ pageData, onApplyChanges, onClose }: AIAssistantProps) => {
  const [prompt, setPrompt] = useState('');
  const [isGenerating, setIsGenerating] = useState(false);

  const handleGenerate = async (customPrompt?: string) => {
    const finalPrompt = customPrompt || prompt;
    if (!finalPrompt.trim()) return;

    setIsGenerating(true);
    
    // Simulação de geração com IA
    // Em produção, aqui faria uma chamada para um serviço de IA
    setTimeout(() => {
      const mockResponse = {
        ...pageData,
        title: 'Página Gerada por IA',
        elements: [
          {
            id: 'ai-title-1',
            type: 'text' as const,
            content: 'OFERTA ESPECIAL',
            styles: {
              position: { x: 100, y: 50 },
              size: { width: 300, height: 50 },
              fontSize: 28,
              color: '#ff6b35',
              textAlign: 'center' as const
            }
          },
          {
            id: 'ai-subtitle-1',
            type: 'text' as const,
            content: finalPrompt,
            styles: {
              position: { x: 100, y: 120 },
              size: { width: 300, height: 60 },
              fontSize: 16,
              color: '#1a1a1a',
              textAlign: 'center' as const
            }
          },
          {
            id: 'ai-button-1',
            type: 'button' as const,
            content: 'APROVEITAR OFERTA',
            styles: {
              position: { x: 150, y: 200 },
              size: { width: 200, height: 50 },
              backgroundColor: '#ff6b35',
              color: '#ffffff',
              borderRadius: 8,
              textAlign: 'center' as const,
              padding: 12
            },
            properties: {
              href: '#',
              target: '_self'
            }
          }
        ]
      };
      
      onApplyChanges(mockResponse);
      setIsGenerating(false);
      onClose();
    }, 2000);
  };

  return (
    <Dialog open={true} onOpenChange={onClose}>
      <DialogContent className="max-w-2xl max-h-[80vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Wand2 className="w-5 h-5 text-purple-600" />
            Assistente de IA
          </DialogTitle>
        </DialogHeader>
        
        <div className="space-y-6">
          <div>
            <h3 className="text-sm font-medium mb-3">Descreva sua página</h3>
            <Textarea
              placeholder="Ex: Crie uma página promocional para combo de hambúrguer com 30% de desconto..."
              value={prompt}
              onChange={(e) => setPrompt(e.target.value)}
              rows={3}
            />
            <Button 
              onClick={() => handleGenerate()}
              disabled={!prompt.trim() || isGenerating}
              className="mt-3 w-full"
            >
              {isGenerating ? (
                <>
                  <Sparkles className="w-4 h-4 mr-2 animate-spin" />
                  Gerando...
                </>
              ) : (
                <>
                  <Wand2 className="w-4 h-4 mr-2" />
                  Gerar Página
                </>
              )}
            </Button>
          </div>
          
          <div>
            <h3 className="text-sm font-medium mb-3">Ou escolha uma sugestão</h3>
            <div className="grid gap-3">
              {suggestions.map((suggestion, index) => (
                <Card key={index} className="hover:bg-gray-50 cursor-pointer transition-colors">
                  <CardHeader className="pb-2">
                    <CardTitle className="text-sm">{suggestion.title}</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <p className="text-xs text-gray-600 mb-3">{suggestion.description}</p>
                    <Button 
                      size="sm" 
                      variant="outline" 
                      onClick={() => handleGenerate(suggestion.prompt)}
                      disabled={isGenerating}
                      className="w-full"
                    >
                      {isGenerating ? 'Gerando...' : 'Usar esta sugestão'}
                    </Button>
                  </CardContent>
                </Card>
              ))}
            </div>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
};
