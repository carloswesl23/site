
import { useDraggable } from '@dnd-kit/core';
import { Card } from '@/components/ui/card';
import { Type, Image, Square, Video, Hash, Box } from 'lucide-react';

const elements = [
  {
    type: 'text',
    label: 'Texto',
    icon: Type,
    content: 'Clique para editar texto',
    styles: {
      position: { x: 0, y: 0 },
      size: { width: 200, height: 40 },
      fontSize: 16,
      color: '#1a1a1a',
      textAlign: 'left' as const
    }
  },
  {
    type: 'image',
    label: 'Imagem',
    icon: Image,
    content: 'https://images.unsplash.com/photo-1649972904349-6e44c42644a7?w=400&h=300&fit=crop',
    styles: {
      position: { x: 0, y: 0 },
      size: { width: 300, height: 200 },
      borderRadius: 8
    }
  },
  {
    type: 'button',
    label: 'Botão',
    icon: Square,
    content: 'Clique aqui',
    styles: {
      position: { x: 0, y: 0 },
      size: { width: 150, height: 40 },
      backgroundColor: '#ff6b35',
      color: '#ffffff',
      borderRadius: 6,
      textAlign: 'center' as const,
      padding: 12
    },
    properties: {
      href: '#',
      target: '_self'
    }
  },
  {
    type: 'video',
    label: 'Vídeo',
    icon: Video,
    content: 'https://www.youtube.com/embed/dQw4w9WgXcQ',
    styles: {
      position: { x: 0, y: 0 },
      size: { width: 400, height: 225 },
      borderRadius: 8
    }
  },
  {
    type: 'counter',
    label: 'Contador',
    icon: Hash,
    content: { startValue: 0, endValue: 100, duration: 2000, suffix: '' },
    styles: {
      position: { x: 0, y: 0 },
      size: { width: 150, height: 60 },
      fontSize: 24,
      color: '#ff6b35',
      textAlign: 'center' as const
    }
  },
  {
    type: 'container',
    label: 'Container',
    icon: Box,
    content: [],
    styles: {
      position: { x: 0, y: 0 },
      size: { width: 400, height: 200 },
      backgroundColor: '#f8f9fa',
      borderRadius: 8,
      padding: 20
    }
  }
];

interface DraggableElementProps {
  element: any;
}

const DraggableElement = ({ element }: DraggableElementProps) => {
  const { attributes, listeners, setNodeRef, isDragging } = useDraggable({
    id: `draggable-${element.type}`,
    data: { element }
  });

  const Icon = element.icon;

  return (
    <Card
      ref={setNodeRef}
      {...listeners}
      {...attributes}
      className={`p-4 cursor-move hover:shadow-md transition-shadow ${
        isDragging ? 'opacity-50' : ''
      }`}
    >
      <div className="flex items-center gap-3">
        <div className="w-8 h-8 bg-gray-100 rounded-lg flex items-center justify-center">
          <Icon className="w-4 h-4 text-gray-600" />
        </div>
        <div>
          <p className="font-medium text-sm text-gray-900">{element.label}</p>
          <p className="text-xs text-gray-500">Arraste para adicionar</p>
        </div>
      </div>
    </Card>
  );
};

export const ElementToolbox = () => {
  return (
    <div className="space-y-3">
      <h3 className="text-sm font-medium text-gray-700 mb-3">Elementos</h3>
      {elements.map((element) => (
        <DraggableElement key={element.type} element={element} />
      ))}
    </div>
  );
};
