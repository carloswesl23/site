import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { TrendingUp, DollarSign, CreditCard, BarChart3 } from "lucide-react";

interface ReportsKPICardsProps {
  vendas: number;
  receitaConfirmada: number;
  ticketMedio: number;
  taxaConversaoPix: number;
  totalPedidos: number;
  pedidosPix: number;
}

export function ReportsKPICards({
  vendas,
  receitaConfirmada,
  ticketMedio,
  taxaConversaoPix,
  totalPedidos,
  pedidosPix,
}: ReportsKPICardsProps) {
  return (
    <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
      {/* Vendas */}
      <Card className="border-l-4 border-l-primary">
        <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
          <CardTitle className="text-sm font-medium">Vendas Totais</CardTitle>
          <DollarSign className="h-4 w-4 text-primary" />
        </CardHeader>
        <CardContent>
          <div className="text-2xl font-bold text-foreground">R$ {vendas.toLocaleString('pt-BR', { minimumFractionDigits: 2 })}</div>
          <p className="text-xs text-primary flex items-center gap-1">
            <TrendingUp className="h-3 w-3" />
            Dados em tempo real
          </p>
          <p className="text-xs text-muted-foreground mt-1">{totalPedidos} pedidos realizados</p>
        </CardContent>
      </Card>

      {/* Receita */}
      <Card className="border-l-4 border-l-green-500">
        <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
          <CardTitle className="text-sm font-medium">Receita Confirmada</CardTitle>
          <CreditCard className="h-4 w-4 text-green-600" />
        </CardHeader>
        <CardContent>
          <div className="text-2xl font-bold text-foreground">R$ {receitaConfirmada.toLocaleString('pt-BR', { minimumFractionDigits: 2 })}</div>
          <p className="text-xs text-green-600 flex items-center gap-1">
            <TrendingUp className="h-3 w-3" />
            Pedidos entregues/prontos
          </p>
          <p className="text-xs text-muted-foreground mt-1">Receita de pedidos confirmados</p>
        </CardContent>
      </Card>

      {/* Ticket Médio */}
      <Card className="border-l-4 border-l-orange-500">
        <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
          <CardTitle className="text-sm font-medium">Ticket Médio</CardTitle>
          <BarChart3 className="h-4 w-4 text-orange-600" />
        </CardHeader>
        <CardContent>
          <div className="text-2xl font-bold text-foreground">R$ {ticketMedio.toLocaleString('pt-BR', { minimumFractionDigits: 2 })}</div>
          <p className="text-xs text-orange-600 flex items-center gap-1">
            <TrendingUp className="h-3 w-3" />
            Valor médio por pedido
          </p>
        </CardContent>
      </Card>

      {/* Taxa de Conversão */}
      <Card className="border-l-4 border-l-blue-500">
        <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
          <CardTitle className="text-sm font-medium">Taxa Conversão Pix</CardTitle>
          <div className="h-4 w-4 bg-blue-600 rounded text-white text-xs flex items-center justify-center font-bold">
            Pix
          </div>
        </CardHeader>
        <CardContent>
          <div className="text-2xl font-bold text-foreground">{taxaConversaoPix.toFixed(1)}%</div>
          <p className="text-xs text-blue-600 flex items-center gap-1">
            <TrendingUp className="h-3 w-3" />
            Taxa de pagamento PIX
          </p>
          <p className="text-xs text-muted-foreground mt-1">{pedidosPix} de {totalPedidos} pedidos</p>
        </CardContent>
      </Card>
    </div>
  );
}