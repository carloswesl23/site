import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { ChartContainer, ChartTooltip, ChartTooltipContent } from "@/components/ui/chart";
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, LineChart, Line, Area, AreaChart } from "recharts";

interface SalesData {
  name: string;
  vendas: number;
  receita: number;
  pedidos: number;
}

interface WeeklyData {
  name: string;
  vendas: number;
  conversao: number;
  visualizacoes: number;
}

interface ReportsChartsProps {
  salesData: SalesData[];
  weeklyData: WeeklyData[];
}

const chartConfig = {
  vendas: {
    label: "Vendas",
    color: "hsl(var(--primary))",
  },
  receita: {
    label: "Receita",
    color: "hsl(var(--chart-2))",
  },
  pedidos: {
    label: "Pedidos",
    color: "hsl(var(--chart-3))",
  },
  conversao: {
    label: "Conversão",
    color: "hsl(var(--chart-4))",
  },
  visualizacoes: {
    label: "Visualizações",
    color: "hsl(var(--chart-5))",
  },
};

export function ReportsCharts({ salesData, weeklyData }: ReportsChartsProps) {
  return (
    <div className="grid gap-6 lg:grid-cols-2">
      {/* Vendas Chart */}
      <Card>
        <CardHeader>
          <CardTitle className="text-foreground">Evolução das Vendas</CardTitle>
          <p className="text-sm text-muted-foreground">Faturamento mensal acumulado</p>
        </CardHeader>
        <CardContent>
          <ChartContainer config={chartConfig} className="h-[300px]">
            <AreaChart data={salesData}>
              <defs>
                <linearGradient id="vendas" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="hsl(var(--primary))" stopOpacity={0.3}/>
                  <stop offset="95%" stopColor="hsl(var(--primary))" stopOpacity={0}/>
                </linearGradient>
              </defs>
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis dataKey="name" />
              <YAxis />
              <ChartTooltip
                content={<ChartTooltipContent />}
                formatter={(value: any) => [`R$ ${value.toLocaleString()}`, 'Vendas']}
              />
              <Area
                type="monotone"
                dataKey="vendas"
                stroke="hsl(var(--primary))"
                fillOpacity={1}
                fill="url(#vendas)"
                strokeWidth={2}
              />
            </AreaChart>
          </ChartContainer>
        </CardContent>
      </Card>

      {/* Receita vs Vendas */}
      <Card>
        <CardHeader>
          <CardTitle className="text-foreground">Receita vs Vendas</CardTitle>
          <p className="text-sm text-muted-foreground">Comparativo mensal</p>
        </CardHeader>
        <CardContent>
          <ChartContainer config={chartConfig} className="h-[300px]">
            <BarChart data={salesData}>
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis dataKey="name" />
              <YAxis />
              <ChartTooltip content={<ChartTooltipContent />} />
              <Bar dataKey="vendas" fill="hsl(var(--primary))" name="Vendas" />
              <Bar dataKey="receita" fill="hsl(var(--chart-2))" name="Receita" />
            </BarChart>
          </ChartContainer>
        </CardContent>
      </Card>

      {/* Performance Semanal */}
      <Card>
        <CardHeader>
          <CardTitle className="text-foreground">Performance Semanal</CardTitle>
          <p className="text-sm text-muted-foreground">Vendas e conversão por dia</p>
        </CardHeader>
        <CardContent>
          <ChartContainer config={chartConfig} className="h-[300px]">
            <LineChart data={weeklyData}>
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis dataKey="name" />
              <YAxis />
              <ChartTooltip content={<ChartTooltipContent />} />
              <Line
                type="monotone"
                dataKey="vendas"
                stroke="hsl(var(--primary))"
                strokeWidth={2}
                name="Vendas"
              />
              <Line
                type="monotone"
                dataKey="conversao"
                stroke="hsl(var(--chart-4))"
                strokeWidth={2}
                name="Conversão %"
              />
            </LineChart>
          </ChartContainer>
        </CardContent>
      </Card>

      {/* Visualizações vs Conversão */}
      <Card>
        <CardHeader>
          <CardTitle className="text-foreground">Visualizações vs Conversão</CardTitle>
          <p className="text-sm text-muted-foreground">Efetividade do cardápio</p>
        </CardHeader>
        <CardContent>
          <ChartContainer config={chartConfig} className="h-[300px]">
            <AreaChart data={weeklyData}>
              <defs>
                <linearGradient id="visualizacoes" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="hsl(var(--chart-5))" stopOpacity={0.3}/>
                  <stop offset="95%" stopColor="hsl(var(--chart-5))" stopOpacity={0}/>
                </linearGradient>
              </defs>
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis dataKey="name" />
              <YAxis />
              <ChartTooltip content={<ChartTooltipContent />} />
              <Area
                type="monotone"
                dataKey="visualizacoes"
                stroke="hsl(var(--chart-5))"
                fillOpacity={1}
                fill="url(#visualizacoes)"
                strokeWidth={2}
                name="Visualizações"
              />
            </AreaChart>
          </ChartContainer>
        </CardContent>
      </Card>
    </div>
  );
}