import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { TrendingDown, TrendingUp, Users, Eye } from "lucide-react";

interface ReportsSecondaryKPIsProps {
  taxaCancelamento: number;
  clientesRecorrentes: number;
  visualizacoesCardapio: number;
  conversaoGeral: number;
  clientesRecorrentesQtd: number;
  clientesTotais: number;
  totalPedidos: number;
}

export function ReportsSecondaryKPIs({
  taxaCancelamento,
  clientesRecorrentes,
  visualizacoesCardapio,
  conversaoGeral,
  clientesRecorrentesQtd,
  clientesTotais,
  totalPedidos,
}: ReportsSecondaryKPIsProps) {
  return (
    <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
      {/* Taxa de Cancelamento */}
      <Card>
        <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
          <CardTitle className="text-sm font-medium">Taxa Cancelamento</CardTitle>
          <TrendingDown className="h-4 w-4 text-red-600" />
        </CardHeader>
        <CardContent>
          <div className="text-2xl font-bold text-foreground">{taxaCancelamento.toFixed(1)}%</div>
          <p className="text-xs text-muted-foreground">Taxa de pedidos cancelados</p>
        </CardContent>
      </Card>

      {/* Clientes Recorrentes */}
      <Card>
        <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
          <CardTitle className="text-sm font-medium">Clientes Recorrentes</CardTitle>
          <Users className="h-4 w-4 text-purple-600" />
        </CardHeader>
        <CardContent>
          <div className="text-2xl font-bold text-foreground">{clientesRecorrentes.toFixed(1)}%</div>
          <p className="text-xs text-muted-foreground">{clientesRecorrentesQtd} clientes recorrentes</p>
          <p className="text-xs text-muted-foreground">{clientesTotais - clientesRecorrentesQtd} novos clientes</p>
        </CardContent>
      </Card>

      {/* Visualizações */}
      <Card>
        <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
          <CardTitle className="text-sm font-medium">Visualizações Cardápio</CardTitle>
          <Eye className="h-4 w-4 text-indigo-600" />
        </CardHeader>
        <CardContent>
          <div className="text-2xl font-bold text-foreground">{visualizacoesCardapio.toLocaleString()}</div>
          <p className="text-xs text-indigo-600">Visualizações estimadas</p>
        </CardContent>
      </Card>

      {/* Taxa de Conversão Geral */}
      <Card>
        <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
          <CardTitle className="text-sm font-medium">Conversão Geral</CardTitle>
          <TrendingUp className="h-4 w-4 text-green-600" />
        </CardHeader>
        <CardContent>
          <div className="text-2xl font-bold text-foreground">{conversaoGeral.toFixed(1)}%</div>
          <p className="text-xs text-green-600">{totalPedidos} pedidos de {visualizacoesCardapio} visualizações</p>
        </CardContent>
      </Card>
    </div>
  );
}