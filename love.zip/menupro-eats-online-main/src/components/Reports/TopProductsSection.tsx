import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Medal } from "lucide-react";

interface TopProduct {
  id: string;
  name: string;
  vendas: number;
  image: string | null;
  category: string;
}

interface TopProductsSectionProps {
  products: TopProduct[];
}

export function TopProductsSection({ products }: TopProductsSectionProps) {
  return (
    <Card>
      <CardHeader>
        <CardTitle className="text-foreground flex items-center gap-2">
          <Medal className="h-5 w-5 text-yellow-500" />
          Top Produtos
        </CardTitle>
        <p className="text-sm text-muted-foreground">Os mais vendidos do período</p>
      </CardHeader>
      <CardContent className="space-y-4">
        {products.length === 0 ? (
          <div className="text-center py-8 text-muted-foreground">
            <Medal className="h-12 w-12 mx-auto mb-3 text-muted-foreground/50" />
            <p>Nenhum produto vendido no período</p>
            <p className="text-sm">Os produtos mais vendidos aparecerão aqui</p>
          </div>
        ) : (
          products.map((product, index) => (
            <div key={product.id} className="flex items-center gap-3 p-3 rounded-lg bg-muted/50">
              <div className="flex-shrink-0">
                {index < 3 ? (
                  <div className={`w-8 h-8 rounded-full flex items-center justify-center text-white font-bold text-sm ${
                    index === 0 ? 'bg-yellow-500' : index === 1 ? 'bg-gray-400' : 'bg-amber-600'
                  }`}>
                    {index + 1}
                  </div>
                ) : (
                  <div className="w-8 h-8 rounded-full bg-muted flex items-center justify-center text-sm font-medium">
                    {index + 1}
                  </div>
                )}
              </div>
              {product.image && (
                <img
                  src={product.image}
                  alt={product.name}
                  className="w-12 h-12 rounded-lg object-cover"
                />
              )}
              <div className="flex-1">
                <p className="font-medium text-foreground">{product.name}</p>
                <p className="text-sm text-muted-foreground">{product.vendas} vendas</p>
              </div>
              {index < 3 && (
                <Medal className={`h-5 w-5 ${
                  index === 0 ? 'text-yellow-500' : index === 1 ? 'text-gray-400' : 'text-amber-600'
                }`} />
              )}
            </div>
          ))
        )}
      </CardContent>
    </Card>
  );
}