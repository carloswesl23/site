
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Clock, Eye, ShoppingCart } from "lucide-react";
import { useNavigate } from "react-router-dom";
import { useState, useEffect } from "react";
import { supabase } from "@/integrations/supabase/client";

interface Order {
  id: string;
  order_number: string;
  customer_name: string;
  items: any[];
  total: number;
  status: 'pending' | 'preparing' | 'delivery';
  created_at: string;
}

const getStatusColor = (status: Order['status']) => {
  switch (status) {
    case 'pending': return 'bg-blue-100 text-blue-800';
    case 'preparing': return 'bg-yellow-100 text-yellow-800';
    case 'delivery': return 'bg-green-100 text-green-800';
    default: return 'bg-gray-100 text-gray-800';
  }
};

const getStatusText = (status: Order['status']) => {
  switch (status) {
    case 'pending': return 'Aguardando Pagamento';
    case 'preparing': return 'Em Preparo';
    case 'delivery': return 'Em Entrega';
    default: return 'Desconhecido';
  }
};

const getOrderStatus = (status: string): 'pending' | 'preparing' | 'delivery' => {
  switch (status) {
    case 'pending':
    case 'confirmed':
      return 'pending';
    case 'preparing':
      return 'preparing';
    case 'ready':
    case 'ready_for_delivery':
    case 'out_for_delivery':
    case 'delivered':
      return 'delivery';
    default:
      return 'pending';
  }
};

export function RecentOrders() {
  const navigate = useNavigate();
  const [orders, setOrders] = useState<Order[]>([]);

  useEffect(() => {
    const fetchRecentOrders = async () => {
      try {
        const { data: { user } } = await supabase.auth.getUser();
        if (!user) return;

        // Buscar apenas pedidos do dia atual
        const today = new Date();
        const startOfDay = new Date(today.setHours(0, 0, 0, 0));

        const { data, error } = await supabase
          .from('user_orders')
          .select('*')
          .eq('user_id', user.id)
          .gte('created_at', startOfDay.toISOString())
          .order('created_at', { ascending: false })
          .limit(5);

        if (error) {
          console.error('Error fetching orders:', error);
          return;
        }

        setOrders((data || []).map(order => ({
          id: order.id,
          order_number: order.order_number,
          customer_name: order.customer_name,
          items: Array.isArray(order.items) ? order.items : [],
          total: order.total,
          status: getOrderStatus(order.status),
          created_at: order.created_at
        })));
      } catch (error) {
        console.error('Error fetching recent orders:', error);
      }
    };

    fetchRecentOrders();
    
    // Configurar realtime updates para user_orders
    const ordersChannel = supabase
      .channel('recent-orders-changes')
      .on(
        'postgres_changes',
        {
          event: '*',
          schema: 'public',
          table: 'user_orders'
        },
        () => {
          console.log('Orders updated, refreshing recent orders...');
          fetchRecentOrders();
        }
      )
      .subscribe();
    
    // Atualizar pedidos a cada 60 segundos como fallback
    const interval = setInterval(fetchRecentOrders, 60000);
    
    return () => {
      clearInterval(interval);
      supabase.removeChannel(ordersChannel);
    };
  }, []);

  const handleViewOrder = (orderId: string) => {
    navigate("/orders", { state: { selectedOrderId: orderId } });
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Clock className="h-5 w-5 text-brand-orange" />
          Pedidos Recentes
        </CardTitle>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          {orders.length === 0 ? (
            <div className="text-center py-8 text-gray-500">
              <ShoppingCart className="h-12 w-12 mx-auto mb-3 text-gray-300" />
              <p>Nenhum pedido recente encontrado</p>
              <p className="text-sm">Os pedidos aparecerão aqui quando você começar a receber vendas</p>
            </div>
          ) : (
            orders.map((order) => (
              <div key={order.id} className="flex items-center justify-between p-4 border rounded-lg hover:bg-gray-50 transition-colors">
                <div className="flex-1">
                  <div className="flex items-center gap-2 mb-1">
                    <span className="font-medium text-brand-dark">#{order.order_number}</span>
                    <Badge className={getStatusColor(order.status)}>
                      {getStatusText(order.status)}
                    </Badge>
                  </div>
                  <p className="text-sm text-gray-600 mb-1">{order.customer_name}</p>
                  <p className="text-xs text-gray-500">
                    {Array.isArray(order.items) ? 
                      order.items.map(item => `${item.quantity}x ${item.name}`).join(', ') : 
                      'Itens do pedido'
                    }
                  </p>
                </div>
                <div className="text-right">
                  <p className="font-semibold text-brand-orange">R$ {order.total.toFixed(2).replace('.', ',')}</p>
                  <p className="text-xs text-gray-500">
                    {new Date(order.created_at).toLocaleTimeString('pt-BR', { 
                      hour: '2-digit', 
                      minute: '2-digit' 
                    })}
                  </p>
                  <Button 
                    size="sm" 
                    variant="outline" 
                    className="mt-2"
                    onClick={() => handleViewOrder(order.id)}
                  >
                    <Eye className="h-3 w-3 mr-1" />
                    Ver
                  </Button>
                </div>
              </div>
            ))
          )}
        </div>
      </CardContent>
    </Card>
  );
}
