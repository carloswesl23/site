import React, { useEffect, useState, useRef, useCallback } from 'react';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Separator } from '@/components/ui/separator';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Switch } from '@/components/ui/switch';
import { Search, Send, X, MessageSquare, Pin, Users, Package, Settings, Volume2, VolumeX, Loader2, MessageCircle, Minimize2 } from 'lucide-react';
import { supabase } from '@/integrations/supabase/client';
import { useToast } from '@/components/ui/use-toast';
import { format } from 'date-fns';
import { ptBR } from 'date-fns/locale';

interface Chat {
  id: string;
  phone_e164: string;
  name?: string;
  last_message?: string;
  last_message_at?: string;
  unread_count: number;
  is_pinned: boolean;
  is_vip: boolean;
  has_open_order: boolean;
}

interface WhatsAppMessage {
  id: string;
  phone_e164: string;
  direction: 'IN' | 'OUT';
  body: string;
  media_url?: string;
  status: string;
  created_at: string;
  zapi_msg_id?: string;
}

interface LoveZapMiniPanelProps {
  isOpen: boolean;
  onClose: () => void;
  selectedPhone?: string;
  onPhoneSelect: (phone: string) => void;
}

const LoveZapMiniPanel: React.FC<LoveZapMiniPanelProps> = ({ 
  isOpen, 
  onClose, 
  selectedPhone,
  onPhoneSelect 
}) => {
  const [chats, setChats] = useState<Chat[]>([]);
  const [messages, setMessages] = useState<WhatsAppMessage[]>([]);
  const [selectedChat, setSelectedChat] = useState<Chat | null>(null);
  const [searchTerm, setSearchTerm] = useState('');
  const [messageInput, setMessageInput] = useState('');
  const [filter, setFilter] = useState<'all' | 'unread' | 'vip' | 'orders'>('all');
  const [loading, setLoading] = useState(false);
  const [loadingMessages, setLoadingMessages] = useState(false);
  const [sending, setSending] = useState(false);
  const [page, setPage] = useState(1);
  const [hasMore, setHasMore] = useState(true);
  const [soundEnabled, setSoundEnabled] = useState(true);
  
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const panelRef = useRef<HTMLDivElement>(null);
  const { toast } = useToast();

  // Função para tocar som de notificação
  const playNotificationSound = useCallback(() => {
    if (!soundEnabled) return;
    
    try {
      // Criar um som simples usando Web Audio API
      const AudioContextClass = window.AudioContext || (window as any).webkitAudioContext;
      const audioContext = new AudioContextClass();
      const oscillator = audioContext.createOscillator();
      const gainNode = audioContext.createGain();
      
      oscillator.connect(gainNode);
      gainNode.connect(audioContext.destination);
      
      oscillator.frequency.setValueAtTime(800, audioContext.currentTime);
      oscillator.frequency.setValueAtTime(600, audioContext.currentTime + 0.1);
      
      gainNode.gain.setValueAtTime(0.3, audioContext.currentTime);
      gainNode.gain.exponentialRampToValueAtTime(0.01, audioContext.currentTime + 0.3);
      
      oscillator.start(audioContext.currentTime);
      oscillator.stop(audioContext.currentTime + 0.3);
    } catch (error) {
      console.log('Erro ao tocar som de notificação:', error);
    }
  }, [soundEnabled]);

  // Load sound setting
  useEffect(() => {
    const sound = localStorage.getItem('lovezap_sound');
    setSoundEnabled(sound !== 'false');
  }, []);

  // Real-time subscription for messages and contacts
  useEffect(() => {
    if (!isOpen) return;

    const channel = supabase
      .channel('lovezap-realtime')
      .on(
        'postgres_changes',
        {
          event: 'INSERT',
          schema: 'public',
          table: 'wa_messages'
        },
        (payload) => {
          console.log('Nova mensagem recebida:', payload);
          
          // Se for mensagem recebida (direção IN) e som estiver habilitado, tocar notificação
          if (payload.new.direction === 'IN' && soundEnabled) {
            playNotificationSound();
          }
          
          // Refresh conversations and messages when data changes
          loadConversations();
          if (selectedChat) {
            loadMessages(selectedChat.phone_e164, 1, true);
          }
        }
      )
      .on(
        'postgres_changes',
        {
          event: 'UPDATE',
          schema: 'public',
          table: 'wa_messages'
        },
        (payload) => {
          console.log('Mensagem atualizada:', payload);
          // Refresh conversations and messages when data changes
          loadConversations();
          if (selectedChat) {
            loadMessages(selectedChat.phone_e164, 1, true);
          }
        }
      )
      .on(
        'postgres_changes',
        {
          event: '*',
          schema: 'public',
          table: 'contacts'
        },
        (payload) => {
          console.log('Real-time contact update:', payload);
          // Refresh conversations when contacts change
          loadConversations();
        }
      )
      .subscribe();

    return () => {
      supabase.removeChannel(channel);
    };
  }, [isOpen, selectedChat, soundEnabled]);

  // Load conversations using database function (same as main inbox)
  const loadConversations = useCallback(async () => {
    try {
      setLoading(true);
      
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) throw new Error("User not authenticated");

      // Load conversations with message data directly from database (same as main inbox)
      const { data: conversations, error: convError } = await supabase
        .rpc('get_user_conversations', { user_id_param: user.id });

      if (convError) {
        console.error('Error loading conversations:', convError);
        throw convError;
      }

      // Convert to our Chat format and sort by last message time
      const allChats: Chat[] = conversations.map((conv: any) => {
        // Normalize phone number
        let phone = conv.phone_e164;
        if (!phone.startsWith('+')) {
          phone = '+' + phone;
        }

        // Create display name - prioritize contact name over phone
        let displayName = conv.display_name || phone;
        
        return {
          id: conv.tenant_id + '-' + phone,
          phone_e164: phone,
          name: displayName !== phone ? displayName : undefined,
          last_message: conv.last_snippet || undefined,
          last_message_at: conv.last_message_at || new Date().toISOString(),
          unread_count: parseInt(conv.unread_count) || 0,
          is_pinned: false,
          is_vip: false,
          has_open_order: false
        };
      });

      // Apply filters
      let filteredChats = allChats;
      if (filter === 'unread') {
        filteredChats = allChats.filter(chat => chat.unread_count > 0);
      }

      // Sort by last message time (most recent first)
      filteredChats.sort((a, b) => 
        new Date(b.last_message_at || 0).getTime() - new Date(a.last_message_at || 0).getTime()
      );

      setChats(filteredChats);
      
      // Auto-select chat if selectedPhone is provided
      if (selectedPhone && !selectedChat) {
        const targetChat = filteredChats.find(chat => 
          chat.phone_e164 === selectedPhone || 
          chat.phone_e164 === '+' + selectedPhone.replace(/^\+/, '')
        );
        if (targetChat) {
          setSelectedChat(targetChat);
          onPhoneSelect(targetChat.phone_e164);
        }
      }
    } catch (error) {
      console.error('Error loading conversations:', error);
      toast({
        title: "Erro",
        description: "Erro ao carregar conversas",
        variant: "destructive"
      });
    } finally {
      setLoading(false);
    }
  }, [filter, selectedPhone, selectedChat, onPhoneSelect, toast]);

  // Load messages for a chat
  const loadMessages = useCallback(async (phoneE164: string, pageNum = 1, refresh = false) => {
    if (!phoneE164) return;
    
    try {
      setLoadingMessages(true);
      
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) throw new Error("User not authenticated");

      // Call wa-mini-messages edge function to get messages
      const { data: result, error } = await supabase.functions.invoke('wa-mini-messages', {
        body: { 
          phone: phoneE164,
          page: pageNum,
          pageSize: 50
        }
      });

      if (error) {
        console.error('Error loading messages:', error);
        throw error;
      }

      if (result && result.messages) {
        const newMessages = result.messages.map((msg: any) => ({
          id: msg.id,
          phone_e164: msg.phone_e164,
          direction: msg.direction,
          body: msg.body,
          media_url: msg.media_url,
          status: msg.status,
          created_at: msg.created_at,
          zapi_msg_id: msg.zapi_msg_id
        }));

        if (refresh) {
          setMessages(newMessages);
        } else {
          setMessages(prev => [...prev, ...newMessages]);
        }

        setHasMore(newMessages.length === 50);
        
        // Sort messages by created_at to ensure proper order
        setMessages(prev => [...prev].sort((a, b) => 
          new Date(a.created_at).getTime() - new Date(b.created_at).getTime()
        ));

        // Scroll to bottom for new conversation or refresh
        if (refresh || pageNum === 1) {
          setTimeout(() => {
            messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
          }, 100);
        }

        // Perform backfill to sync missing messages
        await performBackfill(phoneE164);
        
        // Mark messages as read
        await markAsRead(phoneE164);
      }
    } catch (error) {
      console.error('Error loading messages:', error);
      toast({
        title: "Erro",
        description: "Erro ao carregar mensagens",
        variant: "destructive"
      });
    } finally {
      setLoadingMessages(false);
    }
  }, [toast]);

  // Send message using same logic as main inbox
  const sendMessage = useCallback(async () => {
    if (!messageInput.trim() || !selectedChat || sending) return;

    try {
      setSending(true);
      
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) throw new Error("User not authenticated");

      // Get WhatsApp instance for sending
      const { data: instances } = await supabase
        .from('whatsapp_instances')
        .select('*')
        .eq('user_id', user.id)
        .eq('status', 'connected')
        .limit(1);

      if (!instances || instances.length === 0) {
        throw new Error("WhatsApp não está conectado");
      }

      const instance = instances[0];

      // Send using wa-send function (same as main inbox)
      const { error } = await supabase.functions.invoke('wa-send', {
        body: {
          userId: user.id,
          instanceId: instance.instance_id,
          tokenInstance: instance.token_instance,
          chatId: selectedChat.phone_e164,
          type: 'text',
          body: { text: messageInput.trim() }
        }
      });

      if (error) throw error;

      // Add message to local state immediately
      const newMsg: WhatsAppMessage = {
        id: Date.now().toString(),
        phone_e164: selectedChat.phone_e164,
        direction: 'OUT',
        body: messageInput.trim(),
        status: 'SENT',
        created_at: new Date().toISOString(),
      };
      
      setMessages(prev => [...prev, newMsg]);
      setMessageInput('');
      
      // Scroll to bottom
      setTimeout(() => {
        messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
      }, 100);
      
      toast({
        title: "Sucesso",
        description: "Mensagem enviada",
      });
    } catch (error) {
      console.error('Error sending message:', error);
      toast({
        title: "Erro",
        description: error.message || "Erro ao enviar mensagem",
        variant: "destructive"
      });
    } finally {
      setSending(false);
    }
  }, [messageInput, selectedChat, sending, toast]);

  // Perform backfill to sync missing messages
  const performBackfill = useCallback(async (phone: string) => {
    try {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) return;

      // Get WhatsApp instance
      const { data: instances } = await supabase
        .from('whatsapp_instances')
        .select('*')
        .eq('user_id', user.id)
        .eq('status', 'connected')
        .limit(1);

      if (!instances || instances.length === 0) {
        console.log('No WhatsApp instance connected for backfill');
        return;
      }

      const instance = instances[0];

      // Call backfill function
      await supabase.functions.invoke('wa-chat-backfill', {
        body: {
          phone,
          instanceId: instance.instance_id,
          tokenInstance: instance.token_instance,
          userId: user.id
        }
      });
    } catch (error) {
      console.error('Error during backfill:', error);
    }
  }, []);

  // Mark messages as read
  const markAsRead = useCallback(async (phone: string) => {
    try {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) return;

      // Get WhatsApp instance
      const { data: instances } = await supabase
        .from('whatsapp_instances')
        .select('*')
        .eq('user_id', user.id)
        .eq('status', 'connected')
        .limit(1);

      if (!instances || instances.length === 0) {
        console.log('No WhatsApp instance connected for mark as read');
        return;
      }

      const instance = instances[0];

      // Call mark as read function
      await supabase.functions.invoke('wa-mark-read', {
        body: {
          phone,
          instanceId: instance.instance_id,
          tokenInstance: instance.token_instance,
          userId: user.id
        }
      });
    } catch (error) {
      console.error('Error marking as read:', error);
    }
  }, []);

  // Initial load and selectedPhone handling
  useEffect(() => {
    if (isOpen) {
      loadConversations();
    }
  }, [isOpen, loadConversations]);

  // Handle chat selection
  const handleChatSelect = useCallback((chat: Chat) => {
    setSelectedChat(chat);
    setMessages([]);
    setPage(1);
    onPhoneSelect(chat.phone_e164);
    loadMessages(chat.phone_e164, 1, true);
  }, [onPhoneSelect, loadMessages]);

  // Handle filter change
  useEffect(() => {
    if (isOpen) {
      loadConversations();
    }
  }, [filter, isOpen, loadConversations]);

  // Filtered chats based on search
  const filteredChats = chats.filter(chat => {
    const searchString = searchTerm.toLowerCase();
    const name = chat.name?.toLowerCase() || '';
    const phone = chat.phone_e164.toLowerCase();
    const lastMessage = chat.last_message?.toLowerCase() || '';
    
    return name.includes(searchString) || 
           phone.includes(searchString) || 
           lastMessage.includes(searchString);
  });

  // Handle sound toggle
  const handleSoundToggle = useCallback((enabled: boolean) => {
    setSoundEnabled(enabled);
    localStorage.setItem('lovezap_sound', enabled.toString());
  }, []);

  // Handle enter key in message input
  const handleKeyPress = useCallback((e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      sendMessage();
    }
  }, [sendMessage]);

  // Render message status icon
  const renderMessageStatus = (status: string) => {
    switch (status.toUpperCase()) {
      case 'SENT':
        return <span className="text-xs text-muted-foreground">✓</span>;
      case 'RECEIVED':
        return <span className="text-xs text-muted-foreground">✓✓</span>;
      case 'READ':
        return <span className="text-xs text-blue-500">✓✓</span>;
      default:
        return <span className="text-xs text-muted-foreground">⏳</span>;
    }
  };

  if (!isOpen) return null;

  return (
    <div
      ref={panelRef}
      className="fixed bottom-4 right-4 w-96 h-[600px] bg-background border rounded-lg shadow-xl z-[9999] flex flex-col"
    >
      {/* Header */}
      <div className="flex items-center justify-between p-4 border-b bg-muted/50">
        <div className="flex items-center gap-2">
          <MessageCircle className="h-5 w-5 text-primary" />
          <h3 className="font-semibold">LoveZap Mini</h3>
        </div>
        <div className="flex items-center gap-2">
          <Button
            variant="ghost"
            size="sm"
            onClick={() => handleSoundToggle(!soundEnabled)}
            className="p-1"
          >
            {soundEnabled ? (
              <Volume2 className="h-4 w-4" />
            ) : (
              <VolumeX className="h-4 w-4" />
            )}
          </Button>
          <Button
            variant="ghost"
            size="sm"
            onClick={onClose}
            className="p-1"
          >
            <X className="h-4 w-4" />
          </Button>
        </div>
      </div>

      {/* Content */}
      <div className="flex flex-1 overflow-hidden">
        {!selectedChat ? (
          /* Chat List */
          <div className="w-full flex flex-col">
            {/* Search and Filter */}
            <div className="p-3 border-b space-y-2">
              <div className="relative">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                <Input
                  placeholder="Buscar conversas..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="pl-9 h-8 text-sm"
                />
              </div>
              
              <Tabs value={filter} onValueChange={(value) => setFilter(value as any)} className="w-full">
                <TabsList className="grid w-full grid-cols-4 h-7">
                  <TabsTrigger value="all" className="text-xs py-1">Todas</TabsTrigger>
                  <TabsTrigger value="unread" className="text-xs py-1">Não lidas</TabsTrigger>
                  <TabsTrigger value="vip" className="text-xs py-1">VIP</TabsTrigger>
                  <TabsTrigger value="orders" className="text-xs py-1">Pedidos</TabsTrigger>
                </TabsList>
              </Tabs>
            </div>

            {/* Chat List */}
            <ScrollArea className="flex-1">
              {loading ? (
                <div className="flex items-center justify-center p-8">
                  <Loader2 className="h-6 w-6 animate-spin" />
                </div>
              ) : filteredChats.length === 0 ? (
                <div className="flex flex-col items-center justify-center p-8 text-center">
                  <MessageSquare className="h-8 w-8 text-muted-foreground mb-2" />
                  <p className="text-sm text-muted-foreground">
                    {searchTerm ? 'Nenhuma conversa encontrada' : 'Nenhuma conversa ainda'}
                  </p>
                </div>
              ) : (
                <div className="p-2 space-y-1">
                  {filteredChats.map((chat) => (
                    <div
                      key={chat.id}
                      onClick={() => handleChatSelect(chat)}
                      className="flex items-center gap-3 p-2 rounded-lg hover:bg-muted/50 cursor-pointer transition-colors"
                    >
                      <div className="relative">
                        <div className="w-10 h-10 bg-primary/10 rounded-full flex items-center justify-center">
                          <MessageSquare className="h-5 w-5 text-primary" />
                        </div>
                        {chat.unread_count > 0 && (
                          <Badge 
                            variant="destructive" 
                            className="absolute -top-1 -right-1 h-5 w-5 flex items-center justify-center p-0 text-xs"
                          >
                            {chat.unread_count > 99 ? '99+' : chat.unread_count}
                          </Badge>
                        )}
                      </div>
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center justify-between">
                          <p className="font-medium text-sm truncate">
                            {chat.name || chat.phone_e164}
                          </p>
                          {chat.last_message_at && (
                            <span className="text-xs text-muted-foreground">
                              {format(new Date(chat.last_message_at), 'HH:mm', { locale: ptBR })}
                            </span>
                          )}
                        </div>
                        {chat.last_message && (
                          <p className="text-xs text-muted-foreground truncate mt-1">
                            {chat.last_message}
                          </p>
                        )}
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </ScrollArea>
          </div>
        ) : (
          /* Messages View */
          <div className="w-full flex flex-col">
            {/* Chat Header */}
            <div className="flex items-center gap-3 p-3 border-b bg-muted/30 sticky top-0 z-10">
              <Button
                variant="ghost"
                size="sm"
                onClick={() => {
                  setSelectedChat(null);
                  onPhoneSelect('');
                }}
                className="p-1"
              >
                <X className="h-4 w-4" />
              </Button>
              <div className="w-8 h-8 bg-primary/10 rounded-full flex items-center justify-center">
                <MessageSquare className="h-4 w-4 text-primary" />
              </div>
              <div className="flex-1 min-w-0">
                <p className="font-medium text-sm truncate">
                  {selectedChat.name || selectedChat.phone_e164}
                </p>
                <p className="text-xs text-muted-foreground">
                  {selectedChat.phone_e164}
                </p>
              </div>
            </div>

            {/* Messages */}
            <ScrollArea className="flex-1 p-2 max-h-[400px]">
              {loadingMessages ? (
                <div className="flex items-center justify-center p-8">
                  <Loader2 className="h-6 w-6 animate-spin" />
                </div>
              ) : messages.length === 0 ? (
                <div className="flex flex-col items-center justify-center p-8 text-center">
                  <MessageSquare className="h-8 w-8 text-muted-foreground mb-2" />
                  <p className="text-sm text-muted-foreground">
                    Nenhuma mensagem ainda
                  </p>
                </div>
              ) : (
                <div className="space-y-2">
                  {messages.map((message) => (
                    <div
                      key={message.id}
                      className={`flex ${message.direction === 'OUT' ? 'justify-end' : 'justify-start'}`}
                    >
                      <div
                        className={`max-w-[80%] p-2 rounded-lg text-sm ${
                          message.direction === 'OUT'
                            ? 'bg-primary text-primary-foreground'
                            : 'bg-muted'
                        }`}
                      >
                        <p className="break-words">{message.body}</p>
                        {message.media_url && (
                          <div className="mt-1">
                            {message.media_url.includes('.jpg') || 
                             message.media_url.includes('.png') || 
                             message.media_url.includes('.jpeg') ? (
                              <img 
                                src={message.media_url} 
                                alt="Imagem" 
                                className="max-w-full rounded"
                              />
                            ) : (
                              <a 
                                href={message.media_url} 
                                target="_blank" 
                                rel="noopener noreferrer"
                                className="text-blue-500 underline"
                              >
                                Ver arquivo
                              </a>
                            )}
                          </div>
                        )}
                        <div className="flex items-center justify-between mt-1">
                          <span className="text-xs opacity-70">
                            {format(new Date(message.created_at), 'HH:mm', { locale: ptBR })}
                          </span>
                          {message.direction === 'OUT' && renderMessageStatus(message.status)}
                        </div>
                      </div>
                    </div>
                  ))}
                  <div ref={messagesEndRef} />
                </div>
              )}
            </ScrollArea>

            {/* Message Input */}
            <div className="p-3 border-t">
              <div className="flex items-center gap-2">
                <Input
                  placeholder="Digite sua mensagem..."
                  value={messageInput}
                  onChange={(e) => setMessageInput(e.target.value)}
                  onKeyPress={handleKeyPress}
                  className="flex-1 h-8 text-sm"
                  disabled={sending}
                />
                <Button
                  onClick={sendMessage}
                  disabled={!messageInput.trim() || sending}
                  size="sm"
                  className="h-8 w-8 p-0"
                >
                  {sending ? (
                    <Loader2 className="h-4 w-4 animate-spin" />
                  ) : (
                    <Send className="h-4 w-4" />
                  )}
                </Button>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default LoveZapMiniPanel;