import React, { useEffect, useState, useRef } from 'react';
import { Sheet, SheetContent, SheetHeader, SheetTitle } from '@/components/ui/sheet';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Separator } from '@/components/ui/separator';
import { Search, Send, Image as ImageIcon, Pin, Users, MessageSquare, Package, X, MessageCircle } from 'lucide-react';
import { supabase } from '@/integrations/supabase/client';
import { useToast } from '@/components/ui/use-toast';
import { format } from 'date-fns';
import { ptBR } from 'date-fns/locale';

interface Chat {
  id: string;
  phone_e164: string;
  name?: string;
  last_message?: string;
  last_message_at?: string;
  unread_count: number;
  is_pinned: boolean;
  is_vip: boolean;
  has_open_order: boolean;
}

interface Message {
  id: string;
  direction: 'in' | 'out';
  type: string;
  content: any;
  created_at: string;
  status: string;
}

interface LoveZapMiniInboxProps {
  isOpen: boolean;
  onClose: () => void;
  initialPhone?: string;
}

const LoveZapMiniInbox: React.FC<LoveZapMiniInboxProps> = ({ isOpen, onClose, initialPhone }) => {
  const [chats, setChats] = useState<Chat[]>([]);
  const [messages, setMessages] = useState<Message[]>([]);
  const [selectedChat, setSelectedChat] = useState<Chat | null>(null);
  const [searchTerm, setSearchTerm] = useState('');
  const [messageInput, setMessageInput] = useState('');
  const [filter, setFilter] = useState<'all' | 'unread' | 'vip' | 'orders'>('all');
  const [loading, setLoading] = useState(false);
  const [sending, setSending] = useState(false);
  const [chatsPage, setChatsPage] = useState(1);
  const [messagesPage, setMessagesPage] = useState(1);
  const [hasMoreChats, setHasMoreChats] = useState(true);
  const [hasMoreMessages, setHasMoreMessages] = useState(true);
  
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const { toast } = useToast();

  // Load chats using the same logic as main inbox
  const loadChats = async (page = 1, reset = false) => {
    try {
      setLoading(true);
      
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) throw new Error("User not authenticated");

      // Load conversations with message data directly from database (same as main inbox)
      const { data: conversations, error: convError } = await supabase
        .rpc('get_user_conversations', { user_id_param: user.id });

      if (convError) {
        console.error('Error loading conversations:', convError);
        throw convError;
      }

      // Convert to our Chat format and sort by last message time
      const allChats: Chat[] = conversations.map((conv: any) => {
        // Normalize phone number
        let phone = conv.phone_e164;
        if (!phone.startsWith('+')) {
          phone = '+' + phone;
        }

        // Create display name - prioritize contact name over phone
        let displayName = conv.display_name || phone;
        
        return {
          id: conv.tenant_id + '-' + phone,
          phone_e164: phone,
          name: displayName !== phone ? displayName : undefined,
          last_message: conv.last_snippet || undefined,
          last_message_at: conv.last_message_at || new Date().toISOString(),
          unread_count: parseInt(conv.unread_count) || 0,
          is_pinned: false,
          is_vip: false,
          has_open_order: false
        };
      });

      // Apply filters
      let filteredChats = allChats;
      if (filter === 'unread') {
        filteredChats = allChats.filter(chat => chat.unread_count > 0);
      }

      // Apply search
      if (searchTerm.trim()) {
        filteredChats = filteredChats.filter(chat => 
          (chat.name && chat.name.toLowerCase().includes(searchTerm.toLowerCase())) ||
          chat.phone_e164.includes(searchTerm)
        );
      }

      // Sort by last message time, most recent first
      const sortedChats = filteredChats.sort((a, b) => {
        const timeA = new Date(a.last_message_at || 0).getTime();
        const timeB = new Date(b.last_message_at || 0).getTime();
        return timeB - timeA;
      });

      setChats(sortedChats);
      setHasMoreChats(false); // For now, load all at once
      setChatsPage(page);
    } catch (error) {
      console.error('Error loading chats:', error);
      toast({
        title: "Erro",
        description: "Erro ao carregar conversas",
        variant: "destructive"
      });
    } finally {
      setLoading(false);
    }
  };

  // Load messages for selected chat using same logic as main inbox
  const loadMessages = async (phone: string, page = 1, reset = false) => {
    try {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) return;

      // Use the wa_messages table directly (same as main inbox)
      const { data: messagesData, error } = await supabase
        .from('wa_messages')
        .select('*')
        .eq('user_id', user.id)
        .eq('phone_e164', phone)
        .order('created_at', { ascending: true })
        .limit(50);

      if (error) throw error;

      // Convert to our format
      const formattedMessages: Message[] = messagesData.map((msg: any) => ({
        id: msg.id,
        direction: msg.direction,
        type: msg.body?.type || 'text',
        content: {
          text: msg.body?.text?.message || msg.body || 'Mensagem'
        },
        created_at: msg.created_at,
        status: msg.status || 'received'
      }));

      setMessages(formattedMessages);
      setHasMoreMessages(false);
      setMessagesPage(page);

      if (reset) {
        setTimeout(() => {
          messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
        }, 100);
      }
    } catch (error) {
      console.error('Error loading messages:', error);
      toast({
        title: "Erro",
        description: "Erro ao carregar mensagens",
        variant: "destructive"
      });
    }
  };

  // Send message using same logic as main inbox
  const sendMessage = async () => {
    if (!messageInput.trim() || !selectedChat || sending) return;

    try {
      setSending(true);
      
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) throw new Error("User not authenticated");

      // Get WhatsApp instance for sending
      const { data: instances } = await supabase
        .from('whatsapp_instances')
        .select('*')
        .eq('user_id', user.id)
        .eq('status', 'connected')
        .limit(1);

      if (!instances || instances.length === 0) {
        throw new Error("WhatsApp não está conectado");
      }

      const instance = instances[0];

      // Send using wa-send function (same as main inbox)
      const { error } = await supabase.functions.invoke('wa-send', {
        body: {
          userId: user.id,
          instanceId: instance.instance_id,
          tokenInstance: instance.token_instance,
          chatId: selectedChat.phone_e164,
          type: 'text',
          body: { text: messageInput.trim() }
        }
      });

      if (error) throw error;

      // Add message to local state immediately
      const newMsg: Message = {
        id: Date.now().toString(),
        direction: 'out',
        type: 'text',
        content: { text: messageInput.trim() },
        created_at: new Date().toISOString(),
        status: 'sent'
      };
      
      setMessages(prev => [...prev, newMsg]);
      setMessageInput('');
      
      // Scroll to bottom
      setTimeout(() => {
        messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
      }, 100);
      
      toast({
        title: "Sucesso",
        description: "Mensagem enviada",
      });
    } catch (error) {
      console.error('Error sending message:', error);
      toast({
        title: "Erro",
        description: error.message || "Erro ao enviar mensagem",
        variant: "destructive"
      });
    } finally {
      setSending(false);
    }
  };

  // Mark chat as read
  const markAsRead = async (phone: string) => {
    try {
      await supabase.functions.invoke('wa-mini-read', {
        body: { phone }
      });

      // Update local state
      setChats(prev => 
        prev.map(chat => 
          chat.phone_e164 === phone 
            ? { ...chat, unread_count: 0 }
            : chat
        )
      );
    } catch (error) {
      console.error('Error marking as read:', error);
    }
  };

  // Handle chat selection
  const selectChat = (chat: Chat) => {
    setSelectedChat(chat);
    setMessages([]);
    setMessagesPage(1);
    loadMessages(chat.phone_e164, 1, true);
    markAsRead(chat.phone_e164);
  };

  // Load initial chats when opened
  useEffect(() => {
    if (isOpen) {
      loadChats(1, true);
    }
  }, [isOpen, filter, searchTerm]);

  // Handle initial phone selection
  useEffect(() => {
    if (initialPhone && chats.length > 0) {
      const chat = chats.find(c => c.phone_e164 === initialPhone);
      if (chat) {
        selectChat(chat);
      }
    }
  }, [initialPhone, chats]);

  // Realtime subscription for new messages
  useEffect(() => {
    if (!isOpen) return;

    const channel = supabase
      .channel('mini_inbox_updates')
      .on('postgres_changes', {
        event: '*',
        schema: 'public',
        table: 'wa_chats'
      }, () => {
        loadChats(1, true);
      })
      .on('postgres_changes', {
        event: 'INSERT',
        schema: 'public',
        table: 'wa_messages'
      }, (payload) => {
        const newMessage = payload.new as any;
        if (selectedChat && newMessage.phone_e164 === selectedChat.phone_e164) {
          setMessages(prev => [...prev, newMessage]);
          setTimeout(() => {
            messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
          }, 100);
        }
      })
      .subscribe();

    return () => {
      channel.unsubscribe();
    };
  }, [isOpen, selectedChat]);

  const getFilterIcon = (filterType: string) => {
    switch (filterType) {
      case 'unread': return <MessageSquare size={16} />;
      case 'vip': return <Pin size={16} />;
      case 'orders': return <Package size={16} />;
      default: return <Users size={16} />;
    }
  };

  const formatTime = (dateString: string) => {
    return format(new Date(dateString), 'HH:mm', { locale: ptBR });
  };

  const formatMessageContent = (message: Message) => {
    if (message.type === 'image') {
      return '📷 Imagem';
    }
    return message.content?.text || message.content || '';
  };

  return (
    <Sheet open={isOpen} onOpenChange={onClose}>
      <SheetContent side="right" className="w-[520px] p-0">
        <div className="flex h-full">
          {/* Chat List */}
          <div className="w-64 border-r border-border flex flex-col">
            <SheetHeader className="p-4 border-b">
              <SheetTitle className="text-sm">LoveZap Mini</SheetTitle>
            </SheetHeader>

            {/* Search */}
            <div className="p-3">
              <div className="relative">
                <Search className="absolute left-3 top-2.5 h-4 w-4 text-muted-foreground" />
                <Input
                  placeholder="Buscar contatos..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="pl-9 h-8"
                />
              </div>
            </div>

            {/* Filters */}
            <div className="flex gap-1 px-3 pb-3">
              {(['all', 'unread', 'vip', 'orders'] as const).map((filterType) => (
                <Button
                  key={filterType}
                  variant={filter === filterType ? "default" : "ghost"}
                  size="sm"
                  onClick={() => setFilter(filterType)}
                  className="h-7 px-2"
                >
                  {getFilterIcon(filterType)}
                </Button>
              ))}
            </div>

            {/* Chat List */}
            <ScrollArea className="flex-1">
              <div className="space-y-1 p-2">
                {chats.map((chat) => (
                  <div
                    key={chat.id}
                    onClick={() => selectChat(chat)}
                    className={`p-3 rounded-lg cursor-pointer transition-colors ${
                      selectedChat?.id === chat.id 
                        ? 'bg-accent' 
                        : 'hover:bg-accent/50'
                    }`}
                  >
                    <div className="flex items-start justify-between">
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center gap-2">
                          <p className="text-sm font-medium truncate">
                            {chat.name || chat.phone_e164}
                          </p>
                          {chat.is_pinned && <Pin size={12} className="text-primary" />}
                          {chat.is_vip && <Badge variant="secondary" className="h-4 text-xs">VIP</Badge>}
                          {chat.has_open_order && <Package size={12} className="text-orange-500" />}
                        </div>
                        <p className="text-xs text-muted-foreground truncate mt-1">
                          {chat.last_message || 'Sem mensagens'}
                        </p>
                      </div>
                      <div className="flex flex-col items-end gap-1">
                        {chat.last_message_at && (
                          <span className="text-xs text-muted-foreground">
                            {formatTime(chat.last_message_at)}
                          </span>
                        )}
                        {chat.unread_count > 0 && (
                          <Badge variant="destructive" className="h-4 w-4 p-0 text-xs flex items-center justify-center">
                            {chat.unread_count > 9 ? '9+' : chat.unread_count}
                          </Badge>
                        )}
                      </div>
                    </div>
                  </div>
                ))}
                
                {hasMoreChats && (
                  <Button 
                    variant="ghost" 
                    className="w-full h-8 text-xs"
                    onClick={() => loadChats(chatsPage + 1)}
                    disabled={loading}
                  >
                    Carregar mais
                  </Button>
                )}
              </div>
            </ScrollArea>
          </div>

          {/* Chat Thread */}
          <div className="flex-1 flex flex-col">
            {selectedChat ? (
              <>
                {/* Chat Header */}
                <div className="p-4 border-b">
                  <div className="flex items-center justify-between">
                    <div>
                      <h3 className="font-medium">
                        {selectedChat.name || selectedChat.phone_e164}
                      </h3>
                      <p className="text-sm text-muted-foreground">
                        {selectedChat.phone_e164}
                      </p>
                    </div>
                    <Button variant="ghost" size="sm" onClick={onClose}>
                      <X size={16} />
                    </Button>
                  </div>
                </div>

                {/* Messages */}
                <ScrollArea className="flex-1 p-4">
                  <div className="space-y-3">
                    {hasMoreMessages && (
                      <Button 
                        variant="ghost" 
                        className="w-full h-8 text-xs"
                        onClick={() => loadMessages(selectedChat.phone_e164, messagesPage + 1)}
                      >
                        Carregar mais antigas
                      </Button>
                    )}
                    
                    {messages.map((message) => (
                      <div
                        key={message.id}
                        className={`flex ${
                          message.direction === 'out' ? 'justify-end' : 'justify-start'
                        }`}
                      >
                        <div
                          className={`max-w-xs px-3 py-2 rounded-lg ${
                            message.direction === 'out'
                              ? 'bg-primary text-primary-foreground'
                              : 'bg-muted'
                          }`}
                        >
                          <p className="text-sm">{formatMessageContent(message)}</p>
                          <p className="text-xs opacity-70 mt-1">
                            {formatTime(message.created_at)}
                          </p>
                        </div>
                      </div>
                    ))}
                    <div ref={messagesEndRef} />
                  </div>
                </ScrollArea>

                {/* Message Input */}
                <div className="p-4 border-t">
                  <div className="flex gap-2">
                    <Input
                      placeholder="Digite sua mensagem..."
                      value={messageInput}
                      onChange={(e) => setMessageInput(e.target.value)}
                      onKeyPress={(e) => {
                        if (e.key === 'Enter' && !e.shiftKey) {
                          e.preventDefault();
                          sendMessage();
                        }
                      }}
                      className="flex-1"
                    />
                    <Button 
                      onClick={sendMessage}
                      disabled={!messageInput.trim() || sending}
                      size="sm"
                    >
                      <Send size={16} />
                    </Button>
                  </div>
                </div>
              </>
            ) : (
              <div className="flex-1 flex items-center justify-center text-muted-foreground">
                <div className="text-center">
                  <MessageCircle size={48} className="mx-auto mb-4 opacity-50" />
                  <p>Selecione uma conversa para começar</p>
                </div>
              </div>
            )}
          </div>
        </div>
      </SheetContent>
    </Sheet>
  );
};

export default LoveZapMiniInbox;