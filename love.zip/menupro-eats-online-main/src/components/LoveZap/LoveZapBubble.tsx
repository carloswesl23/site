import React, { useEffect, useState } from 'react';
import { MessageCircle, Wifi, WifiOff } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { supabase } from '@/integrations/supabase/client';
import { useToast } from '@/components/ui/use-toast';

interface LoveZapBubbleProps {
  onClick: () => void;
  isOpen: boolean;
}

const LoveZapBubble: React.FC<LoveZapBubbleProps> = ({ onClick, isOpen }) => {
  const [totalUnread, setTotalUnread] = useState(0);
  const [isConnected, setIsConnected] = useState(false);
  const [isVisible, setIsVisible] = useState(true);
  const [isLoading, setIsLoading] = useState(false);
  const { toast } = useToast();

  // Check if Mini-Inbox is enabled in settings
  useEffect(() => {
    const enabled = localStorage.getItem('lovezap_mini_enabled');
    setIsVisible(enabled !== 'false');
  }, []);

  // Get WhatsApp connection status
  useEffect(() => {
    const getConnectionStatus = async () => {
      try {
        const { data: { user } } = await supabase.auth.getUser();
        if (!user) return;

        const { data: instance } = await supabase
          .from('whatsapp_instances')
          .select('status')
          .eq('user_id', user.id)
          .eq('status', 'connected')
          .maybeSingle();

        setIsConnected(!!instance);
      } catch (error) {
        console.error('Error checking connection:', error);
      }
    };

    getConnectionStatus();
    const interval = setInterval(getConnectionStatus, 30000); // Check every 30s

    return () => clearInterval(interval);
  }, []);

  // Get total unread count via edge function
  useEffect(() => {
    const getUnreadCount = async () => {
      if (!isConnected) return;
      
      try {
        setIsLoading(true);
        const { data: { session } } = await supabase.auth.getSession();
        if (!session) return;

        const { data, error } = await supabase.functions.invoke('wa-mini-chats', {
          body: { page: 1, pageSize: 1, filter: 'unread' },
          headers: {
            Authorization: `Bearer ${session.access_token}`
          }
        });

        if (error) throw error;

        setTotalUnread(data?.data?.totalUnread || 0);
      } catch (error) {
        console.error('Error fetching unread count:', error);
        setTotalUnread(0);
      } finally {
        setIsLoading(false);
      }
    };

    getUnreadCount();

    // Subscribe to realtime updates for wa_chats
    const channel = supabase
      .channel('wa_chats_bubble')
      .on('postgres_changes', {
        event: '*',
        schema: 'public',
        table: 'wa_chats'
      }, () => {
        getUnreadCount();
      })
      .on('postgres_changes', {
        event: 'INSERT',
        schema: 'public',
        table: 'wa_messages'
      }, (payload) => {
        // Only update for incoming messages
        if (payload.new && payload.new.direction === 'in') {
          getUnreadCount();
        }
      })
      .subscribe();

    return () => {
      channel.unsubscribe();
    };
  }, [isConnected]);

  // Play notification sound
  useEffect(() => {
    if (totalUnread > 0) {
      const soundEnabled = localStorage.getItem('lovezap_sound') !== 'false';
      if (soundEnabled) {
        try {
          const audio = new Audio('/notification.mp3');
          audio.volume = 0.3;
          audio.play().catch(() => {
            // Ignore autoplay restrictions
          });
        } catch (error) {
          console.log('Could not play notification sound:', error);
        }
      }
    }
  }, [totalUnread]);

  if (!isVisible) return null;

  return (
    <div className="fixed bottom-6 right-6 z-50">
      <Button
        onClick={onClick}
        size="lg"
        className={`relative h-14 w-14 rounded-full shadow-lg transition-all duration-200 ${
          isOpen 
            ? 'bg-primary/90 hover:bg-primary scale-95' 
            : 'bg-primary hover:bg-primary/90 hover:scale-105'
        }`}
      >
        <div className="relative flex items-center justify-center">
          <MessageCircle size={24} className="text-white" />
          
          {/* Connection Status */}
          <div className="absolute -top-1 -left-1">
            {isConnected ? (
              <Wifi size={12} className="text-green-400" />
            ) : (
              <WifiOff size={12} className="text-red-400" />
            )}
          </div>

          {/* Unread Badge */}
          {totalUnread > 0 && (
            <Badge 
              variant="destructive" 
              className="absolute -top-2 -right-2 h-5 w-5 p-0 text-xs flex items-center justify-center"
            >
              {totalUnread > 99 ? '99+' : totalUnread}
            </Badge>
          )}
        </div>

        {/* Pulse animation for new messages */}
        {totalUnread > 0 && (
          <div className="absolute inset-0 rounded-full bg-primary animate-ping opacity-75" />
        )}
      </Button>
    </div>
  );
};

export default LoveZapBubble;