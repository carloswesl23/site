import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Plus } from "lucide-react";

interface UpsellProduct {
  id: string;
  name: string;
  price: number;
  image: string | null;
}

interface UpsellSuggestionsProps {
  suggestions: UpsellProduct[];
  onAddToCart: (product: UpsellProduct) => void;
}

export const UpsellSuggestions = ({ suggestions, onAddToCart }: UpsellSuggestionsProps) => {
  if (!suggestions || suggestions.length === 0) return null;

  return (
    <div className="mt-2 p-3 bg-orange-50 rounded-lg border border-orange-200">
      <p className="text-xs font-medium text-orange-800 mb-2 text-center">
        🍟 Que tal acompanhar com:
      </p>
      <div className="space-y-2">
        {suggestions.map((product) => (
          <div key={product.id} className="flex items-center gap-2 p-2 bg-white rounded-md border border-orange-100">
            <img
              src={product.image || "/placeholder.svg"}
              alt={product.name}
              className="w-10 h-10 object-cover rounded flex-shrink-0"
            />
            <div className="flex-1 min-w-0">
              <p className="text-xs font-medium text-gray-800 line-clamp-1">{product.name}</p>
              <p className="text-xs font-bold text-orange-600">
                R$ {product.price.toFixed(2).replace('.', ',')}
              </p>
            </div>
            <Button
              size="sm"
              onClick={() => onAddToCart(product)}
              className="h-6 w-6 p-0 bg-orange-500 hover:bg-orange-600 rounded-full"
            >
              <Plus className="w-3 h-3" />
            </Button>
          </div>
        ))}
      </div>
    </div>
  );
};