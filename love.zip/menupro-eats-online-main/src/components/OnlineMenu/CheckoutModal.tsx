import { useState, useEffect } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Card, CardContent } from "@/components/ui/card";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { MessageSquare, MapPin, User, Phone, Pizza, CreditCard, QrCode, Truck } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { PixPaymentModal } from "./PixPaymentModal";
import { usePreparationTimeSettings } from "@/hooks/usePreparationTimeSettings";
import { useOrderTracking } from "@/hooks/useOrderTracking";

interface CartItem {
  id: string;
  product: any;
  quantity: number;
  customizations?: any;
  totalPrice: number;
}

interface CheckoutModalProps {
  isOpen: boolean;
  onClose: () => void;
  cart: CartItem[];
  total: number;
  establishmentName: string;
}

export const CheckoutModal = ({ 
  isOpen, 
  onClose, 
  cart, 
  total, 
  establishmentName 
}: CheckoutModalProps) => {
  const { toast } = useToast();
  const [step, setStep] = useState<'form' | 'payment'>('form');
  const [paymentMethod, setPaymentMethod] = useState<'whatsapp' | 'pix'>('whatsapp');
  const [isPixModalOpen, setIsPixModalOpen] = useState(false);
  const [orderNumber, setOrderNumber] = useState('');
  const [deliveryFee] = useState(5.00);
  const [customerData, setCustomerData] = useState({
    name: "",
    phone: "",
    deliveryType: "delivery",
    address: {
      street: "",
      number: "",
      neighborhood: "",
      city: "",
      zipCode: "",
      reference: ""
    }
  });
  const [isLoadingCep, setIsLoadingCep] = useState(false);

  // Hooks para tempo de preparo
  const { settings, calculateEstimatedTime } = usePreparationTimeSettings();
  const { createOrderTracking } = useOrderTracking();

  // Calcular total com frete
  const totalWithDelivery = customerData.deliveryType === "delivery" ? total + deliveryFee : total;

  // Gerar número do pedido
  useEffect(() => {
    if (isOpen && !orderNumber) {
      const orderNum = `MP${Date.now().toString().slice(-6)}`;
      setOrderNumber(orderNum);
    }
  }, [isOpen]);

  const formatZipCode = (value: string) => {
    const numbers = value.replace(/\D/g, '');
    if (numbers.length <= 5) {
      return numbers;
    }
    return numbers.replace(/(\d{5})(\d{1,3})/, '$1-$2');
  };

  const searchAddressByCep = async (cep: string) => {
    const cleanCep = cep.replace(/\D/g, '');
    if (cleanCep.length !== 8) return;

    setIsLoadingCep(true);
    try {
      const response = await fetch(`https://viacep.com.br/ws/${cleanCep}/json/`);
      const data = await response.json();
      
      if (!data.erro) {
        setCustomerData(prev => ({
          ...prev,
          address: {
            ...prev.address,
            street: data.logradouro || prev.address.street,
            neighborhood: data.bairro || prev.address.neighborhood,
            city: data.localidade || prev.address.city,
            zipCode: formatZipCode(cleanCep)
          }
        }));
        
        toast({
          title: "Endereço encontrado!",
          description: "Dados preenchidos automaticamente via CEP",
        });
      } else {
        toast({
          title: "CEP não encontrado",
          description: "Verifique o CEP digitado",
          variant: "destructive"
        });
      }
    } catch (error) {
      toast({
        title: "Erro ao buscar CEP",
        description: "Tente novamente ou preencha manualmente",
        variant: "destructive"
      });
    } finally {
      setIsLoadingCep(false);
    }
  };

  const handleZipCodeChange = (value: string) => {
    const formatted = formatZipCode(value);
    setCustomerData(prev => ({
      ...prev,
      address: { ...prev.address, zipCode: formatted }
    }));

    if (formatted.length === 9) {
      searchAddressByCep(formatted);
    }
  };

  const formatPizzaForWhatsApp = (item: CartItem) => {
    if (!item.product.isPizza || !item.customizations.flavors) {
      return `   • ${item.product.name}`;
    }

    let pizzaDescription = `   🍕 ${item.product.name}`;
    
    if (item.customizations.flavors.length === 1) {
      pizzaDescription += ` - ${item.customizations.flavors[0].name}`;
    } else {
      pizzaDescription += ` - ${item.customizations.flavorCount} sabores:`;
      item.customizations.flavors.forEach((flavor: any) => {
        pizzaDescription += `\n      • ${flavor.name}`;
      });
    }

    if (item.customizations.removedIngredients && item.customizations.removedIngredients.length > 0) {
      pizzaDescription += `\n      Retirar: ${item.customizations.removedIngredients.join(', ')}`;
    }

    if (item.customizations.border) {
      pizzaDescription += `\n      Borda: ${item.customizations.border.name} (+R$ ${item.customizations.border.price.toFixed(2)})`;
    }

    if (item.customizations.notes) {
      pizzaDescription += `\n      Obs: ${item.customizations.notes}`;
    }

    return pizzaDescription;
  };

  const formatOrderForWhatsApp = (estimatedTime?: number) => {
    let message = `🍔 *NOVO PEDIDO - ${establishmentName}*\n\n`;
    
    message += `📋 *Pedido:* #${orderNumber}\n`;
    message += `👤 *Cliente:* ${customerData.name}\n`;
    message += `📱 *Telefone:* ${customerData.phone}\n`;
    
    if (estimatedTime) {
      message += `⏰ *Tempo estimado:* ${estimatedTime} minutos\n`;
    }
    
    if (customerData.deliveryType === "delivery") {
      message += `📍 *Endereço de Entrega:*\n`;
      message += `   Rua: ${customerData.address.street}, ${customerData.address.number}\n`;
      message += `   Bairro: ${customerData.address.neighborhood}\n`;
      message += `   Cidade: ${customerData.address.city}\n`;
      message += `   CEP: ${customerData.address.zipCode}\n`;
      if (customerData.address.reference) {
        message += `   Referência: ${customerData.address.reference}\n`;
      }
    } else {
      message += `🏪 *Retirada no local*\n`;
    }
    
    message += `\n📋 *ITENS DO PEDIDO:*\n`;
    
    cart.forEach((item, index) => {
      message += `\n${index + 1}. *${item.quantity}x* `;
      
      if (item.product.isPizza) {
        message += formatPizzaForWhatsApp(item);
      } else {
        message += `${item.product.name}`;
        
        if (item.customizations) {
          if (item.customizations.bread) {
            message += `\n   • Pão: ${item.customizations.bread}`;
          }
          if (item.customizations.ingredients && item.customizations.ingredients.length > 0) {
            message += `\n   • Ingredientes: ${item.customizations.ingredients.join(', ')}`;
          }
          if (item.customizations.extras && item.customizations.extras.length > 0) {
            message += `\n   • Extras: ${item.customizations.extras.map((e: any) => e.name).join(', ')}`;
          }
          if (item.customizations.notes) {
            message += `\n   • Obs: ${item.customizations.notes}`;
          }
        }
      }
      
      message += `\n   💰 R$ ${item.totalPrice.toFixed(2)}\n`;
    });
    
    message += `\n💰 *Subtotal: R$ ${total.toFixed(2)}*`;
    
    if (customerData.deliveryType === "delivery") {
      message += `\n🚚 *Taxa de entrega: R$ ${deliveryFee.toFixed(2)}*`;
    }
    
    message += `\n💳 *TOTAL: R$ ${totalWithDelivery.toFixed(2)}*`;
    
    if (paymentMethod === 'pix') {
      message += `\n💰 *Forma de pagamento:* PIX`;
    }
    
    return encodeURIComponent(message);
  };

  const sendWhatsAppMessage = async (estimatedTime: number) => {
    if (!settings.auto_send_whatsapp) return;

    const message = settings.whatsapp_message_template.replace('{tempo}', estimatedTime.toString());
    const phone = customerData.phone.replace(/\D/g, '');
    const whatsappUrl = `https://wa.me/55${phone}?text=${encodeURIComponent(message)}`;
    
    // Abrir WhatsApp em nova aba
    window.open(whatsappUrl, '_blank');
  };

  const handleContinueToPayment = () => {
    if (!customerData.name || !customerData.phone) {
      toast({
        title: "Dados incompletos",
        description: "Por favor, preencha pelo menos o nome e telefone",
        variant: "destructive"
      });
      return;
    }

    if (customerData.deliveryType === "delivery") {
      const { street, number, neighborhood, city } = customerData.address;
      if (!street || !number || !neighborhood || !city) {
        toast({
          title: "Endereço incompleto",
          description: "Para entrega, preencha pelo menos rua, número, bairro e cidade",
          variant: "destructive"
        });
        return;
      }
    }

    setStep('payment');
  };

  const handleSubmitOrder = async () => {
    try {
      // Calcular tempo estimado baseado nas categorias dos produtos
      const categories = cart.map(item => item.product.category).filter(Boolean);
      const estimatedTime = calculateEstimatedTime(categories);

      // Criar rastreamento do pedido
      await createOrderTracking({
        order_number: orderNumber,
        customer_name: customerData.name,
        customer_phone: customerData.phone,
        estimated_time: estimatedTime
      });

      if (paymentMethod === 'pix') {
        setIsPixModalOpen(true);
        return;
      }

      // Envio via WhatsApp (método original)
      const whatsappMessage = formatOrderForWhatsApp(estimatedTime);
      const whatsappNumber = "5511999999999";
      const whatsappUrl = `https://wa.me/${whatsappNumber}?text=${whatsappMessage}`;
      
      window.open(whatsappUrl, '_blank');

      // Enviar mensagem automática para o cliente se habilitado
      if (settings.auto_send_whatsapp) {
        setTimeout(() => {
          sendWhatsAppMessage(estimatedTime);
        }, 2000);
      }
      
      toast({
        title: "Pedido enviado!",
        description: `Seu pedido foi enviado via WhatsApp. Tempo estimado: ${estimatedTime} minutos.`,
      });
      
      onClose();
    } catch (error) {
      console.error('Erro ao processar pedido:', error);
      toast({
        title: "Erro ao processar pedido",
        description: "Tente novamente em alguns instantes",
        variant: "destructive"
      });
    }
  };

  const resetForm = () => {
    setStep('form');
    setPaymentMethod('whatsapp');
    setCustomerData({
      name: "",
      phone: "",
      deliveryType: "delivery",
      address: {
        street: "",
        number: "",
        neighborhood: "",
        city: "",
        zipCode: "",
        reference: ""
      }
    });
  };

  const handleModalClose = () => {
    resetForm();
    onClose();
  };

  return (
    <>
      <Dialog open={isOpen} onOpenChange={handleModalClose}>
        <DialogContent className="max-w-lg max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              {step === 'form' ? (
                <>
                  <User className="w-5 h-5" />
                  Dados do Pedido
                </>
              ) : (
                <>
                  <CreditCard className="w-5 h-5" />
                  Forma de Pagamento
                </>
              )}
            </DialogTitle>
          </DialogHeader>

          {step === 'form' ? (
            <div className="space-y-6">
              {/* Dados do cliente */}
              <Card>
                <CardContent className="p-4 space-y-4">
                  <h3 className="font-semibold flex items-center gap-2">
                    <User className="w-4 h-4" />
                    Seus Dados
                  </h3>
                  
                  <div className="space-y-3">
                    <div>
                      <Label htmlFor="name">Nome completo *</Label>
                      <Input
                        id="name"
                        value={customerData.name}
                        onChange={(e) => setCustomerData(prev => ({ ...prev, name: e.target.value }))}
                        placeholder="Seu nome completo"
                      />
                    </div>
                    
                    <div>
                      <Label htmlFor="phone">WhatsApp *</Label>
                      <Input
                        id="phone"
                        value={customerData.phone}
                        onChange={(e) => setCustomerData(prev => ({ ...prev, phone: e.target.value }))}
                        placeholder="(11) 99999-9999"
                      />
                    </div>
                  </div>
                </CardContent>
              </Card>

              {/* Tipo de entrega */}
              <Card>
                <CardContent className="p-4">
                  <h3 className="font-semibold mb-3">Tipo de Entrega</h3>
                  <RadioGroup
                    value={customerData.deliveryType}
                    onValueChange={(value) => setCustomerData(prev => ({ ...prev, deliveryType: value }))}
                  >
                    <div className="flex items-center space-x-2">
                      <RadioGroupItem value="delivery" id="delivery" />
                      <Label htmlFor="delivery" className="flex items-center gap-2">
                        🛵 Entrega 
                        <span className="text-sm text-gray-500">(+R$ {deliveryFee.toFixed(2)})</span>
                      </Label>
                    </div>
                    <div className="flex items-center space-x-2">
                      <RadioGroupItem value="pickup" id="pickup" />
                      <Label htmlFor="pickup">🏪 Retirada no local</Label>
                    </div>
                  </RadioGroup>
                </CardContent>
              </Card>

              {/* Endereço (se entrega) */}
              {customerData.deliveryType === "delivery" && (
                <Card>
                  <CardContent className="p-4">
                    <h3 className="font-semibold flex items-center gap-2 mb-3">
                      <MapPin className="w-4 h-4" />
                      Endereço de Entrega
                    </h3>

                    <div className="space-y-3">
                      <div>
                        <Label htmlFor="zipCode">CEP</Label>
                        <Input
                          id="zipCode"
                          value={customerData.address.zipCode}
                          onChange={(e) => handleZipCodeChange(e.target.value)}
                          placeholder="00000-000"
                          maxLength={9}
                          disabled={isLoadingCep}
                        />
                        {isLoadingCep && (
                          <p className="text-xs text-muted-foreground mt-1">
                            Buscando endereço...
                          </p>
                        )}
                      </div>

                      <div className="grid grid-cols-3 gap-2">
                        <div className="col-span-2">
                          <Label htmlFor="street">Rua *</Label>
                          <Input
                            id="street"
                            value={customerData.address.street}
                            onChange={(e) => setCustomerData(prev => ({
                              ...prev,
                              address: { ...prev.address, street: e.target.value }
                            }))}
                            placeholder="Nome da rua"
                          />
                        </div>
                        <div>
                          <Label htmlFor="number">Número *</Label>
                          <Input
                            id="number"
                            value={customerData.address.number}
                            onChange={(e) => setCustomerData(prev => ({
                              ...prev,
                              address: { ...prev.address, number: e.target.value }
                            }))}
                            placeholder="123"
                          />
                        </div>
                      </div>

                      <div>
                        <Label htmlFor="neighborhood">Bairro *</Label>
                        <Input
                          id="neighborhood"
                          value={customerData.address.neighborhood}
                          onChange={(e) => setCustomerData(prev => ({
                            ...prev,
                            address: { ...prev.address, neighborhood: e.target.value }
                          }))}
                          placeholder="Nome do bairro"
                        />
                      </div>

                      <div>
                        <Label htmlFor="city">Cidade *</Label>
                        <Input
                          id="city"
                          value={customerData.address.city}
                          onChange={(e) => setCustomerData(prev => ({
                            ...prev,
                            address: { ...prev.address, city: e.target.value }
                          }))}
                          placeholder="Nome da cidade"
                        />
                      </div>

                      <div>
                        <Label htmlFor="reference">Ponto de referência</Label>
                        <Textarea
                          id="reference"
                          value={customerData.address.reference}
                          onChange={(e) => setCustomerData(prev => ({
                            ...prev,
                            address: { ...prev.address, reference: e.target.value }
                          }))}
                          placeholder="Ex: Próximo ao supermercado, portão azul..."
                          className="resize-none"
                          rows={2}
                        />
                      </div>
                    </div>
                  </CardContent>
                </Card>
              )}

              <Button
                onClick={handleContinueToPayment}
                className="w-full bg-orange-500 hover:bg-orange-600 h-12 text-lg"
              >
                Continuar para o Pagamento
              </Button>
            </div>
          ) : (
            <div className="space-y-6">
              {/* Resumo do pedido com frete */}
              <Card>
                <CardContent className="p-4">
                  <h3 className="font-semibold mb-3">Resumo do Pedido #{orderNumber}</h3>
                  <div className="space-y-2">
                    {cart.map((item, index) => (
                      <div key={item.id} className="flex justify-between text-sm">
                        <div className="flex items-center gap-2">
                          {item.product.isPizza && <Pizza className="w-3 h-3 text-orange-500" />}
                          <span>
                            {item.quantity}x {item.product.name}
                            {item.product.isPizza && item.customizations?.flavorCount > 1 && (
                              <span className="text-xs text-gray-500 ml-1">
                                ({item.customizations.flavorCount} sabores)
                              </span>
                            )}
                          </span>
                        </div>
                        <span>R$ {item.totalPrice.toFixed(2)}</span>
                      </div>
                    ))}
                    
                    <div className="border-t pt-2 space-y-1">
                      <div className="flex justify-between text-sm">
                        <span>Subtotal:</span>
                        <span>R$ {total.toFixed(2)}</span>
                      </div>
                      
                      {customerData.deliveryType === "delivery" && (
                        <div className="flex justify-between text-sm">
                          <span className="flex items-center gap-1">
                            <Truck className="w-3 h-3" />
                            Taxa de entrega:
                          </span>
                          <span>R$ {deliveryFee.toFixed(2)}</span>
                        </div>
                      )}
                      
                      <div className="flex justify-between font-bold">
                        <span>Total:</span>
                        <span className="text-orange-600">R$ {totalWithDelivery.toFixed(2)}</span>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>

              {/* Forma de pagamento */}
              <Card>
                <CardContent className="p-4">
                  <h3 className="font-semibold mb-3">Forma de Pagamento</h3>
                  <RadioGroup value={paymentMethod} onValueChange={(value: 'whatsapp' | 'pix') => setPaymentMethod(value)}>
                    <div className="flex items-center space-x-2 p-3 border rounded-lg">
                      <RadioGroupItem value="whatsapp" id="whatsapp" />
                      <Label htmlFor="whatsapp" className="flex items-center gap-2 cursor-pointer flex-1">
                        <MessageSquare className="w-4 h-4 text-green-600" />
                        <div>
                          <div className="font-medium">WhatsApp (Padrão)</div>
                          <div className="text-xs text-gray-500">Enviar pedido e combinar pagamento</div>
                        </div>
                      </Label>
                    </div>
                    
                    <div className="flex items-center space-x-2 p-3 border rounded-lg">
                      <RadioGroupItem value="pix" id="pix" />
                      <Label htmlFor="pix" className="flex items-center gap-2 cursor-pointer flex-1">
                        <QrCode className="w-4 h-4 text-blue-600" />
                        <div>
                          <div className="font-medium">PIX</div>
                          <div className="text-xs text-gray-500">Pagamento instantâneo com QR Code</div>
                        </div>
                      </Label>
                    </div>
                  </RadioGroup>
                </CardContent>
              </Card>

              <div className="flex gap-3">
                <Button
                  variant="outline"
                  onClick={() => setStep('form')}
                  className="flex-1"
                >
                  Voltar
                </Button>
                <Button
                  onClick={handleSubmitOrder}
                  className={`flex-1 h-12 text-lg ${
                    paymentMethod === 'pix' 
                      ? 'bg-blue-600 hover:bg-blue-700' 
                      : 'bg-green-600 hover:bg-green-700'
                  }`}
                >
                  {paymentMethod === 'pix' ? (
                    <>
                      <QrCode className="w-5 h-5 mr-2" />
                      Pagar com PIX
                    </>
                  ) : (
                    <>
                      <MessageSquare className="w-5 h-5 mr-2" />
                      Enviar Pedido
                    </>
                  )}
                </Button>
              </div>
            </div>
          )}
        </DialogContent>
      </Dialog>

      <PixPaymentModal
        isOpen={isPixModalOpen}
        onClose={() => {
          setIsPixModalOpen(false);
          handleModalClose();
        }}
        onBack={() => setIsPixModalOpen(false)}
        cart={cart}
        total={totalWithDelivery}
        customerData={customerData}
        orderNumber={orderNumber}
      />
    </>
  );
};
