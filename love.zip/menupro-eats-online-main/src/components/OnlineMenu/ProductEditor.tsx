
import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Switch } from "@/components/ui/switch";
import { Badge } from "@/components/ui/badge";
import { Plus, Trash2, Edit, Star } from "lucide-react";
import { useToast } from "@/hooks/use-toast";

interface Product {
  id: string;
  name: string;
  description: string;
  price: number;
  image: string;
  category: string;
  isPromotion: boolean;
  promotionPrice?: number;
  customizable?: boolean;
  ingredients?: string[];
  extras?: { name: string; price: number }[];
}

interface ProductEditorProps {
  products: Product[];
  categories: string[];
}

export const ProductEditor = ({ products: initialProducts, categories }: ProductEditorProps) => {
  const [products, setProducts] = useState(initialProducts);
  const [editingProduct, setEditingProduct] = useState<Product | null>(null);
  const [isCreating, setIsCreating] = useState(false);
  const [selectedCategory, setSelectedCategory] = useState("Todos");
  const { toast } = useToast();

  const filteredProducts = selectedCategory === "Todos"
    ? products
    : products.filter(product => product.category === selectedCategory);

  const handleCreateProduct = () => {
    const newProduct: Product = {
      id: Date.now().toString(),
      name: "Novo Produto",
      description: "Descrição do produto",
      price: 0,
      image: "/placeholder.svg",
      category: categories.filter(cat => cat !== "Todos")[0] || "Lanches",
      isPromotion: false,
      customizable: false
    };
    
    setEditingProduct(newProduct);
    setIsCreating(true);
  };

  const handleSaveProduct = (product: Product) => {
    if (isCreating) {
      setProducts([...products, product]);
      toast({
        title: "Produto criado!",
        description: `${product.name} foi adicionado ao cardápio.`,
      });
    } else {
      setProducts(products.map(p => p.id === product.id ? product : p));
      toast({
        title: "Produto atualizado!",
        description: `${product.name} foi atualizado.`,
      });
    }
    
    setEditingProduct(null);
    setIsCreating(false);
  };

  const handleDeleteProduct = (productId: string) => {
    const product = products.find(p => p.id === productId);
    setProducts(products.filter(p => p.id !== productId));
    
    toast({
      title: "Produto removido!",
      description: `${product?.name} foi excluído do cardápio.`,
    });
  };

  if (editingProduct) {
    return (
      <ProductForm
        product={editingProduct}
        categories={categories.filter(cat => cat !== "Todos")}
        onSave={handleSaveProduct}
        onCancel={() => {
          setEditingProduct(null);
          setIsCreating(false);
        }}
        isCreating={isCreating}
      />
    );
  }

  return (
    <div className="space-y-4">
      <div className="flex justify-between items-center">
        <h3 className="text-lg font-semibold">Gerenciar Produtos</h3>
        <Button onClick={handleCreateProduct}>
          <Plus className="w-4 h-4 mr-2" />
          Novo Produto
        </Button>
      </div>

      {/* Filtro por categoria */}
      <div className="flex gap-2 flex-wrap">
        {categories.map((category) => (
          <Button
            key={category}
            variant={selectedCategory === category ? "default" : "outline"}
            size="sm"
            onClick={() => setSelectedCategory(category)}
          >
            {category}
          </Button>
        ))}
      </div>

      {/* Lista de produtos */}
      <div className="grid gap-4 md:grid-cols-2">
        {filteredProducts.map((product) => (
          <Card key={product.id}>
            <CardHeader className="p-0">
              <div className="relative">
                <img
                  src={product.image}
                  alt={product.name}
                  className="w-full h-32 object-cover rounded-t-md"
                />
                {product.isPromotion && (
                  <Badge className="absolute top-2 left-2 bg-red-500 text-white">
                    <Star className="w-3 h-3 mr-1" />
                    Promoção
                  </Badge>
                )}
              </div>
            </CardHeader>
            <CardContent className="p-4">
              <div className="flex justify-between items-start mb-2">
                <h4 className="font-semibold">{product.name}</h4>
                <Badge variant="outline">{product.category}</Badge>
              </div>
              
              <p className="text-sm text-gray-600 mb-3 line-clamp-2">
                {product.description}
              </p>
              
              <div className="flex justify-between items-center">
                <div className="flex items-center gap-2">
                  {product.isPromotion && product.promotionPrice ? (
                    <>
                      <span className="text-lg font-bold text-green-600">
                        R$ {product.promotionPrice.toFixed(2)}
                      </span>
                      <span className="text-sm text-gray-500 line-through">
                        R$ {product.price.toFixed(2)}
                      </span>
                    </>
                  ) : (
                    <span className="text-lg font-bold">
                      R$ {product.price.toFixed(2)}
                    </span>
                  )}
                </div>
                
                <div className="flex gap-1">
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => setEditingProduct(product)}
                  >
                    <Edit className="w-3 h-3" />
                  </Button>
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => handleDeleteProduct(product.id)}
                    className="text-red-600 hover:text-red-700"
                  >
                    <Trash2 className="w-3 h-3" />
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      {filteredProducts.length === 0 && (
        <Card>
          <CardContent className="p-8 text-center text-gray-500">
            <p>Nenhum produto encontrado nesta categoria.</p>
            <p className="text-sm">Adicione seu primeiro produto acima.</p>
          </CardContent>
        </Card>
      )}
    </div>
  );
};

interface ProductFormProps {
  product: Product;
  categories: string[];
  onSave: (product: Product) => void;
  onCancel: () => void;
  isCreating: boolean;
}

const ProductForm = ({ product, categories, onSave, onCancel, isCreating }: ProductFormProps) => {
  const [formData, setFormData] = useState(product);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSave(formData);
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-4">
      <div className="flex justify-between items-center">
        <h3 className="text-lg font-semibold">
          {isCreating ? "Novo Produto" : "Editar Produto"}
        </h3>
        <div className="flex gap-2">
          <Button type="button" variant="outline" onClick={onCancel}>
            Cancelar
          </Button>
          <Button type="submit">Salvar</Button>
        </div>
      </div>

      <div className="grid gap-4 md:grid-cols-2">
        <div className="space-y-4">
          <div>
            <Label htmlFor="name">Nome do Produto</Label>
            <Input
              id="name"
              value={formData.name}
              onChange={(e) => setFormData({ ...formData, name: e.target.value })}
              placeholder="Ex: Hambúrguer Clássico"
            />
          </div>

          <div>
            <Label htmlFor="description">Descrição</Label>
            <Textarea
              id="description"
              value={formData.description}
              onChange={(e) => setFormData({ ...formData, description: e.target.value })}
              placeholder="Descreva os ingredientes e características do produto"
              rows={3}
            />
          </div>

          <div>
            <Label htmlFor="category">Categoria</Label>
            <Select
              value={formData.category}
              onValueChange={(value) => setFormData({ ...formData, category: value })}
            >
              <SelectTrigger>
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                {categories.map((category) => (
                  <SelectItem key={category} value={category}>
                    {category}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div>
              <Label htmlFor="price">Preço (R$)</Label>
              <Input
                id="price"
                type="number"
                step="0.01"
                value={formData.price}
                onChange={(e) => setFormData({ ...formData, price: parseFloat(e.target.value) || 0 })}
              />
            </div>

            {formData.isPromotion && (
              <div>
                <Label htmlFor="promotionPrice">Preço Promocional (R$)</Label>
                <Input
                  id="promotionPrice"
                  type="number"
                  step="0.01"
                  value={formData.promotionPrice || 0}
                  onChange={(e) => setFormData({ 
                    ...formData, 
                    promotionPrice: parseFloat(e.target.value) || 0 
                  })}
                />
              </div>
            )}
          </div>

          <div>
            <Label htmlFor="image">URL da Imagem</Label>
            <Input
              id="image"
              value={formData.image}
              onChange={(e) => setFormData({ ...formData, image: e.target.value })}
              placeholder="https://exemplo.com/imagem.jpg"
            />
          </div>
        </div>

        <div className="space-y-4">
          <div className="space-y-3">
            <div className="flex items-center space-x-2">
              <Switch
                id="isPromotion"
                checked={formData.isPromotion}
                onCheckedChange={(checked) => setFormData({ ...formData, isPromotion: checked })}
              />
              <Label htmlFor="isPromotion">Produto em promoção</Label>
            </div>

            <div className="flex items-center space-x-2">
              <Switch
                id="customizable"
                checked={formData.customizable}
                onCheckedChange={(checked) => setFormData({ ...formData, customizable: checked })}
              />
              <Label htmlFor="customizable">Produto personalizável</Label>
            </div>
          </div>

          <div className="border rounded-md p-4">
            <Label className="text-sm font-medium">Pré-visualização</Label>
            <div className="mt-2">
              <img
                src={formData.image}
                alt="Preview"
                className="w-full h-32 object-cover rounded-md mb-2"
              />
              <h4 className="font-semibold">{formData.name}</h4>
              <p className="text-sm text-gray-600 mb-2">{formData.description}</p>
              <div className="flex justify-between items-center">
                <div className="flex items-center gap-2">
                  {formData.isPromotion && formData.promotionPrice ? (
                    <>
                      <span className="text-lg font-bold text-green-600">
                        R$ {formData.promotionPrice.toFixed(2)}
                      </span>
                      <span className="text-sm text-gray-500 line-through">
                        R$ {formData.price.toFixed(2)}
                      </span>
                    </>
                  ) : (
                    <span className="text-lg font-bold">
                      R$ {formData.price.toFixed(2)}
                    </span>
                  )}
                </div>
                <Badge variant="outline">{formData.category}</Badge>
              </div>
            </div>
          </div>
        </div>
      </div>
    </form>
  );
};
