
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Plus, Settings, Pizza } from "lucide-react";
import { UpsellSuggestions } from "./UpsellSuggestions";
import { useState } from "react";
import { useIsMobile } from "@/hooks/use-mobile";

interface Product {
  id: string;
  name: string;
  description: string;
  price: number;
  image: string;
  category: string;
  isPromotion: boolean;
  promotionPrice?: number;
  customizable?: boolean;
  isPizza?: boolean;
}

interface ProductCardProps {
  product: Product;
  onQuickAdd: (product: Product) => void;
  onCustomize: (product: Product) => void;
  showUpsell: boolean;
  onToggleUpsell: () => void;
  upsellSuggestions?: Array<{
    id: string;
    name: string;
    price: number;
    image: string | null;
  }>;
  mobileLayoutMode?: 'single' | 'double';
}

export const ProductCard = ({ product, onQuickAdd, onCustomize, showUpsell, onToggleUpsell, upsellSuggestions = [], mobileLayoutMode = 'single' }: ProductCardProps) => {
  const displayPrice = product.isPromotion && product.promotionPrice ? product.promotionPrice : product.price;
  const isMobile = useIsMobile();
  const isCompactMode = isMobile && mobileLayoutMode === 'double';

  const handleQuickAdd = () => {
    onQuickAdd(product);
    onToggleUpsell();
  };

  return (
    <Card className="overflow-hidden hover:shadow-lg transition-shadow h-full flex flex-col">
      {/* Imagem do produto */}
      <div className="relative">
        <img
          src={product.image}
          alt={product.name}
          className={`w-full object-cover ${isCompactMode ? 'h-24' : 'h-48'}`}
        />
        {product.isPromotion && (
          <Badge className={`absolute top-1 left-1 bg-red-500 text-white ${isCompactMode ? 'text-xs py-0 px-1' : ''}`}>
            {isCompactMode ? '🔥' : 'Promoção'}
          </Badge>
        )}
        {product.isPizza && (
          <Badge className={`absolute top-1 right-1 bg-orange-500 text-white ${isCompactMode ? 'text-xs py-0 px-1' : ''}`}>
            <Pizza className={`${isCompactMode ? 'w-2 h-2' : 'w-3 h-3 mr-1'}`} />
            {!isCompactMode && 'Pizza'}
          </Badge>
        )}
      </div>
      
      {/* Conteúdo do card */}
      <CardContent className={`flex flex-col flex-grow ${isCompactMode ? 'p-2' : 'p-4'}`}>
        {/* Nome do produto */}
        <h3 className={`font-semibold mb-2 line-clamp-2 ${
          isCompactMode 
            ? 'text-xs min-h-[2rem] leading-tight' 
            : 'text-lg min-h-[3.5rem] flex items-center'
        }`}>
          {product.name}
        </h3>
        
        {/* Descrição do produto - oculta no modo compacto */}
        {!isCompactMode && (
          <p className="text-gray-600 text-sm mb-4 line-clamp-2 min-h-[2.5rem] flex-grow">
            {product.description}
          </p>
        )}
        
        {/* Preço */}
        <div className={`${isCompactMode ? 'mb-2' : 'mb-4'}`}>
          {product.isPromotion && product.promotionPrice ? (
            <div className={`flex items-center ${isCompactMode ? 'gap-1 justify-start' : 'gap-2 justify-center'}`}>
              <span className={`font-bold text-green-600 ${isCompactMode ? 'text-sm' : 'text-xl'}`}>
                R$ {product.promotionPrice.toFixed(2)}
              </span>
              <span className={`text-gray-500 line-through ${isCompactMode ? 'text-xs' : 'text-sm'}`}>
                R$ {product.price.toFixed(2)}
              </span>
            </div>
          ) : (
            <div className={isCompactMode ? 'text-left' : 'text-center'}>
              <span className={`font-bold text-gray-900 ${isCompactMode ? 'text-sm' : 'text-xl'}`}>
                R$ {product.price.toFixed(2)}
              </span>
            </div>
          )}
        </div>

        {/* Botões de ação */}
        <div className={`${isCompactMode ? 'mb-2' : 'mb-4'}`}>
          {product.customizable || product.isPizza ? (
            isCompactMode ? (
              // Modo compacto: apenas botão de customizar
              <Button
                variant="outline"
                size="sm"
                onClick={() => onCustomize(product)}
                className="w-full h-7 text-xs px-2"
              >
                {product.isPizza ? (
                  <>
                    <Pizza className="w-3 h-3 mr-1" />
                    Montar
                  </>
                ) : (
                  <>
                    <Settings className="w-3 h-3 mr-1" />
                    Personalizar
                  </>
                )}
              </Button>
            ) : (
              // Modo normal: dois botões
              <div className="flex gap-2">
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => onCustomize(product)}
                  className="flex-1 h-10"
                >
                  {product.isPizza ? (
                    <>
                      <Pizza className="w-4 h-4 mr-2" />
                      Montar
                    </>
                  ) : (
                    <>
                      <Settings className="w-4 h-4 mr-2" />
                      Personalizar
                    </>
                  )}
                </Button>
                <Button
                  size="sm"
                  onClick={handleQuickAdd}
                  className="bg-orange-500 hover:bg-orange-600 h-10 px-4"
                >
                  <Plus className="w-4 h-4" />
                </Button>
              </div>
            )
          ) : (
            <Button
              size="sm"
              onClick={handleQuickAdd}
              className={`w-full bg-orange-500 hover:bg-orange-600 ${
                isCompactMode ? 'h-7 text-xs px-2' : 'h-10'
              }`}
            >
              <Plus className={`${isCompactMode ? 'w-3 h-3 mr-1' : 'w-4 h-4 mr-2'}`} />
              {isCompactMode ? '+' : 'Adicionar'}
            </Button>
          )}
        </div>

        {/* Upsell - oculto no modo compacto */}
        {showUpsell && !isCompactMode && (
          <UpsellSuggestions
            suggestions={upsellSuggestions}
            onAddToCart={(upsellProduct) => {
              onQuickAdd({
                ...upsellProduct,
                category: "Bebidas",
                description: "Sugestão automática",
                isPromotion: false,
                customizable: false,
                isPizza: false
              });
            }}
          />
        )}
      </CardContent>
    </Card>
  );
};
