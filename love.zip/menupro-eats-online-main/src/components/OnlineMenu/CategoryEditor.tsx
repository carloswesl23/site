
import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Plus, Trash2, Edit, GripVertical } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { useUserData } from "@/hooks/useUserData";

interface CategoryEditorProps {
  categories: { id: string; name: string; sort_order: number }[];
}

export const CategoryEditor = ({ categories }: CategoryEditorProps) => {
  const [editingIndex, setEditingIndex] = useState<number | null>(null);
  const [editingValue, setEditingValue] = useState("");
  const [newCategoryName, setNewCategoryName] = useState("");
  const { toast } = useToast();
  const { addCategory, updateCategory, deleteCategory } = useUserData();

  const handleAddCategory = async () => {
    if (newCategoryName.trim()) {
      try {
        await addCategory(newCategoryName.trim());
        setNewCategoryName("");
      } catch (error) {
        // Error already handled in addCategory
      }
    }
  };

  const handleEditCategory = (index: number) => {
    setEditingIndex(index);
    setEditingValue(categories[index].name);
  };

  const handleSaveEdit = async () => {
    if (editingIndex !== null && editingValue.trim()) {
      try {
        await updateCategory(categories[editingIndex].id, { name: editingValue.trim() });
        setEditingIndex(null);
        setEditingValue("");
      } catch (error) {
        // Error already handled in updateCategory
      }
    }
  };

  const handleCancelEdit = () => {
    setEditingIndex(null);
    setEditingValue("");
  };

  const handleDeleteCategory = async (index: number) => {
    try {
      await deleteCategory(categories[index].id);
    } catch (error) {
      // Error already handled in deleteCategory
    }
  };

  return (
    <div className="space-y-4">
      <div className="flex justify-between items-center">
        <h3 className="text-lg font-semibold">Gerenciar Categorias</h3>
      </div>

      {/* Adicionar nova categoria */}
      <Card>
        <CardHeader>
          <CardTitle className="text-base">Nova Categoria</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="flex gap-2">
            <Input
              value={newCategoryName}
              onChange={(e) => setNewCategoryName(e.target.value)}
              placeholder="Nome da categoria"
              onKeyPress={(e) => e.key === 'Enter' && handleAddCategory()}
            />
            <Button onClick={handleAddCategory} disabled={!newCategoryName.trim()}>
              <Plus className="w-4 h-4 mr-2" />
              Adicionar
            </Button>
          </div>
        </CardContent>
      </Card>

      {/* Lista de categorias */}
      <div className="space-y-2">
        {categories.map((category, index) => (
          <Card key={category.id}>
            <CardContent className="p-4">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-3 flex-1">
                  <GripVertical className="w-4 h-4 text-gray-400 cursor-move" />
                  
                  {editingIndex === index ? (
                    <div className="flex gap-2 flex-1">
                      <Input
                        value={editingValue}
                        onChange={(e) => setEditingValue(e.target.value)}
                        onKeyPress={(e) => {
                          if (e.key === 'Enter') handleSaveEdit();
                          if (e.key === 'Escape') handleCancelEdit();
                        }}
                        autoFocus
                      />
                      <Button size="sm" onClick={handleSaveEdit}>
                        Salvar
                      </Button>
                      <Button size="sm" variant="outline" onClick={handleCancelEdit}>
                        Cancelar
                      </Button>
                    </div>
                  ) : (
                    <>
                      <span className="font-medium">{category.name}</span>
                      <div className="flex gap-1 ml-auto">
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => handleEditCategory(index)}
                        >
                          <Edit className="w-3 h-3" />
                        </Button>
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => handleDeleteCategory(index)}
                          className="text-red-600 hover:text-red-700"
                        >
                          <Trash2 className="w-3 h-3" />
                        </Button>
                      </div>
                    </>
                  )}
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      {categories.length === 0 && (
        <Card>
          <CardContent className="p-8 text-center text-gray-500">
            <p>Nenhuma categoria criada ainda.</p>
            <p className="text-sm">Adicione sua primeira categoria acima.</p>
          </CardContent>
        </Card>
      )}
    </div>
  );
};
