
import { useState, useEffect } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Copy, CheckCircle, QrCode, CreditCard, ArrowLeft } from "lucide-react";
import { useToast } from "@/hooks/use-toast";

interface CartItem {
  id: string;
  product: any;
  quantity: number;
  customizations?: any;
  totalPrice: number;
}

interface PixPaymentModalProps {
  isOpen: boolean;
  onClose: () => void;
  onBack: () => void;
  cart: CartItem[];
  total: number;
  customerData: any;
  orderNumber: string;
}

// Simulação de resposta da API do Pix
interface PixResponse {
  qrCode: string;
  qrCodeImage: string;
  pixKey: string;
  amount: number;
  orderId: string;
  expiresAt: string;
}

export const PixPaymentModal = ({ 
  isOpen, 
  onClose, 
  onBack,
  cart, 
  total, 
  customerData,
  orderNumber 
}: PixPaymentModalProps) => {
  const { toast } = useToast();
  const [pixData, setPixData] = useState<PixResponse | null>(null);
  const [isGenerating, setIsGenerating] = useState(false);
  const [copied, setCopied] = useState(false);
  const [paymentStatus, setPaymentStatus] = useState<'pending' | 'checking' | 'confirmed'>('pending');

  // Simular geração do Pix
  const generatePixPayment = async () => {
    setIsGenerating(true);
    
    // Simular chamada para API de pagamento
    try {
      // Aqui seria a integração real com Gerencianet, ASAAS, Mercado Pago, etc.
      await new Promise(resolve => setTimeout(resolve, 2000));
      
      const mockPixData: PixResponse = {
        qrCode: `00020126580014br.gov.bcb.pix013662dc2b9b-5b1f-4e5e-8e5e-1234567890ab5204000053039865802BR5925BURGER HOUSE LTDA6014SAO PAULO6304ABCD`,
        qrCodeImage: `data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMjAwIiBoZWlnaHQ9IjIwMCIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj4KICA8cmVjdCB3aWR0aD0iMjAwIiBoZWlnaHQ9IjIwMCIgZmlsbD0iI2ZmZiIvPgogIDx0ZXh0IHg9IjEwMCIgeT0iMTAwIiB0ZXh0LWFuY2hvcj0ibWlkZGxlIiBkeT0iLjNlbSIgZm9udC1mYW1pbHk9Im1vbm9zcGFjZSIgZm9udC1zaXplPSIxNCIgZmlsbD0iIzMzMyI+UVIgQ09ERTwvdGV4dD4KPC9zdmc+`,
        pixKey: "pix@burgerhouse.com.br",
        amount: total,
        orderId: orderNumber,
        expiresAt: new Date(Date.now() + 30 * 60 * 1000).toISOString() // 30 minutos
      };
      
      setPixData(mockPixData);
      
      toast({
        title: "Pix gerado com sucesso!",
        description: "Escaneie o QR Code ou copie o código para efetuar o pagamento",
      });
    } catch (error) {
      toast({
        title: "Erro ao gerar Pix",
        description: "Tente novamente em alguns instantes",
        variant: "destructive"
      });
    } finally {
      setIsGenerating(false);
    }
  };

  const copyPixCode = () => {
    if (pixData) {
      navigator.clipboard.writeText(pixData.qrCode);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
      
      toast({
        title: "Código copiado!",
        description: "Cole no seu aplicativo bancário para efetuar o pagamento",
      });
    }
  };

  const checkPaymentStatus = () => {
    setPaymentStatus('checking');
    
    // Simular verificação de pagamento
    setTimeout(() => {
      // Aqui seria a verificação real via webhook ou polling
      const isConfirmed = Math.random() > 0.3; // 70% de chance de confirmar (para demo)
      
      if (isConfirmed) {
        setPaymentStatus('confirmed');
        toast({
          title: "Pagamento confirmado! 🎉",
          description: "Seu pedido foi confirmado e está sendo preparado",
        });
        
        // Fechar modal após 3 segundos
        setTimeout(() => {
          onClose();
        }, 3000);
      } else {
        setPaymentStatus('pending');
        toast({
          title: "Pagamento ainda não identificado",
          description: "Aguarde alguns instantes e tente verificar novamente",
        });
      }
    }, 2000);
  };

  useEffect(() => {
    if (isOpen && !pixData) {
      generatePixPayment();
    }
  }, [isOpen]);

  const formatTime = (isoString: string) => {
    return new Date(isoString).toLocaleTimeString('pt-BR', {
      hour: '2-digit',
      minute: '2-digit'
    });
  };

  if (paymentStatus === 'confirmed') {
    return (
      <Dialog open={isOpen} onOpenChange={onClose}>
        <DialogContent className="max-w-md text-center">
          <div className="space-y-6 py-6">
            <div className="mx-auto w-16 h-16 bg-green-100 rounded-full flex items-center justify-center">
              <CheckCircle className="w-8 h-8 text-green-600" />
            </div>
            
            <div>
              <h2 className="text-xl font-bold text-gray-900 mb-2">
                Pagamento Confirmado! 🎉
              </h2>
              <p className="text-gray-600">
                Seu pedido #{orderNumber} foi confirmado e está sendo preparado.
              </p>
            </div>
            
            <div className="bg-green-50 p-4 rounded-lg">
              <p className="text-sm text-green-800">
                Você receberá atualizações sobre o status do seu pedido via WhatsApp.
              </p>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    );
  }

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-md max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <div className="flex items-center gap-2">
            <Button
              variant="ghost"
              size="sm"
              onClick={onBack}
              className="p-1"
            >
              <ArrowLeft className="w-4 h-4" />
            </Button>
            <DialogTitle className="flex items-center gap-2">
              <QrCode className="w-5 h-5" />
              Pagamento via Pix
            </DialogTitle>
          </div>
        </DialogHeader>

        <div className="space-y-6">
          {/* Resumo do pedido */}
          <Card>
            <CardContent className="p-4">
              <div className="flex justify-between items-center mb-2">
                <span className="font-medium">Pedido #{orderNumber}</span>
                <Badge variant="outline">Aguardando pagamento</Badge>
              </div>
              <div className="flex justify-between text-lg font-bold">
                <span>Total:</span>
                <span className="text-green-600">R$ {total.toFixed(2)}</span>
              </div>
            </CardContent>
          </Card>

          {isGenerating ? (
            <Card>
              <CardContent className="p-8 text-center">
                <div className="animate-spin w-8 h-8 border-2 border-orange-500 border-t-transparent rounded-full mx-auto mb-4"></div>
                <p className="text-gray-600">Gerando código Pix...</p>
              </CardContent>
            </Card>
          ) : pixData ? (
            <>
              {/* QR Code */}
              <Card>
                <CardContent className="p-6 text-center">
                  <h3 className="font-semibold mb-4">Escaneie o QR Code</h3>
                  <div className="bg-white p-4 rounded-lg border-2 border-dashed border-gray-300 inline-block">
                    <img
                      src={pixData.qrCodeImage}
                      alt="QR Code Pix"
                      className="w-48 h-48 mx-auto"
                    />
                  </div>
                  <p className="text-sm text-gray-600 mt-2">
                    Use a câmera do seu banco ou carteira digital
                  </p>
                </CardContent>
              </Card>

              {/* Código Pix */}
              <Card>
                <CardContent className="p-4">
                  <h3 className="font-semibold mb-3">Ou copie o código Pix</h3>
                  <div className="bg-gray-50 p-3 rounded-lg border">
                    <code className="text-xs break-all text-gray-700">
                      {pixData.qrCode}
                    </code>
                  </div>
                  <Button
                    onClick={copyPixCode}
                    variant="outline"
                    className="w-full mt-3"
                    disabled={copied}
                  >
                    {copied ? (
                      <>
                        <CheckCircle className="w-4 h-4 mr-2 text-green-600" />
                        Copiado!
                      </>
                    ) : (
                      <>
                        <Copy className="w-4 h-4 mr-2" />
                        Copiar código Pix
                      </>
                    )}
                  </Button>
                </CardContent>
              </Card>

              {/* Informações importantes */}
              <Card className="border-orange-200 bg-orange-50">
                <CardContent className="p-4">
                  <h4 className="font-medium text-orange-800 mb-2">⚠️ Importante:</h4>
                  <ul className="text-sm text-orange-700 space-y-1">
                    <li>• O código expira às {formatTime(pixData.expiresAt)}</li>
                    <li>• Após o pagamento, clique em "Verificar pagamento"</li>
                    <li>• O pedido será confirmado automaticamente</li>
                  </ul>
                </CardContent>
              </Card>

              {/* Botão verificar pagamento */}
              <Button
                onClick={checkPaymentStatus}
                disabled={paymentStatus === 'checking'}
                className="w-full bg-green-600 hover:bg-green-700 h-12"
              >
                {paymentStatus === 'checking' ? (
                  <>
                    <div className="animate-spin w-4 h-4 border-2 border-white border-t-transparent rounded-full mr-2"></div>
                    Verificando pagamento...
                  </>
                ) : (
                  <>
                    <CreditCard className="w-4 h-4 mr-2" />
                    Verificar pagamento
                  </>
                )}
              </Button>

              <div className="text-center">
                <p className="text-xs text-gray-500">
                  Pagamento 100% seguro via Pix
                </p>
              </div>
            </>
          ) : null}
        </div>
      </DialogContent>
    </Dialog>
  );
};
