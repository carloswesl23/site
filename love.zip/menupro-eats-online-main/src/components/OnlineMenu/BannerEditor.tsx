
import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Switch } from "@/components/ui/switch";
import { Plus, Trash2, Edit, Upload, Save } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { useSecureFileUpload } from "@/hooks/useSecureFileUpload";
import { useUserData } from "@/hooks/useUserData";

interface Banner {
  id: string;
  image: string;
  title: string;
  subtitle: string;
  active: boolean;
}

interface BannerEditorProps {
  banners: Banner[];
  onUpdateBanners: (banners: Banner[]) => void;
}

export const BannerEditor = ({ banners, onUpdateBanners }: BannerEditorProps) => {
  const [editingBanner, setEditingBanner] = useState<Banner | null>(null);
  const [isCreating, setIsCreating] = useState(false);
  const [hasChanges, setHasChanges] = useState(false);
  const { toast } = useToast();
  const { updateSettings } = useUserData();

  const handleCreateBanner = () => {
    const newBanner: Banner = {
      id: Date.now().toString(),
      image: "/placeholder.svg",
      title: "Novo Banner",
      subtitle: "Descrição do banner",
      active: true
    };
    
    onUpdateBanners([...banners, newBanner]);
    setEditingBanner(newBanner);
    setIsCreating(true);
    setHasChanges(true);
    
    toast({
      title: "Banner criado!",
      description: "Novo banner adicionado. Lembre-se de salvar as alterações.",
    });
  };

  const handleUpdateBanner = (updatedBanner: Banner) => {
    const updatedBanners = banners.map(banner =>
      banner.id === updatedBanner.id ? updatedBanner : banner
    );
    onUpdateBanners(updatedBanners);
    setEditingBanner(null);
    setIsCreating(false);
    setHasChanges(true);
    
    toast({
      title: "Banner atualizado!",
      description: "Lembre-se de salvar as alterações.",
    });
  };

  const handleDeleteBanner = (bannerId: string) => {
    const updatedBanners = banners.filter(banner => banner.id !== bannerId);
    onUpdateBanners(updatedBanners);
    setHasChanges(true);
    
    toast({
      title: "Banner removido!",
      description: "Lembre-se de salvar as alterações.",
    });
  };

  const toggleBannerStatus = (bannerId: string) => {
    const updatedBanners = banners.map(banner =>
      banner.id === bannerId ? { ...banner, active: !banner.active } : banner
    );
    onUpdateBanners(updatedBanners);
    setHasChanges(true);
  };

  const handleSaveBanners = async () => {
    try {
      const bannersData = banners.map(banner => ({
        id: banner.id,
        image: banner.image,
        title: banner.title,
        subtitle: banner.subtitle,
        active: banner.active
      }));

      await updateSettings({
        carrousel_banners: JSON.stringify(bannersData)
      });

      setHasChanges(false);
      toast({
        title: "Banners salvos!",
        description: "Todos os banners foram salvos com sucesso.",
      });
    } catch (error) {
      console.error('Erro ao salvar banners:', error);
      toast({
        title: "Erro ao salvar",
        description: "Não foi possível salvar os banners. Tente novamente.",
        variant: "destructive",
      });
    }
  };

  if (editingBanner) {
    return (
      <BannerForm
        banner={editingBanner}
        onSave={handleUpdateBanner}
        onCancel={() => {
          setEditingBanner(null);
          setIsCreating(false);
        }}
        isCreating={isCreating}
      />
    );
  }

  return (
    <div className="space-y-4">
      <div className="flex justify-between items-center">
        <h3 className="text-lg font-semibold">Gerenciar Banners</h3>
        <Button onClick={handleCreateBanner}>
          <Plus className="w-4 h-4 mr-2" />
          Novo Banner
        </Button>
      </div>

      <div className="grid gap-4">
        {banners.map((banner) => (
          <Card key={banner.id}>
            <CardHeader className="pb-3">
              <div className="flex justify-between items-start">
                <div>
                  <CardTitle className="text-base">{banner.title}</CardTitle>
                  <p className="text-sm text-gray-600">{banner.subtitle}</p>
                </div>
                <div className="flex items-center gap-2">
                  <Switch
                    checked={banner.active}
                    onCheckedChange={() => toggleBannerStatus(banner.id)}
                  />
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => setEditingBanner(banner)}
                  >
                    <Edit className="w-3 h-3" />
                  </Button>
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => handleDeleteBanner(banner.id)}
                    className="text-red-600 hover:text-red-700"
                  >
                    <Trash2 className="w-3 h-3" />
                  </Button>
                </div>
              </div>
            </CardHeader>
            <CardContent>
              <img
                src={banner.image}
                alt={banner.title}
                className="w-full h-32 object-cover rounded-md"
              />
            </CardContent>
          </Card>
        ))}
      </div>

      {hasChanges && (
        <div className="bg-yellow-50 border border-yellow-200 rounded-lg p-4 mb-4">
          <p className="text-yellow-800 text-sm">
            Você tem alterações não salvas nos banners. Clique em "Salvar Banners" para aplicar as mudanças.
          </p>
          <Button onClick={handleSaveBanners} className="mt-2" size="sm">
            <Save className="w-4 h-4 mr-2" />
            Salvar Banners
          </Button>
        </div>
      )}
    </div>
  );
};

interface BannerFormProps {
  banner: Banner;
  onSave: (banner: Banner) => void;
  onCancel: () => void;
  isCreating: boolean;
}

const BannerForm = ({ banner, onSave, onCancel, isCreating }: BannerFormProps) => {
  const [formData, setFormData] = useState(banner);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSave(formData);
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-4">
      <div className="flex justify-between items-center">
        <h3 className="text-lg font-semibold">
          {isCreating ? "Novo Banner" : "Editar Banner"}
        </h3>
        <div className="flex gap-2">
          <Button type="button" variant="outline" onClick={onCancel}>
            Cancelar
          </Button>
          <Button type="submit">Salvar</Button>
        </div>
      </div>

      <div className="grid gap-4">
        <div>
          <Label htmlFor="title">Título</Label>
          <Input
            id="title"
            value={formData.title}
            onChange={(e) => setFormData({ ...formData, title: e.target.value })}
            placeholder="Digite o título do banner"
          />
        </div>

        <div>
          <Label htmlFor="subtitle">Subtítulo</Label>
          <Input
            id="subtitle"
            value={formData.subtitle}
            onChange={(e) => setFormData({ ...formData, subtitle: e.target.value })}
            placeholder="Digite o subtítulo do banner"
          />
        </div>

        <div>
          <Label htmlFor="image">URL da Imagem</Label>
          <Input
            id="image"
            value={formData.image}
            onChange={(e) => setFormData({ ...formData, image: e.target.value })}
            placeholder="https://exemplo.com/imagem.jpg"
          />
        </div>

        <div className="flex items-center space-x-2">
          <Switch
            id="active"
            checked={formData.active}
            onCheckedChange={(checked) => setFormData({ ...formData, active: checked })}
          />
          <Label htmlFor="active">Banner ativo</Label>
        </div>

        <div className="border rounded-md p-4">
          <Label className="text-sm font-medium">Pré-visualização</Label>
          <div className="mt-2 relative h-32 rounded-md overflow-hidden">
            <img
              src={formData.image}
              alt="Preview"
              className="w-full h-full object-cover"
            />
            <div className="absolute inset-0 bg-gradient-to-r from-black/70 via-black/30 to-transparent" />
            <div className="absolute bottom-2 left-2 text-white">
              <h4 className="font-bold text-sm">{formData.title}</h4>
              <p className="text-xs">{formData.subtitle}</p>
            </div>
          </div>
        </div>
      </div>
    </form>
  );
};
