
import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Upload, Image as ImageIcon } from "lucide-react";
import { useSecureFileUpload } from "@/hooks/useSecureFileUpload";
import { supabase } from "@/integrations/supabase/client";

interface EstablishmentBannerData {
  image: string;
  establishmentName: string;
  rating: number;
  deliveryTime: string;
  address: string;
  whatsappNumber: string;
  instagramUrl: string;
}

interface EstablishmentBannerEditorProps {
  bannerData: EstablishmentBannerData;
  onUpdateBanner: (bannerData: EstablishmentBannerData) => void;
}

export const EstablishmentBannerEditor = ({ 
  bannerData, 
  onUpdateBanner 
}: EstablishmentBannerEditorProps) => {
  const [formData, setFormData] = useState<EstablishmentBannerData>(bannerData);
  const { uploadFile, uploading } = useSecureFileUpload({ 
    bucket: 'establishment-banners',
    folder: 'banners'
  });

  const handleInputChange = (field: keyof EstablishmentBannerData, value: string | number) => {
    const updated = {
      ...formData,
      [field]: value
    };
    setFormData(updated);
    onUpdateBanner(updated);
  };

  const handleImageUpload = async (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;

    try {
      // Get current user
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) {
        console.error('User not authenticated');
        return;
      }

      // Upload file to Supabase Storage
      const result = await uploadFile(file, user.id);
      
      if (result.url) {
        const updated = {
          ...formData,
          image: result.url
        };
        setFormData(updated);
        onUpdateBanner(updated);
      }
    } catch (error) {
      console.error('Error uploading image:', error);
    }
  };



  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <ImageIcon className="w-5 h-5" />
            Banner Principal do Estabelecimento
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-6">
          {/* Preview do Banner */}
          <div className="space-y-2">
            <Label>Preview do Banner</Label>
            <div className="relative h-48 rounded-lg overflow-hidden border">
              <img 
                src={formData.image} 
                alt="Preview do Banner"
                className="w-full h-full object-cover"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-transparent to-transparent" />
              <div className="absolute bottom-4 left-4 text-white">
                <h2 className="text-xl font-bold">{formData.establishmentName}</h2>
                <div className="flex items-center gap-4 text-sm mt-1">
                  <span>⭐ {formData.rating}</span>
                  <span>🕒 {formData.deliveryTime}</span>
                </div>
              </div>
            </div>
          </div>

          {/* Upload de Imagem */}
          <div className="space-y-2">
            <Label htmlFor="banner-upload">Imagem do Banner</Label>
            <div className="flex gap-2">
              <Input
                id="banner-upload"
                type="file"
                accept="image/*"
                onChange={handleImageUpload}
                className="flex-1"
              />
              <Button
                type="button"
                variant="outline"
                onClick={() => document.getElementById('banner-upload')?.click()}
                disabled={uploading}
              >
                <Upload className="w-4 h-4 mr-2" />
                {uploading ? 'Enviando...' : 'Upload'}
              </Button>
            </div>
            <p className="text-sm text-gray-500">
              Recomendamos imagens com resolução 800x400px para melhor qualidade
            </p>
            <Input
              placeholder="Ou cole a URL da imagem aqui..."
              value={formData.image}
              onChange={(e) => handleInputChange('image', e.target.value)}
              className="mt-2"
            />
          </div>

          {/* Informações do Estabelecimento */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="establishment-name">Nome do Estabelecimento</Label>
              <Input
                id="establishment-name"
                value={formData.establishmentName}
                onChange={(e) => handleInputChange('establishmentName', e.target.value)}
                placeholder="Ex: Burger House Premium"
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="rating">Avaliação</Label>
              <Input
                id="rating"
                type="number"
                min="0"
                max="5"
                step="0.1"
                value={formData.rating}
                onChange={(e) => handleInputChange('rating', parseFloat(e.target.value) || 0)}
                placeholder="4.8"
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="delivery-time">Tempo de Entrega</Label>
              <Input
                id="delivery-time"
                value={formData.deliveryTime}
                onChange={(e) => handleInputChange('deliveryTime', e.target.value)}
                placeholder="30-45 min"
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="whatsapp">WhatsApp (com código do país)</Label>
              <Input
                id="whatsapp"
                value={formData.whatsappNumber}
                onChange={(e) => handleInputChange('whatsappNumber', e.target.value)}
                placeholder="5511999999999"
              />
            </div>

            <div className="space-y-2 md:col-span-2">
              <Label htmlFor="address">Endereço</Label>
              <Textarea
                id="address"
                value={formData.address}
                onChange={(e) => handleInputChange('address', e.target.value)}
                placeholder="Rua das Flores, 123 - Centro, São Paulo - SP"
                rows={2}
              />
            </div>

            <div className="space-y-2 p-4 bg-gray-50 rounded-lg border border-gray-200">
              <div className="flex items-center gap-2">
                <div className="w-3 h-3 bg-blue-500 rounded-full"></div>
                <Label className="text-sm font-medium text-gray-700">Configuração do Instagram</Label>
              </div>
              <p className="text-sm text-gray-600">
                A URL do Instagram é configurada em <strong>Configurações → Geral</strong>
              </p>
              <p className="text-xs text-gray-500">
                Isso evita duplicidade e garante que a configuração seja aplicada corretamente em todo o sistema.
              </p>
            </div>
          </div>

        </CardContent>
      </Card>
    </div>
  );
};
