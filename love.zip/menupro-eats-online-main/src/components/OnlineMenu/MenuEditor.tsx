
import { useState, useEffect } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Save, RotateCcw } from "lucide-react";
import { BannerEditor } from "./BannerEditor";
import { CategoryEditor } from "./CategoryEditor";
import { ProductEditor } from "./ProductEditor";
import { EstablishmentBannerEditor } from "./EstablishmentBannerEditor";
import { useToast } from "@/hooks/use-toast";

interface Banner {
  id: string;
  image: string;
  title: string;
  subtitle: string;
  active: boolean;
}

interface EstablishmentBannerData {
  image: string;
  establishmentName: string;
  rating: number;
  deliveryTime: string;
  address: string;
  whatsappNumber: string;
  instagramUrl: string;
}

interface Product {
  id: string;
  name: string;
  description: string;
  price: number;
  image: string;
  category: string;
  isPromotion: boolean;
  promotionPrice?: number;
  customizable?: boolean;
  ingredients?: string[];
  extras?: { name: string; price: number }[];
}

interface MenuEditorProps {
  isOpen: boolean;
  onClose: () => void;
  banners: Banner[];
  onUpdateBanners: (banners: Banner[]) => void;
  categories: { id: string; name: string; sort_order: number }[];
  products: Product[];
  establishmentName: string;
  establishmentBanner?: EstablishmentBannerData;
  onUpdateEstablishmentBanner?: (bannerData: EstablishmentBannerData) => void;
  layoutMode: 'list' | 'grid';
  onLayoutModeChange: (mode: 'list' | 'grid') => void;
  mobileLayoutMode?: 'single' | 'double';
  onMobileLayoutModeChange?: (mode: 'single' | 'double') => void;
}

export const MenuEditor = ({
  isOpen,
  onClose,
  banners,
  onUpdateBanners,
  categories,
  products,
  establishmentName,
  establishmentBanner,
  onUpdateEstablishmentBanner,
  layoutMode,
  onLayoutModeChange,
  mobileLayoutMode = 'single',
  onMobileLayoutModeChange
}: MenuEditorProps) => {
  const { toast } = useToast();
  
  const defaultEstablishmentBanner: EstablishmentBannerData = {
    image: "https://images.unsplash.com/photo-1555396273-367ea4eb4db5?w=800&h=400&fit=crop&crop=center",
    establishmentName: establishmentName || "Burger House Premium",
    rating: 4.8,
    deliveryTime: "30-45 min",
    address: "Rua das Flores, 123 - Centro",
    whatsappNumber: "5511999999999",
    instagramUrl: "https://instagram.com/burgerhouse"
  };

  // Estados locais para cada seção
  const [localBanners, setLocalBanners] = useState<Banner[]>(banners);
  const [localEstablishmentBanner, setLocalEstablishmentBanner] = useState<EstablishmentBannerData>(
    establishmentBanner || defaultEstablishmentBanner
  );
  const [localLayoutMode, setLocalLayoutMode] = useState<'list' | 'grid'>(layoutMode);
  const [localMobileLayoutMode, setLocalMobileLayoutMode] = useState<'single' | 'double'>(mobileLayoutMode);

  // Sincronizar estados locais quando as props mudam
  useEffect(() => {
    setLocalBanners(banners);
  }, [banners]);

  useEffect(() => {
    setLocalEstablishmentBanner(establishmentBanner || defaultEstablishmentBanner);
  }, [establishmentBanner]);

  useEffect(() => {
    setLocalLayoutMode(layoutMode);
  }, [layoutMode]);

  useEffect(() => {
    setLocalMobileLayoutMode(mobileLayoutMode);
  }, [mobileLayoutMode]);

  // Funções de salvamento para cada seção
  const handleSaveBanners = () => {
    onUpdateBanners(localBanners);
    toast({
      title: "Banners salvos!",
      description: "Os banners promocionais foram atualizados com sucesso.",
    });
  };

  const handleSaveEstablishmentBanner = async () => {
    if (onUpdateEstablishmentBanner) {
      try {
        await onUpdateEstablishmentBanner(localEstablishmentBanner);
        // O toast de sucesso será mostrado pela função de salvamento
      } catch (error) {
        // O toast de erro será mostrado pela função de salvamento
        console.error('Error saving establishment banner:', error);
      }
    }
  };

  const handleSaveLayout = () => {
    onLayoutModeChange(localLayoutMode);
    if (onMobileLayoutModeChange) {
      onMobileLayoutModeChange(localMobileLayoutMode);
    }
    toast({
      title: "Layout salvo!",
      description: `Layout alterado para: ${localLayoutMode === 'list' ? 'Lista' : 'Grade'} | Móvel: ${localMobileLayoutMode === 'single' ? '1 por linha' : '2 por linha'}`,
    });
  };

  // Funções de reset para cada seção
  const handleResetBanners = () => {
    setLocalBanners(banners);
    toast({
      title: "Banners restaurados!",
      description: "Os banners foram restaurados para a versão salva.",
    });
  };

  const handleResetEstablishmentBanner = () => {
    setLocalEstablishmentBanner(establishmentBanner || defaultEstablishmentBanner);
    toast({
      title: "Banner restaurado!",
      description: "O banner principal foi restaurado para a versão salva.",
    });
  };

  const handleResetLayout = () => {
    setLocalLayoutMode(layoutMode);
    setLocalMobileLayoutMode(mobileLayoutMode);
    toast({
      title: "Layout restaurado!",
      description: "O layout foi restaurado para a versão salva.",
    });
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>Editor do Cardápio - {establishmentName}</DialogTitle>
        </DialogHeader>

        <Tabs defaultValue="establishment" className="w-full">
          <TabsList className="grid w-full grid-cols-5">
            <TabsTrigger value="establishment">Banner Principal</TabsTrigger>
            <TabsTrigger value="banners">Banners Promocionais</TabsTrigger>
            <TabsTrigger value="layout">Layout</TabsTrigger>
            <TabsTrigger value="categories">Categorias</TabsTrigger>
            <TabsTrigger value="products">Produtos</TabsTrigger>
          </TabsList>

          <TabsContent value="establishment" className="space-y-4">
            <Card>
              <CardHeader>
                <CardTitle>Banner Principal do Estabelecimento</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <EstablishmentBannerEditor 
                  bannerData={localEstablishmentBanner}
                  onUpdateBanner={setLocalEstablishmentBanner}
                />
                <div className="flex gap-2 pt-4 border-t">
                  <Button onClick={handleSaveEstablishmentBanner} className="flex-1">
                    <Save className="w-4 h-4 mr-2" />
                    Salvar Banner Principal
                  </Button>
                  <Button variant="outline" onClick={handleResetEstablishmentBanner}>
                    <RotateCcw className="w-4 h-4 mr-2" />
                    Desfazer
                  </Button>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="banners" className="space-y-4">
            {/* Banners Promocionais - Temporariamente desabilitado até estar 100% funcional */}
            <Card>
              <CardHeader>
                <CardTitle>Banners Promocionais</CardTitle>
                <p className="text-sm text-muted-foreground">Esta funcionalidade está sendo aprimorada e estará disponível em breve.</p>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="text-center py-8 text-muted-foreground">
                  <p>Funcionalidade em desenvolvimento</p>
                  <p className="text-xs mt-2">Em breve você poderá criar banners promocionais personalizados</p>
                </div>
              </CardContent>
            </Card>
            {/* 
            <Card>
              <CardHeader>
                <CardTitle>Banners Promocionais</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <BannerEditor banners={localBanners} onUpdateBanners={setLocalBanners} />
                <div className="flex gap-2 pt-4 border-t">
                  <Button onClick={handleSaveBanners} className="flex-1">
                    <Save className="w-4 h-4 mr-2" />
                    Salvar Banners
                  </Button>
                  <Button variant="outline" onClick={handleResetBanners}>
                    <RotateCcw className="w-4 h-4 mr-2" />
                    Desfazer
                  </Button>
                </div>
              </CardContent>
            </Card>
            */}
          </TabsContent>

          <TabsContent value="layout" className="space-y-4">
            <Card>
              <CardHeader>
                <CardTitle>Configuração de Layout</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <p className="text-gray-600">Escolha como os produtos serão exibidos no cardápio online:</p>
                
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div 
                    className={`border-2 rounded-lg p-4 cursor-pointer transition-all ${
                      localLayoutMode === 'list' ? 'border-orange-500 bg-orange-50' : 'border-gray-200 hover:border-gray-300'
                    }`}
                    onClick={() => setLocalLayoutMode('list')}
                  >
                    <div className="flex items-center gap-3 mb-3">
                      <div className="w-6 h-6 rounded-full border-2 border-orange-500 flex items-center justify-center">
                        {localLayoutMode === 'list' && <div className="w-3 h-3 bg-orange-500 rounded-full" />}
                      </div>
                      <h4 className="font-medium">Lista (1 produto por linha)</h4>
                    </div>
                    <div className="space-y-2">
                      <div className="flex gap-2">
                        <div className="w-16 h-12 bg-gray-200 rounded"></div>
                        <div className="flex-1 space-y-1">
                          <div className="w-full h-2 bg-gray-300 rounded"></div>
                          <div className="w-3/4 h-2 bg-gray-200 rounded"></div>
                        </div>
                      </div>
                      <div className="flex gap-2">
                        <div className="w-16 h-12 bg-gray-200 rounded"></div>
                        <div className="flex-1 space-y-1">
                          <div className="w-full h-2 bg-gray-300 rounded"></div>
                          <div className="w-3/4 h-2 bg-gray-200 rounded"></div>
                        </div>
                      </div>
                    </div>
                    <p className="text-sm text-gray-600 mt-3">Ideal para cardápios com descrições detalhadas</p>
                  </div>

                  <div 
                    className={`border-2 rounded-lg p-4 cursor-pointer transition-all ${
                      localLayoutMode === 'grid' ? 'border-orange-500 bg-orange-50' : 'border-gray-200 hover:border-gray-300'
                    }`}
                    onClick={() => setLocalLayoutMode('grid')}
                  >
                    <div className="flex items-center gap-3 mb-3">
                      <div className="w-6 h-6 rounded-full border-2 border-orange-500 flex items-center justify-center">
                        {localLayoutMode === 'grid' && <div className="w-3 h-3 bg-orange-500 rounded-full" />}
                      </div>
                      <h4 className="font-medium">Grade (2 produtos por linha)</h4>
                    </div>
                    <div className="grid grid-cols-2 gap-2">
                      <div className="space-y-1">
                        <div className="w-full h-8 bg-gray-200 rounded"></div>
                        <div className="w-full h-1 bg-gray-300 rounded"></div>
                        <div className="w-3/4 h-1 bg-gray-200 rounded"></div>
                      </div>
                      <div className="space-y-1">
                        <div className="w-full h-8 bg-gray-200 rounded"></div>
                        <div className="w-full h-1 bg-gray-300 rounded"></div>
                        <div className="w-3/4 h-1 bg-gray-200 rounded"></div>
                      </div>
                    </div>
                    <p className="text-sm text-gray-600 mt-3">Melhor aproveitamento do espaço visual</p>
                  </div>
                </div>

                {/* Configuração de Layout Móvel */}
                <div className="pt-6 border-t">
                  <h4 className="font-medium mb-4 text-gray-900">📱 Layout para Dispositivos Móveis</h4>
                  <p className="text-sm text-gray-600 mb-4">Configure como os produtos serão exibidos em celulares e tablets:</p>
                  
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div 
                      className={`border-2 rounded-lg p-4 cursor-pointer transition-all ${
                        localMobileLayoutMode === 'single' ? 'border-brand-orange bg-orange-50' : 'border-gray-200 hover:border-gray-300'
                      }`}
                      onClick={() => setLocalMobileLayoutMode('single')}
                    >
                      <div className="flex items-center gap-3 mb-3">
                        <div className="w-6 h-6 rounded-full border-2 border-brand-orange flex items-center justify-center">
                          {localMobileLayoutMode === 'single' && <div className="w-3 h-3 bg-brand-orange rounded-full" />}
                        </div>
                        <h5 className="font-medium">1 produto por linha</h5>
                      </div>
                      <div className="space-y-2">
                        <div className="flex gap-2 p-2 bg-white rounded border">
                          <div className="w-12 h-12 bg-gray-200 rounded"></div>
                          <div className="flex-1 space-y-1">
                            <div className="w-full h-2 bg-gray-300 rounded"></div>
                            <div className="w-2/3 h-2 bg-gray-200 rounded"></div>
                            <div className="w-1/3 h-2 bg-brand-orange rounded"></div>
                          </div>
                        </div>
                      </div>
                      <p className="text-xs text-gray-600 mt-2">Formato padrão com descrição completa e upsells detalhados</p>
                    </div>

                    <div 
                      className={`border-2 rounded-lg p-4 cursor-pointer transition-all ${
                        localMobileLayoutMode === 'double' ? 'border-brand-orange bg-orange-50' : 'border-gray-200 hover:border-gray-300'
                      }`}
                      onClick={() => setLocalMobileLayoutMode('double')}
                    >
                      <div className="flex items-center gap-3 mb-3">
                        <div className="w-6 h-6 rounded-full border-2 border-brand-orange flex items-center justify-center">
                          {localMobileLayoutMode === 'double' && <div className="w-3 h-3 bg-brand-orange rounded-full" />}
                        </div>
                        <h5 className="font-medium">2 produtos por linha</h5>
                      </div>
                      <div className="grid grid-cols-2 gap-2">
                        <div className="p-2 bg-white rounded border">
                          <div className="w-full h-8 bg-gray-200 rounded mb-1"></div>
                          <div className="w-full h-1 bg-gray-300 rounded mb-1"></div>
                          <div className="w-2/3 h-1 bg-brand-orange rounded"></div>
                        </div>
                        <div className="p-2 bg-white rounded border">
                          <div className="w-full h-8 bg-gray-200 rounded mb-1"></div>
                          <div className="w-full h-1 bg-gray-300 rounded mb-1"></div>
                          <div className="w-2/3 h-1 bg-brand-orange rounded"></div>
                        </div>
                      </div>
                      <p className="text-xs text-gray-600 mt-2">Estilo compacto "mini vitrine" como Shopify (48% cada card)</p>
                    </div>
                  </div>
                </div>

                <div className="flex gap-2 pt-4 border-t">
                  <Button onClick={handleSaveLayout} className="flex-1">
                    <Save className="w-4 h-4 mr-2" />
                    Salvar Layout
                  </Button>
                  <Button variant="outline" onClick={handleResetLayout}>
                    <RotateCcw className="w-4 h-4 mr-2" />
                    Desfazer
                  </Button>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="categories" className="space-y-4">
            <CategoryEditor categories={categories} />
          </TabsContent>

          <TabsContent value="products" className="space-y-4">
            <ProductEditor products={products} categories={categories.map(c => c.name)} />
          </TabsContent>
        </Tabs>
      </DialogContent>
    </Dialog>
  );
};
