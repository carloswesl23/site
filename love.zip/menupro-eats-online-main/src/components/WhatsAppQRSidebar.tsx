import { useState, useEffect } from 'react';
import { QrCode, MessageSquare, Wifi, WifiOff, RefreshCw } from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { useWhatsAppInstances } from '@/hooks/useWhatsAppInstances';
import { Separator } from '@/components/ui/separator';

export function WhatsAppQRSidebar() {
  const { instances, loading, updateInstanceStatus, generateQrCode, generatingQr, qrAttempts } = useWhatsAppInstances();
  const [collapsed, setCollapsed] = useState(false);

  // Auto-refresh das instâncias a cada 30 segundos
  useEffect(() => {
    if (instances.length === 0) return;
    
    const interval = setInterval(() => {
      instances.forEach(instance => {
        if (instance.status === 'disconnected' || instance.status === 'initializing') {
          updateInstanceStatus(instance.instance_id, instance.token_instance);
        }
      });
    }, 30000);

    return () => clearInterval(interval);
  }, [instances, updateInstanceStatus]);

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'connected':
        return 'bg-success text-success-foreground';
      case 'qrcode':
        return 'bg-blue-500 text-white';
      case 'waiting_phone':
        return 'bg-yellow-500 text-white';
      case 'initializing':
        return 'bg-orange-500 text-white';
      case 'disconnected':
        return 'bg-destructive text-destructive-foreground';
      default:
        return 'bg-muted text-muted-foreground';
    }
  };

  const getStatusText = (status: string) => {
    switch (status) {
      case 'connected':
        return 'Conectado';
      case 'qrcode':
        return 'QR Code';
      case 'waiting_phone':
        return 'Aguardando';
      case 'initializing':
        return 'Inicializando';
      case 'disconnected':
        return 'Desconectado';
      default:
        return 'Aguardando';
    }
  };

  if (loading || instances.length === 0) {
    return null;
  }

  const instance = instances[0]; // Primeira instância

  return (
    <div className={`bg-white border-l border-gray-200 transition-all duration-300 ${collapsed ? 'w-16' : 'w-80'} flex flex-col`}>
      {/* Header */}
      <div className="p-4 border-b border-gray-200">
        <div className="flex items-center justify-between">
          {!collapsed && (
            <div className="flex items-center gap-2">
              <MessageSquare className="h-5 w-5 text-primary" />
              <h3 className="font-semibold text-sm">WhatsApp</h3>
            </div>
          )}
          <Button
            variant="ghost"
            size="sm"
            onClick={() => setCollapsed(!collapsed)}
            className="h-8 w-8 p-0"
          >
            {collapsed ? <MessageSquare className="h-4 w-4" /> : <RefreshCw className="h-4 w-4" />}
          </Button>
        </div>
      </div>

      {/* Content */}
      <div className="flex-1 overflow-auto">
        {collapsed ? (
          // Modo collapsed - apenas ícone de status
          <div className="p-2 flex flex-col items-center">
            <div className="relative">
              {instance.status === 'connected' ? (
                <Wifi className="h-6 w-6 text-success" />
              ) : (
                <WifiOff className="h-6 w-6 text-destructive" />
              )}
              <div className={`absolute -top-1 -right-1 w-3 h-3 rounded-full ${
                instance.status === 'connected' ? 'bg-success' : 'bg-destructive'
              }`}></div>
            </div>
          </div>
        ) : (
          // Modo expandido - card completo
          <div className="p-4">
            <Card>
              <CardHeader className="pb-3">
                <div className="flex items-center justify-between">
                  <CardTitle className="text-sm font-medium truncate">
                    {instance.instance_name}
                  </CardTitle>
                  <Badge className={`text-xs ${getStatusColor(instance.status)}`}>
                    {getStatusText(instance.status)}
                  </Badge>
                </div>
              </CardHeader>

              <CardContent className="pt-0 space-y-4">
                {/* Status conectado */}
                {instance.status === 'connected' && instance.numero_cliente && (
                  <div className="bg-success/10 border border-success/20 rounded-lg p-3">
                    <div className="flex items-center gap-2 text-success mb-1">
                      <Wifi className="h-4 w-4" />
                      <span className="text-xs font-medium">Conectado</span>
                    </div>
                    <p className="text-xs text-muted-foreground">
                      {instance.numero_cliente}
                    </p>
                  </div>
                )}

                {/* QR Code disponível */}
                {instance.qr_code && instance.status !== 'connected' && (
                  <div className="space-y-3">
                    <div className="text-center">
                      <div className="flex items-center justify-center gap-2 text-blue-600 mb-2">
                        <QrCode className="h-4 w-4" />
                        <span className="text-xs font-medium">QR Code</span>
                        {qrAttempts[instance.instance_id] && (
                          <span className="text-xs text-orange-500">
                            ({qrAttempts[instance.instance_id]}/3 tentativas)
                          </span>
                        )}
                      </div>
                      <div className="bg-white border rounded-lg p-2">
                        <img 
                          src={instance.qr_code} 
                          alt="QR Code WhatsApp" 
                          className="w-32 h-32 mx-auto"
                        />
                      </div>
                      <p className="text-xs text-muted-foreground mt-2">
                        Escaneie com seu WhatsApp
                      </p>
                      <p className="text-xs text-orange-500 mt-1">
                        Código renovado automaticamente a cada 15s
                      </p>
                    </div>
                  </div>
                )}

                {/* Status desconectado sem QR */}
                {instance.status === 'disconnected' && !instance.qr_code && (
                  <div className="text-center space-y-3">
                    <div className="bg-orange-50 border border-orange-200 rounded-lg p-3">
                      <WifiOff className="h-8 w-8 mx-auto text-orange-500 mb-2" />
                      <p className="text-xs text-orange-700 mb-3">
                        WhatsApp desconectado
                      </p>
                      {qrAttempts[instance.instance_id] >= 3 ? (
                        <div className="space-y-2">
                          <p className="text-xs text-red-600 mb-2">
                            QR Code expirou após 3 tentativas
                          </p>
                          <Button
                            size="sm"
                            onClick={() => generateQrCode(instance.instance_id)}
                            disabled={generatingQr}
                            className="w-full gap-2"
                          >
                            <QrCode className={`h-3 w-3 ${generatingQr ? 'animate-spin' : ''}`} />
                            Tentar Novamente
                          </Button>
                        </div>
                      ) : (
                        <Button
                          size="sm"
                          onClick={() => generateQrCode(instance.instance_id)}
                          disabled={generatingQr}
                          className="w-full gap-2"
                        >
                          <QrCode className={`h-3 w-3 ${generatingQr ? 'animate-spin' : ''}`} />
                          Gerar QR
                        </Button>
                      )}
                    </div>
                  </div>
                )}

                <Separator />

                {/* Informações da instância - sem opção de número */}
                <div className="space-y-3 text-xs">
                  <div className="flex justify-between">
                    <span className="text-muted-foreground">ID:</span>
                    <span className="font-mono truncate ml-2">{instance.instance_id.slice(-8)}</span>
                  </div>

                  <div className="flex justify-between">
                    <span className="text-muted-foreground">Atualizado:</span>
                    <span className="ml-2">
                      {new Date(instance.updated_at).toLocaleTimeString('pt-BR', {
                        hour: '2-digit',
                        minute: '2-digit'
                      })}
                    </span>
                  </div>
                </div>

                {/* Botão de atualizar status */}
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => updateInstanceStatus(instance.instance_id, instance.token_instance)}
                  className="w-full gap-2"
                >
                  <RefreshCw className="h-3 w-3" />
                  Atualizar Status
                </Button>
              </CardContent>
            </Card>
          </div>
        )}
      </div>
    </div>
  );
}