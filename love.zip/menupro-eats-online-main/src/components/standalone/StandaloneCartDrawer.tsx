import { Button } from "@/components/ui/button";
import { Sheet, SheetContent, SheetHeader, SheetTitle } from "@/components/ui/sheet";
import { Plus, Minus, ShoppingCart, Trash2 } from "lucide-react";
import { Separator } from "@/components/ui/separator";

interface CartItem {
  id: string;
  product: any;
  quantity: number;
  customizations?: any;
  totalPrice: number;
}

interface StandaloneCartDrawerProps {
  isOpen: boolean;
  onClose: () => void;
  cart: CartItem[];
  onUpdateItem: (itemId: string, quantity: number) => void;
  onCheckout: () => void;
  total: number;
}

export const StandaloneCartDrawer = ({ 
  isOpen, 
  onClose, 
  cart, 
  onUpdateItem, 
  onCheckout, 
  total 
}: StandaloneCartDrawerProps) => {
  if (cart.length === 0) {
    return (
      <Sheet open={isOpen} onOpenChange={onClose}>
        <SheetContent side="right" className="w-full sm:w-96">
          <SheetHeader>
            <SheetTitle className="flex items-center gap-2">
              <ShoppingCart className="w-5 h-5" />
              Sua Sacola
            </SheetTitle>
          </SheetHeader>
          
          <div className="flex flex-col items-center justify-center h-64 text-gray-500">
            <ShoppingCart className="w-16 h-16 mb-4" />
            <p className="text-lg font-medium">Sua sacola está vazia</p>
            <p className="text-sm">Adicione alguns produtos deliciosos!</p>
          </div>
        </SheetContent>
      </Sheet>
    );
  }

  return (
    <Sheet open={isOpen} onOpenChange={onClose}>
      <SheetContent side="right" className="w-full sm:w-96 flex flex-col">
        <SheetHeader>
          <SheetTitle className="flex items-center gap-2">
            <ShoppingCart className="w-5 h-5" />
            Sua Sacola ({cart.length} {cart.length === 1 ? 'item' : 'itens'})
          </SheetTitle>
        </SheetHeader>

        <div className="flex-1 overflow-y-auto space-y-4 py-4">
          {cart.map((item) => (
            <div key={item.id} className="border rounded-lg p-4">
              <div className="flex gap-3">
                <img
                  src={item.product.image}
                  alt={item.product.name}
                  className="w-16 h-16 object-cover rounded"
                />
                
                <div className="flex-1">
                  <h4 className="font-medium text-sm">{item.product.name}</h4>
                  
                  {/* Customizações */}
                  {item.customizations && (
                    <div className="text-xs text-gray-600 mt-1">
                      {item.customizations.extras && item.customizations.extras.length > 0 && (
                        <p>Extras: {item.customizations.extras.map((e: any) => e.name).join(', ')}</p>
                      )}
                      {item.customizations.flavors && item.customizations.flavors.length > 0 && (
                        <p>Sabores: {item.customizations.flavors.map((f: any) => f.name).join(', ')}</p>
                      )}
                      {item.customizations.notes && (
                        <p>Obs: {item.customizations.notes}</p>
                      )}
                    </div>
                  )}
                  
                  <div className="flex items-center justify-between mt-2">
                    <span className="font-bold text-orange-600">
                      R$ {item.totalPrice.toFixed(2)}
                    </span>
                    
                    <div className="flex items-center gap-2">
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => onUpdateItem(item.id, Math.max(0, item.quantity - 1))}
                        className="h-8 w-8 p-0"
                      >
                        {item.quantity === 1 ? <Trash2 className="w-3 h-3" /> : <Minus className="w-3 h-3" />}
                      </Button>
                      
                      <span className="w-8 text-center text-sm font-medium">
                        {item.quantity}
                      </span>
                      
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => onUpdateItem(item.id, item.quantity + 1)}
                        className="h-8 w-8 p-0"
                      >
                        <Plus className="w-3 h-3" />
                      </Button>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>

        <div className="border-t pt-4 space-y-4">
          <div className="flex justify-between items-center">
            <span className="text-lg font-bold">Total:</span>
            <span className="text-xl font-bold text-orange-600">
              R$ {total.toFixed(2)}
            </span>
          </div>
          
          <Button 
            onClick={onCheckout}
            className="w-full bg-orange-500 hover:bg-orange-600 text-white h-12"
            size="lg"
          >
            Finalizar Pedido
          </Button>
        </div>
      </SheetContent>
    </Sheet>
  );
};