import { useState } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { useWhatsAppMessages } from "@/hooks/useWhatsAppMessages";
import { Button } from "@/components/ui/button";
import { ShoppingCart, CheckCircle } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { useSecureInput } from "@/hooks/useSecureInput";
import { createRateLimiter, getGenericErrorMessage } from "@/utils/security";
import { CustomerDataForm } from "./checkout/CustomerDataForm";
import { AddressForm } from "./checkout/AddressForm";
import { PaymentMethodSelector } from "./checkout/PaymentMethodSelector";
import { OrderSummary } from "./checkout/OrderSummary";
import { NotesSection } from "./checkout/NotesSection";
import { PixPaymentSection } from "./checkout/PixPaymentSection";
import { CouponSection } from "./checkout/CouponSection";
import { supabase } from "@/integrations/supabase/client";

interface CartItem {
  id: string;
  product: any;
  quantity: number;
  customizations?: any;
  totalPrice: number;
}

interface StandaloneCheckoutModalProps {
  isOpen: boolean;
  onClose: () => void;
  cart: CartItem[];
  total: number;
  establishmentName: string;
  establishmentPhone?: string;
  establishmentId: string;
  establishmentData?: {
    pix_key: string | null;
    pix_beneficiary_name: string | null;
    pix_enabled: boolean | null;
  };
}

export const StandaloneCheckoutModal = ({
  isOpen,
  onClose,
  cart,
  total,
  establishmentName,
  establishmentPhone,
  establishmentId,
  establishmentData
}: StandaloneCheckoutModalProps) => {
  const { toast } = useToast();
  const { sendOrderNotification } = useWhatsAppMessages();
  const [paymentMethod, setPaymentMethod] = useState("pix");
  const [step, setStep] = useState<'form' | 'payment' | 'success'>('form');
  const [orderNumber, setOrderNumber] = useState('');
  const [appliedCoupon, setAppliedCoupon] = useState<any>(null);
  const [discount, setDiscount] = useState(0);
  
  // Rate limiter for form submissions (max 3 submissions per minute)
  const submitRateLimiter = createRateLimiter(3, 60000);
  
  const { fields, updateField, validateAllFields, getFieldProps, hasErrors } = useSecureInput({
    name: "",
    phone: "",
    email: "",
    address: "",
    neighborhood: "",
    notes: ""
  });

  const handleInputChange = (field: string, value: string) => {
    const validationRules = {
      name: { required: true, type: 'name' as const },
      phone: { required: true, type: 'phone' as const },
      email: { required: false, type: 'email' as const }, // Email opcional
      address: { required: true, type: 'address' as const },
      neighborhood: { type: 'text' as const, maxLength: 100 },
      notes: { type: 'text' as const, maxLength: 500 }
    };
    
    updateField(field, value, validationRules[field as keyof typeof validationRules]);
  };

  const handleFinishOrder = async () => {
    // Rate limiting check
    const clientIP = 'client-' + Date.now();
    if (!submitRateLimiter(clientIP)) {
      toast({
        title: "Muitas tentativas",
        description: "Aguarde um momento antes de tentar novamente.",
        variant: "destructive"
      });
      return;
    }

    // Validate all fields
    const validationRules = {
      name: { required: true, type: 'name' as const },
      phone: { required: true, type: 'phone' as const },
      email: { required: false, type: 'email' as const }, // Email opcional
      address: { required: true, type: 'address' as const },
      neighborhood: { type: 'text' as const, maxLength: 100 },
      notes: { type: 'text' as const, maxLength: 500 }
    };

    if (!validateAllFields(validationRules)) {
      toast({
        title: "Dados inválidos",
        description: "Por favor, corrija os erros nos campos destacados.",
        variant: "destructive"
      });
      return;
    }

    try {
      const nameField = getFieldProps('name');
      const phoneField = getFieldProps('phone');
      const emailField = getFieldProps('email');
      const addressField = getFieldProps('address');
      const neighborhoodField = getFieldProps('neighborhood');
      const notesField = getFieldProps('notes');

      // Gerar número do pedido
      const orderNum = `PD${Date.now().toString().slice(-6)}`;
      setOrderNumber(orderNum);

      // Calcular total final com desconto
      const finalTotal = total - discount;

      // Preparar dados do pedido
      const orderData = {
        order_number: orderNum,
        user_id: establishmentId,
        customer_name: nameField.value,
        customer_phone: phoneField.value,
        customer_email: emailField.value || null,
        delivery_address: `${addressField.value}${neighborhoodField.value ? `, ${neighborhoodField.value}` : ''}`,
        payment_method: paymentMethod,
        total: finalTotal,
        items: cart.map(item => ({
          id: item.id,
          product_name: item.product.name,
          quantity: item.quantity,
          price: item.totalPrice,
          customizations: item.customizations
        })),
        notes: notesField.value || null,
        status: 'aguardando_pagamento'
      };

      // Salvar pedido no banco
      const { data, error } = await supabase
        .from('user_orders')
        .insert(orderData)
        .select();

      if (error) {
        throw error;
      }

      // Registrar uso do cupom se aplicado
      if (appliedCoupon && data?.[0]) {
        await supabase
          .from('coupon_usage')
          .insert({
            coupon_id: appliedCoupon.id,
            order_id: data[0].id,
            user_id: establishmentId,
            customer_name: nameField.value,
            customer_phone: phoneField.value,
            discount_applied: discount,
            order_total: finalTotal + discount
          });
      }

      toast({
        title: "Pedido realizado!",
        description: `Pedido #${orderNum} foi registrado com sucesso.`,
      });

      // Enviar mensagem automática via WhatsApp
      try {
        await sendOrderNotification(
          establishmentId,
          orderNum,
          {
            name: nameField.value,
            phone: phoneField.value,
            email: emailField.value,
            address: addressField.value ? {
              street: addressField.value,
              number: '',
              neighborhood: neighborhoodField.value || '',
              city: '',
              zipCode: ''
            } : undefined
          },
          cart,
          paymentMethod,
          finalTotal,
          establishmentName
        );
      } catch (error) {
        // WhatsApp error não deve quebrar o fluxo
        console.error('Erro ao enviar WhatsApp:', error);
      }

      if (paymentMethod === 'pix') {
        setStep('payment');
      } else {
        setStep('success');
      }
      
    } catch (error) {
      console.error('Error creating order:', error);
      toast({
        title: "Erro ao finalizar pedido",
        description: getGenericErrorMessage('network'),
        variant: "destructive"
      });
    }
  };

  const handleModalClose = () => {
    setStep('form');
    setOrderNumber('');
    setAppliedCoupon(null);
    setDiscount(0);
    onClose();
  };

  const handleCouponApplied = (coupon: any, discountAmount: number) => {
    setAppliedCoupon(coupon);
    setDiscount(discountAmount);
  };

  const handleCouponRemoved = () => {
    setAppliedCoupon(null);
    setDiscount(0);
  };

  const nameField = getFieldProps('name');
  const phoneField = getFieldProps('phone');
  const emailField = getFieldProps('email');
  const addressField = getFieldProps('address');
  const neighborhoodField = getFieldProps('neighborhood');
  const notesField = getFieldProps('notes');

  const isFormValid = !hasErrors && nameField.value && phoneField.value && addressField.value;

  return (
    <Dialog open={isOpen} onOpenChange={handleModalClose}>
      <DialogContent className="max-w-md max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <ShoppingCart className="w-5 h-5" />
            {step === 'form' ? 'Finalizar Pedido' : 
             step === 'payment' ? 'Pagamento PIX' : 
             'Pedido Realizado'}
          </DialogTitle>
        </DialogHeader>

        {step === 'form' && (
          <div className="space-y-6">
            <OrderSummary 
              cart={cart} 
              total={total} 
              discount={discount}
              appliedCoupon={appliedCoupon}
            />
            
            <CustomerDataForm 
              nameField={nameField}
              phoneField={phoneField}
              emailField={emailField}
              onInputChange={handleInputChange}
            />
            
            <AddressForm 
              addressField={addressField}
              neighborhoodField={neighborhoodField}
              onInputChange={handleInputChange}
            />
            
            <PaymentMethodSelector 
              paymentMethod={paymentMethod}
              onPaymentMethodChange={setPaymentMethod}
            />

            {isFormValid && (
              <CouponSection
                establishmentId={establishmentId}
                subtotal={total}
                appliedCoupon={appliedCoupon}
                onCouponApplied={handleCouponApplied}
                onCouponRemoved={handleCouponRemoved}
                cart={cart}
              />
            )}
            
            <NotesSection 
              notesField={notesField}
              onInputChange={handleInputChange}
            />

            <Button
              onClick={handleFinishOrder}
              disabled={!isFormValid}
              className="w-full bg-primary hover:bg-primary/90 text-primary-foreground h-12"
              size="lg"
            >
              <CheckCircle className="w-4 h-4 mr-2" />
              Finalizar Pedido - R$ {(total - discount).toFixed(2)}
            </Button>
          </div>
        )}

        {step === 'payment' && (
          <div className="space-y-6">
            <div className="text-center">
              <CheckCircle className="w-12 h-12 text-green-600 mx-auto mb-2" />
              <h3 className="text-lg font-semibold">Pedido #{orderNumber}</h3>
              <p className="text-sm text-muted-foreground">Confirmado com sucesso!</p>
            </div>
            
            <PixPaymentSection 
              total={total - discount} 
              pixKey={establishmentData?.pix_key || establishmentPhone || ""} 
              beneficiaryName={establishmentData?.pix_beneficiary_name || establishmentName}
              orderNumber={orderNumber}
            />
            
            <Button
              onClick={() => setStep('success')}
              variant="outline"
              className="w-full"
            >
              Finalizar
            </Button>
          </div>
        )}

        {step === 'success' && (
          <div className="space-y-6 text-center">
            <CheckCircle className="w-16 h-16 text-green-600 mx-auto" />
            
            <div>
              <h3 className="text-xl font-semibold mb-2">Pedido Confirmado!</h3>
              <p className="text-lg font-medium">#{orderNumber}</p>
            </div>
            
            <div className="bg-muted/50 rounded-lg p-4">
              <p className="text-sm text-muted-foreground mb-2">
                Seu pedido foi recebido e está sendo preparado.
              </p>
              <p className="text-sm font-medium">
                Total: R$ {(total - discount).toFixed(2)}
              </p>
              {discount > 0 && (
                <p className="text-sm text-green-600">
                  Desconto aplicado: R$ {discount.toFixed(2)}
                </p>
              )}
              <p className="text-sm text-muted-foreground">
                Forma de pagamento: {paymentMethod === 'pix' ? 'PIX' : paymentMethod}
              </p>
            </div>
            
            <Button
              onClick={handleModalClose}
              className="w-full bg-primary hover:bg-primary/90"
            >
              Fechar
            </Button>
          </div>
        )}
      </DialogContent>
    </Dialog>
  );
};