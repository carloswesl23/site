import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { User } from "lucide-react";

interface CustomerDataFormProps {
  nameField: { value: string; error: string | null };
  phoneField: { value: string; error: string | null };
  emailField: { value: string; error: string | null };
  onInputChange: (field: string, value: string) => void;
}

export const CustomerDataForm = ({ 
  nameField, 
  phoneField, 
  emailField, 
  onInputChange 
}: CustomerDataFormProps) => {
  return (
    <div className="space-y-4">
      <div className="flex items-center gap-2 mb-3">
        <User className="w-4 h-4" />
        <h3 className="font-medium text-sm">Seus Dados</h3>
      </div>

      <div className="space-y-3">
        <div>
          <Label htmlFor="name" className="text-xs">Nome Completo *</Label>
          <Input
            id="name"
            value={nameField.value}
            onChange={(e) => onInputChange('name', e.target.value)}
            placeholder="Seu nome completo"
            className={`mt-1 ${nameField.error ? 'border-red-500' : ''}`}
            maxLength={100}
          />
          {nameField.error && (
            <p className="text-red-500 text-xs mt-1">{nameField.error}</p>
          )}
        </div>

        <div>
          <Label htmlFor="phone" className="text-xs">Telefone/WhatsApp *</Label>
          <Input
            id="phone"
            type="tel"
            value={phoneField.value}
            onChange={(e) => onInputChange('phone', e.target.value)}
            placeholder="(11) 99999-9999"
            className={`mt-1 ${phoneField.error ? 'border-red-500' : ''}`}
            maxLength={20}
          />
          {phoneField.error && (
            <p className="text-red-500 text-xs mt-1">{phoneField.error}</p>
          )}
        </div>

        <div>
          <Label htmlFor="email" className="text-xs">E-mail</Label>
          <Input
            id="email"
            type="email"
            value={emailField.value}
            onChange={(e) => onInputChange('email', e.target.value)}
            placeholder="seu@email.com"
            className={`mt-1 ${emailField.error ? 'border-red-500' : ''}`}
            maxLength={254}
          />
          {emailField.error && (
            <p className="text-red-500 text-xs mt-1">{emailField.error}</p>
          )}
        </div>
      </div>
    </div>
  );
};