import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Label } from "@/components/ui/label";
import { CreditCard } from "lucide-react";

interface PaymentMethodSelectorProps {
  paymentMethod: string;
  onPaymentMethodChange: (value: string) => void;
}

export const PaymentMethodSelector = ({ 
  paymentMethod, 
  onPaymentMethodChange 
}: PaymentMethodSelectorProps) => {
  return (
    <div className="space-y-4">
      <div className="flex items-center gap-2 mb-3">
        <CreditCard className="w-4 h-4" />
        <h3 className="font-medium text-sm">Forma de Pagamento</h3>
      </div>

      <Select value={paymentMethod} onValueChange={onPaymentMethodChange}>
        <SelectTrigger>
          <SelectValue />
        </SelectTrigger>
        <SelectContent>
          <SelectItem value="pix">PIX</SelectItem>
          <SelectItem value="money">Dinheiro</SelectItem>
          <SelectItem value="card">Cartão (na entrega)</SelectItem>
        </SelectContent>
      </Select>
    </div>
  );
};