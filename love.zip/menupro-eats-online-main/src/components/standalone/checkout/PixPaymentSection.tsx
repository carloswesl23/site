import React, { useState } from "react";
import { QRCodeSVG } from "qrcode.react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Copy, Check } from "lucide-react";
import { useToast } from "@/hooks/use-toast";

interface PixPaymentSectionProps {
  total: number;
  pixKey?: string;
  beneficiaryName?: string;
  orderNumber?: string;
}

export const PixPaymentSection = ({ total, pixKey = "exemplo@pix.com", beneficiaryName, orderNumber }: PixPaymentSectionProps) => {
  const [copied, setCopied] = useState(false);
  const { toast } = useToast();

  // Gerar payload PIX completo conforme padrão BACEN
  const merchantName = (beneficiaryName || "ESTABELECIMENTO").substring(0, 25).toUpperCase();
  const merchantCity = "SAO PAULO";
  const txid = orderNumber || "***";
  
  // Formato EMV do PIX
  const generatePixPayload = () => {
    // Merchant Category Code (0000 = não especificado)
    const mcc = "0000";
    // Currency Code (986 = BRL)
    const currency = "986";
    // Transaction Amount
    const amount = total.toFixed(2);
    // Country Code
    const countryCode = "BR";
    
    // Chave PIX (campo 26 - Merchant Account Information)
    const pixKeyField = `0014br.gov.bcb.pix01${String(pixKey.length).padStart(2, '0')}${pixKey}`;
    const pixKeyWithLength = `26${String(pixKeyField.length).padStart(2, '0')}${pixKeyField}`;
    
    // TXID (campo 62 - Additional Data)
    const txidField = `05${String(txid.length).padStart(2, '0')}${txid}`;
    const additionalData = `62${String(txidField.length).padStart(2, '0')}${txidField}`;
    
    // Construir payload
    let payload = "";
    payload += "000201"; // Payload Format Indicator
    payload += "010212"; // Point of Initiation Method (12 = static QR)
    payload += pixKeyWithLength; // Merchant Account Information
    payload += `52${String(mcc.length).padStart(2, '0')}${mcc}`; // Merchant Category Code
    payload += "5303986"; // Transaction Currency (986 = BRL)  
    payload += `54${String(amount.length).padStart(2, '0')}${amount}`; // Transaction Amount
    payload += "5802BR"; // Country Code
    payload += `59${String(merchantName.length).padStart(2, '0')}${merchantName}`; // Merchant Name
    payload += `60${String(merchantCity.length).padStart(2, '0')}${merchantCity}`; // Merchant City
    payload += additionalData; // Additional Data Field Template
    payload += "6304"; // CRC placeholder
    
    // Calcular CRC16 e adicionar ao final
    const crc = generateCRC16(payload);
    payload += crc;
    
    return payload;
  };

  const pixPayload = generatePixPayload();

  function generateCRC16(payload: string): string {
    // Implementação simplificada do CRC16 para PIX
    let crc = 0xFFFF;
    
    for (let i = 0; i < payload.length; i++) {
      crc ^= payload.charCodeAt(i) << 8;
      
      for (let j = 0; j < 8; j++) {
        if ((crc & 0x8000) !== 0) {
          crc = (crc << 1) ^ 0x1021;
        } else {
          crc <<= 1;
        }
      }
    }
    
    return (crc & 0xFFFF).toString(16).toUpperCase().padStart(4, '0');
  }

  const copyPixPayload = async () => {
    try {
      await navigator.clipboard.writeText(pixPayload);
      setCopied(true);
      toast({
        title: "PIX Copia e Cola copiado!",
        description: `Código PIX completo copiado com valor R$ ${total.toFixed(2)}`,
      });
      
      setTimeout(() => setCopied(false), 2000);
    } catch (error) {
      toast({
        title: "Erro ao copiar",
        description: "Não foi possível copiar o código PIX.",
        variant: "destructive"
      });
    }
  };

  return (
    <div className="space-y-6">
      <div className="text-center">
        <h3 className="text-lg font-semibold mb-2">Pagamento via PIX</h3>
        <p className="text-sm text-muted-foreground">
          Escaneie o QR Code ou copie a chave PIX abaixo
        </p>
      </div>

      {/* QR Code */}
      <Card>
        <CardContent className="p-6 flex flex-col items-center">
          <div className="bg-white p-4 rounded-lg mb-4">
            <QRCodeSVG
              value={pixPayload}
              size={200}
              bgColor="#ffffff"
              fgColor="#000000"
              level="M"
              includeMargin={true}
            />
          </div>
          
          <div className="text-center">
            <p className="text-sm text-muted-foreground mb-2">
              Valor: <span className="font-semibold text-foreground">R$ {total.toFixed(2)}</span>
            </p>
          </div>
        </CardContent>
      </Card>

      {/* Chave PIX */}
      <Card>
        <CardContent className="p-4">
          <div className="space-y-3">
            <h4 className="font-medium">PIX Copia e Cola</h4>
            
            <div className="flex items-center gap-2">
              <div className="flex-1 bg-muted rounded-md px-3 py-2 text-xs font-mono break-all">
                {pixPayload}
              </div>
              
              <Button
                onClick={copyPixPayload}
                variant="outline"
                size="sm"
                className="shrink-0"
              >
                {copied ? (
                  <Check className="w-4 h-4 text-green-600" />
                ) : (
                  <Copy className="w-4 h-4" />
                )}
              </Button>
            </div>
            
            <p className="text-xs text-muted-foreground">
              Código PIX completo com valor R$ {total.toFixed(2)} e dados do pedido
            </p>
          </div>
        </CardContent>
      </Card>

      <div className="bg-muted/50 rounded-lg p-4">
        <h4 className="font-medium mb-2">Instruções:</h4>
        <ol className="text-sm text-muted-foreground space-y-1">
          <li>1. Escaneie o QR Code com seu app do banco</li>
          <li>2. Ou copie o código PIX Copia e Cola</li>
          <li>3. O valor R$ {total.toFixed(2)} já está incluso</li>
          <li>4. Finalize o pagamento</li>
        </ol>
      </div>
    </div>
  );
};