import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";

interface NotesSectionProps {
  notesField: { value: string; error: string | null };
  onInputChange: (field: string, value: string) => void;
}

export const NotesSection = ({ notesField, onInputChange }: NotesSectionProps) => {
  return (
    <div>
      <Label htmlFor="notes" className="text-xs">Observações</Label>
      <Textarea
        id="notes"
        value={notesField.value}
        onChange={(e) => onInputChange('notes', e.target.value)}
        placeholder="Alguma observação sobre o pedido ou entrega..."
        className={`mt-1 ${notesField.error ? 'border-red-500' : ''}`}
        rows={3}
        maxLength={500}
      />
      {notesField.error && (
        <p className="text-red-500 text-xs mt-1">{notesField.error}</p>
      )}
    </div>
  );
};