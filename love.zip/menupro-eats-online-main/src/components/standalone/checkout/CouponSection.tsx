import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Percent, Tag, X } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { useToast } from "@/hooks/use-toast";

interface CouponSectionProps {
  establishmentId: string;
  subtotal: number;
  appliedCoupon: any | null;
  onCouponApplied: (coupon: any, discount: number) => void;
  onCouponRemoved: () => void;
  cart: any[];
  isFormValid?: boolean;
}

export const CouponSection = ({
  establishmentId,
  subtotal,
  appliedCoupon,
  onCouponApplied,
  onCouponRemoved,
  cart,
  isFormValid = false
}: CouponSectionProps) => {
  const [couponCode, setCouponCode] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const [autoApplyChecked, setAutoApplyChecked] = useState(false);
  const { toast } = useToast();

  // Função para verificar e aplicar cupons automáticos
  const checkAndApplyAutoCoupons = async () => {
    console.log('🔍 Verificando cupons automáticos...', {
      isFormValid,
      appliedCoupon: !!appliedCoupon,
      autoApplyChecked,
      establishmentId
    });

    if (!isFormValid || appliedCoupon || autoApplyChecked) {
      console.log('❌ Condições não atendidas para aplicar cupom automático');
      return;
    }

    try {
      console.log('🔍 Buscando cupons automáticos no banco...');
      const now = new Date().toISOString();
      
      const { data: autoCoupons, error } = await supabase
        .from('discount_coupons')
        .select('*')
        .eq('user_id', establishmentId)
        .eq('is_active', true)
        .eq('auto_apply', true)
        .lte('valid_from', now)
        .or('valid_until.is.null,valid_until.gte.now()');

      console.log('📊 Resultado da busca:', { autoCoupons, error });

      if (error || !autoCoupons?.length) {
        console.log('❌ Nenhum cupom automático encontrado');
        setAutoApplyChecked(true);
        return;
      }

      // Encontrar o primeiro cupom aplicável
      for (const coupon of autoCoupons) {
        // Verificar limite de uso
        if (coupon.max_uses && coupon.current_uses >= coupon.max_uses) {
          continue;
        }

        console.log('🔍 Verificando cupom:', {
          code: coupon.code,
          name: coupon.name,
          auto_apply: coupon.auto_apply,
          valid_from: coupon.valid_from,
          valid_until: coupon.valid_until,
          current_time: now,
          applies_to_type: coupon.applies_to_type,
          applies_to_categories: coupon.applies_to_categories,
          applies_to_products: coupon.applies_to_products,
          cart: cart.map(item => ({ name: item.product.name, category: item.product.category, id: item.product.id }))
        });

        // Verificar novamente se o cupom está dentro do período válido (verificação dupla)
        const validFromDate = new Date(coupon.valid_from);
        const validUntilDate = coupon.valid_until ? new Date(coupon.valid_until) : null;
        const currentDate = new Date(now);
        
        if (currentDate < validFromDate) {
          console.log('⚠️ Cupom ainda não começou:', {
            valid_from: coupon.valid_from,
            current: now
          });
          continue;
        }
        
        if (validUntilDate && currentDate > validUntilDate) {
          console.log('⚠️ Cupom já expirou:', {
            valid_until: coupon.valid_until,
            current: now
          });
          continue;
        }

        // Verificar se se aplica aos produtos
        let isApplicable = true;
        
        if (coupon.applies_to_type === 'categories' && coupon.applies_to_categories?.length > 0) {
          const validItems = cart.filter(item => 
            coupon.applies_to_categories.includes(item.product.category)
          );
          console.log('📦 Verificação por categoria:', {
            categories: coupon.applies_to_categories,
            validItems: validItems.length,
            cartCategories: cart.map(item => item.product.category)
          });
          isApplicable = validItems.length > 0;
        }

        if (coupon.applies_to_type === 'products' && coupon.applies_to_products?.length > 0) {
          const validItems = cart.filter(item => 
            coupon.applies_to_products.includes(item.product.id)
          );
          console.log('📦 Verificação por produto:', {
            products: coupon.applies_to_products,
            validItems: validItems.length,
            cartProducts: cart.map(item => item.product.id)
          });
          isApplicable = validItems.length > 0;
        }

        console.log('✅ Cupom aplicável?', isApplicable);

        if (isApplicable) {
          // Calcular desconto
          let discount = 0;
          if (coupon.discount_type === 'percentage') {
            discount = (subtotal * coupon.discount_value) / 100;
          } else {
            discount = Math.min(coupon.discount_value, subtotal);
          }

          onCouponApplied(coupon, discount);
          toast({
            title: "Cupom automático aplicado!",
            description: `${coupon.name} - Desconto de R$ ${discount.toFixed(2)}`,
          });
          break;
        }
      }
      
      setAutoApplyChecked(true);
    } catch (error) {
      console.error('Erro ao verificar cupons automáticos:', error);
      setAutoApplyChecked(true);
    }
  };

  // Verificar cupons automáticos quando o formulário estiver válido
  useEffect(() => {
    console.log('🔄 useEffect executado - Verificação de cupons automáticos', {
      isFormValid,
      appliedCoupon: !!appliedCoupon,
      establishmentId,
      subtotal
    });
    
    if (isFormValid && !appliedCoupon) {
      checkAndApplyAutoCoupons();
    }
  }, [isFormValid, appliedCoupon, establishmentId, subtotal]);

  const validateAndApplyCoupon = async () => {
    if (!couponCode.trim()) {
      toast({
        title: "Código obrigatório",
        description: "Digite o código do cupom",
        variant: "destructive"
      });
      return;
    }

    setIsLoading(true);

    try {
      const { data: coupon, error } = await supabase
        .from('discount_coupons')
        .select('*')
        .eq('user_id', establishmentId)
        .eq('code', couponCode.toUpperCase())
        .eq('is_active', true)
        .single();

      if (error || !coupon) {
        toast({
          title: "Cupom inválido",
          description: "Código não encontrado ou expirado",
          variant: "destructive"
        });
        return;
      }

      // Verificar se o cupom está dentro do período válido
      const now = new Date();
      const validFromDate = new Date(coupon.valid_from);
      const validUntilDate = coupon.valid_until ? new Date(coupon.valid_until) : null;
      
      if (now < validFromDate) {
        toast({
          title: "Cupom não iniciado",
          description: "Este cupom ainda não está válido",
          variant: "destructive"
        });
        return;
      }
      
      if (validUntilDate && now > validUntilDate) {
        toast({
          title: "Cupom expirado",
          description: "Este cupom não está mais válido",
          variant: "destructive"
        });
        return;
      }

      // Verificar limite de uso
      if (coupon.max_uses && coupon.current_uses >= coupon.max_uses) {
        toast({
          title: "Cupom esgotado",
          description: "Este cupom atingiu o limite de uso",
          variant: "destructive"
        });
        return;
      }

      // Verificar se o cupom se aplica aos produtos do carrinho
      if (coupon.applies_to_type === 'categories' && coupon.applies_to_categories?.length > 0) {
        const validItems = cart.filter(item => 
          coupon.applies_to_categories.includes(item.product.category)
        );
        
        if (validItems.length === 0) {
          toast({
            title: "Cupom não aplicável",
            description: "Este cupom não se aplica aos produtos selecionados",
            variant: "destructive"
          });
          return;
        }
      }

      if (coupon.applies_to_type === 'products' && coupon.applies_to_products?.length > 0) {
        const validItems = cart.filter(item => 
          coupon.applies_to_products.includes(item.product.id)
        );
        
        if (validItems.length === 0) {
          toast({
            title: "Cupom não aplicável",
            description: "Este cupom não se aplica aos produtos selecionados",
            variant: "destructive"
          });
          return;
        }
      }

      // Calcular desconto
      let discount = 0;
      if (coupon.discount_type === 'percentage') {
        discount = (subtotal * coupon.discount_value) / 100;
      } else {
        discount = Math.min(coupon.discount_value, subtotal);
      }

      onCouponApplied(coupon, discount);
      setCouponCode("");
      
      toast({
        title: "Cupom aplicado!",
        description: `Desconto de R$ ${discount.toFixed(2)} aplicado`,
      });

    } catch (error) {
      console.error('Erro ao validar cupom:', error);
      toast({
        title: "Erro",
        description: "Erro ao validar o cupom",
        variant: "destructive"
      });
    } finally {
      setIsLoading(false);
    }
  };

  const removeCoupon = () => {
    onCouponRemoved();
    toast({
      title: "Cupom removido",
      description: "O desconto foi removido do pedido",
    });
  };

  return (
    <div className="space-y-4">
      <div className="flex items-center gap-2">
        <Tag className="w-4 h-4 text-primary" />
        <Label className="text-sm font-medium">Cupom de Desconto</Label>
      </div>

      {appliedCoupon ? (
        <div className="bg-green-50 border border-green-200 rounded-lg p-3">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Badge variant="outline" className="bg-green-100 text-green-700 border-green-300">
                <Percent className="w-3 h-3 mr-1" />
                {appliedCoupon.code}
              </Badge>
              <span className="text-sm text-green-700 font-medium">
                {appliedCoupon.name}
              </span>
            </div>
            <Button
              variant="ghost"
              size="sm"
              onClick={removeCoupon}
              className="h-6 w-6 p-0 text-red-500 hover:text-red-700"
            >
              <X className="w-4 h-4" />
            </Button>
          </div>
        </div>
      ) : (
        <div className="flex gap-2">
          <div className="flex-1">
            <Input
              type="text"
              placeholder="Digite o código do cupom"
              value={couponCode}
              onChange={(e) => setCouponCode(e.target.value.toUpperCase())}
              onKeyPress={(e) => e.key === 'Enter' && validateAndApplyCoupon()}
              className="text-sm"
            />
          </div>
          <Button
            onClick={validateAndApplyCoupon}
            disabled={isLoading || !couponCode.trim()}
            variant="outline"
            size="sm"
            className="px-4"
          >
            {isLoading ? 'Validando...' : 'Aplicar'}
          </Button>
        </div>
      )}
    </div>
  );
};