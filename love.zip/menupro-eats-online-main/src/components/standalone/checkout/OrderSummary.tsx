import { Separator } from "@/components/ui/separator";

interface CartItem {
  id: string;
  product: any;
  quantity: number;
  customizations?: any;
  totalPrice: number;
}

interface OrderSummaryProps {
  cart: CartItem[];
  total: number;
  discount?: number;
  appliedCoupon?: any;
}

export const OrderSummary = ({ cart, total, discount = 0, appliedCoupon }: OrderSummaryProps) => {
  return (
    <div className="bg-gray-50 p-4 rounded-lg">
      <h3 className="font-medium mb-3 text-sm">Resumo do Pedido:</h3>
      <div className="space-y-2">
        {cart.map((item) => (
          <div key={item.id} className="flex justify-between text-sm">
            <span>{item.quantity}x {item.product.name}</span>
            <span>R$ {item.totalPrice.toFixed(2)}</span>
          </div>
        ))}
      </div>
      <Separator className="my-2" />
      
      <div className="space-y-1">
        <div className="flex justify-between text-sm">
          <span>Subtotal:</span>
          <span>R$ {total.toFixed(2)}</span>
        </div>
        
        {discount && discount > 0 && (
          <div className="flex justify-between text-sm text-green-600">
            <span>Desconto ({appliedCoupon?.code}):</span>
            <span>-R$ {discount.toFixed(2)}</span>
          </div>
        )}
        
        <Separator className="my-1" />
        <div className="flex justify-between font-bold">
          <span>Total:</span>
          <span className="text-orange-600">R$ {(total - (discount || 0)).toFixed(2)}</span>
        </div>
      </div>
    </div>
  );
};