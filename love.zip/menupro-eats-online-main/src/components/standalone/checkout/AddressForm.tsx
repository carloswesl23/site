import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { MapPin } from "lucide-react";

interface AddressFormProps {
  addressField: { value: string; error: string | null };
  neighborhoodField: { value: string; error: string | null };
  onInputChange: (field: string, value: string) => void;
}

export const AddressForm = ({ 
  addressField, 
  neighborhoodField, 
  onInputChange 
}: AddressFormProps) => {
  return (
    <div className="space-y-4">
      <div className="flex items-center gap-2 mb-3">
        <MapPin className="w-4 h-4" />
        <h3 className="font-medium text-sm">Endereço de Entrega</h3>
      </div>

      <div className="space-y-3">
        <div>
          <Label htmlFor="address" className="text-xs">Endereço completo *</Label>
          <Input
            id="address"
            value={addressField.value}
            onChange={(e) => onInputChange('address', e.target.value)}
            placeholder="Rua, número, complemento"
            className={`mt-1 ${addressField.error ? 'border-red-500' : ''}`}
            maxLength={200}
          />
          {addressField.error && (
            <p className="text-red-500 text-xs mt-1">{addressField.error}</p>
          )}
        </div>

        <div>
          <Label htmlFor="neighborhood" className="text-xs">Bairro</Label>
          <Input
            id="neighborhood"
            value={neighborhoodField.value}
            onChange={(e) => onInputChange('neighborhood', e.target.value)}
            placeholder="Seu bairro"
            className={`mt-1 ${neighborhoodField.error ? 'border-red-500' : ''}`}
            maxLength={100}
          />
          {neighborhoodField.error && (
            <p className="text-red-500 text-xs mt-1">{neighborhoodField.error}</p>
          )}
        </div>
      </div>
    </div>
  );
};