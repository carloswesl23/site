import { useState, useEffect } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Checkbox } from "@/components/ui/checkbox";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Plus, Minus } from "lucide-react";
import { Separator } from "@/components/ui/separator";

interface Product {
  id: string;
  name: string;
  description: string;
  price: number;
  image: string;
  isPromotion: boolean;
  promotionPrice?: number;
  customizable?: boolean;
  ingredients?: string[];
  extras?: { name: string; price: number }[];
  isPizza?: boolean;
}

interface StandaloneProductModalProps {
  product: Product | null;
  isOpen: boolean;
  onClose: () => void;
  onAddToCart: (product: Product, customizations?: any, quantity?: number) => void;
}

export const StandaloneProductModal = ({
  product,
  isOpen,
  onClose,
  onAddToCart
}: StandaloneProductModalProps) => {
  const [quantity, setQuantity] = useState(1);
  const [selectedExtras, setSelectedExtras] = useState<{ name: string; price: number }[]>([]);
  const [removedIngredients, setRemovedIngredients] = useState<string[]>([]);
  const [notes, setNotes] = useState("");

  useEffect(() => {
    if (isOpen) {
      setQuantity(1);
      setSelectedExtras([]);
      setRemovedIngredients([]);
      setNotes("");
    }
  }, [isOpen, product]);

  if (!product) return null;

  const basePrice = product.isPromotion && product.promotionPrice 
    ? product.promotionPrice 
    : product.price;
  
  const extrasPrice = selectedExtras.reduce((sum, extra) => sum + extra.price, 0);
  const totalPrice = (basePrice + extrasPrice) * quantity;

  const handleExtraToggle = (extra: { name: string; price: number }) => {
    setSelectedExtras(prev => {
      const exists = prev.find(e => e.name === extra.name);
      if (exists) {
        return prev.filter(e => e.name !== extra.name);
      } else {
        return [...prev, extra];
      }
    });
  };

  const handleIngredientToggle = (ingredient: string) => {
    setRemovedIngredients(prev => {
      if (prev.includes(ingredient)) {
        return prev.filter(i => i !== ingredient);
      } else {
        return [...prev, ingredient];
      }
    });
  };

  const handleAddToCart = () => {
    const customizations = {
      extras: selectedExtras,
      removedIngredients,
      notes: notes.trim() || undefined
    };

    onAddToCart(product, customizations, quantity);
    onClose();
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-md max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>{product.name}</DialogTitle>
        </DialogHeader>

        <div className="space-y-4">
          {/* Imagem do produto */}
          <img
            src={product.image}
            alt={product.name}
            className="w-full h-48 object-cover rounded-lg"
          />

          {/* Descrição */}
          <p className="text-sm text-gray-600">{product.description}</p>

          {/* Preço base */}
          <div className="text-center">
            {product.isPromotion && product.promotionPrice ? (
              <div className="flex items-center gap-2 justify-center">
                <span className="font-bold text-green-600 text-xl">
                  R$ {product.promotionPrice.toFixed(2)}
                </span>
                <span className="text-gray-500 line-through text-sm">
                  R$ {product.price.toFixed(2)}
                </span>
              </div>
            ) : (
              <span className="font-bold text-gray-900 text-xl">
                R$ {product.price.toFixed(2)}
              </span>
            )}
          </div>

          {/* Ingredientes removíveis */}
          {product.ingredients && product.ingredients.length > 0 && (
            <div>
              <Label className="text-sm font-medium">Remover ingredientes:</Label>
              <div className="grid grid-cols-2 gap-2 mt-2">
                {product.ingredients.map((ingredient) => (
                  <div key={ingredient} className="flex items-center space-x-2">
                    <Checkbox
                      id={`ingredient-${ingredient}`}
                      checked={removedIngredients.includes(ingredient)}
                      onCheckedChange={() => handleIngredientToggle(ingredient)}
                    />
                    <Label
                      htmlFor={`ingredient-${ingredient}`}
                      className="text-sm text-gray-600"
                    >
                      {ingredient}
                    </Label>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Extras */}
          {product.extras && product.extras.length > 0 && (
            <div>
              <Label className="text-sm font-medium">Adicionais:</Label>
              <div className="space-y-2 mt-2">
                {product.extras.map((extra) => (
                  <div key={extra.name} className="flex items-center justify-between p-2 border rounded">
                    <div className="flex items-center space-x-2">
                      <Checkbox
                        id={`extra-${extra.name}`}
                        checked={selectedExtras.some(e => e.name === extra.name)}
                        onCheckedChange={() => handleExtraToggle(extra)}
                      />
                      <Label htmlFor={`extra-${extra.name}`} className="text-sm">
                        {extra.name}
                      </Label>
                    </div>
                    <span className="text-sm font-medium text-orange-600">
                      + R$ {extra.price.toFixed(2)}
                    </span>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Observações */}
          <div>
            <Label htmlFor="notes" className="text-sm font-medium">
              Observações:
            </Label>
            <Textarea
              id="notes"
              placeholder="Alguma observação especial..."
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              className="mt-1"
              rows={3}
            />
          </div>

          <Separator />

          {/* Quantidade e total */}
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <Label className="text-sm font-medium">Quantidade:</Label>
              <div className="flex items-center gap-2">
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => setQuantity(Math.max(1, quantity - 1))}
                  className="h-8 w-8 p-0"
                >
                  <Minus className="w-3 h-3" />
                </Button>
                <span className="w-8 text-center font-medium">{quantity}</span>
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => setQuantity(quantity + 1)}
                  className="h-8 w-8 p-0"
                >
                  <Plus className="w-3 h-3" />
                </Button>
              </div>
            </div>

            <div className="text-right">
              <p className="text-lg font-bold text-orange-600">
                R$ {totalPrice.toFixed(2)}
              </p>
            </div>
          </div>

          {/* Botão adicionar */}
          <Button
            onClick={handleAddToCart}
            className="w-full bg-orange-500 hover:bg-orange-600 text-white h-12"
            size="lg"
          >
            Adicionar à Sacola
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
};