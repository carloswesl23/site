import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Clock, MapPin, Star, MessageCircle } from "lucide-react";
import { Instagram } from "lucide-react";

interface StandaloneMenuHeaderProps {
  establishmentName: string;
  image?: string;
  rating?: number;
  deliveryTime?: string;
  address?: string;
  whatsappNumber?: string;
  instagramUrl?: string;
}

export const StandaloneMenuHeader = ({ 
  establishmentName, 
  image = "https://images.unsplash.com/photo-1571091718767-18b5b1457add?w=800&h=400&fit=crop&crop=center",
  rating = 4.8,
  deliveryTime = "30-45 min",
  address = "Rua das Flores, 123 - Centro",
  whatsappNumber = "5511999999999",
  instagramUrl = "https://instagram.com/estabelecimento"
}: StandaloneMenuHeaderProps) => {
  const handleWhatsAppClick = () => {
    const whatsappUrl = `https://wa.me/${whatsappNumber}?text=Olá! Gostaria de fazer um pedido.`;
    window.open(whatsappUrl, '_blank');
  };

  const handleInstagramClick = () => {
    if (!instagramUrl) return;
    
    let validUrl = instagramUrl;
    if (!instagramUrl.startsWith('http')) {
      // Se não começar com http, assume que é apenas o username e adiciona a URL base
      const username = instagramUrl.replace('@', '').replace(/^instagram\.com\//, '');
      validUrl = `https://instagram.com/${username}`;
    }
    
    window.open(validUrl, '_blank');
  };

  return (
    <div className="bg-white shadow-sm">
      <div className="container mx-auto px-4 py-6 max-w-6xl">
        <Card className="overflow-hidden">
          <div className="relative h-48 md:h-64">
            <img 
              src={image} 
              alt={establishmentName}
              className="w-full h-full object-cover"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-transparent to-transparent" />
            <div className="absolute bottom-4 left-4 text-white">
              <h1 className="text-2xl md:text-3xl font-bold mb-2">{establishmentName}</h1>
              <div className="flex items-center gap-4 text-sm">
                <div className="flex items-center gap-1">
                  <Star className="w-4 h-4 fill-yellow-400 text-yellow-400" />
                  <span>{rating}</span>
                </div>
                <div className="flex items-center gap-1">
                  <Clock className="w-4 h-4" />
                  <span>{deliveryTime}</span>
                </div>
              </div>
            </div>
          </div>
          
          <div className="p-4">
            <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
              <div className="flex items-center gap-2 text-gray-600">
                <MapPin className="w-4 h-4" />
                <span className="text-sm">{address}</span>
              </div>
              
              <div className="flex items-center gap-3">
                <Badge className="bg-green-100 text-green-800 hover:bg-green-100">
                  Aberto
                </Badge>
                
                <div className="flex gap-2">
                  <Button
                    onClick={handleWhatsAppClick}
                    className="bg-green-600 hover:bg-green-700 text-white flex items-center gap-2 px-3 py-2 text-sm"
                    size="sm"
                  >
                    <MessageCircle className="w-4 h-4" />
                    WhatsApp
                  </Button>
                  
                  <Button
                    onClick={handleInstagramClick}
                    className="bg-pink-600 hover:bg-pink-700 text-white flex items-center gap-2 px-3 py-2 text-sm"
                    size="sm"
                  >
                    <Instagram className="w-4 h-4" />
                    Instagram
                  </Button>
                </div>
              </div>
            </div>
          </div>
        </Card>
      </div>
    </div>
  );
};