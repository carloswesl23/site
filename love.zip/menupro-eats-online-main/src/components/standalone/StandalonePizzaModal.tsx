import { useState, useEffect } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Plus, Minus, Pizza } from "lucide-react";
import { Separator } from "@/components/ui/separator";
import { Badge } from "@/components/ui/badge";

interface PizzaFlavor {
  id: string;
  name: string;
  price: number;
  ingredients: string[];
}

interface PizzaBorder {
  id: string;
  name: string;
  price: number;
}

interface Product {
  id: string;
  name: string;
  description: string;
  price: number;
  image: string;
  isPromotion: boolean;
  promotionPrice?: number;
  maxFlavors?: number;
  allow_half_half?: boolean;
  pizzaFlavors?: PizzaFlavor[];
  pizzaBorders?: PizzaBorder[];
}

interface StandalonePizzaModalProps {
  product: Product | null;
  isOpen: boolean;
  onClose: () => void;
  onAddToCart: (product: Product, customizations?: any, quantity?: number) => void;
}

// Mock data para sabores e bordas
const mockFlavors: PizzaFlavor[] = [
  {
    id: "1",
    name: "Margherita",
    price: 35.90,
    ingredients: ["Molho de tomate", "Mussarela", "Manjericão", "Azeite"]
  },
  {
    id: "2", 
    name: "Pepperoni",
    price: 42.90,
    ingredients: ["Molho de tomate", "Mussarela", "Pepperoni"]
  },
  {
    id: "3",
    name: "Quatro Queijos",
    price: 45.90,
    ingredients: ["Molho branco", "Mussarela", "Gorgonzola", "Parmesão", "Provolone"]
  },
  {
    id: "4",
    name: "Portuguesa",
    price: 39.90,
    ingredients: ["Molho de tomate", "Mussarela", "Presunto", "Ovos", "Cebola", "Azeitona"]
  }
];

const mockBorders: PizzaBorder[] = [
  { id: "1", name: "Tradicional", price: 0 },
  { id: "2", name: "Catupiry", price: 8.90 },
  { id: "3", name: "Cheddar", price: 6.90 },
  { id: "4", name: "Chocolate", price: 9.90 }
];

export const StandalonePizzaModal = ({
  product,
  isOpen,
  onClose,
  onAddToCart
}: StandalonePizzaModalProps) => {
  const [quantity, setQuantity] = useState(1);
  const [selectedFlavors, setSelectedFlavors] = useState<PizzaFlavor[]>([]);
  const [selectedBorder, setSelectedBorder] = useState<PizzaBorder | null>(null);
  const [removedIngredients, setRemovedIngredients] = useState<string[]>([]);
  const [notes, setNotes] = useState("");
  const [currentMaxFlavors, setCurrentMaxFlavors] = useState(1);

  useEffect(() => {
    if (isOpen) {
      setQuantity(1);
      setSelectedFlavors([]);
      setSelectedBorder(null);
      setRemovedIngredients([]);
      setNotes("");
      setCurrentMaxFlavors(1);
    }
  }, [isOpen, product]);

  if (!product) return null;

  const maxFlavors = currentMaxFlavors;
  const allowHalfHalf = product.allow_half_half || false;
  const availableFlavors = product.pizzaFlavors || mockFlavors;
  const availableBorders = product.pizzaBorders || [];
  const canAddMoreFlavors = selectedFlavors.length < maxFlavors;

  // Cálculo do preço da pizza
  const pizzaPrice = selectedFlavors.length > 0 
    ? Math.max(...selectedFlavors.map(f => f.price))
    : product.price;
  
  const borderPrice = selectedBorder?.price || 0;
  const totalPrice = (pizzaPrice + borderPrice) * quantity;

  const handleFlavorToggle = (flavor: PizzaFlavor) => {
    setSelectedFlavors(prev => {
      const exists = prev.find(f => f.id === flavor.id);
      if (exists) {
        return prev.filter(f => f.id !== flavor.id);
      } else if (canAddMoreFlavors) {
        return [...prev, flavor];
      }
      return prev;
    });
  };

  const handleIngredientToggle = (ingredient: string) => {
    setRemovedIngredients(prev => {
      if (prev.includes(ingredient)) {
        return prev.filter(i => i !== ingredient);
      } else {
        return [...prev, ingredient];
      }
    });
  };

  const handleAddToCart = () => {
    const customizations = {
      flavors: selectedFlavors,
      border: selectedBorder,
      removedIngredients,
      notes: notes.trim() || undefined,
      pizzaPrice,
      borderPrice
    };

    onAddToCart(product, customizations, quantity);
    onClose();
  };

  const allIngredients = Array.from(
    new Set(selectedFlavors.flatMap(f => f.ingredients))
  );

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-md max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Pizza className="w-5 h-5" />
            Monte sua Pizza
          </DialogTitle>
        </DialogHeader>

        <div className="space-y-4">
          {/* Imagem da pizza */}
          <img
            src={product.image}
            alt={product.name}
            className="w-full h-48 object-cover rounded-lg"
          />

          {/* Opção de escolha de sabores */}
          {allowHalfHalf && (
            <div>
              <Label className="text-sm font-medium mb-3 block">
                Como você deseja sua pizza?
              </Label>
              <div className="grid grid-cols-1 gap-2 mb-4">
                <div
                  className={`p-3 border rounded-lg cursor-pointer transition-colors ${
                    currentMaxFlavors === 1 
                      ? 'border-orange-500 bg-orange-50' 
                      : 'border-gray-200 hover:border-orange-300'
                  }`}
                  onClick={() => {
                    setCurrentMaxFlavors(1);
                    setSelectedFlavors(prev => prev.slice(0, 1));
                  }}
                >
                  <div className="flex items-center gap-2">
                    <span>🍕</span>
                    <span className="font-medium">Pizza inteira (1 sabor)</span>
                  </div>
                </div>
                <div
                  className={`p-3 border rounded-lg cursor-pointer transition-colors ${
                    currentMaxFlavors === 2 
                      ? 'border-orange-500 bg-orange-50' 
                      : 'border-gray-200 hover:border-orange-300'
                  }`}
                  onClick={() => {
                    setCurrentMaxFlavors(2);
                  }}
                >
                  <div className="flex items-center gap-2">
                    <span>🍕</span>
                    <span className="font-medium">Meia a meia (2 sabores)</span>
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* Seleção de sabores */}
          <div>
            <div className="flex items-center justify-between mb-2">
              <Label className="text-sm font-medium">
                {allowHalfHalf && currentMaxFlavors === 2 ? 'Escolha os 2 sabores:' : 'Escolha o sabor:'}
              </Label>
              <Badge variant="outline">
                {selectedFlavors.length}/{currentMaxFlavors}
              </Badge>
            </div>
            
            <div className="space-y-2">
              {availableFlavors.map((flavor) => {
                const isSelected = selectedFlavors.some(f => f.id === flavor.id);
                const canSelect = canAddMoreFlavors || isSelected;
                
                return (
                  <div
                    key={flavor.id}
                    className={`p-3 border rounded-lg cursor-pointer transition-colors ${
                      isSelected 
                        ? 'border-orange-500 bg-orange-50' 
                        : canSelect 
                        ? 'border-gray-200 hover:border-orange-300' 
                        : 'border-gray-100 bg-gray-50 cursor-not-allowed'
                    }`}
                    onClick={() => canSelect && handleFlavorToggle(flavor)}
                  >
                    <div className="flex justify-between items-start">
                      <div className="flex-1">
                        <h4 className="font-medium text-sm">{flavor.name}</h4>
                        <p className="text-xs text-gray-600 mt-1">
                          {flavor.ingredients.join(', ')}
                        </p>
                      </div>
                      <span className="text-sm font-medium text-orange-600">
                        R$ {flavor.price.toFixed(2)}
                      </span>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>

          {/* Borda */}
          {availableBorders.length > 0 && (
            <div>
              <Label className="text-sm font-medium">Escolha a borda:</Label>
              <div className="grid grid-cols-2 gap-2 mt-2">
                <div
                  className={`p-2 border rounded cursor-pointer text-center transition-colors ${
                    !selectedBorder
                      ? 'border-orange-500 bg-orange-50'
                      : 'border-gray-200 hover:border-orange-300'
                  }`}
                  onClick={() => setSelectedBorder(null)}
                >
                  <div className="text-sm font-medium">Sem borda</div>
                  <div className="text-xs text-gray-600">Grátis</div>
                </div>
                {availableBorders.map((border) => (
                <div
                  key={border.id}
                  className={`p-2 border rounded cursor-pointer text-center transition-colors ${
                    selectedBorder?.id === border.id
                      ? 'border-orange-500 bg-orange-50'
                      : 'border-gray-200 hover:border-orange-300'
                  }`}
                  onClick={() => setSelectedBorder(border)}
                >
                  <div className="text-sm font-medium">{border.name}</div>
                  <div className="text-xs text-orange-600">
                    {border.price > 0 ? `+ R$ ${border.price.toFixed(2)}` : 'Grátis'}
                  </div>
                </div>
                ))}
              </div>
            </div>
          )}

          {/* Remover ingredientes */}
          {allIngredients.length > 0 && (
            <div>
              <Label className="text-sm font-medium">Remover ingredientes:</Label>
              <div className="grid grid-cols-2 gap-2 mt-2">
                {allIngredients.map((ingredient) => (
                  <div
                    key={ingredient}
                    className={`p-2 border rounded cursor-pointer text-center text-xs transition-colors ${
                      removedIngredients.includes(ingredient)
                        ? 'border-red-500 bg-red-50 line-through'
                        : 'border-gray-200 hover:border-red-300'
                    }`}
                    onClick={() => handleIngredientToggle(ingredient)}
                  >
                    {ingredient}
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Observações */}
          <div>
            <Label htmlFor="notes" className="text-sm font-medium">
              Observações:
            </Label>
            <Textarea
              id="notes"
              placeholder="Alguma observação especial..."
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              className="mt-1"
              rows={3}
            />
          </div>

          <Separator />

          {/* Quantidade e total */}
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <Label className="text-sm font-medium">Quantidade:</Label>
              <div className="flex items-center gap-2">
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => setQuantity(Math.max(1, quantity - 1))}
                  className="h-8 w-8 p-0"
                >
                  <Minus className="w-3 h-3" />
                </Button>
                <span className="w-8 text-center font-medium">{quantity}</span>
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => setQuantity(quantity + 1)}
                  className="h-8 w-8 p-0"
                >
                  <Plus className="w-3 h-3" />
                </Button>
              </div>
            </div>

            <div className="text-right">
              <p className="text-lg font-bold text-orange-600">
                R$ {totalPrice.toFixed(2)}
              </p>
              {borderPrice > 0 && (
                <p className="text-xs text-gray-600">
                  Pizza: R$ {pizzaPrice.toFixed(2)} + Borda: R$ {borderPrice.toFixed(2)}
                </p>
              )}
            </div>
          </div>

          {/* Botão adicionar */}
          <Button
            onClick={handleAddToCart}
            disabled={selectedFlavors.length === 0}
            className="w-full bg-orange-500 hover:bg-orange-600 text-white h-12 disabled:bg-gray-300"
            size="lg"
          >
            {selectedFlavors.length === 0 
              ? 'Escolha pelo menos 1 sabor' 
              : 'Adicionar à Sacola'
            }
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
};