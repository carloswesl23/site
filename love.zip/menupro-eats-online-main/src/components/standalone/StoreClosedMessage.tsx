import { AlertCircle, Clock } from "lucide-react";
import { Card, CardContent } from "@/components/ui/card";

interface StoreClosedMessageProps {
  businessName: string;
}

export function StoreClosedMessage({ businessName }: StoreClosedMessageProps) {
  return (
    <div className="min-h-screen bg-gray-50 flex items-center justify-center p-4">
      <Card className="w-full max-w-md">
        <CardContent className="p-8 text-center">
          <div className="mb-6">
            <AlertCircle className="h-16 w-16 text-red-500 mx-auto mb-4" />
            <h1 className="text-2xl font-bold text-gray-900 mb-2">
              Loja Fechada
            </h1>
            <h2 className="text-lg text-gray-700 mb-4">
              {businessName}
            </h2>
          </div>
          
          <div className="space-y-4">
            <div className="p-4 bg-red-50 rounded-lg border border-red-200">
              <div className="flex items-center justify-center gap-2 text-red-700">
                <Clock className="h-5 w-5" />
                <span className="font-medium">Estamos fechados no momento</span>
              </div>
              <p className="text-sm text-red-600 mt-2">
                Não estamos recebendo pedidos agora.
              </p>
            </div>
            
            <div className="text-gray-600 text-sm space-y-2">
              <p>Desculpe pelo inconveniente!</p>
              <p>Volte mais tarde para fazer seu pedido.</p>
            </div>
          </div>
          
          <div className="mt-8 pt-6 border-t border-gray-200">
            <p className="text-xs text-gray-500">
              Entre em contato conosco pelo WhatsApp se precisar de mais informações
            </p>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}