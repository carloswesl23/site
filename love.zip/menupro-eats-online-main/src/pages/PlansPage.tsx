
import { useState } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Check, Heart, ArrowLeft } from "lucide-react";
import { useNavigate } from "react-router-dom";
import { useToast } from "@/hooks/use-toast";

export default function PlansPage() {
  const [selectedPlan, setSelectedPlan] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const navigate = useNavigate();
  const { toast } = useToast();

  const plans = [
    {
      id: "monthly",
      name: "Mensal",
      price: "R$ 35",
      period: "/mês",
      description: "Perfeito para começar",
      originalPrice: null,
      savings: null,
      features: [
        "Cardápio digital completo",
        "Personalização de produtos",
        "Integração WhatsApp",
        "Pagamento via Pix",
        "Taxa de entrega configurável",
        "Botões de redes sociais",
        "Painel administrativo",
        "Suporte por email"
      ],
      popular: false
    },
    {
      id: "quarterly",
      name: "Trimestral",
      price: "R$ 90",
      period: "/3 meses",
      description: "Economia garantida",
      originalPrice: "R$ 105",
      savings: "R$ 15",
      features: [
        "Tudo do plano mensal",
        "Economia de R$ 15",
        "Suporte prioritário",
        "Relatórios avançados",
        "Configurações extras",
        "QR Code personalizado",
        "Backup automático"
      ],
      popular: true
    },
    {
      id: "annual",
      name: "Anual",
      price: "R$ 299",
      period: "/ano",
      description: "Máxima economia",
      originalPrice: "R$ 420",
      savings: "R$ 121",
      features: [
        "Tudo dos planos anteriores",
        "Economia de R$ 121",
        "Suporte VIP",
        "Recursos exclusivos",
        "Consultoria gratuita",
        "Múltiplos cardápios",
        "Integrações avançadas",
        "Análises detalhadas"
      ],
      popular: false
    }
  ];

  const handleSelectPlan = async (planId: string) => {
    setSelectedPlan(planId);
    setIsLoading(true);

    // Simular processo de pagamento
    setTimeout(() => {
      setIsLoading(false);
      toast({
        title: "Plano selecionado!",
        description: "Redirecionando para o pagamento...",
      });
      
      // Simular sucesso no pagamento e redirecionar para dashboard
      setTimeout(() => {
        navigate("/dashboard");
      }, 2000);
    }, 1500);
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-brand-orange via-brand-red to-brand-dark">
      <div className="container mx-auto px-4 py-8">
        {/* Header */}
        <div className="text-center mb-12">
          <Button
            variant="ghost"
            onClick={() => navigate("/")}
            className="absolute top-8 left-8 text-white hover:bg-white/10"
          >
            <ArrowLeft className="w-4 h-4 mr-2" />
            Voltar
          </Button>
          
          <div className="flex items-center justify-center space-x-2 mb-6">
            <div className="w-12 h-12 bg-white rounded-xl flex items-center justify-center">
              <Heart className="w-6 h-6 text-brand-orange" />
            </div>
            <h1 className="text-3xl font-bold text-white">LoveMenu</h1>
          </div>
          
          <h2 className="text-4xl md:text-5xl font-bold text-white mb-4">
            Escolha seu Plano
          </h2>
          <p className="text-xl text-white/90 max-w-2xl mx-auto">
            Selecione o plano ideal para seu negócio e comece a vender mais hoje mesmo!
          </p>
        </div>

        {/* Plans Grid */}
        <div className="grid md:grid-cols-3 gap-8 max-w-6xl mx-auto">
          {plans.map((plan) => (
            <Card 
              key={plan.id} 
              className={`relative transform transition-all duration-300 hover:scale-105 ${
                plan.popular 
                  ? 'ring-4 ring-yellow-400 shadow-2xl' 
                  : 'shadow-xl hover:shadow-2xl'
              } ${
                selectedPlan === plan.id 
                  ? 'ring-4 ring-green-400' 
                  : ''
              }`}
            >
              {plan.popular && (
                <Badge className="absolute -top-3 left-1/2 transform -translate-x-1/2 bg-yellow-400 text-brand-dark font-bold">
                  🔥 Mais Popular
                </Badge>
              )}
              
              {plan.savings && (
                <Badge className="absolute -top-3 right-4 bg-green-500 text-white">
                  Economize {plan.savings}
                </Badge>
              )}

              <CardHeader className="text-center pb-4">
                <CardTitle className="text-2xl font-bold">{plan.name}</CardTitle>
                <div className="space-y-2">
                  {plan.originalPrice && (
                    <div className="text-sm text-gray-500 line-through">
                      De {plan.originalPrice}
                    </div>
                  )}
                  <div className="flex items-end justify-center">
                    <span className="text-4xl font-bold text-brand-orange">{plan.price}</span>
                    <span className="text-gray-600 ml-1">{plan.period}</span>
                  </div>
                </div>
                <CardDescription className="text-base">{plan.description}</CardDescription>
              </CardHeader>

              <CardContent>
                <ul className="space-y-3 mb-8">
                  {plan.features.map((feature, index) => (
                    <li key={index} className="flex items-start">
                      <Check className="w-5 h-5 text-green-500 mr-3 flex-shrink-0 mt-0.5" />
                      <span className="text-sm">{feature}</span>
                    </li>
                  ))}
                </ul>

                <Button 
                  className={`w-full text-lg py-6 ${
                    plan.popular 
                      ? 'gradient-brand text-white hover:opacity-90' 
                      : 'border-2 border-brand-orange text-brand-orange hover:bg-brand-orange hover:text-white'
                  }`}
                  variant={plan.popular ? 'default' : 'outline'}
                  onClick={() => handleSelectPlan(plan.id)}
                  disabled={isLoading}
                >
                  {isLoading && selectedPlan === plan.id 
                    ? "Processando..." 
                    : "Escolher este Plano"
                  }
                </Button>
              </CardContent>
            </Card>
          ))}
        </div>

        {/* Security Badge */}
        <div className="text-center mt-12">
          <div className="inline-flex items-center bg-white/10 backdrop-blur-md rounded-lg px-6 py-3">
            <div className="w-6 h-6 bg-green-500 rounded-full flex items-center justify-center mr-3">
              <Check className="w-4 h-4 text-white" />
            </div>
            <span className="text-white font-medium">
              Pagamento 100% seguro • Cancele quando quiser • Suporte incluído
            </span>
          </div>
        </div>
      </div>
    </div>
  );
}
