import { Navigation } from "@/components/Landing/Navigation";
import { HeroSection } from "@/components/Landing/HeroSection";
import { ProblemsSection } from "@/components/Landing/ProblemsSection";
import { SolutionsSection } from "@/components/Landing/SolutionsSection";
import { FeatureComparisonSection } from "@/components/Landing/FeatureComparisonSection";
import { ProcessSection } from "@/components/Landing/ProcessSection";
import { DemoSection } from "@/components/Landing/DemoSection";
import { PricingSection } from "@/components/Landing/PricingSection";
import { UrgencySection } from "@/components/Landing/UrgencySection";
import { TestimonialsSection } from "@/components/Landing/TestimonialsSection";
import { FAQSection } from "@/components/Landing/FAQSection";
import { FooterSection } from "@/components/Landing/FooterSection";
import { TrackingPixels } from "@/components/Landing/TrackingPixels";

const LandingPage = () => {
  return (
    <div className="min-h-screen bg-background">
      <TrackingPixels />
      <Navigation />
      
      <div className="pt-16">
        <div id="hero-section">
          <HeroSection />
        </div>
        <ProblemsSection />
        <div id="solutions-section">
          <SolutionsSection />
        </div>
        <FeatureComparisonSection />
        <ProcessSection />
        <div id="demo-section">
          <DemoSection />
        </div>
        <div id="pricing-section">
          <PricingSection />
        </div>
        <UrgencySection />
        <div id="testimonials-section">
          <TestimonialsSection />
        </div>
        <FAQSection />
        <FooterSection />
      </div>
    </div>
  );
};

export default LandingPage;