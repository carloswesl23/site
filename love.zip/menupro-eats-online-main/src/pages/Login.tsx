
import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { useToast } from "@/hooks/use-toast";
import { useNavigate } from "react-router-dom";
import { supabase } from "@/integrations/supabase/client";
import { Heart } from "lucide-react";
import { useSecureInput } from "@/hooks/useSecureInput";
import { createRateLimiter, getGenericErrorMessage } from "@/utils/security";

export default function Login() {
  const [isLoading, setIsLoading] = useState(false);
  const [isSignUp, setIsSignUp] = useState(false);
  const { toast } = useToast();
  const navigate = useNavigate();
  
  // Rate limiter for login attempts (max 5 per 15 minutes)
  const loginRateLimiter = createRateLimiter(5, 15 * 60 * 1000);
  
  const { fields, updateField, validateAllFields, getFieldProps, hasErrors } = useSecureInput({
    email: "",
    password: "",
    businessName: ""
  });

  const handleAuth = async (e: React.FormEvent) => {
    e.preventDefault();
    
    // Rate limiting check
    const clientIP = 'login-' + Date.now();
    if (!loginRateLimiter(clientIP)) {
      toast({
        title: "Muitas tentativas",
        description: "Aguarde 15 minutos antes de tentar novamente.",
        variant: "destructive",
      });
      return;
    }
    
    // Validate inputs
    const validationRules: any = {
      email: { required: true, type: 'email' as const },
      password: { required: true, type: 'password' as const }
    };
    
    if (isSignUp) {
      validationRules.businessName = { required: true, type: 'text' as const };
    }
    
    if (!validateAllFields(validationRules)) {
      toast({
        title: "Dados inválidos",
        description: "Por favor, corrija os erros nos campos.",
        variant: "destructive",
      });
      return;
    }
    
    setIsLoading(true);
    
    const emailField = getFieldProps('email');
    const passwordField = getFieldProps('password');
    const businessNameField = getFieldProps('businessName');

    try {
      if (isSignUp) {
        const { data, error } = await supabase.auth.signUp({
          email: emailField.value.trim(),
          password: passwordField.value,
          options: {
            emailRedirectTo: `${window.location.origin}/`,
            data: {
              business_name: businessNameField.value.trim()
            }
          }
        });

        if (error) {
          console.error('Signup error:', error);
          throw error;
        }

        if (data.user && !data.session) {
          toast({
            title: "Conta criada com sucesso!",
            description: "Verifique seu email para confirmar a conta.",
          });
        } else if (data.session) {
          toast({
            title: "Conta criada e logado com sucesso!",
            description: "Bem-vindo ao LoveMenu! Seu cardápio foi configurado automaticamente.",
          });
          navigate("/");
        }
      } else {
        const { data, error } = await supabase.auth.signInWithPassword({
          email: emailField.value.trim(),
          password: passwordField.value,
        });

        if (error) {
          console.error('Login error:', error);
          throw error;
        }

        if (data.session) {
          toast({
            title: "Login realizado com sucesso!",
            description: "Bem-vindo ao LoveMenu",
          });
          navigate("/");
        }
      }
    } catch (error: any) {
      console.error('Auth error:', error);
      
      // Use generic error messages for security
      let errorMessage = getGenericErrorMessage('auth');
      
      // Only provide specific error messages for safe cases
      if (error.message.includes('Email not confirmed')) {
        errorMessage = "Por favor, confirme seu email antes de fazer login.";
      } else if (error.message.includes('User already registered')) {
        errorMessage = "Este email já está cadastrado. Tente fazer login.";
      }
      
      toast({
        title: "Erro na autenticação",
        description: errorMessage,
        variant: "destructive",
      });
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-brand-orange via-brand-red to-brand-dark p-4">
      <div className="w-full max-w-md">
        <div className="text-center mb-8">
          <div className="inline-flex items-center justify-center w-16 h-16 gradient-brand rounded-2xl mb-4">
            <Heart className="text-white font-bold text-2xl w-8 h-8" />
          </div>
          <h1 className="text-4xl font-bold text-white mb-2">LoveMenu</h1>
          <p className="text-white/80">Seu cardápio digital completo, inteligente e pronto para vender!</p>
        </div>

        <Card className="glass-effect shadow-2xl">
          <CardHeader>
            <CardTitle className="text-2xl text-center text-brand-dark">
              {isSignUp ? "Criar sua conta" : "Entrar na sua conta"}
            </CardTitle>
            <CardDescription className="text-center">
              {isSignUp 
                ? "Preencha os dados para criar sua conta" 
                : "Digite suas credenciais para acessar o painel"
              }
            </CardDescription>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleAuth} className="space-y-4">
              {isSignUp && (
                <div className="space-y-2">
                  <Label htmlFor="businessName">Nome da Empresa</Label>
                  <Input
                    id="businessName"
                    type="text"
                    placeholder="Pizza da Rosa"
                    value={getFieldProps('businessName').value}
                    onChange={(e) => updateField('businessName', e.target.value, { required: true, type: 'text' })}
                    required
                    className={`border-gray-300 focus:border-brand-orange focus:ring-brand-orange ${getFieldProps('businessName').error ? 'border-red-500' : ''}`}
                    disabled={isLoading}
                    maxLength={100}
                  />
                  {getFieldProps('businessName').error && (
                    <p className="text-red-500 text-xs mt-1">{getFieldProps('businessName').error}</p>
                  )}
                </div>
              )}
              <div className="space-y-2">
                <Label htmlFor="email">Email</Label>
                <Input
                  id="email"
                  type="email"
                  placeholder="seu@email.com"
                  value={getFieldProps('email').value}
                  onChange={(e) => updateField('email', e.target.value, { required: true, type: 'email' })}
                  required
                  className={`border-gray-300 focus:border-brand-orange focus:ring-brand-orange ${getFieldProps('email').error ? 'border-red-500' : ''}`}
                  disabled={isLoading}
                  maxLength={254}
                />
                {getFieldProps('email').error && (
                  <p className="text-red-500 text-xs mt-1">{getFieldProps('email').error}</p>
                )}
              </div>
              <div className="space-y-2">
                <Label htmlFor="password">Senha</Label>
                <Input
                  id="password"
                  type="password"
                  placeholder="••••••••"
                  value={getFieldProps('password').value}
                  onChange={(e) => updateField('password', e.target.value, { required: true, type: 'password' })}
                  required
                  minLength={8}
                  className={`border-gray-300 focus:border-brand-orange focus:ring-brand-orange ${getFieldProps('password').error ? 'border-red-500' : ''}`}
                  disabled={isLoading}
                  maxLength={128}
                />
                {getFieldProps('password').error && (
                  <p className="text-red-500 text-xs mt-1">{getFieldProps('password').error}</p>
                )}
              </div>
              <Button 
                type="submit" 
                className="w-full gradient-brand text-white hover:opacity-90 transition-opacity"
                disabled={isLoading || hasErrors}
              >
                {isLoading ? "Processando..." : (isSignUp ? "Criar Conta" : "Entrar")}
              </Button>
            </form>

            <div className="mt-6 text-center">
              <button
                onClick={() => setIsSignUp(!isSignUp)}
                className="text-sm text-brand-orange hover:underline"
                disabled={isLoading}
              >
                {isSignUp ? "Já tem uma conta? Faça login" : "Não tem uma conta? Cadastre-se"}
              </button>
            </div>
          </CardContent>
        </Card>

        <div className="mt-8 text-center">
          <p className="text-white/60 text-sm">
            © 2024 LoveMenu. Feito com ❤️ para transformar seu negócio.
          </p>
        </div>
      </div>
    </div>
  );
}
