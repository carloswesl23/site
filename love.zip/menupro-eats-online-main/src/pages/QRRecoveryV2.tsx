import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { AlertTriangle } from "lucide-react";
import { Button } from "@/components/ui/button";
import { useNavigate } from "react-router-dom";

export default function QRRecoveryV2() {
  const navigate = useNavigate();

  return (
    <div className="container mx-auto py-8 space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold">QR Recovery 2.0</h1>
          <p className="text-muted-foreground">
            Funcionalidade temporariamente desativada
          </p>
        </div>
      </div>

      {/* Aviso de Desativação */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <AlertTriangle className="w-5 h-5 text-orange-500" />
            Funcionalidade Desativada
            <Badge variant="secondary">Temporário</Badge>
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            <p className="text-muted-foreground">
              A funcionalidade QR Recovery 2.0 foi temporariamente desativada.
            </p>
            <p className="text-muted-foreground">
              Por favor, use a funcionalidade WhatsApp principal no menu lateral.
            </p>
            <Button onClick={() => navigate('/whatsapp')} className="mt-4">
              Ir para WhatsApp Principal
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}