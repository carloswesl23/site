
import { DashboardStats } from "@/components/DashboardStats";
import { RecentOrders } from "@/components/RecentOrders";
import { QuickActions } from "@/components/QuickActions";
import { StoreStatusControl } from "@/components/Settings/StoreStatusControl";

export default function Dashboard() {
  return (
    <div className="flex-1 space-y-6 p-6 bg-gray-50 min-h-screen">
      <div className="flex flex-col md:flex-row md:items-center md:justify-between">
        <div>
          <h1 className="text-3xl font-bold text-brand-dark">Dashboard</h1>
          <p className="text-gray-600 mt-1">Bem-vindo de volta! Aqui está o resumo do seu negócio hoje.</p>
        </div>
        <div className="mt-4 md:mt-0">
          <div className="text-sm text-gray-500">
            Última atualização: {new Date().toLocaleTimeString('pt-BR')}
          </div>
        </div>
      </div>

      <div className="mb-6">
        <StoreStatusControl />
      </div>

      <DashboardStats />

      <div className="grid gap-6 md:grid-cols-2">
        <RecentOrders />
        <QuickActions />
      </div>
    </div>
  );
}
