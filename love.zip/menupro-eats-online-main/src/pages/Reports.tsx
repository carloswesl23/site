import { useState, useMemo, useEffect } from "react";
import { subDays, startOfDay, endOfDay, isWithinInterval, startOfMonth, endOfMonth, startOfYear, endOfYear } from "date-fns";
import { supabase } from "@/integrations/supabase/client";
import { useToast } from "@/hooks/use-toast";
import { useReportsData } from "@/hooks/useReportsData";
import { ReportsHeader } from "@/components/Reports/ReportsHeader";
import { ReportsKPICards } from "@/components/Reports/ReportsKPICards";
import { ReportsSecondaryKPIs } from "@/components/Reports/ReportsSecondaryKPIs";
import { ReportsCharts } from "@/components/Reports/ReportsCharts";
import { TopProductsSection } from "@/components/Reports/TopProductsSection";
import { TopCombosSection } from "@/components/Reports/TopCombosSection";

interface TopProduct {
  id: string;
  name: string;
  vendas: number;
  image: string | null;
  category: string;
}

// Sample data - in a real app, this would come from your database
const allSalesData = [
  { name: "Jan", vendas: 65000, pedidos: 150, receita: 58500, date: new Date(2024, 0, 15) },
  { name: "Fev", vendas: 78000, pedidos: 180, receita: 70200, date: new Date(2024, 1, 15) },
  { name: "Mar", vendas: 52000, pedidos: 120, receita: 46800, date: new Date(2024, 2, 15) },
  { name: "Abr", vendas: 91000, pedidos: 210, receita: 81900, date: new Date(2024, 3, 15) },
  { name: "Mai", vendas: 105000, pedidos: 240, receita: 94500, date: new Date(2024, 4, 15) },
  { name: "Jun", vendas: 88000, pedidos: 200, receita: 79200, date: new Date(2024, 5, 15) },
];

const allWeeklyData = [
  { name: "Seg", vendas: 12000, conversao: 3.2, visualizacoes: 450, date: subDays(new Date(), 6) },
  { name: "Ter", vendas: 19000, conversao: 4.1, visualizacoes: 520, date: subDays(new Date(), 5) },
  { name: "Qua", vendas: 8000, conversao: 2.8, visualizacoes: 380, date: subDays(new Date(), 4) },
  { name: "Qui", vendas: 21000, conversao: 4.8, visualizacoes: 580, date: subDays(new Date(), 3) },
  { name: "Sex", vendas: 28000, conversao: 5.2, visualizacoes: 650, date: subDays(new Date(), 2) },
  { name: "Sáb", vendas: 32000, conversao: 6.1, visualizacoes: 720, date: subDays(new Date(), 1) },
  { name: "Dom", vendas: 24000, conversao: 4.5, visualizacoes: 480, date: new Date() }
];

export default function Reports() {
  const [periodFilter, setPeriodFilter] = useState("mes");
  const [customDateFrom, setCustomDateFrom] = useState<Date>();
  const [customDateTo, setCustomDateTo] = useState<Date>();
  const [isCustomDateOpen, setIsCustomDateOpen] = useState(false);
  const [topProducts, setTopProducts] = useState<TopProduct[]>([]);
  const [topCombos, setTopCombos] = useState<TopProduct[]>([]);
  const { toast } = useToast();

  // Filter data based on selected period
  const getDateRange = () => {
    const now = new Date();
    switch (periodFilter) {
      case "dia":
        return { start: startOfDay(now), end: endOfDay(now) };
      case "ontem":
        const yesterday = subDays(now, 1);
        return { start: startOfDay(yesterday), end: endOfDay(yesterday) };
      case "semana":
        const weekStart = subDays(now, 6);
        return { start: startOfDay(weekStart), end: endOfDay(now) };
      case "mes":
        return { start: startOfMonth(now), end: endOfMonth(now) };
      case "ano":
        return { start: startOfYear(now), end: endOfYear(now) };
      case "personalizado":
        if (customDateFrom && customDateTo) {
          return { start: startOfDay(customDateFrom), end: endOfDay(customDateTo) };
        }
        return { start: startOfMonth(now), end: endOfMonth(now) };
      default:
        return { start: startOfMonth(now), end: endOfMonth(now) };
    }
  };

  // Buscar dados reais dos relatórios
  const { data: reportsData, loading: reportsLoading } = useReportsData(
    getDateRange().start,
    getDateRange().end
  );

  // Fetch real data for top products and combos
  useEffect(() => {
    const fetchTopProducts = async () => {
      try {
        const { data: { user } } = await supabase.auth.getUser();
        if (!user) return;

        const { start, end } = getDateRange();

        // Buscar todos os pedidos do período
        const { data: orders, error } = await supabase
          .from('user_orders')
          .select('items, created_at')
          .eq('user_id', user.id)
          .gte('created_at', start.toISOString())
          .lte('created_at', end.toISOString());

        if (error) throw error;

        // Processar itens dos pedidos para contar vendas por produto
        const productSales: { [key: string]: { name: string; vendas: number; image: string | null; category: string; } } = {};
        const comboSales: { [key: string]: { name: string; vendas: number; image: string | null; category: string; } } = {};

        orders?.forEach(order => {
          if (Array.isArray(order.items)) {
            order.items.forEach((item: any) => {
              const key = `${item.name}_${item.category || ''}`;
              const isCombo = item.name.toLowerCase().includes('combo') || 
                            item.category?.toLowerCase().includes('combo');
              
              if (isCombo) {
                if (!comboSales[key]) {
                  comboSales[key] = {
                    name: item.name,
                    vendas: 0,
                    image: item.image || 'https://images.unsplash.com/photo-1572802419224-296b0aeee0d9?w=80&h=80&fit=crop',
                    category: item.category || 'Combos'
                  };
                }
                comboSales[key].vendas += item.quantity || 1;
              } else {
                if (!productSales[key]) {
                  productSales[key] = {
                    name: item.name,
                    vendas: 0,
                    image: item.image || 'https://images.unsplash.com/photo-1568901346375-23c9450c58cd?w=80&h=80&fit=crop',
                    category: item.category || 'Produtos'
                  };
                }
                productSales[key].vendas += item.quantity || 1;
              }
            });
          }
        });

        // Converter para arrays e ordenar por vendas
        const topProductsArray = Object.entries(productSales)
          .map(([key, data]) => ({ id: key, ...data }))
          .sort((a, b) => b.vendas - a.vendas)
          .slice(0, 5);

        const topCombosArray = Object.entries(comboSales)
          .map(([key, data]) => ({ id: key, ...data }))
          .sort((a, b) => b.vendas - a.vendas)
          .slice(0, 5);

        setTopProducts(topProductsArray);
        setTopCombos(topCombosArray);

      } catch (error) {
        console.error('Error fetching top products:', error);
        toast({
          title: "Erro ao carregar produtos",
          description: "Não foi possível carregar os dados dos produtos mais vendidos.",
          variant: "destructive",
        });
      }
    };

    fetchTopProducts();
  }, [periodFilter, customDateFrom, customDateTo, toast]);

  const filteredData = useMemo(() => {
    const { start, end } = getDateRange();
    
    const filteredSales = allSalesData.filter(item => 
      isWithinInterval(item.date, { start, end })
    );
    
    const filteredWeekly = allWeeklyData.filter(item => 
      isWithinInterval(item.date, { start, end })
    );

    // Calculate filtered KPIs - TODO: Replace with real data from user_orders
    const totalVendas = filteredSales.reduce((sum, item) => sum + item.vendas, 0);
    const totalPedidos = filteredSales.reduce((sum, item) => sum + item.pedidos, 0);
    const totalReceita = filteredSales.reduce((sum, item) => sum + item.receita, 0);
    const ticketMedio = totalPedidos > 0 ? totalVendas / totalPedidos : 0;
    const totalVisualizacoes = filteredWeekly.reduce((sum, item) => sum + item.visualizacoes, 0);

    return {
      salesData: filteredSales,
      weeklyData: filteredWeekly,
      kpis: {
        totalVendas,
        totalPedidos,
        totalReceita,
        ticketMedio,
        totalVisualizacoes,
        taxaConversaoPix: 89.7,
        taxaCancelamento: 2.8,
        clientesRecorrentes: 67.3,
        conversaoGeral: 6.2
      }
    };
  }, [periodFilter, customDateFrom, customDateTo]);

  return (
    <div className="flex-1 space-y-6 p-6 bg-background min-h-screen">
      {/* Header with Filters */}
      <ReportsHeader
        periodFilter={periodFilter}
        setPeriodFilter={setPeriodFilter}
        customDateFrom={customDateFrom}
        setCustomDateFrom={setCustomDateFrom}
        customDateTo={customDateTo}
        setCustomDateTo={setCustomDateTo}
        isCustomDateOpen={isCustomDateOpen}
        setIsCustomDateOpen={setIsCustomDateOpen}
      />

      {/* Main KPI Cards */}
      <ReportsKPICards 
        vendas={reportsData.vendas}
        receitaConfirmada={reportsData.receitaConfirmada}
        ticketMedio={reportsData.ticketMedio}
        taxaConversaoPix={reportsData.taxaConversaoPix}
        totalPedidos={reportsData.totalPedidos}
        pedidosPix={reportsData.pedidosPix}
      />

      {/* Secondary KPI Cards */}
      <ReportsSecondaryKPIs 
        taxaCancelamento={reportsData.taxaCancelamento}
        clientesRecorrentes={reportsData.clientesRecorrentes}
        visualizacoesCardapio={reportsData.visualizacoesCardapio}
        conversaoGeral={reportsData.conversaoGeral}
        clientesRecorrentesQtd={reportsData.clientesRecorrentesQtd}
        clientesTotais={reportsData.clientesTotais}
        totalPedidos={reportsData.totalPedidos}
      />

      {/* Charts Section */}
      <ReportsCharts 
        salesData={filteredData.salesData} 
        weeklyData={filteredData.weeklyData} 
      />

      {/* Top Products and Combos */}
      <div className="grid gap-6 lg:grid-cols-2">
        <TopProductsSection products={topProducts} />
        <TopCombosSection combos={topCombos} />
      </div>
    </div>
  );
}