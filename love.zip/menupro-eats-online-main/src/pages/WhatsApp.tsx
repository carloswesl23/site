import { WhatsAppBot } from "@/components/WhatsApp/WhatsAppBot";

const WhatsApp = () => {
  return <WhatsAppBot />;
};

export default WhatsApp;