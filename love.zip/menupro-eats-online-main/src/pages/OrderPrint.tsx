import { useEffect, useState } from "react";
import { useParams } from "react-router-dom";
import { supabase } from "@/integrations/supabase/client";
import { QRCodeSVG } from "qrcode.react";

interface Order {
  id: string;
  order_number: string;
  customer_name: string;
  customer_phone: string | null;
  customer_email: string | null;
  delivery_address: string | null;
  payment_method: string | null;
  total: number;
  status: string;
  items: any[];
  notes: string | null;
  created_at: string;
}

interface EstablishmentSettings {
  business_name: string;
  business_phone: string | null;
  business_address: string | null;
}

export default function OrderPrint() {
  const { id } = useParams<{ id: string }>();
  const [order, setOrder] = useState<Order | null>(null);
  const [establishment, setEstablishment] = useState<EstablishmentSettings | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (id) {
      fetchOrderData();
    }
  }, [id]);

  const fetchOrderData = async () => {
    try {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) return;

      // Buscar dados do pedido
      const { data: orderData, error: orderError } = await supabase
        .from('user_orders')
        .select('*')
        .eq('id', id)
        .eq('user_id', user.id)
        .single();

      if (orderError) throw orderError;

      // Buscar dados do estabelecimento
      const { data: establishmentData, error: establishmentError } = await supabase
        .from('establishment_settings')
        .select('business_name, business_phone, business_address')
        .eq('user_id', user.id)
        .single();

      if (establishmentError) throw establishmentError;

      // Processar items se vier como string
      const processedOrder = {
        ...orderData,
        items: Array.isArray(orderData.items) 
          ? orderData.items 
          : typeof orderData.items === 'string' 
            ? JSON.parse(orderData.items) 
            : []
      };
      
      setOrder(processedOrder);
      setEstablishment(establishmentData);
    } catch (error) {
      console.error('Error fetching order data:', error);
    } finally {
      setLoading(false);
    }
  };

  const formatDateTime = (dateString: string) => {
    const date = new Date(dateString);
    return date.toLocaleString('pt-BR', {
      day: '2-digit',
      month: '2-digit',
      year: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    });
  };

  const calculateItemTotal = (item: any) => {
    const basePrice = item.price || 0;
    const addonsTotal = (item.selectedAddons || []).reduce((sum: number, addon: any) => {
      return sum + (addon.price || 0);
    }, 0);
    return (basePrice + addonsTotal) * (item.quantity || 1);
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-orange-500"></div>
      </div>
    );
  }

  if (!order || !establishment) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="text-center">
          <h1 className="text-xl font-bold mb-2">Pedido não encontrado</h1>
          <p className="text-gray-600">O pedido solicitado não foi encontrado.</p>
        </div>
      </div>
    );
  }

  return (
    <>
      <style>
        {`
          @page { 
            size: 80mm auto; 
            margin: 0;
          }
          @media print {
            body { 
              margin: 0;
              padding: 0;
              font-size: 12px;
              line-height: 1.3;
            }
            .print-hint { 
              display: none !important; 
            }
            .no-print { 
              display: none !important; 
            }
          }
          @media screen {
            .print-hint {
              background: #fff3cd;
              padding: 12px;
              border: 1px solid #ffe08a;
              margin-bottom: 16px;
              border-radius: 4px;
            }
          }
        `}
      </style>
      
      <div className="max-w-sm mx-auto bg-white p-4">
        <div className="print-hint no-print">
          <p className="text-sm text-yellow-800 font-medium">
            Pré-visualização de impressão
          </p>
          <p className="text-xs text-yellow-700 mt-1">
            Esta página está otimizada para impressoras térmicas de 80mm
          </p>
        </div>

        <div className="text-center mb-4">
          <h1 className="text-lg font-bold mb-1">{establishment.business_name}</h1>
          {establishment.business_phone && (
            <p className="text-sm text-gray-600">{establishment.business_phone}</p>
          )}
          {establishment.business_address && (
            <p className="text-xs text-gray-500 mt-1">{establishment.business_address}</p>
          )}
        </div>

        <div className="border-t border-dashed border-gray-400 pt-3 mb-3">
          <h2 className="text-base font-bold mb-2">Pedido #{order.order_number}</h2>
          <div className="text-sm space-y-1">
            <div className="flex justify-between">
              <span>Data/Hora:</span>
              <span>{formatDateTime(order.created_at)}</span>
            </div>
            <div className="flex justify-between">
              <span>Cliente:</span>
              <span className="font-medium">{order.customer_name}</span>
            </div>
            {order.customer_phone && (
              <div className="flex justify-between">
                <span>Telefone:</span>
                <span>{order.customer_phone}</span>
              </div>
            )}
          </div>
        </div>

        {order.delivery_address && (
          <div className="mb-3">
            <h3 className="text-sm font-medium mb-1">Endereço de Entrega:</h3>
            <p className="text-xs text-gray-600">{order.delivery_address}</p>
          </div>
        )}

        <div className="border-t border-dashed border-gray-400 pt-3 mb-3">
          <h3 className="text-sm font-medium mb-2">Itens do Pedido</h3>
          <div className="space-y-2">
            {order.items.map((item, index) => (
              <div key={index} className="text-sm">
                <div className="flex justify-between">
                  <span>{item.quantity}x {item.name}</span>
                  <span>R$ {calculateItemTotal(item).toFixed(2)}</span>
                </div>
                {item.selectedAddons && item.selectedAddons.length > 0 && (
                  <div className="ml-4 text-xs text-gray-600">
                    {item.selectedAddons.map((addon: any, addonIndex: number) => (
                      <div key={addonIndex}>+ {addon.name} (+R$ {addon.price.toFixed(2)})</div>
                    ))}
                  </div>
                )}
                {item.notes && (
                  <div className="ml-4 text-xs text-gray-600 italic">
                    Obs: {item.notes}
                  </div>
                )}
              </div>
            ))}
          </div>
        </div>

        <div className="border-t border-dashed border-gray-400 pt-3 mb-3">
          <div className="flex justify-between text-sm mb-1">
            <span>Pagamento:</span>
            <span>{order.payment_method || 'Não informado'}</span>
          </div>
          <div className="flex justify-between text-base font-bold">
            <span>Total:</span>
            <span>R$ {order.total.toFixed(2)}</span>
          </div>
        </div>

        {order.notes && (
          <div className="mb-3">
            <h3 className="text-sm font-medium mb-1">Observações:</h3>
            <p className="text-xs text-gray-600">{order.notes}</p>
          </div>
        )}

        <div className="text-center mt-4">
          <QRCodeSVG 
            value={`${window.location.origin}/track/${order.order_number}`}
            size={100}
          />
          <p className="text-xs text-gray-500 mt-2">
            Acompanhe seu pedido
          </p>
        </div>

        <div className="text-center mt-4 pt-3 border-t border-dashed border-gray-400">
          <p className="text-xs text-gray-500">Obrigado pela preferência! 💛</p>
          <p className="text-xs text-gray-400 mt-1">Powered by LoveMenu</p>
        </div>
      </div>

      <div className="no-print text-center mt-6 space-x-4">
        <button
          onClick={() => window.print()}
          className="bg-orange-500 text-white px-6 py-2 rounded hover:bg-orange-600"
        >
          Imprimir Pedido
        </button>
        <button
          onClick={() => window.close()}
          className="bg-gray-500 text-white px-6 py-2 rounded hover:bg-gray-600"
        >
          Fechar
        </button>
      </div>
    </>
  );
}