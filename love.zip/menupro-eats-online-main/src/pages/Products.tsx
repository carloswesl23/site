import { useState } from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { useToast } from "@/hooks/use-toast";
import { useUserData } from "@/hooks/useUserData";
import { ProductActions } from "@/components/Products/ProductActions";
import { ProductFilters } from "@/components/Products/ProductFilters";
import { ProductGrid } from "@/components/Products/ProductGrid";
import { ProductModal } from "@/components/Products/ProductModal";
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle } from "@/components/ui/alert-dialog";

export default function Products() {
  const [searchTerm, setSearchTerm] = useState("");
  const [selectedCategory, setSelectedCategory] = useState("Todas Categorias");
  const [productModalOpen, setProductModalOpen] = useState(false);
  const [editingProduct, setEditingProduct] = useState<any>(null);
  const [deleteDialogOpen, setDeleteDialogOpen] = useState(false);
  const [productToDelete, setProductToDelete] = useState<string | null>(null);
  const [modalLoading, setModalLoading] = useState(false);
  
  const { toast } = useToast();
  const { products, categories, settings, isLoading, addProduct, updateProduct, deleteProduct } = useUserData();
  
  const filteredProducts = products.filter(product => {
    const matchesSearch = product.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      product.category.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesCategory = selectedCategory === "Todas Categorias" || product.category === selectedCategory;
    return matchesSearch && matchesCategory;
  });

  const categoryNames = categories.map(cat => cat.name);

  const toggleOnlineMenu = async (productId: string) => {
    try {
      const product = products.find(p => p.id === productId);
      if (!product) return;

      await updateProduct(productId, {
        show_online_menu: !product.show_online_menu
      });
    } catch (error) {
      console.error('Error updating product:', error);
    }
  };

  const handleCopyLink = async () => {
    if (!settings?.online_menu_slug) {
      toast({
        title: "Link não disponível",
        description: "Configure primeiro o slug do seu estabelecimento.",
        variant: "destructive"
      });
      return;
    }
    
    const onlineMenuUrl = `https://lovemenu.com.br/${settings.online_menu_slug}`;
    navigator.clipboard.writeText(onlineMenuUrl);
    toast({
      title: "Link copiado!",
      description: "O link do cardápio foi copiado para a área de transferência.",
    });
  };

  const handleNewProduct = () => {
    setEditingProduct(null);
    setProductModalOpen(true);
  };

  const handleEditProduct = (productId: string) => {
    const product = products.find(p => p.id === productId);
    if (product) {
      setEditingProduct(product);
      setProductModalOpen(true);
    }
  };

  const handleDeleteProduct = (productId: string) => {
    setProductToDelete(productId);
    setDeleteDialogOpen(true);
  };

  const confirmDeleteProduct = async () => {
    if (!productToDelete) return;
    
    try {
      await deleteProduct(productToDelete);
      setDeleteDialogOpen(false);
      setProductToDelete(null);
    } catch (error) {
      console.error('Error deleting product:', error);
    }
  };

  const handleProductSubmit = async (data: any) => {
    setModalLoading(true);
    try {
      if (editingProduct) {
        // Atualizar produto existente
        await updateProduct(editingProduct.id, data);
      } else {
        // Criar novo produto
        await addProduct(data);
      }
      setProductModalOpen(false);
      setEditingProduct(null);
    } catch (error) {
      console.error('Error submitting product:', error);
    } finally {
      setModalLoading(false);
    }
  };

  return (
    <div className="flex-1 space-y-6 p-6 bg-gray-50 min-h-screen">
      <div className="flex flex-col md:flex-row md:items-center md:justify-between">
        <div>
          <h1 className="text-3xl font-bold text-brand-dark">Produtos</h1>
          <p className="text-gray-600 mt-1">Gerencie seu cardápio e promoções</p>
        </div>
        <ProductActions categories={categories} settings={settings} onNewProduct={handleNewProduct} />
      </div>

      {/* Link do Cardápio Online */}
      <Card className="bg-gradient-to-r from-blue-50 to-indigo-50 border-blue-200">
        <CardContent className="p-4">
          <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
            <div className="flex flex-col">
              <Label className="text-sm font-medium mb-2">Link do Cardápio Online:</Label>
              <div className="flex items-center gap-2">
                <div className="flex-1 p-3 bg-gray-100 rounded-md font-mono text-sm break-all">
                  {settings?.online_menu_slug ? (
                    `https://lovemenu.com.br/${settings.online_menu_slug}`
                  ) : (
                    <span className="text-gray-500">Configure o slug nas Configurações primeiro</span>
                  )}
                </div>
              </div>
            </div>
            <div className="flex gap-2">
              <Button 
                variant="outline" 
                size="sm" 
                onClick={handleCopyLink}
                disabled={!settings?.online_menu_slug}
              >
                Copiar Link
              </Button>
              {!settings?.online_menu_slug && (
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => window.location.href = '/settings'}
                >
                  Configurar Slug
                </Button>
              )}
            </div>
          </div>
        </CardContent>
      </Card>

      <ProductFilters
        searchTerm={searchTerm}
        setSearchTerm={setSearchTerm}
        selectedCategory={selectedCategory}
        setSelectedCategory={setSelectedCategory}
        categories={categories}
      />

      <ProductGrid
        products={filteredProducts}
        isLoading={isLoading}
        searchTerm={searchTerm}
        selectedCategory={selectedCategory}
        onToggleOnlineMenu={toggleOnlineMenu}
        onEditProduct={handleEditProduct}
        onDeleteProduct={handleDeleteProduct}
        onNewProduct={handleNewProduct}
      />

      {/* Modal de Produto */}
      <ProductModal
        isOpen={productModalOpen}
        onClose={() => {
          setProductModalOpen(false);
          setEditingProduct(null);
        }}
        onSubmit={handleProductSubmit}
        product={editingProduct}
        categories={categoryNames}
        loading={modalLoading}
      />

      {/* Diálogo de Confirmação de Exclusão */}
      <AlertDialog open={deleteDialogOpen} onOpenChange={setDeleteDialogOpen}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Confirmar Exclusão</AlertDialogTitle>
            <AlertDialogDescription>
              Tem certeza que deseja excluir este produto? Esta ação não pode ser desfeita e o produto será removido do cardápio online.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancelar</AlertDialogCancel>
            <AlertDialogAction onClick={confirmDeleteProduct} className="bg-red-600 hover:bg-red-700">
              Excluir
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}