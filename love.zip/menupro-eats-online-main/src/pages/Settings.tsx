
import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Switch } from "@/components/ui/switch";
import { Textarea } from "@/components/ui/textarea";
import { Smartphone, CreditCard, Bell, Palette, Globe, Save } from "lucide-react";
import { WebhookManager } from "@/components/Webhooks/WebhookManager";
import { PaymentConfigModal } from "@/components/Settings/PaymentConfigModal";
import { GoogleAnalyticsModal } from "@/components/Settings/GoogleAnalyticsModal";
import { PreparationTimeSettings } from "@/components/PreparationTime/PreparationTimeSettings";
import { PrintSettings } from "@/components/Settings/PrintSettings";
import { StoreStatusControl } from "@/components/Settings/StoreStatusControl";

import { GeneralSettings } from "@/components/Settings/GeneralSettings";
import { CheckoutSettings } from "@/components/Settings/CheckoutSettings";
import { WhatsAppMessageSettings } from "@/components/Settings/WhatsAppMessageSettings";
import { useUserData } from "@/hooks/useUserData";
import { useToast } from "@/hooks/use-toast";
import { supabase } from '@/integrations/supabase/client';

export default function Settings() {
  const { settings, updateSettings } = useUserData();
  const { toast } = useToast();
  const [currentUserId, setCurrentUserId] = useState<string>('');
  
  const [whatsappNumber, setWhatsappNumber] = useState("");
  const [notificationsEnabled, setNotificationsEnabled] = useState(true);
  const [autoConfirmOrders, setAutoConfirmOrders] = useState(false);

  // Load current user ID
  useEffect(() => {
    const getCurrentUser = async () => {
      const { data: { user } } = await supabase.auth.getUser();
      if (user) {
        setCurrentUserId(user.id);
      }
    };
    getCurrentUser();
  }, []);

  // Load settings when component mounts
  useEffect(() => {
    if (settings) {
      setWhatsappNumber(settings.business_phone || "");
    }
  }, [settings]);

  // Modal states
  const [pixModalOpen, setPixModalOpen] = useState(false);
  const [mercadoPagoModalOpen, setMercadoPagoModalOpen] = useState(false);
  const [facebookModalOpen, setFacebookModalOpen] = useState(false);
  const [analyticsModalOpen, setAnalyticsModalOpen] = useState(false);

  // Handle WhatsApp settings save
  const handleSaveWhatsAppSettings = async () => {
    try {
      await updateSettings({
        business_phone: whatsappNumber
      });
      
      toast({
        title: "Configurações salvas!",
        description: "Suas configurações foram atualizadas com sucesso.",
      });
    } catch (error) {
      console.error('Error saving settings:', error);
      toast({
        title: "Erro ao salvar",
        description: "Não foi possível salvar as configurações. Tente novamente.",
        variant: "destructive",
      });
    }
  };

  return (
    <div className="flex-1 space-y-6 p-6 bg-gray-50 min-h-screen">
      <div className="flex flex-col md:flex-row md:items-center md:justify-between">
        <div>
          <h1 className="text-3xl font-bold text-brand-dark">Configurações</h1>
          <p className="text-gray-600 mt-1">Configure seu estabelecimento e preferências do sistema</p>
        </div>
      </div>

      <Tabs defaultValue="general" className="space-y-6">
        <TabsList className="grid w-full grid-cols-2 md:grid-cols-8">
          <TabsTrigger value="general">Geral</TabsTrigger>
          <TabsTrigger value="whatsapp">WhatsApp</TabsTrigger>
          <TabsTrigger value="preparation">Tempo Preparo</TabsTrigger>
          <TabsTrigger value="print">Impressão</TabsTrigger>
          <TabsTrigger value="checkout">Checkout</TabsTrigger>
          <TabsTrigger value="appearance">Aparência</TabsTrigger>
          <TabsTrigger value="notifications">Notificações</TabsTrigger>
          <TabsTrigger value="integrations">Integrações</TabsTrigger>
          <TabsTrigger value="webhooks">Webhooks</TabsTrigger>
        </TabsList>

        <TabsContent value="general" className="space-y-6">
          <StoreStatusControl />
          <GeneralSettings settings={settings} onUpdateSettings={updateSettings} />
        </TabsContent>

        <TabsContent value="whatsapp" className="space-y-6">
          <WhatsAppMessageSettings />
        </TabsContent>

        <TabsContent value="preparation" className="space-y-6">
          <PreparationTimeSettings />
        </TabsContent>

        <TabsContent value="print" className="space-y-6">
          <PrintSettings />
        </TabsContent>

        <TabsContent value="checkout" className="space-y-6">
          <CheckoutSettings settings={settings} onUpdateSettings={updateSettings} />
        </TabsContent>

        <TabsContent value="appearance" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Palette className="w-5 h-5" />
                Personalização Visual
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-4">
                <div>
                  <Label>Cores da Marca</Label>
                  <div className="grid grid-cols-3 gap-4 mt-2">
                    <div className="space-y-2">
                      <Label className="text-sm">Cor Principal</Label>
                      <div className="flex items-center gap-2">
                        <div className="w-8 h-8 bg-brand-orange rounded border"></div>
                        <Input value="#ff6b35" className="flex-1" />
                      </div>
                    </div>
                    <div className="space-y-2">
                      <Label className="text-sm">Cor Secundária</Label>
                      <div className="flex items-center gap-2">
                        <div className="w-8 h-8 bg-brand-red rounded border"></div>
                        <Input value="#ff4757" className="flex-1" />
                      </div>
                    </div>
                    <div className="space-y-2">
                      <Label className="text-sm">Cor de Destaque</Label>
                      <div className="flex items-center gap-2">
                        <div className="w-8 h-8 bg-brand-dark rounded border"></div>
                        <Input value="#1a1a1a" className="flex-1" />
                      </div>
                    </div>
                  </div>
                </div>

                <div className="space-y-2">
                  <Label>Fonte Personalizada</Label>
                  <Input placeholder="URL da fonte ou nome" />
                </div>
              </div>

              <Button className="gradient-brand text-white">
                <Save className="w-4 h-4 mr-2" />
                Aplicar Personalização
              </Button>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="notifications" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Bell className="w-5 h-5" />
                Configurações de Notificações
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-4">
                <div className="flex items-center justify-between">
                  <div className="space-y-0.5">
                    <Label>Notificações de Pedidos</Label>
                    <p className="text-sm text-gray-500">
                      Receber notificações quando houver novos pedidos
                    </p>
                  </div>
                  <Switch
                    checked={notificationsEnabled}
                    onCheckedChange={setNotificationsEnabled}
                  />
                </div>

                <div className="flex items-center justify-between">
                  <div className="space-y-0.5">
                    <Label>Email de Vendas Diárias</Label>
                    <p className="text-sm text-gray-500">
                      Relatório diário enviado por email
                    </p>
                  </div>
                  <Switch defaultChecked />
                </div>

                <div className="flex items-center justify-between">
                  <div className="space-y-0.5">
                    <Label>Alertas de Estoque Baixo</Label>
                    <p className="text-sm text-gray-500">
                      Notificação quando produtos estiverem em falta
                    </p>
                  </div>
                  <Switch defaultChecked />
                </div>
              </div>

              <Button className="gradient-brand text-white">
                <Save className="w-4 h-4 mr-2" />
                Salvar Preferências
              </Button>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="integrations" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <CreditCard className="w-5 h-5" />
                Integrações e Pagamentos
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-4">
                <div className="flex items-center justify-between p-4 border rounded-lg">
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 bg-green-100 rounded-lg flex items-center justify-center">
                      <span className="text-green-600 font-bold">PIX</span>
                    </div>
                    <div>
                      <h3 className="font-medium">PIX</h3>
                      <p className="text-sm text-gray-500">Pagamento instantâneo</p>
                    </div>
                  </div>
                  <Button variant="outline" size="sm" onClick={() => setPixModalOpen(true)}>
                    Configurar
                  </Button>
                </div>

                <div className="flex items-center justify-between p-4 border rounded-lg">
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 bg-blue-100 rounded-lg flex items-center justify-center">
                      <CreditCard className="w-5 h-5 text-blue-600" />
                    </div>
                    <div>
                      <h3 className="font-medium">Mercado Pago</h3>
                      <p className="text-sm text-gray-500">Cartões e outros métodos</p>
                    </div>
                  </div>
                  <Button variant="outline" size="sm" onClick={() => setMercadoPagoModalOpen(true)}>
                    Configurar
                  </Button>
                </div>

                <div className="flex items-center justify-between p-4 border rounded-lg">
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 bg-orange-100 rounded-lg flex items-center justify-center">
                      <Globe className="w-5 h-5 text-orange-600" />
                    </div>
                    <div>
                      <h3 className="font-medium">Google Analytics</h3>
                      <p className="text-sm text-gray-500">Rastreamento de conversões</p>
                    </div>
                  </div>
                  <Button variant="outline" size="sm" onClick={() => setAnalyticsModalOpen(true)}>
                    Configurar
                  </Button>
                </div>

                <div className="flex items-center justify-between p-4 border rounded-lg">
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 bg-blue-100 rounded-lg flex items-center justify-center">
                      <span className="text-blue-600 font-bold">FB</span>
                    </div>
                    <div>
                      <h3 className="font-medium">Facebook Pixel</h3>
                      <p className="text-sm text-gray-500">Pixel para anúncios</p>
                    </div>
                  </div>
                  <Button variant="outline" size="sm" onClick={() => setFacebookModalOpen(true)}>
                    Configurar
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="webhooks" className="space-y-6">
          <WebhookManager />
        </TabsContent>
      </Tabs>

      {/* Modals */}
      <PaymentConfigModal 
        isOpen={pixModalOpen} 
        onClose={() => setPixModalOpen(false)} 
        type="pix" 
      />
      
      <PaymentConfigModal 
        isOpen={mercadoPagoModalOpen} 
        onClose={() => setMercadoPagoModalOpen(false)} 
        type="mercadopago" 
      />
      
      <PaymentConfigModal 
        isOpen={facebookModalOpen} 
        onClose={() => setFacebookModalOpen(false)} 
        type="facebook" 
      />
      
      <GoogleAnalyticsModal 
        isOpen={analyticsModalOpen} 
        onClose={() => setAnalyticsModalOpen(false)} 
      />
    </div>
  );
}
