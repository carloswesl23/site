import React, { useState, useEffect } from 'react';
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { useToast } from "@/hooks/use-toast";
import { supabase } from "@/integrations/supabase/client";
import { WhatsAppConnection } from "@/components/WhatsApp/WhatsAppConnection";
import { WhatsAppInbox } from "@/components/WhatsApp/WhatsAppInbox";
import { WhatsAppBroadcast } from "@/components/WhatsApp/WhatsAppBroadcast";
import { WhatsAppReports } from "@/components/WhatsApp/WhatsAppReports";
import { Smartphone, MessageCircle, Send, BarChart3 } from "lucide-react";

interface WhatsAppInstance {
  id: string;
  instance_id: string;
  token_instance: string;
  status: string;
  qr_code?: string;
  numero_cliente?: string;
  device_pushname?: string;
  device_phone?: string;
  device_battery?: string;
  device_plugged?: string;
  updated_at: string;
}

export default function WhatsAppV2() {
  const [activeTab, setActiveTab] = useState("connection");
  const [instance, setInstance] = useState<WhatsAppInstance | null>(null);
  const [loading, setLoading] = useState(true);
  const { toast } = useToast();

  const fetchInstance = async () => {
    try {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) return;

      const { data, error } = await supabase
        .from("whatsapp_instances")
        .select("*")
        .eq("user_id", user.id)
        .order("updated_at", { ascending: false })
        .limit(1)
        .maybeSingle();

      if (error) throw error;
      setInstance(data);
    } catch (error) {
      console.error("Error fetching instance:", error);
      toast({
        title: "Erro",
        description: "Erro ao carregar instância do WhatsApp",
        variant: "destructive"
      });
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchInstance();
  }, []);

  // Auto-switch to inbox when connected
  useEffect(() => {
    if (instance?.status === 'connected' && activeTab === 'connection') {
      setActiveTab('inbox');
    }
  }, [instance?.status, activeTab]);

  if (loading) {
    return (
      <div className="container mx-auto py-8">
        <div className="flex items-center justify-center h-64">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div>
        </div>
      </div>
    );
  }

  const getStatusBadge = (status: string) => {
    const variants: { [key: string]: "default" | "secondary" | "destructive" | "outline" } = {
      'connected': 'default',
      'qrcode': 'secondary',
      'disconnected': 'destructive',
      'expired': 'destructive'
    };

    const labels: { [key: string]: string } = {
      'connected': 'Conectado',
      'qrcode': 'Aguardando QR',
      'disconnected': 'Desconectado',
      'expired': 'Expirado'
    };

    return (
      <Badge variant={variants[status] || 'secondary'}>
        {labels[status] || status}
      </Badge>
    );
  };

  return (
    <div className="container mx-auto py-8 space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold">WhatsApp Business</h1>
          <p className="text-muted-foreground">
            Central de mensagens e automação
          </p>
        </div>
        {instance && (
          <div className="flex items-center gap-4">
            {getStatusBadge(instance.status)}
            {instance.numero_cliente && (
              <div className="text-sm text-muted-foreground">
                📱 {instance.numero_cliente}
              </div>
            )}
          </div>
        )}
      </div>

      <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-6">
        <TabsList className="grid w-full grid-cols-4">
          <TabsTrigger value="connection" className="flex items-center gap-2">
            <Smartphone className="w-4 h-4" />
            Conexão
          </TabsTrigger>
          <TabsTrigger 
            value="inbox" 
            className="flex items-center gap-2"
            disabled={instance?.status !== 'connected'}
          >
            <MessageCircle className="w-4 h-4" />
            Inbox
          </TabsTrigger>
          <TabsTrigger 
            value="broadcast" 
            className="flex items-center gap-2"
            disabled={instance?.status !== 'connected'}
          >
            <Send className="w-4 h-4" />
            Disparos
          </TabsTrigger>
          <TabsTrigger 
            value="reports" 
            className="flex items-center gap-2"
            disabled={instance?.status !== 'connected'}
          >
            <BarChart3 className="w-4 h-4" />
            Relatórios
          </TabsTrigger>
        </TabsList>

        <TabsContent value="connection">
          <WhatsAppConnection 
            instance={instance}
            onInstanceUpdate={fetchInstance}
          />
        </TabsContent>

        <TabsContent value="inbox">
          <WhatsAppInbox instance={instance} />
        </TabsContent>

        <TabsContent value="broadcast">
          <WhatsAppBroadcast instance={instance} />
        </TabsContent>

        <TabsContent value="reports">
          <WhatsAppReports instance={instance} />
        </TabsContent>
      </Tabs>
    </div>
  );
}