import { useState, useEffect } from "react";
import { useParams, useSearchParams } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Plus, Minus, ShoppingCart, Star, ChefHat, Edit, Settings, Grid, List } from "lucide-react";
import { MenuHeader } from "@/components/OnlineMenu/MenuHeader";
import { CategoryTabs } from "@/components/OnlineMenu/CategoryTabs";
import { ProductCard } from "@/components/OnlineMenu/ProductCard";
import { CartDrawer } from "@/components/OnlineMenu/CartDrawer";
import { ProductModal } from "@/components/OnlineMenu/ProductModal";
import { CheckoutModal } from "@/components/OnlineMenu/CheckoutModal";
import { MenuEditor } from "@/components/OnlineMenu/MenuEditor";
import { BannerCarousel } from "@/components/OnlineMenu/BannerCarousel";
import { useToast } from "@/hooks/use-toast";
import { useIsMobile } from "@/hooks/use-mobile";
import { useUserData } from "@/hooks/useUserData";
import { supabase } from "@/integrations/supabase/client";
import { EstablishmentNotFound } from "@/components/EstablishmentNotFound";
import { checkRateLimit, getClientIdentifier } from "@/utils/rateLimiting";
import { logAccessDenied } from "@/utils/securityMonitoring";

interface Product {
  id: string;
  name: string;
  description: string;
  price: number;
  image: string;
  category: string;
  isPromotion: boolean;
  promotionPrice?: number;
  customizable?: boolean;
  ingredients?: string[];
  extras?: { name: string; price: number }[];
  isPizza?: boolean;
  pizzaFlavors?: any[];
  pizzaBorders?: any[];
  maxFlavors?: number;
}

interface CartItem {
  id: string;
  product: Product;
  quantity: number;
  customizations?: {
    bread?: string;
    ingredients?: string[];
    extras?: { name: string; price: number }[];
    notes?: string;
    // Pizza specific
    flavors?: any[];
    flavorCount?: number;
    removedIngredients?: string[];
    border?: any;
    pizzaPrice?: number;
    borderPrice?: number;
  };
  totalPrice: number;
}

interface EstablishmentBannerData {
  image: string;
  establishmentName: string;
  rating: number;
  deliveryTime: string;
  address: string;
  whatsappNumber: string;
  instagramUrl: string;
}

const mockProducts: Product[] = [
  {
    id: "1",
    name: "Big Burger Classic",
    description: "Pão brioche artesanal, hambúrguer 180g grelhado, alface americana, tomate, cebola roxa, queijo cheddar derretido e molho especial da casa",
    price: 28.90,
    image: "https://images.unsplash.com/photo-1568901346375-23c9450c58cd?w=400&h=300&fit=crop&crop=center",
    category: "Lanches",
    isPromotion: false,
    customizable: true,
    ingredients: ["Pão brioche", "Hambúrguer 180g", "Alface", "Tomate", "Cebola", "Queijo cheddar", "Molho especial"],
    extras: [
      { name: "Bacon crocante", price: 4.50 },
      { name: "Queijo extra", price: 3.50 },
      { name: "Ovo frito", price: 2.50 },
      { name: "Cebola caramelizada", price: 2.00 }
    ]
  },
  {
    id: "2",
    name: "Mega Combo Família",
    description: "2 hambúrgueres clássicos + batata grande + 2 refrigerantes 350ml + sobremesa. Perfeito para compartilhar!",
    price: 75.90,
    image: "https://images.unsplash.com/photo-1594212699903-ec8a3eca50f5?w=400&h=300&fit=crop&crop=center",
    category: "Combos",
    isPromotion: true,
    promotionPrice: 59.90
  },
  {
    id: "3",
    name: "Pizza Margherita Tradicional",
    description: "Massa artesanal, molho de tomate especial, mussarela de búfala, manjericão fresco e azeite extravirgem",
    price: 42.90,
    image: "https://images.unsplash.com/photo-1513104890138-7c749659a591?w=400&h=300&fit=crop&crop=center",
    category: "Pizzas",
    isPromotion: false,
    isPizza: true,
    maxFlavors: 4
  },
  {
    id: "4",
    name: "Pizza Família Gigante",
    description: "Pizza tamanho família de 45cm - Monte com até 6 sabores diferentes! Ideal para toda a família",
    price: 65.90,
    image: "https://images.unsplash.com/photo-1571997478779-2adcbbe9ab2f?w=400&h=300&fit=crop&crop=center",
    category: "Pizzas",
    isPromotion: true,
    promotionPrice: 54.90,
    isPizza: true,
    maxFlavors: 6
  },
  {
    id: "5",
    name: "Batata Rústica Especial",
    description: "Porção generosa de batatas rústicas temperadas com ervas finas, acompanha molhos barbecue e aioli",
    price: 18.90,
    image: "https://images.unsplash.com/photo-1573080496219-bb080dd4f877?w=400&h=300&fit=crop&crop=center",
    category: "Acompanhamentos",
    isPromotion: false
  },
  {
    id: "6",
    name: "Refrigerante Gelado 350ml",
    description: "Coca-Cola, Guaraná Antarctica, Fanta Laranja ou Sprite - Sempre gelado!",
    price: 5.90,
    image: "https://images.unsplash.com/photo-1581636625402-29b2a704ef9c?w=400&h=300&fit=crop&crop=center",
    category: "Bebidas",
    isPromotion: false
  },
  {
    id: "7",
    name: "Brownie com Sorvete",
    description: "Brownie artesanal quentinho com sorvete de baunilha, calda de chocolate e chantilly",
    price: 12.90,
    image: "https://images.unsplash.com/photo-1606313564200-e75d5e30476c?w=400&h=300&fit=crop&crop=center",
    category: "Sobremesas",
    isPromotion: false
  },
  {
    id: "8",
    name: "Hambúrguer Bacon Supreme",
    description: "Pão de cerveja, duplo hambúrguer 160g, bacon crocante, queijo provolone, cebola caramelizada e molho barbecue",
    price: 34.90,
    image: "https://images.unsplash.com/photo-1572802419224-296b0aeee0d9?w=400&h=300&fit=crop&crop=center",
    category: "Lanches",
    isPromotion: true,
    promotionPrice: 29.90,
    customizable: true,
    ingredients: ["Pão de cerveja", "Duplo hambúrguer", "Bacon", "Queijo provolone", "Cebola caramelizada", "Molho barbecue"],
    extras: [
      { name: "Bacon extra", price: 4.50 },
      { name: "Queijo extra", price: 3.50 },
      { name: "Cebola rings", price: 3.00 }
    ]
  },
  {
    id: "9",
    name: "Combo Executivo",
    description: "Hambúrguer de sua escolha + batata média + refrigerante 350ml. Ideal para almoço!",
    price: 32.90,
    image: "https://images.unsplash.com/photo-1565299624946-b28f40a0ca4b?w=400&h=300&fit=crop&crop=center",
    category: "Combos",
    isPromotion: false
  },
  {
    id: "10",
    name: "Suco Natural 500ml",
    description: "Laranja, limão, maracujá ou acerola. Feito na hora com frutas selecionadas!",
    price: 8.90,
    image: "https://images.unsplash.com/photo-1546171753-97d7676e4602?w=400&h=300&fit=crop&crop=center",
    category: "Bebidas",
    isPromotion: false
  }
];

const categories = ["Todos", "Lanches", "Pizzas", "Combos", "Acompanhamentos", "Bebidas", "Sobremesas"];

export default function OnlineMenu() {
  const { establishmentSlug } = useParams();
  const [searchParams] = useSearchParams();
  const isEditMode = searchParams.get("edit") === "true";
  const slugFromParams = searchParams.get("slug");
  const { toast } = useToast();
  const isMobile = useIsMobile();
  
  // Hook para gerenciar dados do usuário logado
  const { settings, updateSettings } = useUserData();
  
  const [selectedCategory, setSelectedCategory] = useState("Todos");
  const [cart, setCart] = useState<CartItem[]>([]);
  const [isCartOpen, setIsCartOpen] = useState(false);
  const [selectedProduct, setSelectedProduct] = useState<Product | null>(null);
  const [isCheckoutOpen, setIsCheckoutOpen] = useState(false);
  const [isEditorOpen, setIsEditorOpen] = useState(false);
  const [layoutMode, setLayoutMode] = useState<'list' | 'grid'>('grid');
  const [mobileLayoutMode, setMobileLayoutMode] = useState<'single' | 'double'>('single');
  const [showUpsell, setShowUpsell] = useState<string | null>(null);
  
  // Real data from Supabase
  const [establishmentData, setEstablishmentData] = useState<any>(null);
  const [products, setProducts] = useState<Product[]>([]);
  const [categories, setCategories] = useState<string[]>([]);
  const [loading, setLoading] = useState(true);

  const [banners, setBanners] = useState([
    {
      id: "1",
      image: "https://images.unsplash.com/photo-1586190848861-99aa4a171e90?w=800&h=400&fit=crop&crop=center",
      title: "🔥 Super Promoção de Inverno!",
      subtitle: "50% OFF em todos os hambúrgueres - Válido até domingo!",
      active: true
    },
    {
      id: "2",
      image: "https://images.unsplash.com/photo-1565299624946-b28f40a0ca4b?w=800&h=400&fit=crop&crop=center",
      title: "🍕 Rodízio de Pizza aos Domingos",
      subtitle: "R$ 29,90 por pessoa - Das 18h às 22h",
      active: true
    }
  ]);

  const [establishmentBanner, setEstablishmentBanner] = useState<EstablishmentBannerData>({
    image: "https://images.unsplash.com/photo-1555396273-367ea4eb4db5?w=800&h=400&fit=crop&crop=center",
    establishmentName: "Carregando...",
    rating: 4.8,
    deliveryTime: "30-45 min",
    address: "Carregando endereço...",
    whatsappNumber: "5511999999999",
    instagramUrl: "https://instagram.com/loading"
  });

  // Fetch establishment data and products
  useEffect(() => {
    const fetchData = async () => {
      const currentSlug = establishmentSlug || slugFromParams;
      
      if (!currentSlug) {
        console.error('No establishment slug provided');
        setLoading(false);
        return;
      }

      try {
        // Get establishment data by slug
        const { data: establishment, error: establishmentError } = await supabase
          .rpc('get_establishment_by_slug', { slug: currentSlug });

        if (establishmentError) {
          console.error('Error fetching establishment:', establishmentError);
          toast({
            title: "Estabelecimento não encontrado",
            description: "Verifique se o link está correto.",
            variant: "destructive"
          });
          setLoading(false);
          return;
        }

        if (!establishment || establishment.length === 0) {
          toast({
            title: "Estabelecimento não encontrado",
            description: "Este estabelecimento não existe ou não está ativo.",
            variant: "destructive"
          });
          setLoading(false);
          return;
        }

        const estData = establishment[0];
        setEstablishmentData(estData);
        
        // Update establishment banner with real data
        setEstablishmentBanner({
          image: estData.business_logo || "https://images.unsplash.com/photo-1555396273-367ea4eb4db5?w=800&h=400&fit=crop&crop=center",
          establishmentName: estData.business_name,
          rating: 4.8,
          deliveryTime: "30-45 min",
          address: estData.business_address || "Endereço não informado",
          whatsappNumber: estData.business_phone || "5511999999999",
          instagramUrl: estData.instagram_url || "https://instagram.com/estabelecimento"
        });

        // Fetch products for this establishment
        const { data: productsData, error: productsError } = await supabase
          .from('user_products')
          .select('*')
          .eq('user_id', estData.establishment_id)
          .eq('show_online_menu', true)
          .order('created_at', { ascending: false });

        if (productsError) {
          console.error('Error fetching products:', productsError);
        } else {
          const formattedProducts = (productsData || []).map(product => ({
            id: product.id,
            name: product.name,
            description: product.description || '',
            price: product.price,
            image: product.image || 'https://images.unsplash.com/photo-1568901346375-23c9450c58cd?w=400&h=300&fit=crop&crop=center',
            category: product.category,
            isPromotion: product.is_promotion,
            promotionPrice: product.promotion_price,
            customizable: product.customizable,
            isPizza: product.is_pizza,
            ingredients: [],
            extras: [],
            pizzaFlavors: [],
            pizzaBorders: [],
            maxFlavors: 4
          }));
          setProducts(formattedProducts);
        }

        // Fetch categories for this establishment
        const { data: categoriesData, error: categoriesError } = await supabase
          .from('user_categories')
          .select('*')
          .eq('user_id', estData.establishment_id)
          .order('sort_order', { ascending: true });

        if (categoriesError) {
          console.error('Error fetching categories:', categoriesError);
        } else {
          const categoryNames = (categoriesData || []).map(cat => cat.name);
          setCategories(['Todos', ...categoryNames]);
        }

      } catch (error) {
        console.error('Error in fetchData:', error);
        toast({
          title: "Erro ao carregar dados",
          description: "Tente novamente em alguns instantes.",
          variant: "destructive"
        });
      } finally {
        setLoading(false);
      }
    };

    fetchData();
  }, [establishmentSlug, slugFromParams, toast]);

  const filteredProducts = selectedCategory === "Todos" 
    ? products 
    : products.filter(product => product.category === selectedCategory);

  const cartTotal = cart.reduce((total, item) => total + item.totalPrice, 0);
  const cartItemsCount = cart.reduce((total, item) => total + item.quantity, 0);

  const addToCart = (product: Product, customizations?: any, quantity: number = 1) => {
    let totalPrice: number;

    if (product.isPizza && customizations?.flavors) {
      // Para pizzas, usar o preço calculado das customizações
      totalPrice = (customizations.pizzaPrice + (customizations.borderPrice || 0)) * quantity;
    } else {
      // Para produtos normais
      const basePrice = product.isPromotion && product.promotionPrice ? product.promotionPrice : product.price;
      const extrasPrice = customizations?.extras?.reduce((sum: number, extra: any) => sum + extra.price, 0) || 0;
      totalPrice = (basePrice + extrasPrice) * quantity;
    }

    const cartItem: CartItem = {
      id: `${product.id}-${Date.now()}`,
      product,
      quantity,
      customizations,
      totalPrice
    };

    setCart(prev => [...prev, cartItem]);
    
    toast({
      title: "Produto adicionado!",
      description: `${product.name} foi adicionado à sua sacola`,
    });
  };

  const updateCartItem = (itemId: string, quantity: number) => {
    if (quantity === 0) {
      setCart(prev => prev.filter(item => item.id !== itemId));
      return;
    }

    setCart(prev => prev.map(item => {
      if (item.id === itemId) {
        let newTotalPrice: number;

        if (item.product.isPizza && item.customizations?.flavors) {
          // Para pizzas
          newTotalPrice = (item.customizations.pizzaPrice + (item.customizations.borderPrice || 0)) * quantity;
        } else {
          // Para produtos normais
          const basePrice = item.product.isPromotion && item.product.promotionPrice 
            ? item.product.promotionPrice 
            : item.product.price;
          const extrasPrice = item.customizations?.extras?.reduce((sum: number, extra: any) => sum + extra.price, 0) || 0;
          newTotalPrice = (basePrice + extrasPrice) * quantity;
        }

        return { ...item, quantity, totalPrice: newTotalPrice };
      }
      return item;
    }));
  };

  const handleQuickAdd = (product: Product) => {
    if (product.customizable || product.isPizza) {
      setSelectedProduct(product);
    } else {
      addToCart(product);
    }
  };

  const handleToggleUpsell = (productId: string) => {
    setShowUpsell(showUpsell === productId ? null : productId);
  };

  // Função para salvar o banner do estabelecimento no Supabase
  const handleUpdateEstablishmentBanner = async (bannerData: EstablishmentBannerData) => {
    try {
      console.log('=== INÍCIO SALVAMENTO BANNER ===');
      console.log('Dados recebidos:', bannerData);
      
      // Verificar se o hook está disponível
      if (!updateSettings) {
        console.error('Hook updateSettings não está disponível');
        throw new Error('Sistema de salvamento não está disponível');
      }
      
      // Atualizar estado local
      setEstablishmentBanner(bannerData);
      console.log('Estado local atualizado');
      
      // Salvar no Supabase usando o hook useUserData
      console.log('Chamando updateSettings...');
      const result = await updateSettings({
        business_name: bannerData.establishmentName,
        business_phone: bannerData.whatsappNumber,
        business_address: bannerData.address,
        business_logo: bannerData.image
      });
      
      console.log('Resultado do updateSettings:', result);
      console.log('=== SALVAMENTO CONCLUÍDO COM SUCESSO ===');
      
      toast({
        title: "Banner atualizado!",
        description: "As alterações foram salvas e já estão visíveis no cardápio público.",
      });
      
    } catch (error) {
      console.error('=== ERRO NO SALVAMENTO ===');
      console.error('Erro detalhado:', error);
      console.error('Stack trace:', error instanceof Error ? error.stack : 'N/A');
      
      toast({
        title: "Erro ao salvar",
        description: "Tente novamente em alguns instantes.",
        variant: "destructive",
      });
    }
  };

  if (isEditMode) {
    return (
      <div className="min-h-screen bg-gray-50">
        <div className="bg-white shadow-sm border-b">
          <div className="container mx-auto px-4 py-4 max-w-6xl">
            <div className="flex justify-between items-center">
              <h1 className="text-2xl font-bold text-gray-900">Editando Cardápio Online</h1>
              <div className="flex gap-2">
                <Button
                  type="button"
                  variant="outline"
                  onClick={() => setIsEditorOpen(true)}
                >
                  <Settings className="w-4 h-4 mr-2" />
                  Configurações
                </Button>
                <Button
                  type="button"
                  onClick={() => window.location.href = `https://lovemenu.com.br/${establishmentSlug || slugFromParams}`}
                >
                  Visualizar Cardápio
                </Button>
              </div>
            </div>
          </div>
        </div>

        <MenuEditor
          isOpen={isEditorOpen}
          onClose={() => setIsEditorOpen(false)}
          banners={banners}
          onUpdateBanners={setBanners}
          categories={categories.slice(1).map((name, index) => ({ id: `cat-${index}`, name, sort_order: index + 1 }))}
          products={products}
          establishmentName={establishmentBanner.establishmentName}
          establishmentBanner={establishmentBanner}
          onUpdateEstablishmentBanner={handleUpdateEstablishmentBanner}
          layoutMode={layoutMode}
          onLayoutModeChange={setLayoutMode}
          mobileLayoutMode={mobileLayoutMode}
          onMobileLayoutModeChange={setMobileLayoutMode}
        />
      </div>
    );
  }

  // Show loading state
  if (loading) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="text-center">
          <div className="w-16 h-16 border-4 border-orange-500 border-t-transparent rounded-full animate-spin mx-auto mb-4"></div>
          <p className="text-gray-600">Carregando cardápio...</p>
        </div>
      </div>
    );
  }

  // Show error if no establishment data
  if (!establishmentData) {
    return <EstablishmentNotFound slug={establishmentSlug || slugFromParams} />;
  }

  return (
    <div className="min-h-screen bg-gray-50">
      {/* <BannerCarousel banners={banners} /> */}
      <MenuHeader 
        establishmentName={establishmentBanner.establishmentName}
        image={establishmentBanner.image}
        rating={establishmentBanner.rating}
        deliveryTime={establishmentBanner.deliveryTime}
        address={establishmentBanner.address}
        whatsappNumber={establishmentBanner.whatsappNumber}
        instagramUrl={establishmentBanner.instagramUrl}
      />
      
      <div className="container mx-auto px-4 py-6 max-w-6xl">
        <div className="mb-4">
          <CategoryTabs 
            categories={categories}
            selectedCategory={selectedCategory}
            onCategoryChange={setSelectedCategory}
          />
        </div>

        <div className={`grid gap-4 ${
          isMobile && mobileLayoutMode === 'double'
            ? 'grid-cols-2'
            : isMobile && mobileLayoutMode === 'single'
            ? 'grid-cols-1'
            : layoutMode === 'grid' 
            ? 'grid-cols-2 lg:grid-cols-3' 
            : 'grid-cols-1 md:grid-cols-2 lg:grid-cols-3'
        }`}>
          {filteredProducts.map((product) => (
            <ProductCard
              key={product.id}
              product={product}
              onQuickAdd={handleQuickAdd}
              onCustomize={() => setSelectedProduct(product)}
              showUpsell={showUpsell === product.id}
              onToggleUpsell={() => handleToggleUpsell(product.id)}
              mobileLayoutMode={mobileLayoutMode}
            />
          ))}
        </div>
      </div>

      {/* Botão flutuante do carrinho */}
      {cartItemsCount > 0 && (
        <div className="fixed bottom-4 right-4 z-50">
          <Button
            type="button"
            onClick={() => setIsCartOpen(true)}
            className="h-14 w-14 rounded-full bg-orange-500 hover:bg-orange-600 shadow-lg"
            size="icon"
          >
            <div className="relative">
              <ShoppingCart className="w-6 h-6" />
              <Badge className="absolute -top-2 -right-2 bg-red-500 text-white text-xs min-w-[20px] h-5 flex items-center justify-center rounded-full">
                {cartItemsCount}
              </Badge>
            </div>
          </Button>
        </div>
      )}

      {/* Modais e Drawers */}
      <CartDrawer
        isOpen={isCartOpen}
        onClose={() => setIsCartOpen(false)}
        cart={cart}
        onUpdateItem={updateCartItem}
        onCheckout={() => {
          setIsCartOpen(false);
          setIsCheckoutOpen(true);
        }}
        total={cartTotal}
      />

      <ProductModal
        product={selectedProduct}
        isOpen={!!selectedProduct}
        onClose={() => setSelectedProduct(null)}
        onAddToCart={addToCart}
      />

      <CheckoutModal
        isOpen={isCheckoutOpen}
        onClose={() => setIsCheckoutOpen(false)}
        cart={cart}
        total={cartTotal}
        establishmentName={establishmentBanner.establishmentName}
      />
    </div>
  );
}
