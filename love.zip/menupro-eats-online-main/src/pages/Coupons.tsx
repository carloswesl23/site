import { CouponManager } from "@/components/Coupons/CouponManager";

export default function Coupons() {
  return <CouponManager />;
}