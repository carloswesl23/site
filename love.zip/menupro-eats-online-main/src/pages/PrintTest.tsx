import { useEffect } from "react";

export default function PrintTest() {
  useEffect(() => {
    // Auto-imprimir quando a página carregar
    const timer = setTimeout(() => {
      window.print();
    }, 500);

    return () => clearTimeout(timer);
  }, []);

  return (
    <>
      <style>
        {`
          @page { 
            size: 80mm auto; 
            margin: 0;
          }
          @media print {
            body { 
              margin: 0;
              padding: 0;
              font-size: 12px;
              line-height: 1.3;
            }
            .no-print { 
              display: none !important; 
            }
          }
        `}
      </style>
      
      <div className="max-w-sm mx-auto bg-white p-4">
        <div className="text-center mb-4">
          <h1 className="text-lg font-bold mb-1">LoveMenu - Teste de Impressão</h1>
          <p className="text-sm text-gray-600">Impressora Térmica 80mm</p>
        </div>

        <div className="border-t border-dashed border-gray-400 pt-3 mb-3">
          <h2 className="text-base font-bold mb-2">Pedido #TEST-001</h2>
          <div className="text-sm space-y-1">
            <div className="flex justify-between">
              <span>Data/Hora:</span>
              <span>{new Date().toLocaleString('pt-BR')}</span>
            </div>
            <div className="flex justify-between">
              <span>Cliente:</span>
              <span className="font-medium">Cliente Teste</span>
            </div>
            <div className="flex justify-between">
              <span>Telefone:</span>
              <span>(11) 99999-9999</span>
            </div>
          </div>
        </div>

        <div className="mb-3">
          <h3 className="text-sm font-medium mb-1">Endereço de Entrega:</h3>
          <p className="text-xs text-gray-600">Rua Exemplo, 123 - Centro - São Paulo/SP</p>
        </div>

        <div className="border-t border-dashed border-gray-400 pt-3 mb-3">
          <h3 className="text-sm font-medium mb-2">Itens do Pedido</h3>
          <div className="space-y-2">
            <div className="text-sm">
              <div className="flex justify-between">
                <span>1x Hambúrguer Clássico</span>
                <span>R$ 25,90</span>
              </div>
              <div className="ml-4 text-xs text-gray-600">
                + Bacon (+R$ 3,00)
              </div>
            </div>
            <div className="text-sm">
              <div className="flex justify-between">
                <span>1x Batata Frita</span>
                <span>R$ 12,90</span>
              </div>
            </div>
            <div className="text-sm">
              <div className="flex justify-between">
                <span>1x Refrigerante</span>
                <span>R$ 5,90</span>
              </div>
            </div>
          </div>
        </div>

        <div className="border-t border-dashed border-gray-400 pt-3 mb-3">
          <div className="flex justify-between text-sm mb-1">
            <span>Pagamento:</span>
            <span>PIX</span>
          </div>
          <div className="flex justify-between text-base font-bold">
            <span>Total:</span>
            <span>R$ 47,70</span>
          </div>
        </div>

        <div className="mb-3">
          <h3 className="text-sm font-medium mb-1">Observações:</h3>
          <p className="text-xs text-gray-600">Sem cebola no hambúrguer, por favor.</p>
        </div>

        <div className="text-center mt-4 pt-3 border-t border-dashed border-gray-400">
          <p className="text-xs text-gray-500">*** TESTE DE IMPRESSÃO ***</p>
          <p className="text-xs text-gray-500 mt-1">Se você consegue ler isso claramente,</p>
          <p className="text-xs text-gray-500">sua impressora está configurada corretamente!</p>
          <p className="text-xs text-gray-400 mt-2">Powered by LoveMenu</p>
        </div>
      </div>

      <div className="no-print text-center mt-6 space-x-4">
        <p className="text-sm text-gray-600 mb-4">
          Esta é uma página de teste para verificar se sua impressora térmica está configurada corretamente.
        </p>
        <button
          onClick={() => window.print()}
          className="bg-orange-500 text-white px-6 py-2 rounded hover:bg-orange-600 mr-4"
        >
          Imprimir Novamente
        </button>
        <button
          onClick={() => window.close()}
          className="bg-gray-500 text-white px-6 py-2 rounded hover:bg-gray-600"
        >
          Fechar
        </button>
      </div>
    </>
  );
}