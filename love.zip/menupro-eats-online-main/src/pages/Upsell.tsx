import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Switch } from "@/components/ui/switch";
import { Checkbox } from "@/components/ui/checkbox";
import { Search, Plus, Package, TrendingUp } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { useUserData } from "@/hooks/useUserData";

export default function Upsell() {
  const { toast } = useToast();
  const { 
    products, 
    categories, 
    upsellConfigs, 
    isLoading, 
    getUpsellConfig, 
    updateUpsellConfig 
  } = useUserData();
  
  const [searchTerm, setSearchTerm] = useState("");
  const [selectedCategory, setSelectedCategory] = useState("Todos");
  const [selectedProductId, setSelectedProductId] = useState<string | null>(null);

  // Criar lista de categorias com "Todos" no início
  const categoryOptions = ["Todos", ...categories.map(c => c.name)];
  
  const filteredProducts = products.filter(product => {
    const matchesSearch = product.name.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesCategory = selectedCategory === "Todos" || product.category === selectedCategory;
    return matchesSearch && matchesCategory;
  });

  const toggleUpsellActive = async (productId: string) => {
    const config = getUpsellConfig(productId);
    const newActiveState = !config?.is_active;
    
    try {
      await updateUpsellConfig(productId, { 
        is_active: newActiveState,
        suggested_products: config?.suggested_products || []
      });
      
      toast({
        title: newActiveState ? "Upsell ativado" : "Upsell desativado",
        description: `Upsell ${newActiveState ? "ativado" : "desativado"} para o produto`,
      });
    } catch (error) {
      console.error('Error toggling upsell:', error);
    }
  };

  const toggleSuggestedProduct = (productId: string, suggestedId: string) => {
    const config = getUpsellConfig(productId);
    const currentSuggested = config?.suggested_products || [];
    const newSuggested = currentSuggested.includes(suggestedId)
      ? currentSuggested.filter(id => id !== suggestedId)
      : [...currentSuggested, suggestedId];
    
    // Atualizar apenas localmente - será salvo quando fechar o modal
    setSelectedProductId(productId);
  };

  const saveSuggestedProducts = async (productId: string, suggestedProducts: string[]) => {
    const config = getUpsellConfig(productId);
    
    try {
      await updateUpsellConfig(productId, {
        is_active: config?.is_active || false,
        suggested_products: suggestedProducts
      });
      
      toast({
        title: "Configuração salva",
        description: "Produtos de upsell configurados com sucesso",
      });
    } catch (error) {
      console.error('Error saving suggested products:', error);
    }
  };

  if (isLoading) {
    return (
      <div className="flex-1 space-y-6 p-6 bg-gray-50 min-h-screen">
        <div className="flex items-center justify-center h-64">
          <div className="animate-spin rounded-full h-32 w-32 border-b-2 border-brand-orange"></div>
        </div>
      </div>
    );
  }

  return (
    <div className="flex-1 space-y-6 p-6 bg-gray-50 min-h-screen">
      <div className="flex flex-col md:flex-row md:items-center md:justify-between">
        <div>
          <h1 className="text-3xl font-bold text-brand-dark">Configuração de Upsell</h1>
          <p className="text-gray-600 mt-1">Configure sugestões de produtos para aumentar o ticket médio</p>
        </div>
        <div className="mt-4 md:mt-0 flex items-center gap-2">
          <TrendingUp className="w-5 h-5 text-brand-orange" />
          <span className="text-sm font-medium text-brand-orange">
            {upsellConfigs.filter(c => c.is_active).length} produtos com upsell ativo
          </span>
        </div>
      </div>

      {/* Filtros */}
      <Card>
        <CardHeader>
          <CardTitle className="text-lg">Filtros</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="flex flex-col md:flex-row gap-4">
            <div className="flex-1">
              <div className="relative">
                <Search className="absolute left-3 top-3 h-4 w-4 text-gray-400" />
                <Input
                  placeholder="Buscar produtos..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="pl-10"
                />
              </div>
            </div>
            <div className="flex gap-2 flex-wrap">
              {categoryOptions.map((category) => (
                <Button
                  key={category}
                  variant={selectedCategory === category ? "default" : "outline"}
                  size="sm"
                  onClick={() => setSelectedCategory(category)}
                >
                  {category}
                </Button>
              ))}
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Lista de produtos */}
      {filteredProducts.length === 0 ? (
        <Card>
          <CardContent className="p-8 text-center text-gray-500">
            <Package className="h-16 w-16 text-gray-300 mx-auto mb-4" />
            <p className="text-lg font-medium mb-2">Nenhum produto encontrado</p>
            <p className="text-sm">
              {searchTerm || selectedCategory !== "Todos" 
                ? "Tente ajustar os filtros de busca" 
                : "Adicione produtos primeiro na aba Produtos"
              }
            </p>
          </CardContent>
        </Card>
      ) : (
        <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
          {filteredProducts.map((product) => {
            const config = getUpsellConfig(product.id);
            const suggestedProducts = config?.suggested_products
              .map(id => products.find(p => p.id === id))
              .filter(Boolean) || [];

            return (
              <Card key={product.id} className="overflow-hidden">
                <div className="relative">
                  <img
                    src={product.image || "/placeholder.svg"}
                    alt={product.name}
                    className="w-full h-32 object-cover"
                  />
                  <Badge 
                    className={`absolute top-2 right-2 ${
                      config?.is_active ? 'bg-green-500' : 'bg-gray-500'
                    }`}
                  >
                    {config?.is_active ? 'Ativo' : 'Inativo'}
                  </Badge>
                </div>
                
                <CardContent className="p-4">
                  <h3 className="font-semibold text-lg mb-1 line-clamp-1">{product.name}</h3>
                  <p className="text-gray-600 text-sm mb-2 line-clamp-2">
                    {product.description || "Sem descrição"}
                  </p>
                  <p className="text-lg font-bold text-brand-orange mb-3">
                    R$ {product.price.toFixed(2).replace('.', ',')}
                  </p>

                  {/* Switch de ativação */}
                  <div className="flex items-center justify-between mb-3">
                    <span className="text-sm font-medium">Ativar Upsell</span>
                    <Switch
                      checked={config?.is_active || false}
                      onCheckedChange={() => toggleUpsellActive(product.id)}
                    />
                  </div>

                  {/* Produtos sugeridos */}
                  {config?.is_active && (
                    <div className="space-y-2">
                      <span className="text-sm font-medium">Produtos sugeridos:</span>
                      {suggestedProducts.length > 0 ? (
                        <div className="space-y-1">
                          {suggestedProducts.map((suggested) => (
                            <div key={suggested.id} className="flex items-center justify-between text-xs bg-gray-100 p-2 rounded">
                              <span className="truncate">{suggested.name}</span>
                              <span className="font-medium">R$ {suggested.price.toFixed(2).replace('.', ',')}</span>
                            </div>
                          ))}
                        </div>
                      ) : (
                        <p className="text-xs text-gray-500">Nenhum produto selecionado</p>
                      )}
                      
                      <Button
                        size="sm"
                        variant="outline"
                        onClick={() => setSelectedProductId(product.id)}
                        className="w-full"
                      >
                        <Plus className="w-3 h-3 mr-1" />
                        Configurar Sugestões
                      </Button>
                    </div>
                  )}
                </CardContent>
              </Card>
            );
          })}
        </div>
      )}

      {/* Modal de seleção de produtos sugeridos */}
      {selectedProductId && (
        <UpsellConfigModal
          productId={selectedProductId}
          products={products}
          currentConfig={getUpsellConfig(selectedProductId)}
          onSave={saveSuggestedProducts}
          onClose={() => setSelectedProductId(null)}
        />
      )}
    </div>
  );
}

// Componente separado para o modal
interface UpsellConfigModalProps {
  productId: string;
  products: any[];
  currentConfig: any;
  onSave: (productId: string, suggestedProducts: string[]) => void;
  onClose: () => void;
}

function UpsellConfigModal({ 
  productId, 
  products, 
  currentConfig, 
  onSave, 
  onClose 
}: UpsellConfigModalProps) {
  const [selectedProducts, setSelectedProducts] = useState<string[]>(
    currentConfig?.suggested_products || []
  );

  const toggleProduct = (id: string) => {
    setSelectedProducts(prev => 
      prev.includes(id) 
        ? prev.filter(pid => pid !== id)
        : [...prev, id]
    );
  };

  const handleSave = () => {
    onSave(productId, selectedProducts);
    onClose();
  };

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
      <Card className="w-full max-w-2xl max-h-[80vh] overflow-hidden">
        <CardHeader>
          <CardTitle>Selecionar Produtos para Upsell</CardTitle>
        </CardHeader>
        <CardContent className="overflow-y-auto">
          <div className="space-y-2 mb-4">
            {products
              .filter(p => p.id !== productId)
              .map((product) => {
                const isSelected = selectedProducts.includes(product.id);
                
                return (
                  <div key={product.id} className="flex items-center space-x-3 p-2 rounded border hover:bg-gray-50">
                    <Checkbox
                      checked={isSelected}
                      onCheckedChange={() => toggleProduct(product.id)}
                    />
                    <img 
                      src={product.image || "/placeholder.svg"} 
                      alt={product.name} 
                      className="w-10 h-10 object-cover rounded" 
                    />
                    <div className="flex-1">
                      <p className="font-medium text-sm">{product.name}</p>
                      <p className="text-xs text-gray-500">{product.category}</p>
                    </div>
                    <span className="text-sm font-bold text-brand-orange">
                      R$ {product.price.toFixed(2).replace('.', ',')}
                    </span>
                  </div>
                );
              })}
          </div>
          
          <div className="flex gap-2 justify-end">
            <Button variant="outline" onClick={onClose}>
              Cancelar
            </Button>
            <Button onClick={handleSave}>
              Salvar
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}