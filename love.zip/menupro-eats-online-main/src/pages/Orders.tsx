import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Search, Eye, Check, Clock, MapPin, Phone, Truck, MessageSquare, Printer, Edit, Star, Users, CreditCard, Wallet, Banknote, User, UserPlus } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { useToast } from "@/hooks/use-toast";
import { DeliveryAssignmentModal } from "@/components/DeliveryDrivers/DeliveryAssignmentModal";
import { OrderDetailsModal } from "@/components/Orders/OrderDetailsModal";
import { useWhatsAppMessages } from "@/hooks/useWhatsAppMessages";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";

interface Order {
  id: string;
  order_number: string;
  customer_name: string;
  customer_phone: string | null;
  customer_email: string | null;
  delivery_address: string | null;
  payment_method: string | null;
  total: number;
  status: string;
  items: any[];
  notes: string | null;
  created_at: string;
  fulfillment_method?: string;
}

export default function Orders() {
  const [orders, setOrders] = useState<Order[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState("");
  const [deliveryModalOpen, setDeliveryModalOpen] = useState(false);
  const [orderDetailsModalOpen, setOrderDetailsModalOpen] = useState(false);
  const [selectedOrder, setSelectedOrder] = useState<Order | null>(null);
  const { toast } = useToast();
  const { sendOutForDeliveryMessage } = useWhatsAppMessages();

  // Buscar motoboys
  const [motoboys, setMotoboys] = useState<any[]>([]);

  useEffect(() => {
    fetchOrders();
    fetchMotoboys();
  }, []);

  const fetchMotoboys = async () => {
    try {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) return;

      const { data, error } = await supabase
        .from('motoboys')
        .select('*')
        .eq('user_id', user.id)
        .eq('active', true)
        .order('name');

      if (error) {
        console.error('Error fetching motoboys:', error);
        return;
      }

      setMotoboys(data || []);
    } catch (error) {
      console.error('Error fetching motoboys:', error);
    }
  };

  const fetchOrders = async () => {
    try {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) return;

      const { data, error } = await supabase
        .from('user_orders')
        .select('*')
        .eq('user_id', user.id)
        .order('created_at', { ascending: false });

      if (error) {
        console.error('Error fetching orders:', error);
        toast({
          title: "Erro ao carregar pedidos",
          description: "Não foi possível carregar os pedidos.",
          variant: "destructive"
        });
        return;
      }

      const mappedOrders = (data || []).map(order => ({
        ...order,
        items: Array.isArray(order.items) ? order.items : []
      }));
      setOrders(mappedOrders);
    } catch (error) {
      console.error('Error fetching orders:', error);
    } finally {
      setLoading(false);
    }
  };

  const filteredOrders = orders.filter(order => {
    const matchesSearch = order.customer_name.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         order.order_number.includes(searchTerm);
    return matchesSearch;
  });

  const updateOrderStatus = async (orderId: string, newStatus: string) => {
    try {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) return;

      const { error } = await supabase
        .from('user_orders')
        .update({ status: newStatus })
        .eq('id', orderId)
        .eq('user_id', user.id);

      if (error) throw error;

      // Atualizar estado local
      setOrders(prev => prev.map(order => 
        order.id === orderId ? { ...order, status: newStatus } : order
      ));

      toast({
        title: "Status atualizado!",
        description: `Pedido marcado como ${getStatusText(newStatus)}.`,
      });

      fetchOrders(); // Refresh para garantir sincronização
    } catch (error) {
      console.error('Error updating order status:', error);
      toast({
        title: "Erro ao atualizar",
        description: "Não foi possível atualizar o status do pedido.",
        variant: "destructive"
      });
    }
  };

  const mapOrderStatus = (status: string) => {
    switch (status) {
      case 'pending':
      case 'confirmed':
        return 'pending';
      case 'preparing':
        return 'preparing';
      case 'delivery':
      case 'ready':
      case 'ready_for_delivery':
      case 'out_for_delivery':
      case 'delivered':
        return 'delivery';
      default:
        return 'pending';
    }
  };

  const getStatusText = (status: string) => {
    switch (status) {
      case "pending": return "Aguardando Pagamento";
      case "preparing": return "Em Preparo";
      case "delivery": return "Em Entrega";
      default: return status;
    }
  };

  const getPaymentIcon = (method: string | null) => {
    if (!method) return CreditCard;
    const methodLower = method.toLowerCase();
    if (methodLower.includes('pix')) return Banknote;
    if (methodLower.includes('dinheiro') || methodLower.includes('cash')) return Wallet;
    return CreditCard;
  };

  const getFulfillmentIcon = (method: string | null) => {
    if (!method || method === 'delivery') return Truck;
    if (method === 'pickup') return Users;
    return Users; // dining in
  };

  const getTimeSinceCreated = (createdAt: string) => {
    const now = new Date();
    const created = new Date(createdAt);
    const diffInMinutes = Math.floor((now.getTime() - created.getTime()) / (1000 * 60));
    
    if (diffInMinutes < 60) {
      return `Há ${diffInMinutes} min`;
    } else {
      const hours = Math.floor(diffInMinutes / 60);
      return `Há ${hours}h ${diffInMinutes % 60}min`;
    }
  };

  const getCustomerType = (customerName: string) => {
    // Esta seria uma lógica mais complexa baseada em histórico
    // Por enquanto, simulando tipos de cliente
    const hash = customerName.split('').reduce((a, b) => {
      a = ((a << 5) - a) + b.charCodeAt(0);
      return a & a;
    }, 0);
    
    const types = ['novo', 'fiel', 'vip'];
    return types[Math.abs(hash) % 3];
  };

  const handleOrderAction = (order: Order, nextStatus: string) => {
    console.log('🔥 Ação do pedido iniciada:', { 
      orderNumber: order.order_number, 
      orderId: order.id,
      nextStatus, 
      currentStatus: order.status 
    });
    
    // Para todos os status, incluindo delivery, atualizar diretamente
    console.log('✅ Atualizando status diretamente para:', nextStatus);
    updateOrderStatus(order.id, nextStatus);
  };

  const handleViewOrder = (order: Order) => {
    setSelectedOrder(order);
    setOrderDetailsModalOpen(true);
  };

  const handleOrderUpdated = () => {
    fetchOrders();
  };

  const assignMotoboy = async (orderId: string, motoboyId: string, motoboyName: string) => {
    try {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) return;

      // Buscar dados do pedido e motoboy para mensagens
      const [orderResponse, motoboyResponse, establishmentResponse] = await Promise.all([
        supabase.from('user_orders').select('*').eq('id', orderId).single(),
        supabase.from('motoboys').select('*').eq('id', motoboyId).single(),
        supabase.from('establishment_settings').select('business_name').eq('user_id', user.id).single()
      ]);

      if (orderResponse.error || motoboyResponse.error) {
        throw new Error('Erro ao buscar dados do pedido ou motoboy');
      }

      const order = orderResponse.data;
      const motoboy = motoboyResponse.data;
      const establishment = establishmentResponse.data;

      // Atualizar status do pedido e criar registro de entrega
      const { error } = await supabase
        .from('deliveries')
        .insert({
          user_id: user.id,
          order_id: orderId,
          motoboy_id: motoboyId,
          status: 'assigned'
        });

      if (error) throw error;

      // Atualizar status do pedido para delivery
      await updateOrderStatus(orderId, 'delivery');

      // Preparar dados do pedido para mensagens
      const orderData = {
        establishment_name: establishment?.business_name || 'Estabelecimento',
        order_number: order.order_number,
        customer_name: order.customer_name,
        customer_phone: order.customer_phone || '',
        items: Array.isArray(order.items) ? order.items : [],
        subtotal: order.total,
        delivery_fee: 0,
        total: order.total,
        payment_method: order.payment_method || 'Não informado'
      };

      // Enviar mensagem para o cliente informando que o pedido saiu para entrega
      if (order.customer_phone) {
        try {
          await sendOutForDeliveryMessage(
            user.id,
            orderId,
            order.customer_phone,
            orderData
          );
          console.log('✅ Mensagem enviada para o cliente');
        } catch (error) {
          console.error('Erro ao enviar mensagem para cliente:', error);
        }
      }

      // Buscar instância WhatsApp ativa para enviar mensagem ao entregador
      const { data: whatsappInstance } = await supabase
        .from('whatsapp_instances')
        .select('instance_id, token_instance')
        .eq('user_id', user.id)
        .eq('status', 'connected')
        .order('updated_at', { ascending: false })
        .limit(1)
        .single();

      // Enviar mensagem para o entregador com detalhes do pedido
      if (motoboy.phone_e164 && whatsappInstance) {
        try {
          await supabase.functions.invoke('send-delivery-notification', {
            body: {
              driver_phone: motoboy.phone_e164,
              driver_name: motoboy.name,
              order_number: order.order_number,
              customer_name: order.customer_name,
              customer_phone: order.customer_phone,
              delivery_address: order.delivery_address,
              items: order.items,
              total: order.total,
              payment_method: order.payment_method,
              notes: order.notes,
              instance_id: whatsappInstance.instance_id,
              token_instance: whatsappInstance.token_instance
            }
          });
          console.log('✅ Mensagem enviada para o entregador');
        } catch (error) {
          console.error('Erro ao enviar mensagem para entregador:', error);
        }
      } else if (motoboy.phone_e164 && !whatsappInstance) {
        console.warn('⚠️ WhatsApp não configurado - mensagem para entregador não enviada');
      }

      toast({
        title: "Motoboy atribuído!",
        description: `Pedido enviado para ${motoboyName}. Mensagens automáticas enviadas.`,
      });

    } catch (error) {
      console.error('Error assigning motoboy:', error);
      toast({
        title: "Erro ao atribuir",
        description: "Não foi possível atribuir o motoboy.",
        variant: "destructive"
      });
    }
  };

  if (loading) {
    return (
      <div className="flex-1 space-y-6 p-6 bg-gray-50 min-h-screen">
        <div className="flex items-center justify-center h-64">
          <div className="animate-spin rounded-full h-32 w-32 border-b-2 border-orange-500"></div>
        </div>
      </div>
    );
  }

  // Kanban columns com design melhorado
  const kanbanColumns = [
    {
      id: 'pending',
      title: 'Em Análise',
      subtitle: 'Aguardando pagamento ou confirmação',
      bgColor: 'bg-gradient-to-br from-red-50 to-red-100',
      borderColor: 'border-red-200',
      headerColor: 'bg-gradient-to-r from-red-500 to-red-600',
      textColor: 'text-white',
      icon: Clock,
      accentColor: 'text-red-600'
    },
    {
      id: 'preparing',
      title: 'Em Preparo',
      subtitle: 'Cozinha preparando',
      bgColor: 'bg-gradient-to-br from-amber-50 to-yellow-100',
      borderColor: 'border-amber-200',
      headerColor: 'bg-gradient-to-r from-amber-500 to-orange-500',
      textColor: 'text-white',
      icon: Clock,
      accentColor: 'text-amber-600'
    },
    {
      id: 'delivery',
      title: 'Em Entrega',
      subtitle: 'Pedidos saindo para entrega',
      bgColor: 'bg-gradient-to-br from-green-50 to-emerald-100',
      borderColor: 'border-green-200',
      headerColor: 'bg-gradient-to-r from-green-500 to-emerald-600',
      textColor: 'text-white',
      icon: Truck,
      accentColor: 'text-green-600'
    }
  ];

  const getOrdersByStatus = (status: string) => {
    return filteredOrders.filter(order => mapOrderStatus(order.status) === status);
  };

  const getNextAction = (order: Order) => {
    const mappedStatus = mapOrderStatus(order.status);
    console.log('🔍 getNextAction - Status original:', order.status, 'Status mapeado:', mappedStatus);
    
    switch (mappedStatus) {
      case 'pending':
        return { action: 'preparing', label: 'Iniciar Preparo', icon: Clock };
      case 'preparing':
        console.log('✅ Retornando ação "Avançar" para pedido:', order.order_number);
        return { action: 'advance', label: 'Avançar', icon: Truck };
      default:
        return null;
    }
  };

  const renderOrderCard = (order: Order) => {
    const nextAction = getNextAction(order);
    const PaymentIcon = getPaymentIcon(order.payment_method);
    const FulfillmentIcon = getFulfillmentIcon(order.fulfillment_method);
    const timeSince = getTimeSinceCreated(order.created_at);
    const customerType = getCustomerType(order.customer_name);
    
    return (
      <Card key={order.id} className="mb-3 hover:shadow-md transition-all duration-200 border-l-4 border-l-primary group">
        <CardContent className="p-4">
          <div className="space-y-3">
            {/* Header com código, tempo e valor */}
            <div className="flex justify-between items-start">
              <div className="flex items-center gap-2">
                <h4 className="font-bold text-brand-dark text-sm">
                  #{order.order_number}
                </h4>
                <Badge variant="secondary" className="text-xs px-2 py-0.5">
                  {timeSince}
                </Badge>
              </div>
              <Badge variant="outline" className="text-xs font-semibold">
                R$ {order.total.toFixed(2)}
              </Badge>
            </div>

            {/* Cliente e tipo */}
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <p className="font-medium text-sm text-brand-dark">{order.customer_name}</p>
                {customerType === 'vip' && (
                  <Badge className="text-xs bg-purple-100 text-purple-800 border-purple-200">
                    <Star className="w-3 h-3 mr-1" />
                    VIP
                  </Badge>
                )}
                {customerType === 'fiel' && (
                  <Badge className="text-xs bg-blue-100 text-blue-800 border-blue-200">
                    Fiel
                  </Badge>
                )}
                {customerType === 'novo' && (
                  <Badge className="text-xs bg-green-100 text-green-800 border-green-200">
                    Novo
                  </Badge>
                )}
              </div>
            </div>

            {/* Informações de contato e pagamento */}
            <div className="flex items-center justify-between text-xs">
              <div className="flex items-center gap-3">
                {order.customer_phone && (
                  <div className="flex items-center gap-1">
                    <Phone className="w-3 h-3 text-gray-400" />
                    <span className="text-gray-600">{order.customer_phone}</span>
                  </div>
                )}
                <div className="flex items-center gap-1">
                  <PaymentIcon className="w-3 h-3 text-gray-400" />
                  <span className="text-gray-600">{order.payment_method || 'Não informado'}</span>
                </div>
              </div>
              <div className="flex items-center gap-1">
                <FulfillmentIcon className="w-3 h-3 text-gray-400" />
                <span className="text-gray-600">
                  {order.fulfillment_method === 'pickup' ? 'Retirada' : 
                   order.fulfillment_method === 'dine_in' ? 'Local' : 'Entrega'}
                </span>
              </div>
            </div>

            {/* Endereço de entrega */}
            {order.delivery_address && (
              <div className="flex items-start gap-1">
                <MapPin className="w-3 h-3 text-gray-400 mt-0.5" />
                <p className="text-xs text-gray-600 line-clamp-2">{order.delivery_address}</p>
              </div>
            )}

            {/* Itens resumidos */}
            <div>
              <p className="text-xs font-medium text-gray-700 mb-1">Itens ({order.items.length}):</p>
              <ul className="text-xs text-gray-600 space-y-0.5">
                {order.items.slice(0, 2).map((item: any, index: number) => (
                  <li key={index} className="truncate">
                    {item.quantity}x {item.name || item.product_name}
                  </li>
                ))}
                {order.items.length > 2 && (
                  <li className="text-gray-500">+{order.items.length - 2} itens...</li>
                )}
              </ul>
            </div>

            {/* Ações rápidas */}
            <div className="space-y-2 pt-2 border-t">
              {/* Primeira linha - Ações principais */}
              <div className="flex gap-1">
                <Button 
                  size="sm" 
                  variant="destructive" 
                  className="flex-1 text-xs h-8"
                  onClick={() => updateOrderStatus(order.id, 'cancelled')}
                >
                  <Eye className="w-3 h-3 mr-1" />
                  Recusar
                </Button>
                
                {nextAction && (
                  <Button 
                    size="sm" 
                    className={`flex-1 text-xs h-8 ${
                      nextAction.action === 'advance' 
                        ? 'bg-green-600 hover:bg-green-700' 
                        : 'bg-blue-600 hover:bg-blue-700'
                    }`}
                    onClick={() => {
                      console.log('🔥 Botão clicado:', nextAction.action, 'para pedido:', order.order_number);
                      console.log('📦 Status atual do pedido:', order.status);
                      console.log('🎯 nextAction completo:', nextAction);
                      console.log('🏪 Pedido completo:', order);
                      
                      if (nextAction.action === 'advance') {
                        console.log('🚀 Movendo pedido automaticamente para entrega...');
                        handleOrderAction(order, 'delivery');
                      } else {
                        console.log('📋 Executando ação direta:', nextAction.action);
                        handleOrderAction(order, nextAction.action);
                      }
                    }}
                  >
                    <nextAction.icon className="w-3 h-3 mr-1" />
                    {nextAction.label}
                  </Button>
                )}
              </div>

              {/* Segunda linha - Ações secundárias */}
              <div className="flex gap-1">
                <Button 
                  size="sm" 
                  variant="ghost" 
                  className="flex-1 text-xs h-7 text-gray-600"
                  onClick={() => window.open(`/orders/${order.id}/print`, '_blank', 'width=400,height=600')}
                >
                  <Printer className="w-3 h-3 mr-1" />
                  Imprimir
                </Button>
                
                {/* Dropdown de Motoboys */}
                <DropdownMenu>
                  <DropdownMenuTrigger asChild>
                    <Button 
                      size="sm" 
                      variant="ghost" 
                      className="flex-1 text-xs h-7 text-blue-600"
                      disabled={motoboys.length === 0}
                    >
                      <UserPlus className="w-3 h-3 mr-1" />
                      Motoboy
                    </Button>
                  </DropdownMenuTrigger>
                  <DropdownMenuContent align="end" className="w-48">
                    {motoboys.length === 0 ? (
                      <DropdownMenuItem disabled>
                        Nenhum motoboy disponível
                      </DropdownMenuItem>
                    ) : (
                      motoboys.map((motoboy) => (
                        <DropdownMenuItem
                          key={motoboy.id}
                          onClick={() => assignMotoboy(order.id, motoboy.id, motoboy.name)}
                          className="cursor-pointer"
                        >
                          <User className="w-4 h-4 mr-2" />
                          {motoboy.name}
                        </DropdownMenuItem>
                      ))
                    )}
                  </DropdownMenuContent>
                </DropdownMenu>
                
                {order.customer_phone && (
                  <Button 
                    size="sm" 
                    variant="ghost" 
                    className="flex-1 text-xs h-7 text-green-600"
                    onClick={() => window.open(`https://wa.me/${order.customer_phone.replace(/\D/g, '')}`, '_blank')}
                  >
                    <MessageSquare className="w-3 h-3 mr-1" />
                    WhatsApp
                  </Button>
                )}
                
                <Button 
                  size="sm" 
                  variant="ghost" 
                  className="flex-1 text-xs h-7 text-gray-600"
                  onClick={() => console.log('Editar pedido:', order.id)}
                >
                  <Edit className="w-3 h-3 mr-1" />
                  Editar
                </Button>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>
    );
  };

  return (
    <div className="flex-1 p-4 md:p-6 bg-gray-50 min-h-screen">
      <div className="mb-6">
        <h1 className="text-2xl md:text-3xl font-bold text-brand-dark">Pedidos</h1>
        <p className="text-gray-600 mt-1">Gerencie todos os pedidos do seu estabelecimento</p>
      </div>

      <div className="mb-6">
        <div className="relative max-w-md">
          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
          <Input
            placeholder="Buscar por nome ou número do pedido..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="pl-10"
          />
        </div>
      </div>

      {/* Estatísticas rápidas */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-6">
        <Card className="bg-gradient-to-r from-blue-500 to-blue-600 text-white">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm opacity-90">Total de Pedidos</p>
                <p className="text-2xl font-bold">{filteredOrders.length}</p>
              </div>
              <Users className="w-8 h-8 opacity-80" />
            </div>
          </CardContent>
        </Card>
        
        <Card className="bg-gradient-to-r from-green-500 to-green-600 text-white">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm opacity-90">Faturamento</p>
                <p className="text-2xl font-bold">
                  R$ {filteredOrders.reduce((sum, order) => sum + order.total, 0).toFixed(2)}
                </p>
              </div>
              <Banknote className="w-8 h-8 opacity-80" />
            </div>
          </CardContent>
        </Card>

        <Card className="bg-gradient-to-r from-amber-500 to-orange-500 text-white">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm opacity-90">Em Preparo</p>
                <p className="text-2xl font-bold">{getOrdersByStatus('preparing').length}</p>
              </div>
              <Clock className="w-8 h-8 opacity-80" />
            </div>
          </CardContent>
        </Card>

        <Card className="bg-gradient-to-r from-purple-500 to-purple-600 text-white">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm opacity-90">Em Entrega</p>
                <p className="text-2xl font-bold">{getOrdersByStatus('delivery').length}</p>
              </div>
              <Truck className="w-8 h-8 opacity-80" />
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Kanban Board Melhorado */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {kanbanColumns.map((column) => {
          const columnOrders = getOrdersByStatus(column.id);
          const Icon = column.icon;
          
          return (
            <div key={column.id} className={`${column.bgColor} rounded-xl shadow-lg border-2 ${column.borderColor} flex flex-col min-h-[600px] overflow-hidden`}>
              {/* Header da coluna */}
              <div className={`${column.headerColor} ${column.textColor} px-6 py-4`}>
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <div className="bg-white/20 p-2 rounded-lg">
                      <Icon className="w-5 h-5" />
                    </div>
                    <div>
                      <h3 className="font-bold text-lg">{column.title}</h3>
                      <p className="text-sm opacity-90">{column.subtitle}</p>
                    </div>
                  </div>
                  <div className="bg-white/20 px-3 py-1 rounded-full">
                    <span className="text-sm font-bold">{columnOrders.length}</span>
                  </div>
                </div>
              </div>
              
              {/* Conteúdo da coluna */}
              <div className="flex-1 p-4 overflow-y-auto">
                {columnOrders.length === 0 ? (
                  <div className="flex flex-col items-center justify-center h-48 text-gray-500">
                    <Icon className={`w-12 h-12 mb-3 ${column.accentColor} opacity-50`} />
                    <p className="text-sm font-medium">Nenhum pedido</p>
                    <p className="text-xs text-center mt-1 opacity-75">
                      Os pedidos aparecerão aqui quando estiverem neste status
                    </p>
                  </div>
                ) : (
                  <div className="space-y-4">
                    {columnOrders.map(renderOrderCard)}
                  </div>
                )}
              </div>
            </div>
          );
        })}
      </div>

      <DeliveryAssignmentModal
        isOpen={deliveryModalOpen}
        onClose={() => {
          console.log('🔴 Fechando modal de entrega');
          setDeliveryModalOpen(false);
          setSelectedOrder(null);
        }}
        order={selectedOrder}
        onDeliveryAssigned={(driverName) => {
          console.log('✅ Entrega atribuída para:', driverName);
          setDeliveryModalOpen(false);
          setSelectedOrder(null);
          fetchOrders(); // Recarrega pedidos para mostrar a mudança de status
          toast({
            title: "Entrega atribuída!",
            description: `Pedido enviado para ${driverName}`,
          });
        }}
        onSkipDriver={() => {
          if (selectedOrder) {
            console.log('🚀 Pulando motoboy e avançando pedido para delivery:', selectedOrder.order_number);
            updateOrderStatus(selectedOrder.id, 'delivery');
            setDeliveryModalOpen(false);
            setSelectedOrder(null);
          }
        }}
      />

      <OrderDetailsModal
        isOpen={orderDetailsModalOpen}
        onClose={() => {
          setOrderDetailsModalOpen(false);
          setSelectedOrder(null);
        }}
        order={selectedOrder}
        onOrderUpdated={handleOrderUpdated}
      />
    </div>
  );
}