import { useState, useEffect, useRef } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { Loader2, Smartphone, RefreshCw } from 'lucide-react';
import { supabase } from '@/integrations/supabase/client';
import { useParams, useLocation } from 'react-router-dom';

const QRRecovery = () => {
  const { slug } = useParams();
  const [isLoading, setIsLoading] = useState(true);
  const [qrCode, setQrCode] = useState('');
  const [error, setError] = useState('');
  const [status, setStatus] = useState<string>('initializing');
  const [resolved, setResolved] = useState<{ userId: string; instanceId: string } | null>(null);
  const intervalRef = useRef<NodeJS.Timeout | null>(null);

  // Buscar/gerar QR Code com base no slug
  const fetchQRCode = async (instanceId: string, userId: string) => {
    try {
      console.log('📱 Gerando QR Code via phone-code...');
      const tokenOverride = new URLSearchParams(window.location.search).get('token')?.trim() || undefined;
      
      const { data: qrData, error: qrError } = await supabase.functions.invoke('gerar-qr-code', {
        body: tokenOverride ? { instanceId, userId, tokenOverride } : { instanceId, userId }
      });

      if (qrError || qrData?.error) {
        throw new Error(qrData?.error || 'Erro ao gerar QR Code');
      }

      if (qrData?.qrCode) {
        setQrCode(qrData.qrCode);
        setError('');
      }
      if (qrData?.status) setStatus(qrData.status);
    } catch (err: any) {
      console.error('Erro ao buscar QR Code:', err);
      setError(err.message);
    }
  };

  // Resolver instância por slug e iniciar loop de QR
  const resolveAndStart = async () => {
    try {
      setIsLoading(true);
      if (!slug) throw new Error('Slug inválido');

      const { data: resolvedData, error: resolveErr } = await supabase.functions.invoke('resolve-qr-instance', {
        body: { slug }
      });
      if (resolveErr || resolvedData?.error) {
        throw new Error(resolvedData?.error || 'Falha ao resolver instância');
      }

      const userId = resolvedData.userId as string;
      const instanceId = resolvedData.instanceId as string;
      setResolved({ userId, instanceId });

      // primeira tentativa imediata
      await fetchQRCode(instanceId, userId);

      // auto refresh
      intervalRef.current = setInterval(() => {
        fetchQRCode(instanceId, userId);
      }, 22000);
    } catch (err: any) {
      console.error('❌ Erro:', err);
      setError(err.message);
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    resolveAndStart();
  }, [slug]);

  // Limpar interval ao desmontar componente
  useEffect(() => {
    return () => {
      if (intervalRef.current) {
        clearInterval(intervalRef.current);
      }
    };
  }, []);

  const handleRefresh = () => {
    setQrCode('');
    setError('');
    if (resolved) fetchQRCode(resolved.instanceId, resolved.userId);
  };


  return (
    <div className="min-h-screen bg-gradient-to-br from-background to-secondary/20 flex items-center justify-center p-4">
      <div className="w-full max-w-md">
        <Card>
          <CardHeader className="text-center">
            <div className="mx-auto w-12 h-12 bg-primary rounded-full flex items-center justify-center mb-4">
              <Smartphone className="w-6 h-6 text-primary-foreground" />
            </div>
            <CardTitle>Conectar WhatsApp</CardTitle>
            <CardDescription>
              {qrCode ? 'Escaneie o QR Code com seu WhatsApp' : 'Gerando QR Code automaticamente...'}
            </CardDescription>
          </CardHeader>
          
          <CardContent className="space-y-4">

            {isLoading && !qrCode ? (
              <div className="text-center space-y-4">
                <Loader2 className="w-8 h-8 mx-auto animate-spin text-primary" />
                <p className="text-muted-foreground">Resolvendo instância e gerando QR Code...</p>
              </div>
            ) : null}

            {error && (
              <Alert variant="destructive">
                <AlertDescription>{error}</AlertDescription>
              </Alert>
            )}

            {qrCode && (
              <>
                <div className="text-center space-y-4">
                  <div className="bg-white p-4 rounded-lg border-2 border-dashed border-border">
                    <img 
                      src={qrCode} 
                      alt="QR Code WhatsApp" 
                      className="w-full max-w-[250px] mx-auto"
                    />
                  </div>
                  
                  <div className="text-sm text-muted-foreground space-y-2">
                    <p><strong>Como conectar:</strong></p>
                    <p>1. Abra o WhatsApp no seu celular</p>
                    <p>2. Toque em Mais opções (⋮) e depois em "Aparelhos conectados"</p>
                    <p>3. Toque em "Conectar um aparelho"</p>
                    <p>4. Aponte seu celular para esta tela para capturar o código</p>
                  </div>

                  {resolved && (
                    <Alert>
                      <AlertDescription>
                        <strong>Instância:</strong> {resolved.instanceId}<br />
                        <strong>Status:</strong> {status}<br />
                        <strong>Atualização automática:</strong> A cada 22 segundos
                      </AlertDescription>
                    </Alert>
                  )}
                </div>

                <div className="flex gap-2">
                  <Button 
                    variant="outline" 
                    onClick={handleRefresh}
                    className="flex-1 gap-2"
                  >
                    <RefreshCw className="w-4 h-4" />
                    Renovar Conexão
                  </Button>
                </div>
              </>
            )}

            {!qrCode && !isLoading && (
              <Button 
                onClick={handleRefresh}
                className="w-full gap-2"
              >
                <RefreshCw className="w-4 h-4" />
                Tentar Novamente
              </Button>
            )}
          </CardContent>
        </Card>

        <div className="mt-6 text-center">
          <p className="text-xs text-muted-foreground">
            💡 Esta página atualiza o QR Code automaticamente a cada 22 segundos.<br />
            URL fixa: <strong>/qr-recovery</strong>
          </p>
        </div>
      </div>
    </div>
  );
};

export default QRRecovery;