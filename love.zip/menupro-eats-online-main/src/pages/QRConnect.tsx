import { useState, useEffect, useRef } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { Loader2, Smartphone } from 'lucide-react';
import { toast } from 'sonner';
import { supabase } from '@/integrations/supabase/client';

interface ZAPIInstance {
  id: string;
  token: string;
  phoneNumber: string;
}

interface QRCodeResponse {
  qrcode?: string;
  status?: string;
}

const QRConnect = () => {
  const [isCreatingInstance, setIsCreatingInstance] = useState(true);
  const [qrCode, setQrCode] = useState('');
  const [instance, setInstance] = useState<ZAPIInstance | null>(null);
  const [error, setError] = useState('');
  const intervalRef = useRef<NodeJS.Timeout | null>(null);

  useEffect(() => {
    console.log('🔄 QRConnect: Página carregada, iniciando processo...');
    const criarInstanciaEObterQR = async () => {
      try {
        console.log('🚀 Criando instância Z-API automaticamente...');
        
        const instanceName = `instancia-${Date.now()}`;
        const phoneNumber = '5511999999999'; // Pode ser configurado dinamicamente
        
        // 1. Criar instância na Z-API via edge function
        const { data: instanceData, error: createError } = await supabase.functions.invoke('zapi-direct-connect', {
          body: {
            action: 'create-instance',
            instanceName,
            phoneNumber
          }
        });

        if (createError || !instanceData?.success) {
          throw new Error(instanceData?.error || 'Erro ao criar instância');
        }
        console.log('✅ Instância criada:', instanceData);

        const instanceObj = {
          id: instanceData.instanceId,
          token: instanceData.token,
          phoneNumber
        };
        
        setInstance(instanceObj);

        // 2. Função para buscar QR Code via phone-code
        const fetchQRCode = async () => {
          try {
            console.log('📱 Gerando QR Code via phone-code...');
            
            const { data: qrData, error: qrError } = await supabase.functions.invoke('zapi-direct-connect', {
              body: {
                action: 'get-qrcode',
                instanceId: instanceData.instanceId,
                token: instanceData.token,
                phoneNumber
              }
            });

            if (qrError || !qrData?.success) {
              throw new Error(qrData?.error || 'Erro ao gerar QR Code');
            }
            console.log('QR Response:', qrData);

            if (qrData.qrCode) {
              setQrCode(qrData.qrCode);
              if (!intervalRef.current) {
                toast.success('QR Code gerado! Escaneie com seu WhatsApp');
              }
            }
          } catch (err: any) {
            console.error('Erro ao buscar QR Code:', err);
          }
        };

        // Buscar QR Code inicial
        await new Promise(resolve => setTimeout(resolve, 3000));
        await fetchQRCode();
        
        // Configurar auto-refresh a cada 22 segundos
        intervalRef.current = setInterval(fetchQRCode, 22000);

      } catch (err: any) {
        console.error('❌ Erro:', err);
        setError(err.message);
        toast.error('Erro ao conectar WhatsApp');
      } finally {
        setIsCreatingInstance(false);
      }
    };

    criarInstanciaEObterQR();
  }, []);

  // Limpar interval ao desmontar componente
  useEffect(() => {
    return () => {
      if (intervalRef.current) {
        clearInterval(intervalRef.current);
      }
    };
  }, []);

  const resetConnection = () => {
    if (intervalRef.current) {
      clearInterval(intervalRef.current);
      intervalRef.current = null;
    }
    setQrCode('');
    setInstance(null);
    setError('');
    window.location.reload();
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-background to-secondary/20 flex items-center justify-center p-4">
      <div className="w-full max-w-md">
        <Card>
          <CardHeader className="text-center">
            <div className="mx-auto w-12 h-12 bg-primary rounded-full flex items-center justify-center mb-4">
              <Smartphone className="w-6 h-6 text-primary-foreground" />
            </div>
            <CardTitle>Conectar WhatsApp</CardTitle>
            <CardDescription>
              {qrCode ? 'Escaneie o QR Code com seu WhatsApp' : 'Carregando instância...'}
            </CardDescription>
          </CardHeader>
          
          <CardContent className="space-y-4">
            {isCreatingInstance && !qrCode ? (
              <div className="text-center space-y-4">
                <Loader2 className="w-8 h-8 mx-auto animate-spin text-primary" />
                <p className="text-muted-foreground">Criando instância e gerando QR Code...</p>
              </div>
            ) : null}

            {error && (
              <Alert variant="destructive">
                <AlertDescription>{error}</AlertDescription>
              </Alert>
            )}

            {qrCode && (
              <>
                <div className="text-center space-y-4">
                  <div className="bg-white p-4 rounded-lg border-2 border-dashed border-border">
                    <img 
                      src={qrCode} 
                      alt="QR Code WhatsApp" 
                      className="w-full max-w-[250px] mx-auto"
                    />
                  </div>
                  
                  <div className="text-sm text-muted-foreground space-y-2">
                    <p>1. Abra o WhatsApp no seu celular</p>
                    <p>2. Toque em Mais opções (⋮) e depois em "Aparelhos conectados"</p>
                    <p>3. Toque em "Conectar um aparelho"</p>
                    <p>4. Aponte seu celular para esta tela para capturar o código</p>
                  </div>

                  {instance && (
                    <Alert>
                      <AlertDescription>
                        <strong>Instance ID:</strong> {instance.id}<br />
                        <strong>Status:</strong> Aguardando conexão
                      </AlertDescription>
                    </Alert>
                  )}
                </div>

                <Button 
                  variant="outline" 
                  onClick={resetConnection}
                  className="w-full"
                >
                  Nova Conexão
                </Button>
              </>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  );
};

export default QRConnect;