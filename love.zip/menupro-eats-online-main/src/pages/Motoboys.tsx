import { useState } from "react";
import { Plus, Edit, Trash2, Phone, MapPin, User } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";
import { DeliveryDriverModal } from "@/components/DeliveryDrivers/DeliveryDriverModal";

interface DeliveryDriver {
  id: string;
  name: string;
  phone_e164: string;
  active: boolean;
  created_at: string;
}

export default function DeliveryDrivers() {
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingDriver, setEditingDriver] = useState<DeliveryDriver | null>(null);
  const queryClient = useQueryClient();

  const { data: drivers, isLoading } = useQuery({
    queryKey: ['motoboys'],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('motoboys')
        .select('*')
        .order('created_at', { ascending: false });
      
      if (error) throw error;
      return data as DeliveryDriver[];
    }
  });

  const deleteMutation = useMutation({
    mutationFn: async (id: string) => {
      const { error } = await supabase
        .from('motoboys')
        .delete()
        .eq('id', id);
      
      if (error) throw error;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['motoboys'] });
      toast.success('Motoboy excluído com sucesso!');
    },
    onError: () => {
      toast.error('Erro ao excluir entregador');
    }
  });

  const toggleStatusMutation = useMutation({
    mutationFn: async ({ id, active }: { id: string; active: boolean }) => {
      const { error } = await supabase
        .from('motoboys')
        .update({ active })
        .eq('id', id);
      
      if (error) throw error;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['motoboys'] });
      toast.success('Status atualizado com sucesso!');
    },
    onError: () => {
      toast.error('Erro ao atualizar status');
    }
  });

  const handleEdit = (driver: DeliveryDriver) => {
    setEditingDriver(driver);
    setIsModalOpen(true);
  };

  const handleDelete = (id: string) => {
    if (confirm('Tem certeza que deseja excluir este entregador?')) {
      deleteMutation.mutate(id);
    }
  };

  const handleToggleStatus = (id: string, currentStatus: boolean) => {
    toggleStatusMutation.mutate({ id, active: !currentStatus });
  };

  const formatPhone = (phone: string) => {
    if (phone.startsWith('+55')) {
      const numbers = phone.replace('+55', '');
      return `(${numbers.slice(0, 2)}) ${numbers.slice(2, 7)}-${numbers.slice(7)}`;
    }
    return phone;
  };

  return (
    <div className="container mx-auto p-6">
      <div className="flex justify-between items-center mb-6">
        <div>
          <h1 className="text-3xl font-bold text-foreground">Entregadores</h1>
          <p className="text-muted-foreground">Gerencie sua equipe de entrega</p>
        </div>
        <Button 
          onClick={() => {
            setEditingDriver(null);
            setIsModalOpen(true);
          }}
          className="flex items-center gap-2"
        >
          <Plus className="h-4 w-4" />
          Novo Entregador
        </Button>
      </div>

      {isLoading ? (
        <div className="text-center py-8">Carregando entregadores...</div>
      ) : (
        <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
          {drivers?.map((driver) => (
            <Card key={driver.id} className="relative">
              <CardHeader className="pb-3">
                <div className="flex items-start justify-between">
                  <div className="flex items-center gap-2">
                    <User className="h-5 w-5 text-primary" />
                    <CardTitle className="text-lg">{driver.name}</CardTitle>
                  </div>
                  <div className="flex gap-1">
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => handleEdit(driver)}
                    >
                      <Edit className="h-4 w-4" />
                    </Button>
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => handleDelete(driver.id)}
                    >
                      <Trash2 className="h-4 w-4" />
                    </Button>
                  </div>
                </div>
              </CardHeader>
              
              <CardContent className="space-y-3">
                <div className="flex items-center gap-2 text-sm">
                  <Phone className="h-4 w-4 text-muted-foreground" />
                  <span>{formatPhone(driver.phone_e164)}</span>
                </div>
                
                <div className="flex items-center justify-between pt-2">
                  <Button
                    variant={driver.active ? "destructive" : "default"}
                    size="sm"
                    onClick={() => handleToggleStatus(driver.id, driver.active)}
                  >
                    {driver.active ? 'Desativar' : 'Ativar'}
                  </Button>
                  
                  <Badge variant={driver.active ? 'default' : 'secondary'}>
                    {driver.active ? 'Ativo' : 'Inativo'}
                  </Badge>
                </div>
              </CardContent>
            </Card>
          ))}
          
          {(!drivers || drivers.length === 0) && (
            <div className="col-span-full text-center py-12">
              <MapPin className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
              <h3 className="text-lg font-medium mb-2">Nenhum entregador cadastrado</h3>
              <p className="text-muted-foreground mb-4">
                Cadastre entregadores para gerenciar suas entregas
              </p>
              <Button 
                onClick={() => {
                  setEditingDriver(null);
                  setIsModalOpen(true);
                }}
              >
                <Plus className="h-4 w-4 mr-2" />
                Cadastrar Primeiro Entregador
              </Button>
            </div>
          )}
        </div>
      )}

      <DeliveryDriverModal
        isOpen={isModalOpen}
        onClose={() => {
          setIsModalOpen(false);
          setEditingDriver(null);
        }}
        driver={editingDriver}
      />
    </div>
  );
}