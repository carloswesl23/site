import { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { supabase } from '@/integrations/supabase/client';
import { RefreshCw, User, Database, Settings, Package } from 'lucide-react';

export default function Debug() {
  const [user, setUser] = useState<any>(null);
  const [settings, setSettings] = useState<any>(null);
  const [products, setProducts] = useState<any[]>([]);
  const [categories, setCategories] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);

  const fetchDebugData = async () => {
    setLoading(true);
    try {
      // Get current user
      const { data: { user: currentUser } } = await supabase.auth.getUser();
      setUser(currentUser);

      if (!currentUser) {
        setLoading(false);
        return;
      }

      // Get settings
      const { data: settingsData } = await supabase
        .from('establishment_settings')
        .select('*')
        .eq('user_id', currentUser.id)
        .single();
      setSettings(settingsData);

      // Get products
      const { data: productsData } = await supabase
        .from('user_products')
        .select('*')
        .eq('user_id', currentUser.id);
      setProducts(productsData || []);

      // Get categories
      const { data: categoriesData } = await supabase
        .from('user_categories')
        .select('*')
        .eq('user_id', currentUser.id);
      setCategories(categoriesData || []);

    } catch (error) {
      console.error('Error fetching debug data:', error);
    } finally {
      setLoading(false);
    }
  };

  const testSlugAccess = async () => {
    if (!settings?.online_menu_slug) return;
    
    try {
      const { data, error } = await supabase
        .rpc('get_establishment_by_slug', { slug: settings.online_menu_slug });
      
      console.log('Slug test result:', { data, error });
      alert(`Slug test: ${data?.length ? 'SUCCESS' : 'FAILED'}`);
    } catch (error) {
      console.error('Slug test error:', error);
      alert('Slug test FAILED');
    }
  };

  useEffect(() => {
    fetchDebugData();
  }, []);

  if (loading) {
    return (
      <div className="flex-1 space-y-6 p-6 bg-gray-50 min-h-screen">
        <div className="flex items-center justify-center">
          <RefreshCw className="h-8 w-8 animate-spin text-brand-orange" />
        </div>
      </div>
    );
  }

  return (
    <div className="flex-1 space-y-6 p-6 bg-gray-50 min-h-screen">
      <div className="flex items-center justify-between">
        <h1 className="text-3xl font-bold text-brand-dark">Debug Panel</h1>
        <Button onClick={fetchDebugData} variant="outline">
          <RefreshCw className="h-4 w-4 mr-2" />
          Atualizar
        </Button>
      </div>

      <div className="grid gap-6 md:grid-cols-2">
        {/* User Info */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <User className="h-5 w-5" />
              Informações do Usuário
            </CardTitle>
          </CardHeader>
          <CardContent>
            {user ? (
              <div className="space-y-2">
                <p><strong>ID:</strong> {user.id}</p>
                <p><strong>Email:</strong> {user.email}</p>
                <p><strong>Criado em:</strong> {new Date(user.created_at).toLocaleString('pt-BR')}</p>
                <p><strong>Metadados:</strong> {JSON.stringify(user.user_metadata, null, 2)}</p>
              </div>
            ) : (
              <p className="text-red-500">Nenhum usuário logado</p>
            )}
          </CardContent>
        </Card>

        {/* Settings */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Settings className="h-5 w-5" />
              Configurações do Estabelecimento
            </CardTitle>
          </CardHeader>
          <CardContent>
            {settings ? (
              <div className="space-y-2">
                <p><strong>Nome:</strong> {settings.business_name}</p>
                <p><strong>Slug:</strong> {settings.online_menu_slug}</p>
                <p><strong>Telefone:</strong> {settings.business_phone || 'Não informado'}</p>
                <p><strong>Endereço:</strong> {settings.business_address || 'Não informado'}</p>
                <div className="mt-4">
                  <Button onClick={testSlugAccess} size="sm">
                    Testar Acesso por Slug
                  </Button>
                </div>
              </div>
            ) : (
              <p className="text-red-500">Nenhuma configuração encontrada</p>
            )}
          </CardContent>
        </Card>

        {/* Products */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Package className="h-5 w-5" />
              Produtos ({products.length})
            </CardTitle>
          </CardHeader>
          <CardContent>
            {products.length > 0 ? (
              <div className="space-y-2">
                {products.map(product => (
                  <div key={product.id} className="flex items-center justify-between p-2 border rounded">
                    <div>
                      <p className="font-medium">{product.name}</p>
                      <p className="text-sm text-gray-600">{product.category}</p>
                    </div>
                    <div className="text-right">
                      <p className="font-semibold">R$ {product.price}</p>
                      <Badge variant={product.show_online_menu ? "default" : "secondary"}>
                        {product.show_online_menu ? "Online" : "Offline"}
                      </Badge>
                    </div>
                  </div>
                ))}
              </div>
            ) : (
              <p className="text-yellow-600">Nenhum produto encontrado</p>
            )}
          </CardContent>
        </Card>

        {/* Categories */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Database className="h-5 w-5" />
              Categorias ({categories.length})
            </CardTitle>
          </CardHeader>
          <CardContent>
            {categories.length > 0 ? (
              <div className="space-y-2">
                {categories.map(category => (
                  <div key={category.id} className="flex items-center justify-between p-2 border rounded">
                    <p className="font-medium">{category.name}</p>
                    <Badge variant="outline">#{category.sort_order}</Badge>
                  </div>
                ))}
              </div>
            ) : (
              <p className="text-yellow-600">Nenhuma categoria encontrada</p>
            )}
          </CardContent>
        </Card>
      </div>

      {/* Direct Menu Link */}
      {settings?.online_menu_slug && (
        <Card>
          <CardHeader>
            <CardTitle>Link do Cardápio</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <p className="font-mono text-sm bg-gray-100 p-2 rounded">
                https://lovemenu.com.br/{settings.online_menu_slug}
              </p>
              <Button 
                onClick={() => window.open(`/${settings.online_menu_slug}`, '_blank')}
                className="w-full"
              >
                Abrir Cardápio em Nova Aba
              </Button>
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
}