import { Tables } from "@/integrations/supabase/types";

export type DiscountCoupon = Tables<'discount_coupons'>;

export interface CouponUsageStats {
  total_orders: number;
  total_sales: number;
  unique_customers: number;
  total_discount_given: number;
}

export type CreateCouponData = Omit<DiscountCoupon, 'id' | 'current_uses' | 'created_at' | 'updated_at'> & { user_id: string };