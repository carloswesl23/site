
export interface PageElement {
  id: string;
  type: 'text' | 'image' | 'button' | 'video' | 'counter' | 'container';
  content: any;
  styles: {
    position: { x: number; y: number };
    size: { width: number; height: number };
    backgroundColor?: string;
    color?: string;
    fontSize?: number;
    fontFamily?: string;
    padding?: number;
    margin?: number;
    borderRadius?: number;
    textAlign?: 'left' | 'center' | 'right';
  };
  properties?: any;
}

export interface PageTemplate {
  id: string;
  name: string;
  description: string;
  category: string;
  elements: PageElement[];
  thumbnail: string;
}

export interface PageData {
  id: string;
  title: string;
  elements: PageElement[];
  settings: {
    backgroundColor: string;
    fontFamily: string;
    primaryColor: string;
    secondaryColor: string;
  };
}
