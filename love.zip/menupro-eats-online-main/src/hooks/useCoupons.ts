import { useState, useEffect } from "react";
import { useToast } from "@/hooks/use-toast";
import { supabase } from "@/integrations/supabase/client";
import { couponService } from "@/services/couponService";
import { DiscountCoupon, CouponUsageStats, CreateCouponData } from "@/types/coupons";

export const useCoupons = () => {
  const [coupons, setCoupons] = useState<DiscountCoupon[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const { toast } = useToast();

  const fetchCoupons = async () => {
    setIsLoading(true);
    try {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) throw new Error('User not authenticated');

      // Filtrar cupons para demo
      if (user.email === 'demo@lovemenu.com') {
        setCoupons([]);
        return;
      }

      const data = await couponService.fetchUserCoupons(user.id);
      setCoupons(data);
    } catch (error) {
      console.error('Erro ao buscar cupons:', error);
      toast({
        title: "Erro",
        description: "Erro ao carregar cupons",
        variant: "destructive"
      });
    } finally {
      setIsLoading(false);
    }
  };

  const createCoupon = async (couponData: CreateCouponData) => {
    try {
      const data = await couponService.createCoupon(couponData);
      setCoupons(prev => [data, ...prev]);
      toast({
        title: "Cupom criado!",
        description: `Cupom ${data.code} criado com sucesso`,
      });
      return data;
    } catch (error: any) {
      console.error('Erro ao criar cupom:', error);
      
      if (error.code === '23505') {
        toast({
          title: "Código já existe",
          description: "Este código de cupom já está sendo usado",
          variant: "destructive"
        });
      } else {
        toast({
          title: "Erro",
          description: "Erro ao criar cupom",
          variant: "destructive"
        });
      }
      throw error;
    }
  };

  const updateCoupon = async (id: string, updates: Partial<DiscountCoupon>) => {
    try {
      const data = await couponService.updateCoupon(id, updates);
      setCoupons(prev => prev.map(coupon => 
        coupon.id === id ? { ...coupon, ...data } : coupon
      ));
      toast({
        title: "Cupom atualizado!",
        description: "Alterações salvas com sucesso",
      });
      return data;
    } catch (error) {
      console.error('Erro ao atualizar cupom:', error);
      toast({
        title: "Erro",
        description: "Erro ao atualizar cupom",
        variant: "destructive"
      });
      throw error;
    }
  };

  const deleteCoupon = async (id: string) => {
    try {
      await couponService.deleteCoupon(id);
      setCoupons(prev => prev.filter(coupon => coupon.id !== id));
      toast({
        title: "Cupom excluído",
        description: "Cupom removido com sucesso",
      });
    } catch (error) {
      console.error('Erro ao excluir cupom:', error);
      toast({
        title: "Erro",
        description: "Erro ao excluir cupom",
        variant: "destructive"
      });
      throw error;
    }
  };

  const getCouponStats = async (couponId: string): Promise<CouponUsageStats> => {
    try {
      return await couponService.getCouponStats(couponId);
    } catch (error) {
      console.error('Erro ao buscar estatísticas do cupom:', error);
      return {
        total_orders: 0,
        total_sales: 0,
        unique_customers: 0,
        total_discount_given: 0
      };
    }
  };

  const getAutoCoupons = async (establishmentId: string) => {
    try {
      return await couponService.getAutoCoupons(establishmentId);
    } catch (error) {
      console.error('Erro ao buscar cupons automáticos:', error);
      return [];
    }
  };

  useEffect(() => {
    fetchCoupons();
  }, []);

  return {
    coupons,
    isLoading,
    createCoupon,
    updateCoupon,
    deleteCoupon,
    getCouponStats,
    getAutoCoupons,
    refetch: fetchCoupons
  };
};