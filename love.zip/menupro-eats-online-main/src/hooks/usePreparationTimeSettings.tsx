
import { useState, useEffect } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { useToast } from '@/hooks/use-toast';

interface PreparationTimeSettings {
  id?: string;
  default_preparation_time: number;
  peak_hours_start?: string;
  peak_hours_end?: string;
  peak_hours_extra_time?: number;
  auto_send_whatsapp: boolean;
  whatsapp_message_template: string;
}

interface CategoryPreparationTime {
  id?: string;
  category_name: string;
  preparation_time: number;
}

export const usePreparationTimeSettings = () => {
  const [settings, setSettings] = useState<PreparationTimeSettings>({
    default_preparation_time: 30,
    auto_send_whatsapp: true,
    whatsapp_message_template: '🍽️ Pedido confirmado! Estimamos {tempo} minutos para preparo. Em breve estará a caminho!'
  });
  const [categoryTimes, setCategoryTimes] = useState<CategoryPreparationTime[]>([]);
  const [loading, setLoading] = useState(true);
  const { toast } = useToast();

  useEffect(() => {
    fetchSettings();
    fetchCategoryTimes();
  }, []);

  const fetchSettings = async () => {
    try {
      const { data, error } = await supabase
        .from('preparation_time_settings')
        .select('*')
        .maybeSingle();

      if (error && error.code !== 'PGRST116') {
        throw error;
      }

      if (data) {
        setSettings(data);
      }
    } catch (error) {
      console.error('Erro ao buscar configurações:', error);
      toast({
        title: "Erro ao carregar configurações",
        description: "Não foi possível carregar as configurações de tempo",
        variant: "destructive"
      });
    } finally {
      setLoading(false);
    }
  };

  const fetchCategoryTimes = async () => {
    try {
      const { data, error } = await supabase
        .from('category_preparation_times')
        .select('*')
        .order('category_name');

      if (error) throw error;
      setCategoryTimes(data || []);
    } catch (error) {
      console.error('Erro ao buscar tempos por categoria:', error);
    }
  };

  const saveSettings = async (newSettings: PreparationTimeSettings) => {
    try {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) throw new Error('Usuário não autenticado');

      const settingsData = {
        ...newSettings,
        user_id: user.id,
        updated_at: new Date().toISOString()
      };

      const { error } = await supabase
        .from('preparation_time_settings')
        .upsert(settingsData, { onConflict: 'user_id' });

      if (error) throw error;

      setSettings(newSettings);
      toast({
        title: "Configurações salvas!",
        description: "As configurações de tempo foram atualizadas com sucesso"
      });
    } catch (error) {
      console.error('Erro ao salvar configurações:', error);
      toast({
        title: "Erro ao salvar",
        description: "Não foi possível salvar as configurações",
        variant: "destructive"
      });
    }
  };

  const saveCategoryTime = async (categoryTime: CategoryPreparationTime) => {
    try {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) throw new Error('Usuário não autenticado');

      const { error } = await supabase
        .from('category_preparation_times')
        .upsert({
          ...categoryTime,
          user_id: user.id,
          updated_at: new Date().toISOString()
        }, { onConflict: 'user_id,category_name' });

      if (error) throw error;

      fetchCategoryTimes();
      toast({
        title: "Tempo personalizado salvo!",
        description: `Tempo para categoria "${categoryTime.category_name}" atualizado`
      });
    } catch (error) {
      console.error('Erro ao salvar tempo da categoria:', error);
      toast({
        title: "Erro ao salvar",
        description: "Não foi possível salvar o tempo da categoria",
        variant: "destructive"
      });
    }
  };

  const deleteCategoryTime = async (id: string) => {
    try {
      const { error } = await supabase
        .from('category_preparation_times')
        .delete()
        .eq('id', id);

      if (error) throw error;

      fetchCategoryTimes();
      toast({
        title: "Tempo removido!",
        description: "Tempo personalizado da categoria foi removido"
      });
    } catch (error) {
      console.error('Erro ao deletar tempo da categoria:', error);
      toast({
        title: "Erro ao remover",
        description: "Não foi possível remover o tempo da categoria",
        variant: "destructive"
      });
    }
  };

  const calculateEstimatedTime = (categories: string[] = []) => {
    const now = new Date();
    const currentTime = now.toTimeString().slice(0, 5);
    
    let baseTime = settings.default_preparation_time;

    // Verificar se há tempo personalizado para as categorias
    if (categories.length > 0) {
      const maxCategoryTime = Math.max(
        ...categories.map(category => {
          const categoryTime = categoryTimes.find(ct => ct.category_name === category);
          return categoryTime ? categoryTime.preparation_time : 0;
        })
      );
      
      if (maxCategoryTime > 0) {
        baseTime = maxCategoryTime;
      }
    }

    // Verificar horário de pico
    if (settings.peak_hours_start && settings.peak_hours_end && settings.peak_hours_extra_time) {
      if (currentTime >= settings.peak_hours_start && currentTime <= settings.peak_hours_end) {
        baseTime += settings.peak_hours_extra_time;
      }
    }

    return baseTime;
  };

  return {
    settings,
    categoryTimes,
    loading,
    saveSettings,
    saveCategoryTime,
    deleteCategoryTime,
    calculateEstimatedTime
  };
};
