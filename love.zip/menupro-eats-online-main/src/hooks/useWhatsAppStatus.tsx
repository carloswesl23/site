import { useState, useEffect, useCallback } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { useToast } from '@/hooks/use-toast';

interface WhatsAppInstance {
  id: string;
  instance_id: string;
  token_instance: string;
  status: string;
  numero_cliente?: string;
}

export const useWhatsAppStatus = (instance: WhatsAppInstance | null) => {
  const [connectionStatus, setConnectionStatus] = useState<string>('disconnected');
  const [phoneNumber, setPhoneNumber] = useState<string | null>(null);
  const [isChecking, setIsChecking] = useState(false);
  const { toast } = useToast();

  const checkStatus = useCallback(async () => {
    if (!instance || !instance.instance_id || !instance.token_instance) {
      setConnectionStatus('disconnected');
      return;
    }

    setIsChecking(true);
    try {
      console.log('Checking WhatsApp status for instance:', instance.instance_id);
      
      const { data, error } = await supabase.functions.invoke('wa-device-status', {
        body: {
          instanceId: instance.instance_id,
          tokenInstance: instance.token_instance
        }
      });

      if (error) {
        console.error('Error checking status:', error);
        throw error;
      }

      console.log('Status response:', data);

      setConnectionStatus(data.status || 'disconnected');
      setPhoneNumber(data.phone || null);

      // Update local instance data if status changed
      if (data.status !== instance.status) {
        toast({
          title: "Status atualizado",
          description: `WhatsApp ${data.status === 'connected' ? 'conectado' : 'desconectado'}`,
          variant: data.status === 'connected' ? 'default' : 'destructive'
        });
      }

    } catch (error: any) {
      console.error('Failed to check WhatsApp status:', error);
      setConnectionStatus('disconnected');
      setPhoneNumber(null);
    } finally {
      setIsChecking(false);
    }
  }, [instance, toast]);

  // Check status immediately when instance changes
  useEffect(() => {
    if (instance) {
      checkStatus();
    } else {
      setConnectionStatus('disconnected');
      setPhoneNumber(null);
    }
  }, [instance, checkStatus]);

  // Auto-check status every 30 seconds for connected instances
  useEffect(() => {
    if (!instance || connectionStatus !== 'connected') return;

    const interval = setInterval(() => {
      checkStatus();
    }, 30000);

    return () => clearInterval(interval);
  }, [instance, connectionStatus, checkStatus]);

  // Manual refresh function
  const refreshStatus = useCallback(() => {
    checkStatus();
  }, [checkStatus]);

  return {
    connectionStatus,
    phoneNumber,
    isChecking,
    refreshStatus,
    isConnected: connectionStatus === 'connected'
  };
};