import { useState, useEffect } from "react";
import { supabase } from "@/integrations/supabase/client";
import { mercadoPagoService, type MercadoPagoConfig } from "@/services/mercadoPagoService";
import { useToast } from "@/hooks/use-toast";

export const useMercadoPago = () => {
  const [config, setConfig] = useState<MercadoPagoConfig | null>(null);
  const [loading, setLoading] = useState(false);
  const { toast } = useToast();

  const loadConfig = async () => {
    try {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) return;

      const mpConfig = await mercadoPagoService.loadConfig(user.id);
      setConfig(mpConfig);
    } catch (error) {
      console.error('Error loading MercadoPago config:', error);
    }
  };

  useEffect(() => {
    loadConfig();
  }, []);

  const createPayment = async (paymentData: {
    amount: number;
    description: string;
    orderId: string;
    customerEmail: string;
    customerName?: string;
  }) => {
    if (!config || !config.enabled) {
      toast({
        title: "Erro",
        description: "Mercado Pago não está configurado",
        variant: "destructive"
      });
      return null;
    }

    setLoading(true);
    try {
      const payment = await mercadoPagoService.createPayment({
        transaction_amount: paymentData.amount,
        description: paymentData.description,
        external_reference: paymentData.orderId,
        payer: {
          email: paymentData.customerEmail,
          first_name: paymentData.customerName?.split(' ')[0],
          last_name: paymentData.customerName?.split(' ').slice(1).join(' ')
        }
      });

      return payment;
    } catch (error) {
      console.error('Error creating payment:', error);
      toast({
        title: "Erro no pagamento",
        description: "Não foi possível processar o pagamento",
        variant: "destructive"
      });
      return null;
    } finally {
      setLoading(false);
    }
  };

  const createPreference = async (paymentData: {
    amount: number;
    description: string;
    orderId: string;
    customerEmail: string;
    customerName?: string;
    successUrl?: string;
    failureUrl?: string;
  }) => {
    if (!config || !config.enabled) {
      toast({
        title: "Erro",
        description: "Mercado Pago não está configurado",
        variant: "destructive"
      });
      return null;
    }

    setLoading(true);
    try {
      const preference = await mercadoPagoService.createPreference({
        transaction_amount: paymentData.amount,
        description: paymentData.description,
        external_reference: paymentData.orderId,
        payer: {
          email: paymentData.customerEmail,
          first_name: paymentData.customerName?.split(' ')[0],
          last_name: paymentData.customerName?.split(' ').slice(1).join(' ')
        },
        success_url: paymentData.successUrl,
        failure_url: paymentData.failureUrl
      });

      return preference;
    } catch (error) {
      console.error('Error creating preference:', error);
      toast({
        title: "Erro no pagamento",
        description: "Não foi possível gerar link de pagamento",
        variant: "destructive"
      });
      return null;
    } finally {
      setLoading(false);
    }
  };

  const checkPaymentStatus = async (paymentId: string) => {
    if (!config || !config.enabled) return null;

    try {
      const payment = await mercadoPagoService.getPayment(paymentId);
      return payment;
    } catch (error) {
      console.error('Error checking payment status:', error);
      return null;
    }
  };

  return {
    config,
    loading,
    createPayment,
    createPreference,
    checkPaymentStatus,
    isEnabled: config?.enabled || false,
    reloadConfig: loadConfig
  };
};