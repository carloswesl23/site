// FUNCIONALIDADE DESATIVADA - WhatsApp 2.0 temporariamente desabilitado
// Use useWhatsAppInstances para funcionalidade WhatsApp principal

import { useState, useCallback } from "react";
import { useToast } from "@/hooks/use-toast";

interface WhatsAppSession {
  id: string;
  tenant_id: string;
  session_key: string;
  status: 'PENDING_QR' | 'QR_AVAILABLE' | 'CONNECTED' | 'DISCONNECTED' | 'ERROR';
  phone_number?: string;
  device_name?: string;
  last_qr?: string;
  last_qr_at?: string;
  last_error?: string;
  created_at: string;
  updated_at: string;
}

export const useWhatsAppSessions = () => {
  const { toast } = useToast();
  const [sessions] = useState<WhatsAppSession[]>([]);
  const [loading] = useState(false);
  const [creating] = useState(false);

  const createSession = useCallback(async () => {
    toast({
      title: "Funcionalidade Desativada",
      description: "WhatsApp 2.0 está temporariamente desativado. Use a funcionalidade principal do WhatsApp.",
      variant: "destructive"
    });
    throw new Error('Funcionalidade desativada');
  }, [toast]);

  const getQrCode = useCallback(async () => {
    toast({
      title: "Funcionalidade Desativada",
      description: "WhatsApp 2.0 está temporariamente desativado.",
      variant: "destructive"
    });
    throw new Error('Funcionalidade desativada');
  }, [toast]);

  const getSessionStatus = useCallback(async () => {
    throw new Error('Funcionalidade desativada');
  }, []);

  const resetSession = useCallback(async () => {
    toast({
      title: "Funcionalidade Desativada",
      description: "WhatsApp 2.0 está temporariamente desativado.",
      variant: "destructive"
    });
  }, [toast]);

  const sendMessage = useCallback(async () => {
    toast({
      title: "Funcionalidade Desativada",
      description: "WhatsApp 2.0 está temporariamente desativado.",
      variant: "destructive"
    });
    throw new Error('Funcionalidade desativada');
  }, [toast]);

  return {
    sessions,
    loading,
    creating,
    createSession,
    getQrCode,
    getSessionStatus,
    resetSession,
    sendMessage,
    refetch: () => Promise.resolve()
  };
};