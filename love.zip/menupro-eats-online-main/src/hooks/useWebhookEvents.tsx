
import { useWebhookSender } from "./useWebhookSender";
import type { 
  PedidoCriadoData, 
  PagamentoConfirmadoData, 
  PedidoCanceladoData, 
  NovoClienteData 
} from "@/utils/webhookEvents";

export const useWebhookEvents = () => {
  const { sendWebhook } = useWebhookSender();

  const triggerPedidoCriado = async (data: PedidoCriadoData) => {
    return sendWebhook({
      event_type: 'pedido_criado',
      data
    });
  };

  const triggerPagamentoConfirmado = async (data: PagamentoConfirmadoData) => {
    return sendWebhook({
      event_type: 'pagamento_confirmado',
      data
    });
  };

  const triggerPedidoCancelado = async (data: PedidoCanceladoData) => {
    return sendWebhook({
      event_type: 'pedido_cancelado',
      data
    });
  };

  const triggerNovoCliente = async (data: NovoClienteData) => {
    return sendWebhook({
      event_type: 'novo_cliente',
      data
    });
  };

  return {
    triggerPedidoCriado,
    triggerPagamentoConfirmado,
    triggerPedidoCancelado,
    triggerNovoCliente
  };
};
