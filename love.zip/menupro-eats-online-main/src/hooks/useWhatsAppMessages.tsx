import { useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { useToast } from "@/hooks/use-toast";

interface OrderData {
  establishment_name: string;
  order_number: string;
  customer_name: string;
  customer_phone: string;
  address?: {
    street: string;
    number: string;
    neighborhood: string;
    city: string;
    zipCode: string;
  };
  items: any[];
  subtotal: number;
  delivery_fee: number;
  total: number;
  payment_method: string;
  pix_key?: string;
  pix_beneficiary_name?: string;
}

export const useWhatsAppMessages = () => {
  const { toast } = useToast();
  const [sending, setSending] = useState(false);

  const sendWhatsAppMessage = async (
    userId: string,
    orderId: string,
    messageType: 'new_order' | 'pix' | 'payment_confirmed' | 'out_for_delivery',
    phoneNumber: string,
    orderData: OrderData
  ) => {
    setSending(true);
    try {
      const { data, error } = await supabase.functions.invoke('send-whatsapp-auto-message', {
        body: {
          user_id: userId,
          order_id: orderId,
          message_type: messageType,
          phone_number: phoneNumber,
          order_data: orderData
        }
      });

      if (error) {
        throw error;
      }

      // Verificar se o envio foi bem-sucedido
      if (data && !data.success) {
        console.log('Mensagem não enviada:', data.message);
        // Não mostrar erro para configurações desativadas
        return data;
      }

      return data;
    } catch (error) {
      console.error('Erro ao enviar mensagem WhatsApp:', error);
      toast({
        title: "Erro no envio",
        description: "Não foi possível enviar a mensagem via WhatsApp.",
        variant: "destructive"
      });
      throw error;
    } finally {
      setSending(false);
    }
  };

  const sendNewOrderMessage = async (userId: string, orderId: string, phoneNumber: string, orderData: OrderData) => {
    return sendWhatsAppMessage(userId, orderId, 'new_order', phoneNumber, orderData);
  };

  const sendPixMessage = async (userId: string, orderId: string, phoneNumber: string, orderData: OrderData) => {
    return sendWhatsAppMessage(userId, orderId, 'pix', phoneNumber, orderData);
  };

  const sendPaymentConfirmedMessage = async (userId: string, orderId: string, phoneNumber: string, orderData: OrderData) => {
    return sendWhatsAppMessage(userId, orderId, 'payment_confirmed', phoneNumber, orderData);
  };

  const sendOutForDeliveryMessage = async (userId: string, orderId: string, phoneNumber: string, orderData: OrderData) => {
    return sendWhatsAppMessage(userId, orderId, 'out_for_delivery', phoneNumber, orderData);
  };

  // Função para enviar mensagem de novo pedido automaticamente após criar um pedido
  const sendOrderNotification = async (
    establishmentId: string, 
    orderNumber: string, 
    customerData: {
      name: string;
      phone: string;
      email?: string;
      address?: any;
      deliveryType?: string;
    },
    cart: any[],
    paymentMethod: string,
    total: number,
    establishmentName: string
  ) => {
    try {
      const orderData: OrderData = {
        establishment_name: establishmentName,
        order_number: orderNumber,
        customer_name: customerData.name,
        customer_phone: customerData.phone,
        address: customerData.address,
        items: cart.map(item => ({
          id: item.id,
          product_name: item.product?.name || item.name,
          quantity: item.quantity,
          price: item.totalPrice || item.price,
          customizations: item.customizations
        })),
        subtotal: total,
        delivery_fee: 0, // Pode ser calculado se necessário
        total: total,
        payment_method: paymentMethod
      };

      await sendNewOrderMessage(establishmentId, orderNumber, customerData.phone, orderData);
      
      // Se for PIX, enviar mensagem com dados de pagamento também
      if (paymentMethod === 'pix') {
        await sendPixMessage(establishmentId, orderNumber, customerData.phone, orderData);
      }
      
    } catch (error) {
      console.error('Erro ao enviar notificação de pedido:', error);
      // Não quebra o fluxo se o WhatsApp falhar
    }
  };

  return {
    sending,
    sendNewOrderMessage,
    sendPixMessage,
    sendPaymentConfirmedMessage,
    sendOutForDeliveryMessage,
    sendOrderNotification
  };
};