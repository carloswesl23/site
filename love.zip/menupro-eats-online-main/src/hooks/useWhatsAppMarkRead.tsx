import { useState } from 'react';
import { supabase } from '@/integrations/supabase/client';

export const useWhatsAppMarkRead = () => {
  const [isLoading, setIsLoading] = useState(false);

  const markAsRead = async (instanceId: string, tokenInstance: string, phone: string, userId: string) => {
    setIsLoading(true);
    
    try {
      const { data, error } = await supabase.functions.invoke('wa-mark-read', {
        body: {
          instanceId,
          tokenInstance,
          phone,
          userId
        }
      });

      if (error) {
        console.error('Erro ao marcar como lido:', error);
        return false;
      }

      console.log('Mensagens marcadas como lidas:', data);
      return true;
    } catch (error) {
      console.error('Erro ao marcar como lido:', error);
      return false;
    } finally {
      setIsLoading(false);
    }
  };

  return {
    markAsRead,
    isLoading
  };
};