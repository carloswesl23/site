import { useState, useEffect } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { useToast } from '@/hooks/use-toast';

export interface WhatsAppInstance {
  id: string;
  user_id: string;
  instance_id: string;
  instance_name: string;
  token_instance: string;
  webhook_url: string | null;
  status: string;
  qr_code: string | null;
  numero_cliente: string | null;
  codigo_verificacao: string | null;
  verificado_em: string | null;
  versao: string | null;
  mensagens: any[] | null;
  phone_number: string | null;
  created_at: string;
  updated_at: string;
}

export const useWhatsAppInstances = () => {
  const [instances, setInstances] = useState<WhatsAppInstance[]>([]);
  const [loading, setLoading] = useState(true);
  const [creating, setCreating] = useState(false);
  const [updating, setUpdating] = useState(false);
  const [generatingQr, setGeneratingQr] = useState(false);
  const [qrAttempts, setQrAttempts] = useState<{ [key: string]: number }>({});
  const [qrIntervals, setQrIntervals] = useState<{ [key: string]: NodeJS.Timeout }>({});
  const { toast } = useToast();

  const fetchInstances = async () => {
    try {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) return;

      const { data, error } = await supabase
        .from('whatsapp_instances')
        .select('*')
        .eq('user_id', user.id)
        .order('created_at', { ascending: false });

      if (error) {
        console.error('Error fetching instances:', error);
        toast({
          title: "Erro",
          description: "Erro ao carregar instâncias do WhatsApp",
          variant: "destructive",
        });
      } else {
        setInstances((data as WhatsAppInstance[]) || []);
      }
    } catch (error) {
      console.error('Error:', error);
    } finally {
      setLoading(false);
    }
  };

  const createInstance = async (instanceName: string, phoneNumber: string) => {
    setCreating(true);
    try {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) {
        throw new Error('Usuário não autenticado');
      }

      // Verificar se já existe uma instância para este usuário
      if (instances.length > 0) {
        throw new Error('Você já possui uma instância WhatsApp. Apenas uma instância é permitida por conta.');
      }

      console.log('Criando instância Z-API:', { instanceName, phoneNumber, userId: user.id });

      const { data, error } = await supabase.functions.invoke('criar-instancia-zapi', {
        body: {
          instanceName,
          phoneNumber,
          userId: user.id,
        }
      });

      console.log('Resposta da função criar-instancia-zapi:', { data, error });

      if (error) {
        console.error('Erro da edge function:', error);
        throw new Error(error.message || 'Erro ao criar instância');
      }

      if (data?.success) {
        await fetchInstances();
        
        toast({
          title: "✅ Instância criada com sucesso!",
          description: data.qrCode ? "QR Code disponível! Escaneie para conectar." : "Instância criada, aguardando inicialização...",
        });

        // Se não tem QR code, tentar gerar após alguns segundos
        if (data.instanceId && !data.qrCode) {
          setTimeout(() => {
            generateQrCodeForInstance(data.instanceId);
          }, 5000);
        }
        
        // Iniciar polling para atualizações de status
        if (data.instanceId) {
          setTimeout(() => {
            startInstanceStatusPolling(data.instanceId);
          }, 3000);
        }
        
        return data;
      } else {
        throw new Error(data?.error || 'Erro desconhecido ao criar instância');
      }
    } catch (error: any) {
      console.error('Error creating instance:', error);
      
      let errorMessage = "Erro ao criar instância do WhatsApp";
      if (error.message?.includes('ZAPI_PARTNER_TOKEN')) {
        errorMessage = "Token Z-API não configurado corretamente";
      } else if (error.message?.includes('Client-Token')) {
        errorMessage = "Token Z-API inválido ou não autorizado";
      } else if (error.message) {
        errorMessage = error.message;
      }
      
      toast({
        title: "Erro",
        description: errorMessage,
        variant: "destructive",
      });
      throw error;
    } finally {
      setCreating(false);
    }
  };

  // Função para gerar QR code para uma instância específica
  const generateQrCodeForInstance = async (instanceId: string) => {
    try {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) return;

      console.log(`Tentando gerar QR Code para instância: ${instanceId}`);

      const { data, error } = await supabase.functions.invoke('gerar-qr-code', {
        body: {
          instanceId,
          userId: user.id,
        }
      });

      if (error) {
        console.error('Erro ao gerar QR code:', error);
        return;
      }

      if (data?.success && data?.qrCode) {
        console.log('QR Code gerado com sucesso!');
        await fetchInstances();
        toast({
          title: "✅ QR Code disponível!",
          description: "QR Code gerado automaticamente. Escaneie para conectar.",
        });
      }
    } catch (error) {
      console.error('Erro na função generateQrCodeForInstance:', error);
    }
  };

  // Função para fazer polling do status da instância após criação
  const startInstanceStatusPolling = (instanceId: string) => {
    let pollCount = 0;
    const maxPolls = 20; // Máximo 1 minuto (20 * 3 segundos)
    
    console.log(`Iniciando polling para instância: ${instanceId}`);
    
    const pollInterval = setInterval(async () => {
      pollCount++;
      
      try {
        // Refetch instances para ter dados atualizados
        await fetchInstances();
        
        // Buscar a instância atualizada
        const { data: updatedInstances } = await supabase
          .from('whatsapp_instances')
          .select('*')
          .eq('instance_id', instanceId);
          
        const instance = updatedInstances?.[0];
        if (!instance) {
          console.log(`Instância ${instanceId} não encontrada, parando polling`);
          clearInterval(pollInterval);
          return;
        }

        console.log(`Polling attempt ${pollCount} for ${instanceId}: Status = ${instance.status}, QR = ${!!instance.qr_code}`);

        // Verificar se a instância tem QR code ou está conectada
        if (instance.qr_code && instance.status === 'qrcode') {
          clearInterval(pollInterval);
          toast({
            title: "✅ QR Code disponível!",
            description: "Escaneie o QR Code abaixo para conectar seu WhatsApp.",
          });
          return;
        }
        
        if (instance.status === 'connected') {
          clearInterval(pollInterval);
          toast({
            title: "✅ WhatsApp conectado!",
            description: "Instância conectada com sucesso.",
          });
          return;
        }
        
        if (pollCount >= maxPolls) {
          clearInterval(pollInterval);
          toast({
            title: "⏱️ Aguardando QR Code",
            description: "A geração do QR Code está demorando. Atualize a página ou clique em 'Gerar QR Code' manualmente.",
            variant: "destructive",
          });
        }
      } catch (error) {
        console.error('Error during status polling:', error);
        if (pollCount >= maxPolls) {
          clearInterval(pollInterval);
        }
      }
    }, 3000); // Poll a cada 3 segundos
  };

  // Nova função para sincronizar status via edge function
  const syncInstanceStatus = async (instanceId?: string) => {
    setUpdating(true);
    try {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) {
        throw new Error('Usuário não autenticado');
      }

      console.log('Syncing instance status via new edge function');

      const { data, error } = await supabase.functions.invoke('wa-instance-status-sync', {
        body: { userId: user.id }
      });

      if (error) {
        throw new Error(error.message || 'Erro ao sincronizar status');
      }

      if (data?.success) {
        let message = "Status sincronizado com sucesso!";
        
        if (data.status === 'connected') {
          message = `✅ WhatsApp conectado${data.numero_cliente ? ` - ${data.numero_cliente}` : ''}`;
          
          // Parar renovação automática de QR code se houver
          if (instanceId && qrIntervals[instanceId]) {
            clearInterval(qrIntervals[instanceId]);
            setQrIntervals(prev => {
              const newIntervals = { ...prev };
              delete newIntervals[instanceId];
              return newIntervals;
            });
          }
          
          toast({
            title: "WhatsApp Conectado!",
            description: message,
          });
        } else if (data.status === 'qrcode') {
          message = "QR Code disponível! Escaneie com seu WhatsApp.";
        }
        
        await fetchInstances();
        return data;
      } else {
        throw new Error(data?.error || 'Erro na sincronização');
      }
    } catch (error: any) {
      console.error('Error syncing status:', error);
      toast({
        title: "Erro",
        description: error.message || "Erro ao sincronizar status da instância",
        variant: "destructive",
      });
      throw error;
    } finally {
      setUpdating(false);
    }
  };

  // Manter função antiga para compatibilidade
  const updateInstanceStatus = async (instanceId: string, instanceToken?: string) => {
    return syncInstanceStatus(instanceId);
  };

  // Função para verificar status em tempo real
  const checkInstanceStatus = async (instanceId: string, instanceToken: string) => {
    try {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) return;

      const url = new URL(`https://mzhyxympbmjjergvbwfa.supabase.co/functions/v1/zapi-manager`);
      url.searchParams.set('action', 'status');
      
      const { data: { session } } = await supabase.auth.getSession();
      
      const response = await fetch(url.toString(), {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${session?.access_token}`,
        },
        body: JSON.stringify({
          instanceId,
          instanceToken,
          userId: user.id,
        }),
      });

      if (response.ok) {
        await fetchInstances();
      }
    } catch (error) {
      console.error('Error checking instance status:', error);
    }
  };

  const disconnectInstance = async (instanceId: string) => {
    try {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) {
        throw new Error('Usuário não autenticado');
      }

      const url = new URL(`https://mzhyxympbmjjergvbwfa.supabase.co/functions/v1/zapi-manager`);
      url.searchParams.set('action', 'disconnect');
      
      const { data: { session } } = await supabase.auth.getSession();
      
      const response = await fetch(url.toString(), {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${session?.access_token}`,
        },
        body: JSON.stringify({
          instanceId,
          userId: user.id,
        }),
      });

      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.error || 'Erro ao desconectar');
      }

      const data = await response.json();
      if (data.success) {
        toast({
          title: "Sucesso",
          description: "WhatsApp desconectado com sucesso! Agora você pode reconectar com um novo QR Code.",
        });
        await fetchInstances();
      } else {
        throw new Error(data.error || 'Erro ao desconectar');
      }
    } catch (error: any) {
      console.error('Error disconnecting instance:', error);
      toast({
        title: "Erro",
        description: error.message || "Erro ao desconectar WhatsApp",
        variant: "destructive",
      });
      throw error;
    }
  };

  const generateQrCode = async (instanceId: string): Promise<void> => {
    try {
      setGeneratingQr(true);
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) {
        throw new Error('Usuário não autenticado');
      }

      // Limpar interval anterior se existir
      if (qrIntervals[instanceId]) {
        clearInterval(qrIntervals[instanceId]);
      }

      // Resetar contador de tentativas
      setQrAttempts(prev => ({ ...prev, [instanceId]: 0 }));

      const { data, error } = await supabase.functions.invoke('gerar-qr-code', {
        body: {
          instanceId,
          userId: user.id,
        }
      });

      if (error) {
        // Tratar diferentes tipos de erro com mensagens específicas
        if (error.message?.includes('already connected')) {
          toast({
            title: "WhatsApp já conectado",
            description: "Esta instância já está conectada ao WhatsApp",
            variant: "default",
          });
          return;
        }
        
        if (error.message?.includes('not ready')) {
          toast({
            title: "Instância não está pronta",
            description: "Aguarde alguns segundos e tente novamente",
            variant: "destructive",
          });
          return;
        }
        
        // Para qualquer outro erro, mostrar a mensagem genérica
        toast({
          title: "Erro ao gerar QR Code",
          description: error.message || 'Erro desconhecido',
          variant: "destructive",
        });
        return;
      }

      if (data?.success && data?.qrCode) {
        toast({
          title: "✅ QR Code gerado",
          description: "Escaneie o código para conectar seu WhatsApp. O código será renovado automaticamente.",
        });
        await fetchInstances();
        
        // Iniciar renovação automática do QR Code
        startQrRenewal(instanceId);
      } else {
        throw new Error(data?.error || 'QR Code não disponível');
      }
    } catch (error: any) {
      console.error('Error generating QR code:', error);
      toast({
        title: "Erro",
        description: error.message || 'Erro ao gerar QR Code',
        variant: "destructive",
      });
      throw error;
    } finally {
      setGeneratingQr(false);
    }
  };

  // Função para renovar QR Code automaticamente
  const startQrRenewal = (instanceId: string) => {
    const renewQrCode = async () => {
      try {
        const currentAttempts = qrAttempts[instanceId] || 0;
        
        // Verificar se atingiu o limite de 3 tentativas
        if (currentAttempts >= 3) {
          console.log(`QR Code renewal stopped for instance ${instanceId} - max attempts reached`);
          if (qrIntervals[instanceId]) {
            clearInterval(qrIntervals[instanceId]);
            setQrIntervals(prev => {
              const newIntervals = { ...prev };
              delete newIntervals[instanceId];
              return newIntervals;
            });
          }
          
          toast({
            title: "⏱️ QR Code expirado",
            description: "O QR Code foi renovado 3 vezes sem leitura. Clique em 'Gerar QR Code' para tentar novamente.",
            variant: "destructive",
          });
          return;
        }

        // Verificar se a instância ainda precisa de QR Code
        const instance = instances.find(inst => inst.instance_id === instanceId);
        if (!instance || instance.status === 'connected') {
          console.log(`Stopping QR renewal for instance ${instanceId} - connected or not found`);
          if (qrIntervals[instanceId]) {
            clearInterval(qrIntervals[instanceId]);
            setQrIntervals(prev => {
              const newIntervals = { ...prev };
              delete newIntervals[instanceId];
              return newIntervals;
            });
          }
          return;
        }

        // Incrementar contador de tentativas
        setQrAttempts(prev => ({ ...prev, [instanceId]: currentAttempts + 1 }));

        console.log(`Renewing QR Code for instance ${instanceId} - attempt ${currentAttempts + 1}/3`);
        
        const { data: { user } } = await supabase.auth.getUser();
        if (!user) return;

        const { data, error } = await supabase.functions.invoke('gerar-qr-code', {
          body: {
            instanceId,
            userId: user.id,
          }
        });

        if (!error && data?.success && data?.qrCode) {
          console.log(`QR Code renewed successfully for instance ${instanceId}`);
          await fetchInstances();
        }
      } catch (error) {
        console.error('Error renewing QR code:', error);
      }
    };

    // Renovar a cada 15 segundos (entre 10-20 segundos conforme recomendado)
    const interval = setInterval(renewQrCode, 15000);
    setQrIntervals(prev => ({ ...prev, [instanceId]: interval }));
  };

  // Função para parar renovação de QR Code
  const stopQrRenewal = (instanceId: string) => {
    if (qrIntervals[instanceId]) {
      clearInterval(qrIntervals[instanceId]);
      setQrIntervals(prev => {
        const newIntervals = { ...prev };
        delete newIntervals[instanceId];
        return newIntervals;
      });
    }
    setQrAttempts(prev => {
      const newAttempts = { ...prev };
      delete newAttempts[instanceId];
      return newAttempts;
    });
  };

  const connectWithPhone = async (instanceId: string, phone: string): Promise<{ needsVerification?: boolean }> => {
    try {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) {
        throw new Error('Usuário não autenticado');
      }

      const url = new URL(`https://mzhyxympbmjjergvbwfa.supabase.co/functions/v1/zapi-manager`);
      url.searchParams.set('action', 'connect-phone');
      
      const { data: { session } } = await supabase.auth.getSession();
      
      const response = await fetch(url.toString(), {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${session?.access_token}`,
        },
        body: JSON.stringify({
          instanceId,
          userId: user.id,
          phone,
        }),
      });

      if (!response.ok) {
        const errorData = await response.json();
        toast({
          title: "Erro ao conectar telefone",
          description: errorData.message || errorData.error || 'Erro desconhecido',
          variant: "destructive",
        });
        return;
      }

      const data = await response.json();
      if (data.success) {
        toast({
          title: "✅ Conexão iniciada",
          description: data.message || "Verifique seu telefone para confirmar a conexão",
        });
        await fetchInstances();
        
        // Retornar se precisa de verificação
        return { needsVerification: data.status === 'waiting_verification' };
      } else {
        throw new Error(data.error || 'Erro ao conectar telefone');
      }
    } catch (error: any) {
      console.error('Error connecting with phone:', error);
      toast({
        title: "Erro",
        description: error.message || 'Erro ao conectar telefone',
        variant: "destructive",
      });
      throw error;
    }
  };

  const verifyCode = async (instanceId: string, code: string): Promise<void> => {
    try {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) {
        throw new Error('Usuário não autenticado');
      }

      const url = new URL(`https://mzhyxympbmjjergvbwfa.supabase.co/functions/v1/zapi-manager`);
      url.searchParams.set('action', 'verify-code');
      
      const { data: { session } } = await supabase.auth.getSession();
      
      const response = await fetch(url.toString(), {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${session?.access_token}`,
        },
        body: JSON.stringify({
          instanceId,
          code,
          userId: user.id,
        }),
      });

      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.message || errorData.error || 'Erro ao verificar código');
      }

      const data = await response.json();
      
      if (!data.success) {
        throw new Error(data.message || data.error || 'Código inválido');
      }

      toast({
        title: "Sucesso",
        description: data.message || "WhatsApp conectado com sucesso!",
      });

      // Atualizar a lista de instâncias
      await fetchInstances();
      
    } catch (error: any) {
      console.error('Error verifying code:', error);
      toast({
        title: "Erro",
        description: error.message || "Erro ao verificar código",
        variant: "destructive",
      });
      throw error;
    }
  };

  // Cleanup intervals on unmount
  useEffect(() => {
    return () => {
      Object.values(qrIntervals).forEach(interval => clearInterval(interval));
    };
  }, [qrIntervals]);

  // Auto-refresh das instâncias a cada 30 segundos
  useEffect(() => {
    if (instances.length === 0) return;
    
    const interval = setInterval(() => {
      instances.forEach(instance => {
        if (instance.status === 'disconnected' || instance.status === 'initializing') {
          updateInstanceStatus(instance.instance_id, instance.token_instance);
        } else if (instance.status === 'connected' && qrIntervals[instance.instance_id]) {
          // Parar renovação de QR code se conectou
          stopQrRenewal(instance.instance_id);
        }
      });
    }, 30000);

    return () => clearInterval(interval);
  }, [instances, updateInstanceStatus, qrIntervals]);

  // Polling automático para instâncias aguardando conexão
  useEffect(() => {
    const pendingInstances = instances.filter(
      instance => instance.status === 'disconnected' && instance.qr_code
    );

    if (pendingInstances.length === 0) return;

    const interval = setInterval(() => {
      pendingInstances.forEach(instance => {
        checkInstanceStatus(instance.instance_id, instance.token_instance);
      });
    }, 10000); // Verifica a cada 10 segundos

    return () => clearInterval(interval);
  }, [instances]);

  const updatePhoneNumber = async (instanceId: string, newPhoneNumber: string) => {
    try {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) {
        throw new Error('Usuário não autenticado');
      }

      // Atualizar no banco de dados
      const { error } = await supabase
        .from('whatsapp_instances')
        .update({ 
          numero_cliente: newPhoneNumber,
          updated_at: new Date().toISOString()
        })
        .eq('instance_id', instanceId)
        .eq('user_id', user.id);

      if (error) {
        throw new Error(error.message);
      }

      toast({
        title: "Sucesso",
        description: "Número de telefone atualizado com sucesso!",
      });

      await fetchInstances();
      return true;
    } catch (error: any) {
      console.error('Error updating phone number:', error);
      toast({
        title: "Erro",
        description: error.message || "Erro ao atualizar número de telefone",
        variant: "destructive",
      });
      throw error;
    }
  };

  useEffect(() => {
    fetchInstances();
  }, []);

  const createPhoneInstance = async (phoneNumber: string, instanceName: string) => {
    try {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) {
        throw new Error('Usuário não autenticado');
      }

      setCreating(true);
      
      // Integração direta com Z-API via edge function
      const response = await supabase.functions.invoke('criar-instancia-zapi', {
        body: {
          instanceName,
          phoneNumber,
          userId: user.id
        }
      });

      if (response.error) {
        throw new Error(response.error.message || 'Erro ao criar instância');
      }

      const result = response.data;
      
      if (!result.success) {
        throw new Error(result.error || 'Erro ao criar instância na Z-API');
      }

      await fetchInstances();
      
      toast({
        title: "Sucesso",
        description: "Instância criada! Aguarde o código de verificação via SMS.",
      });

      return { success: true };
    } catch (error: any) {
      console.error('Erro ao criar instância via telefone:', error);
      toast({
        title: "Erro",
        description: error instanceof Error ? error.message : "Erro ao criar instância",
        variant: "destructive"
      });
      throw error;
    } finally {
      setCreating(false);
    }
  };

  const verifyPhoneCode = async (instanceId: string, code: string) => {
    try {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) {
        throw new Error('Usuário não autenticado');
      }

      // Atualizar o código na instância
      const { error } = await supabase
        .from('whatsapp_instances')
        .update({ 
          codigo_verificacao: code,
          updated_at: new Date().toISOString()
        })
        .eq('id', instanceId)
        .eq('user_id', user.id);

      if (error) throw error;

      await fetchInstances();
      
      toast({
        title: "Código enviado",
        description: "Código de verificação atualizado. O n8n processará a verificação.",
      });

      return { success: true };
    } catch (error: any) {
      console.error('Erro ao verificar código:', error);
      toast({
        title: "Erro",
        description: "Erro ao verificar código.",
        variant: "destructive"
      });
      throw error;
    }
  };

  return {
    instances,
    loading,
    creating,
    updating,
    generatingQr,
    qrAttempts,
    createInstance,
    createPhoneInstance,
    verifyPhoneCode,
    updateInstanceStatus,
    syncInstanceStatus,
    disconnectInstance,
    generateQrCode,
    stopQrRenewal,
    connectWithPhone,
    verifyCode,
    updatePhoneNumber,
    checkInstanceStatus,
    refetch: fetchInstances,
  };
};