
import { useState, useEffect } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { useToast } from '@/hooks/use-toast';

interface OrderTracking {
  id?: string;
  order_number: string;
  customer_name: string;
  customer_phone: string;
  estimated_time: number;
  status: 'pending' | 'preparing' | 'delivery';
  whatsapp_sent: boolean;
  whatsapp_sent_at?: string;
  created_at?: string;
  updated_at?: string;
  // Campos extras para entrega
  delivery_address?: string;
  total?: number;
  payment_method?: string;
  items?: any[];
}

export const useOrderTracking = () => {
  const [orders, setOrders] = useState<OrderTracking[]>([]);
  const [loading, setLoading] = useState(true);
  const { toast } = useToast();

  useEffect(() => {
    fetchOrders();
  }, []);

  const fetchOrders = async () => {
    try {
      console.log('🔍 Buscando pedidos...');
      
      // Buscar pedidos da tabela principal (user_orders) em vez de order_preparation_tracking
      const { data, error } = await supabase
        .from('user_orders')
        .select('*')
        .neq('status', 'cancelled')
        .order('created_at', { ascending: false });

      if (error) throw error;
      
      console.log('📊 Dados brutos do banco:', data);
      
      // Mapear os pedidos para o formato esperado
      const typedOrders = (data || []).map(order => {
        const mappedStatus = mapOrderStatus(order.status);
        console.log(`🔄 Mapeando pedido ${order.order_number}: ${order.status} -> ${mappedStatus}`);
        
        return {
          id: order.id,
          order_number: order.order_number,
          customer_name: order.customer_name,
          customer_phone: order.customer_phone,
          estimated_time: 30, // Tempo padrão
          status: mappedStatus,
          whatsapp_sent: false, // Para compatibilidade
          created_at: order.created_at,
          updated_at: order.updated_at,
          // Dados extras necessários para o modal de entrega
          delivery_address: order.delivery_address,
          total: order.total,
          payment_method: order.payment_method,
          items: Array.isArray(order.items) ? order.items : []
        };
      });
      
      console.log('✅ Pedidos processados:', typedOrders);
      console.log('🧪 Pedidos com status preparing:', typedOrders.filter(o => o.status === 'preparing'));
      
      setOrders(typedOrders);
    } catch (error) {
      console.error('Erro ao buscar pedidos:', error);
      toast({
        title: "Erro ao carregar pedidos",
        description: "Não foi possível carregar o histórico de pedidos",
        variant: "destructive"
      });
    } finally {
      setLoading(false);
    }
  };

  // Mapear status da tabela user_orders para o formato esperado
  const mapOrderStatus = (status: string): 'pending' | 'preparing' | 'delivery' => {
    switch (status) {
      case 'pending':
      case 'confirmed':
        return 'pending';
      case 'preparing':
        return 'preparing';
      case 'ready':
      case 'ready_for_delivery':
      case 'out_for_delivery':
      case 'delivered':
        return 'delivery';
      default:
        return 'pending';
    }
  };

  const createOrderTracking = async (orderData: Omit<OrderTracking, 'id' | 'whatsapp_sent' | 'status'>) => {
    try {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) throw new Error('Usuário não autenticado');

      const { data, error } = await supabase
        .from('order_preparation_tracking')
        .insert({
          ...orderData,
          user_id: user.id,
          status: 'received',
          whatsapp_sent: false
        })
        .select()
        .single();

      if (error) throw error;

      fetchOrders();
      return data;
    } catch (error) {
      console.error('Erro ao criar rastreamento do pedido:', error);
      toast({
        title: "Erro ao criar rastreamento",
        description: "Não foi possível criar o rastreamento do pedido",
        variant: "destructive"
      });
      throw error;
    }
  };

  const updateOrderStatus = async (id: string, status: OrderTracking['status']) => {
    try {
      // Mapear status do painel para status da tabela user_orders
      const userOrderStatus = mapToUserOrderStatus(status);
      
      const { error } = await supabase
        .from('user_orders')
        .update({ 
          status: userOrderStatus,
          updated_at: new Date().toISOString() 
        })
        .eq('id', id);

      if (error) throw error;

      fetchOrders();
      toast({
        title: "Status atualizado!",
        description: `Status do pedido alterado para: ${getStatusLabel(status)}`
      });
    } catch (error) {
      console.error('Erro ao atualizar status:', error);
      toast({
        title: "Erro ao atualizar",
        description: "Não foi possível atualizar o status do pedido",
        variant: "destructive"
      });
    }
  };

  // Mapear status do painel para status da tabela user_orders
  const mapToUserOrderStatus = (status: OrderTracking['status']): string => {
    switch (status) {
      case 'pending':
        return 'confirmed';
      case 'preparing':
        return 'preparing';
      case 'delivery':
        return 'out_for_delivery';
      default:
        return 'pending';
    }
  };

  const markWhatsAppSent = async (id: string) => {
    try {
      const { error } = await supabase
        .from('order_preparation_tracking')
        .update({ 
          whatsapp_sent: true,
          whatsapp_sent_at: new Date().toISOString(),
          updated_at: new Date().toISOString()
        })
        .eq('id', id);

      if (error) throw error;
      fetchOrders();
    } catch (error) {
      console.error('Erro ao marcar WhatsApp como enviado:', error);
    }
  };

  const getStatusLabel = (status: OrderTracking['status']) => {
    const labels = {
      pending: 'Aguardando Pagamento',
      preparing: 'Em Preparo',
      delivery: 'Em Entrega'
    };
    return labels[status];
  };

  const getStatusColor = (status: OrderTracking['status']) => {
    const colors = {
      pending: 'bg-blue-100 text-blue-800',
      preparing: 'bg-yellow-100 text-yellow-800',
      delivery: 'bg-green-100 text-green-800'
    };
    return colors[status];
  };

  return {
    orders,
    loading,
    createOrderTracking,
    updateOrderStatus,
    markWhatsAppSent,
    getStatusLabel,
    getStatusColor,
    fetchOrders
  };
};
