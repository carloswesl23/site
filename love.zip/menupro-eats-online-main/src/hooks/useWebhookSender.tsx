
import { supabase } from "@/integrations/supabase/client";

interface WebhookEventData {
  event_type: string;
  data: any;
}

export const useWebhookSender = () => {
  const sendWebhook = async (eventData: WebhookEventData) => {
    try {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) {
        console.log('No user authenticated, skipping webhook');
        return;
      }

      console.log('Sending webhook:', eventData.event_type);
      
      const { data, error } = await supabase.functions.invoke('send-webhook', {
        body: {
          event_type: eventData.event_type,
          data: eventData.data,
          user_id: user.id
        }
      });

      if (error) {
        console.error('Error sending webhook:', error);
        return;
      }

      console.log('Webhook sent successfully:', data);
    } catch (error) {
      console.error('Webhook sending failed:', error);
    }
  };

  return { sendWebhook };
};
