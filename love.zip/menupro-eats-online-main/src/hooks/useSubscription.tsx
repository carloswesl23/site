
import { useState, useEffect } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { useToast } from '@/hooks/use-toast';

interface Subscription {
  id: string;
  user_id: string;
  email: string;
  subscribed: boolean;
  subscription_tier: string | null;
  subscription_end: string | null;
}

// Lista de emails de administradores que podem acessar sem plano
const ADMIN_EMAILS = [
  'admin@lovemenu.com',
  'teste@lovemenu.com',
  'dev@lovemenu.com'
];

export function useSubscription() {
  const [subscription, setSubscription] = useState<Subscription | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [hasActiveSubscription, setHasActiveSubscription] = useState(false);
  const { toast } = useToast();

  useEffect(() => {
    checkSubscriptionStatus();
  }, []);

  const checkSubscriptionStatus = async () => {
    try {
      const { data: { user } } = await supabase.auth.getUser();
      
      if (!user) {
        setIsLoading(false);
        return;
      }

      // Check if user is admin
      const isAdmin = user.email && ADMIN_EMAILS.includes(user.email);
      
      if (isAdmin) {
        // Admin users always have active subscription
        setHasActiveSubscription(true);
        setIsLoading(false);
        return;
      }

      const { data, error } = await supabase
        .from('subscribers')
        .select('*')
        .eq('user_id', user.id)
        .single();

      if (error && error.code !== 'PGRST116') {
        console.error('Error checking subscription:', error);
        toast({
          title: "Erro ao verificar assinatura",
          description: "Tente novamente em alguns instantes.",
          variant: "destructive",
        });
        setIsLoading(false);
        return;
      }

      if (data) {
        setSubscription(data);
        
        // Check if subscription is active
        const isActive = data.subscribed && 
          (!data.subscription_end || new Date(data.subscription_end) > new Date());
        
        setHasActiveSubscription(isActive);
      }
    } catch (error) {
      console.error('Error checking subscription:', error);
    } finally {
      setIsLoading(false);
    }
  };

  const createSubscription = async (tier: string) => {
    try {
      const { data: { user } } = await supabase.auth.getUser();
      
      if (!user) {
        throw new Error('User not authenticated');
      }

      // Calculate subscription end date based on tier
      const now = new Date();
      let subscriptionEnd: Date;
      
      switch (tier) {
        case 'monthly':
          subscriptionEnd = new Date(now.setMonth(now.getMonth() + 1));
          break;
        case 'quarterly':
          subscriptionEnd = new Date(now.setMonth(now.getMonth() + 3));
          break;
        case 'annual':
          subscriptionEnd = new Date(now.setFullYear(now.getFullYear() + 1));
          break;
        default:
          throw new Error('Invalid subscription tier');
      }

      const { data, error } = await supabase
        .from('subscribers')
        .upsert({
          user_id: user.id,
          email: user.email!,
          subscribed: true,
          subscription_tier: tier,
          subscription_end: subscriptionEnd.toISOString(),
        })
        .select()
        .single();

      if (error) {
        throw error;
      }

      setSubscription(data);
      setHasActiveSubscription(true);
      
      toast({
        title: "Assinatura ativada!",
        description: "Bem-vindo ao LoveMenu! Sua assinatura está ativa.",
      });

      return data;
    } catch (error) {
      console.error('Error creating subscription:', error);
      toast({
        title: "Erro ao criar assinatura",
        description: "Tente novamente em alguns instantes.",
        variant: "destructive",
      });
      throw error;
    }
  };

  return {
    subscription,
    isLoading,
    hasActiveSubscription,
    checkSubscriptionStatus,
    createSubscription,
  };
}
