import { useState } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { useToast } from '@/components/ui/use-toast';

export const useWhatsAppBackfill = () => {
  const [isLoading, setIsLoading] = useState(false);
  const { toast } = useToast();

  const performBackfill = async (instanceId: string, tokenInstance: string, phone: string, userId: string) => {
    setIsLoading(true);
    
    try {
      const { data, error } = await supabase.functions.invoke('wa-chat-backfill', {
        body: {
          instanceId,
          tokenInstance,
          phone,
          userId
        }
      });

      if (error) {
        console.error('Erro no backfill:', error);
        toast({
          title: "Erro",
          description: "Falha ao sincronizar histórico de mensagens",
          variant: "destructive",
        });
        return false;
      }

      console.log('Backfill realizado:', data);
      
      if (data.newMessagesSaved > 0) {
        toast({
          title: "Histórico sincronizado",
          description: `${data.newMessagesSaved} mensagens foram sincronizadas`,
        });
      }

      return true;
    } catch (error) {
      console.error('Erro no backfill:', error);
      toast({
        title: "Erro",
        description: "Falha ao sincronizar histórico de mensagens",
        variant: "destructive",
      });
      return false;
    } finally {
      setIsLoading(false);
    }
  };

  return {
    performBackfill,
    isLoading
  };
};