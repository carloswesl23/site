import { useState, useEffect } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { useToast } from '@/hooks/use-toast';

interface UserProduct {
  id: string;
  name: string;
  description: string | null;
  price: number;
  image: string | null;
  category: string;
  is_promotion: boolean;
  promotion_price: number | null;
  show_online_menu: boolean;
  customizable: boolean;
  is_pizza: boolean;
  ingredients?: string[];
  extras?: { name: string; price: number; is_free?: boolean }[];
  max_flavors?: number;
  pizza_flavors?: { name: string; price: number; ingredients: string[] }[];
  pizza_borders?: { name: string; price: number; is_free?: boolean }[];
  created_at: string;
  updated_at: string;
}

// Helper function to transform database JSON fields to typed objects
const transformProductData = (dbProduct: any): UserProduct => {
  return {
    ...dbProduct,
    extras: Array.isArray(dbProduct.extras) 
      ? dbProduct.extras.map((extra: any) => ({
          name: extra.name || '',
          price: Number(extra.price) || 0,
          is_free: Boolean(extra.is_free)
        }))
      : [],
    pizza_borders: Array.isArray(dbProduct.pizza_borders)
      ? dbProduct.pizza_borders.map((border: any) => ({
          name: border.name || '',
          price: Number(border.price) || 0,
          is_free: Boolean(border.is_free)
        }))
      : [],
    pizza_flavors: Array.isArray(dbProduct.pizza_flavors)
      ? dbProduct.pizza_flavors.map((flavor: any) => ({
          name: flavor.name || '',
          price: Number(flavor.price) || 0,
          ingredients: Array.isArray(flavor.ingredients) ? flavor.ingredients : []
        }))
      : [],
    ingredients: Array.isArray(dbProduct.ingredients) ? dbProduct.ingredients : [],
    max_flavors: Number(dbProduct.max_flavors) || 1
  };
};

interface UserCategory {
  id: string;
  name: string;
  sort_order: number;
  created_at: string;
  updated_at: string;
}

interface UserOrder {
  id: string;
  order_number: string;
  customer_name: string;
  customer_phone: string | null;
  customer_email: string | null;
  items: any[];
  total: number;
  status: string;
  payment_method: string | null;
  delivery_address: string | null;
  notes: string | null;
  created_at: string;
  updated_at: string;
}

interface EstablishmentSettings {
  id: string;
  business_name: string;
  business_phone: string | null;
  business_address: string | null;
  business_logo: string | null;
  online_menu_slug: string | null;
  mobile_layout_mode: 'single' | 'double';
  primary_color: string;
  secondary_color: string;
  carrousel_banners: string | null;
  instagram_url: string | null;
  pix_key: string | null;
  pix_beneficiary_name: string | null;
  pix_beneficiary_document: string | null;
  pix_enabled: boolean;
  accept_cash: boolean;
  accept_credit_on_delivery: boolean;
  combine_payment_via_whatsapp: boolean;
  show_qr_pix: boolean;
  checkout_custom_message: string;
  created_at: string;
  updated_at: string;
}

interface UserCustomer {
  id: string;
  customer_name: string;
  customer_phone: string | null;
  customer_email: string | null;
  delivery_address: string | null;
  total_orders: number;
  total_spent: number;
  last_order_date: string;
  created_at: string;
  updated_at: string;
}

interface UpsellConfig {
  id: string;
  product_id: string;
  is_active: boolean;
  suggested_products: string[];
  created_at: string;
  updated_at: string;
}

export function useUserData() {
  const [products, setProducts] = useState<UserProduct[]>([]);
  const [categories, setCategories] = useState<UserCategory[]>([]);
  const [orders, setOrders] = useState<UserOrder[]>([]);
  const [customers, setCustomers] = useState<UserCustomer[]>([]);
  const [settings, setSettings] = useState<EstablishmentSettings | null>(null);
  const [upsellConfigs, setUpsellConfigs] = useState<UpsellConfig[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const { toast } = useToast();

  const fetchUserData = async () => {
    try {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) {
        console.log('No user found, redirecting to login');
        setIsLoading(false);
        return;
      }

      console.log('Fetching data for user:', user.id);

      // Buscar configurações primeiro para garantir que o setup foi feito
      const { data: settingsData, error: settingsError } = await supabase
        .from('establishment_settings')
        .select('*')
        .eq('user_id', user.id)
        .single();

      if (settingsError && settingsError.code !== 'PGRST116') {
        console.error('Error fetching settings:', settingsError);
      } else if (settingsData) {
        console.log('Settings found for user:', settingsData);
        setSettings({
          ...settingsData,
          mobile_layout_mode: settingsData.mobile_layout_mode === 'double' ? 'double' : 'single',
          carrousel_banners: (settingsData as any).carrousel_banners || null,
          instagram_url: (settingsData as any).instagram_url || null,
          pix_key: (settingsData as any).pix_key || null,
          pix_beneficiary_name: (settingsData as any).pix_beneficiary_name || null,
          pix_beneficiary_document: (settingsData as any).pix_beneficiary_document || null,
          pix_enabled: (settingsData as any).pix_enabled || false,
          accept_cash: (settingsData as any).accept_cash ?? true,
          accept_credit_on_delivery: (settingsData as any).accept_credit_on_delivery ?? true,
          combine_payment_via_whatsapp: (settingsData as any).combine_payment_via_whatsapp ?? true,
          show_qr_pix: (settingsData as any).show_qr_pix ?? true,
          checkout_custom_message: (settingsData as any).checkout_custom_message || "Obrigado! Aguarde que já vamos preparar seu pedido."
        });
      } else {
        console.log('No settings found for user - this should not happen with auto setup');
      }

      // Buscar produtos
      const { data: productsData, error: productsError } = await supabase
        .from('user_products')
        .select('*')
        .eq('user_id', user.id)
        .order('created_at', { ascending: false });

      if (productsError) {
        console.error('Error fetching products:', productsError);
      } else {
        console.log('Products found for user:', productsData?.length || 0);
        const transformedProducts = (productsData || []).map(transformProductData);
        setProducts(transformedProducts);
      }

      // Buscar categorias
      const { data: categoriesData, error: categoriesError } = await supabase
        .from('user_categories')
        .select('*')
        .eq('user_id', user.id)
        .order('sort_order', { ascending: true });

      if (categoriesError) {
        console.error('Error fetching categories:', categoriesError);
      } else {
        console.log('Categories found for user:', categoriesData?.length || 0);
        setCategories(categoriesData || []);
      }

      // Buscar pedidos
      const { data: ordersData, error: ordersError } = await supabase
        .from('user_orders')
        .select('*')
        .eq('user_id', user.id)
        .order('created_at', { ascending: false });

      if (ordersError) {
        console.error('Error fetching orders:', ordersError);
      } else {
        console.log('Orders found for user:', ordersData?.length || 0);
        setOrders((ordersData || []).map(order => ({
          ...order,
          items: Array.isArray(order.items) ? order.items : []
        })));
      }

      // Buscar clientes
      const { data: customersData, error: customersError } = await supabase
        .from('user_customers')
        .select('*')
        .eq('user_id', user.id)
        .order('total_spent', { ascending: false });

      if (customersError) {
        console.error('Error fetching customers:', customersError);
      } else {
        console.log('Customers found for user:', customersData?.length || 0);
        setCustomers(customersData || []);
      }

      // Buscar configurações de upsell
      const { data: upsellData, error: upsellError } = await supabase
        .from('upsell_configs')
        .select('*')
        .eq('user_id', user.id)
        .order('created_at', { ascending: false });

      if (upsellError) {
        console.error('Error fetching upsell configs:', upsellError);
      } else {
        console.log('Upsell configs found for user:', upsellData?.length || 0);
        setUpsellConfigs(upsellData || []);
      }

    } catch (error) {
      console.error('Error in fetchUserData:', error);
      toast({
        title: "Erro ao carregar dados",
        description: "Tente novamente em alguns instantes.",
        variant: "destructive",
      });
    } finally {
      setIsLoading(false);
    }
  };

  const addProduct = async (productData: Omit<UserProduct, 'id' | 'created_at' | 'updated_at'>) => {
    try {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) throw new Error('User not authenticated');

      const { data, error } = await supabase
        .from('user_products')
        .insert([{ ...productData, user_id: user.id }])
        .select()
        .single();

      if (error) throw error;

      const transformedProduct = transformProductData(data);
      setProducts(prev => [transformedProduct, ...prev]);
      toast({
        title: "Produto adicionado",
        description: "O produto foi adicionado com sucesso.",
      });

      return transformedProduct;
    } catch (error) {
      console.error('Error adding product:', error);
      toast({
        title: "Erro ao adicionar produto",
        description: "Tente novamente em alguns instantes.",
        variant: "destructive",
      });
      throw error;
    }
  };

  const updateProduct = async (id: string, updates: Partial<UserProduct>) => {
    try {
      const { data, error } = await supabase
        .from('user_products')
        .update(updates)
        .eq('id', id)
        .select()
        .single();

      if (error) throw error;

      const transformedProduct = transformProductData(data);
      setProducts(prev => prev.map(p => p.id === id ? transformedProduct : p));
      toast({
        title: "Produto atualizado",
        description: "O produto foi atualizado com sucesso.",
      });

      return transformedProduct;
    } catch (error) {
      console.error('Error updating product:', error);
      toast({
        title: "Erro ao atualizar produto",
        description: "Tente novamente em alguns instantes.",
        variant: "destructive",
      });
      throw error;
    }
  };

  const deleteProduct = async (id: string) => {
    try {
      const { error } = await supabase
        .from('user_products')
        .delete()
        .eq('id', id);

      if (error) throw error;

      setProducts(prev => prev.filter(p => p.id !== id));
      toast({
        title: "Produto removido",
        description: "O produto foi removido com sucesso.",
      });
    } catch (error) {
      console.error('Error deleting product:', error);
      toast({
        title: "Erro ao remover produto",
        description: "Tente novamente em alguns instantes.",
        variant: "destructive",
      });
      throw error;
    }
  };

  const addCategory = async (name: string) => {
    try {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) throw new Error('User not authenticated');

      const maxOrder = Math.max(...categories.map(c => c.sort_order), 0);

      const { data, error } = await supabase
        .from('user_categories')
        .insert([{ 
          user_id: user.id, 
          name: name.trim(),
          sort_order: maxOrder + 1 
        }])
        .select()
        .single();

      if (error) throw error;

      setCategories(prev => [...prev, data]);
      toast({
        title: "Categoria adicionada",
        description: "A categoria foi adicionada com sucesso.",
      });

      return data;
    } catch (error) {
      console.error('Error adding category:', error);
      toast({
        title: "Erro ao adicionar categoria",
        description: "Tente novamente em alguns instantes.",
        variant: "destructive",
      });
      throw error;
    }
  };

  const updateCategory = async (id: string, updates: { name?: string; sort_order?: number }) => {
    try {
      const { data, error } = await supabase
        .from('user_categories')
        .update(updates)
        .eq('id', id)
        .select()
        .single();

      if (error) throw error;

      setCategories(prev => prev.map(c => c.id === id ? data : c));
      toast({
        title: "Categoria atualizada",
        description: "A categoria foi atualizada com sucesso.",
      });

      return data;
    } catch (error) {
      console.error('Error updating category:', error);
      toast({
        title: "Erro ao atualizar categoria",
        description: "Tente novamente em alguns instantes.",
        variant: "destructive",
      });
      throw error;
    }
  };

  const deleteCategory = async (id: string) => {
    try {
      const { error } = await supabase
        .from('user_categories')
        .delete()
        .eq('id', id);

      if (error) throw error;

      setCategories(prev => prev.filter(c => c.id !== id));
      toast({
        title: "Categoria removida",
        description: "A categoria foi removida com sucesso.",
      });
    } catch (error) {
      console.error('Error deleting category:', error);
      toast({
        title: "Erro ao remover categoria",
        description: "Tente novamente em alguns instantes.",
        variant: "destructive",
      });
      throw error;
    }
  };

  const updateSettings = async (updates: Partial<EstablishmentSettings>) => {
    try {
      console.log('=== INÍCIO updateSettings ===');
      console.log('Updates recebidos:', updates);
      
      // Log específico para Instagram
      if (updates.instagram_url !== undefined) {
        console.log('🔍 INSTAGRAM URL DETECTADA:', updates.instagram_url);
      }
      
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) {
        console.error('Usuário não autenticado');
        throw new Error('User not authenticated');
      }
      
      console.log('Usuário autenticado:', user.id);

      // Get current settings or create default
      console.log('Buscando configurações atuais...');
      const { data: currentSettings } = await supabase
        .from('establishment_settings')
        .select('*')
        .eq('user_id', user.id)
        .single();

      console.log('Configurações atuais:', currentSettings);

      const dataToUpdate = {
        user_id: user.id,
        business_name: currentSettings?.business_name || 'Meu Negócio',
        ...updates
      };

      console.log('Dados para atualizar:', dataToUpdate);

      const { data, error } = await supabase
        .from('establishment_settings')
        .upsert(dataToUpdate, { 
          onConflict: 'user_id',
          ignoreDuplicates: false 
        })
        .select()
        .single();

      console.log('Resposta do upsert:', { data, error });

      if (error) {
        console.error('Erro no upsert:', error);
        throw error;
      }

      console.log('Dados salvos com sucesso:', data);
      
      // Log específico para verificar se o Instagram foi salvo
      if (data.instagram_url !== undefined) {
        console.log('✅ INSTAGRAM URL SALVO NO BANCO:', data.instagram_url);
      }

      const newSettings: EstablishmentSettings = {
        ...data,
        mobile_layout_mode: (data.mobile_layout_mode === 'double' ? 'double' : 'single') as 'single' | 'double',
        carrousel_banners: (data as any).carrousel_banners || null,
        instagram_url: (data as any).instagram_url || null,
        pix_key: (data as any).pix_key || null,
        pix_beneficiary_name: (data as any).pix_beneficiary_name || null,
        pix_beneficiary_document: (data as any).pix_beneficiary_document || null,
        pix_enabled: (data as any).pix_enabled || false,
        accept_cash: (data as any).accept_cash ?? true,
        accept_credit_on_delivery: (data as any).accept_credit_on_delivery ?? true,
        combine_payment_via_whatsapp: (data as any).combine_payment_via_whatsapp ?? true,
        show_qr_pix: (data as any).show_qr_pix ?? true,
        checkout_custom_message: (data as any).checkout_custom_message || "Obrigado! Aguarde que já vamos preparar seu pedido."
      };
      
      setSettings(newSettings);
      
      console.log('Estado local atualizado');
      console.log('📱 NOVO ESTADO (instagram_url):', newSettings.instagram_url);
      
      toast({
        title: "Configurações atualizadas",
        description: "As configurações foram salvas com sucesso.",
      });

      console.log('=== FIM updateSettings ===');
      return data;
    } catch (error) {
      console.error('=== ERRO updateSettings ===');
      console.error('Error updating settings:', error);
      toast({
        title: "Erro ao atualizar configurações",
        description: "Tente novamente em alguns instantes.",
        variant: "destructive",
      });
      throw error;
    }
  };

  const getUpsellConfig = (productId: string): UpsellConfig | null => {
    return upsellConfigs.find(config => config.product_id === productId) || null;
  };

  const updateUpsellConfig = async (productId: string, updates: { is_active?: boolean; suggested_products?: string[] }) => {
    try {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) throw new Error('User not authenticated');

      const { data, error } = await supabase
        .from('upsell_configs')
        .upsert({
          user_id: user.id,
          product_id: productId,
          ...updates
        }, {
          onConflict: 'user_id,product_id'
        })
        .select()
        .single();

      if (error) throw error;

      setUpsellConfigs(prev => {
        const existing = prev.find(config => config.product_id === productId);
        if (existing) {
          return prev.map(config => 
            config.product_id === productId ? data : config
          );
        } else {
          return [...prev, data];
        }
      });

      toast({
        title: "Configuração de upsell atualizada",
        description: "As configurações foram salvas com sucesso.",
      });

      return data;
    } catch (error) {
      console.error('Error updating upsell config:', error);
      toast({
        title: "Erro ao atualizar configuração de upsell",
        description: "Tente novamente em alguns instantes.",
        variant: "destructive",
      });
      throw error;
    }
  };

  const deleteUpsellConfig = async (productId: string) => {
    try {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) throw new Error('User not authenticated');

      const { error } = await supabase
        .from('upsell_configs')
        .delete()
        .eq('user_id', user.id)
        .eq('product_id', productId);

      if (error) throw error;

      setUpsellConfigs(prev => prev.filter(config => config.product_id !== productId));
      toast({
        title: "Configuração de upsell removida",
        description: "A configuração foi removida com sucesso.",
      });
    } catch (error) {
      console.error('Error deleting upsell config:', error);
      toast({
        title: "Erro ao remover configuração de upsell",
        description: "Tente novamente em alguns instantes.",
        variant: "destructive",
      });
      throw error;
    }
  };

  useEffect(() => {
    fetchUserData();
  }, []);

  return {
    products,
    categories,
    orders,
    customers,
    settings,
    upsellConfigs,
    isLoading,
    fetchUserData,
    addProduct,
    updateProduct,
    deleteProduct,
    addCategory,
    updateCategory,
    deleteCategory,
    updateSettings,
    getUpsellConfig,
    updateUpsellConfig,
    deleteUpsellConfig,
  };
}