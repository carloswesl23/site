import { useState, useCallback } from 'react';
import { 
  validateEmail, 
  validatePhone, 
  validateName, 
  validateAddress, 
  validatePassword,
  sanitizeInput 
} from '@/utils/security';

interface ValidationRules {
  required?: boolean;
  type?: 'email' | 'phone' | 'name' | 'address' | 'password' | 'text';
  minLength?: number;
  maxLength?: number;
}

interface FieldState {
  value: string;
  error: string | null;
  touched: boolean;
}

export const useSecureInput = (initialValues: Record<string, string> = {}) => {
  const [fields, setFields] = useState<Record<string, FieldState>>(() => {
    const initialFields: Record<string, FieldState> = {};
    Object.keys(initialValues).forEach(key => {
      initialFields[key] = {
        value: initialValues[key],
        error: null,
        touched: false
      };
    });
    return initialFields;
  });

  const validateField = useCallback((name: string, value: string, rules: ValidationRules = {}) => {
    // Required validation
    if (rules.required && !value.trim()) {
      return { isValid: false, error: 'Este campo é obrigatório' };
    }

    // Skip other validations if field is empty and not required
    if (!value.trim() && !rules.required) {
      return { isValid: true, error: null };
    }

    // Type-specific validation
    switch (rules.type) {
      case 'email':
        return validateEmail(value);
      case 'phone':
        return validatePhone(value);
      case 'name':
        return validateName(value);
      case 'address':
        return validateAddress(value);
      case 'password':
        return validatePassword(value);
      default:
        // Generic text validation
        if (rules.minLength && value.length < rules.minLength) {
          return { isValid: false, error: `Mínimo ${rules.minLength} caracteres` };
        } else if (rules.maxLength && value.length > rules.maxLength) {
          return { isValid: false, error: `Máximo ${rules.maxLength} caracteres` };
        }
        return { isValid: true, error: null };
    }
  }, []);

  const updateField = useCallback((name: string, value: string, rules: ValidationRules = {}) => {
    // Preserve spaces for name fields
    const preserveSpaces = rules.type === 'name';
    const sanitizedValue = sanitizeInput(value, preserveSpaces);
    const validation = validateField(name, sanitizedValue, rules);

    setFields(prev => ({
      ...prev,
      [name]: {
        value: sanitizedValue,
        error: validation.isValid ? null : (validation.error || null),
        touched: true
      }
    }));

    return validation.isValid;
  }, [validateField]);

  const validateAllFields = useCallback((validationRules: Record<string, ValidationRules> = {}) => {
    let isValid = true;
    const newFields = { ...fields };

    Object.keys(fields).forEach(fieldName => {
      const rules = validationRules[fieldName] || {};
      const validation = validateField(fieldName, fields[fieldName].value, rules);
      
      newFields[fieldName] = {
        ...newFields[fieldName],
        error: validation.isValid ? null : (validation.error || null),
        touched: true
      };

      if (!validation.isValid) {
        isValid = false;
      }
    });

    setFields(newFields);
    return isValid;
  }, [fields, validateField]);

  const getFieldProps = useCallback((name: string) => ({
    value: fields[name]?.value || '',
    error: fields[name]?.error || null,
    touched: fields[name]?.touched || false
  }), [fields]);

  const resetFields = useCallback(() => {
    setFields(prev => {
      const resetFields: Record<string, FieldState> = {};
      Object.keys(prev).forEach(key => {
        resetFields[key] = {
          value: '',
          error: null,
          touched: false
        };
      });
      return resetFields;
    });
  }, []);

  const hasErrors = Object.values(fields).some(field => field.error !== null);
  const allTouched = Object.values(fields).every(field => field.touched);

  return {
    fields,
    updateField,
    validateAllFields,
    getFieldProps,
    resetFields,
    hasErrors,
    allTouched
  };
};