import { useState, useEffect, useCallback } from 'react';

export const useLoveZapMini = () => {
  const [isOpen, setIsOpen] = useState(false);
  const [isEnabled, setIsEnabled] = useState(true);
  const [soundEnabled, setSoundEnabled] = useState(true);
  const [selectedPhone, setSelectedPhone] = useState<string | undefined>();

  useEffect(() => {
    // Load settings from localStorage
    const enabled = localStorage.getItem('lovezap_mini_enabled');
    const sound = localStorage.getItem('lovezap_sound');
    const openState = localStorage.getItem('lovezap_mini_open');
    
    setIsEnabled(enabled !== 'false');
    setSoundEnabled(sound !== 'false');
    setIsOpen(openState === 'true');
  }, []);

  // Save open state to localStorage
  useEffect(() => {
    localStorage.setItem('lovezap_mini_open', isOpen.toString());
  }, [isOpen]);

  const toggleEnabled = useCallback((enabled: boolean) => {
    localStorage.setItem('lovezap_mini_enabled', enabled.toString());
    setIsEnabled(enabled);
    if (!enabled) {
      setIsOpen(false);
    }
  }, []);

  const toggleSound = useCallback((enabled: boolean) => {
    localStorage.setItem('lovezap_sound', enabled.toString());
    setSoundEnabled(enabled);
  }, []);

  const openMiniInbox = useCallback((phone?: string) => {
    if (isEnabled) {
      setIsOpen(true);
      if (phone) {
        setSelectedPhone(phone);
      }
    }
  }, [isEnabled]);

  const closeMiniInbox = useCallback(() => {
    setIsOpen(false);
    setSelectedPhone(undefined);
  }, []);

  const toggleMiniInbox = useCallback(() => {
    if (isOpen) {
      closeMiniInbox();
    } else {
      openMiniInbox();
    }
  }, [isOpen, openMiniInbox, closeMiniInbox]);

  // Handle ESC key
  useEffect(() => {
    const handleEscape = (event: KeyboardEvent) => {
      if (event.key === 'Escape' && isOpen) {
        closeMiniInbox();
      }
    };

    document.addEventListener('keydown', handleEscape);
    return () => document.removeEventListener('keydown', handleEscape);
  }, [isOpen, closeMiniInbox]);

  return {
    isOpen,
    isEnabled,
    soundEnabled,
    selectedPhone,
    openMiniInbox,
    closeMiniInbox,
    toggleMiniInbox,
    toggleEnabled,
    toggleSound,
    setSelectedPhone
  };
};