import { useState, useCallback } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { validateImageFile, validateFileContent, generateSecureFilename } from '@/utils/fileValidation';
import { logInvalidFileUpload } from '@/utils/securityMonitoring';
import { useToast } from '@/hooks/use-toast';

interface UploadResult {
  url?: string;
  error?: string;
  path?: string;
}

interface UseSecureFileUploadProps {
  bucket: string;
  folder?: string;
}

export const useSecureFileUpload = ({ bucket, folder }: UseSecureFileUploadProps) => {
  const [uploading, setUploading] = useState(false);
  const { toast } = useToast();

  const uploadFile = useCallback(async (
    file: File,
    userId: string,
    customPath?: string
  ): Promise<UploadResult> => {
    setUploading(true);

    try {
      // Step 1: Validate file type and size
      const basicValidation = validateImageFile(file);
      if (!basicValidation.isValid) {
        logInvalidFileUpload(file.name, basicValidation.error || 'Basic validation failed');
        toast({
          title: 'Arquivo inválido',
          description: basicValidation.error,
          variant: 'destructive'
        });
        return { error: basicValidation.error };
      }

      // Step 2: Validate file content
      const contentValidation = await validateFileContent(file);
      if (!contentValidation.isValid) {
        logInvalidFileUpload(file.name, contentValidation.error || 'Content validation failed');
        toast({
          title: 'Arquivo inválido',
          description: contentValidation.error,
          variant: 'destructive'
        });
        return { error: contentValidation.error };
      }

      // Step 3: Generate secure filename
      const secureFilename = generateSecureFilename(file.name, userId);
      const filePath = customPath || `${folder ? `${folder}/` : ''}${secureFilename}`;

      // Step 4: Upload to Supabase Storage
      const { data, error } = await supabase.storage
        .from(bucket)
        .upload(filePath, file, {
          cacheControl: '3600',
          upsert: false // Don't overwrite existing files
        });

      if (error) {
        console.error('Upload error:', error);
        toast({
          title: 'Erro no upload',
          description: 'Não foi possível fazer upload do arquivo.',
          variant: 'destructive'
        });
        return { error: error.message };
      }

      // Step 5: Get public URL
      const { data: urlData } = supabase.storage
        .from(bucket)
        .getPublicUrl(data.path);

      toast({
        title: 'Upload realizado',
        description: 'Arquivo enviado com sucesso!'
      });

      return {
        url: urlData.publicUrl,
        path: data.path
      };

    } catch (error: any) {
      console.error('Unexpected upload error:', error);
      logInvalidFileUpload(file.name, `Unexpected error: ${error.message}`);
      
      toast({
        title: 'Erro inesperado',
        description: 'Ocorreu um erro durante o upload.',
        variant: 'destructive'
      });
      
      return { error: 'Erro inesperado durante o upload' };
    } finally {
      setUploading(false);
    }
  }, [bucket, folder, toast]);

  const deleteFile = useCallback(async (path: string): Promise<boolean> => {
    try {
      const { error } = await supabase.storage
        .from(bucket)
        .remove([path]);

      if (error) {
        console.error('Delete error:', error);
        return false;
      }

      return true;
    } catch (error) {
      console.error('Unexpected delete error:', error);
      return false;
    }
  }, [bucket]);

  return {
    uploadFile,
    deleteFile,
    uploading
  };
};