import { supabase } from "@/integrations/supabase/client";
import { DiscountCoupon, CouponUsageStats, CreateCouponData } from "@/types/coupons";

export const couponService = {
  async fetchUserCoupons(userId: string): Promise<DiscountCoupon[]> {
    const { data, error } = await supabase
      .from('discount_coupons')
      .select('*')
      .eq('user_id', userId)
      .order('created_at', { ascending: false });

    if (error) throw error;
    return data || [];
  },

  async createCoupon(couponData: CreateCouponData): Promise<DiscountCoupon> {
    const { data, error } = await supabase
      .from('discount_coupons')
      .insert(couponData)
      .select()
      .single();

    if (error) throw error;
    return data;
  },

  async updateCoupon(id: string, updates: Partial<DiscountCoupon>): Promise<DiscountCoupon> {
    const { data, error } = await supabase
      .from('discount_coupons')
      .update(updates)
      .eq('id', id)
      .select()
      .single();

    if (error) throw error;
    return data;
  },

  async deleteCoupon(id: string): Promise<void> {
    const { error } = await supabase
      .from('discount_coupons')
      .delete()
      .eq('id', id);

    if (error) throw error;
  },

  async getCouponStats(couponId: string): Promise<CouponUsageStats> {
    const { data, error } = await supabase
      .from('coupon_usage')
      .select('discount_applied, order_total, customer_name, customer_phone')
      .eq('coupon_id', couponId);

    if (error) throw error;

    const uniqueCustomers = new Set();
    let totalSales = 0;
    let totalDiscountGiven = 0;

    data?.forEach(usage => {
      const customerKey = `${usage.customer_name}-${usage.customer_phone}`;
      uniqueCustomers.add(customerKey);
      totalSales += Number(usage.order_total);
      totalDiscountGiven += Number(usage.discount_applied);
    });

    return {
      total_orders: data?.length || 0,
      total_sales: totalSales,
      unique_customers: uniqueCustomers.size,
      total_discount_given: totalDiscountGiven
    };
  },

  async getAutoCoupons(establishmentId: string): Promise<DiscountCoupon[]> {
    const { data, error } = await supabase
      .from('discount_coupons')
      .select('*')
      .eq('user_id', establishmentId)
      .eq('is_active', true)
      .eq('auto_apply', true)
      .gte('valid_until', new Date().toISOString())
      .or('valid_until.is.null');

    if (error) throw error;
    return data || [];
  }
};