import { supabase } from "@/integrations/supabase/client";

export interface MercadoPagoConfig {
  publicKey: string;
  accessToken: string;
  webhookUrl: string;
  enabled: boolean;
}

export interface CreatePaymentData {
  transaction_amount: number;
  description: string;
  external_reference: string;
  payer: {
    email: string;
    first_name?: string;
    last_name?: string;
  };
}

export interface PaymentResponse {
  id: string;
  status: string;
  point_of_interaction?: {
    transaction_data?: {
      qr_code?: string;
      qr_code_base64?: string;
    };
  };
  init_point?: string;
}

export class MercadoPagoService {
  private config: MercadoPagoConfig | null = null;

  async loadConfig(userId: string): Promise<MercadoPagoConfig | null> {
    try {
      const { data: settings } = await supabase
        .from('establishment_settings')
        .select('mp_public_key, mp_access_token, mp_webhook_url, mp_enabled')
        .eq('user_id', userId)
        .single();

      if (settings && settings.mp_enabled && settings.mp_access_token) {
        this.config = {
          publicKey: settings.mp_public_key || '',
          accessToken: settings.mp_access_token,
          webhookUrl: settings.mp_webhook_url || '',
          enabled: settings.mp_enabled
        };
        return this.config;
      }
      return null;
    } catch (error) {
      console.error('Error loading MercadoPago config:', error);
      return null;
    }
  }

  async createPayment(paymentData: CreatePaymentData): Promise<PaymentResponse | null> {
    if (!this.config || !this.config.enabled) {
      throw new Error('MercadoPago não está configurado ou habilitado');
    }

    try {
      const response = await fetch('https://api.mercadopago.com/v1/payments', {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${this.config.accessToken}`,
          'Content-Type': 'application/json',
          'X-Idempotency-Key': `${paymentData.external_reference}-${Date.now()}`
        },
        body: JSON.stringify({
          ...paymentData,
          notification_url: this.config.webhookUrl,
          auto_return: 'approved',
          binary_mode: false
        })
      });

      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(`MercadoPago API Error: ${JSON.stringify(errorData)}`);
      }

      const paymentResponse: PaymentResponse = await response.json();
      
      // Salvar registro do pagamento no Supabase
      await this.savePaymentRecord(paymentData.external_reference, paymentResponse);
      
      return paymentResponse;
    } catch (error) {
      console.error('Error creating MercadoPago payment:', error);
      throw error;
    }
  }

  async createPreference(paymentData: CreatePaymentData & { success_url?: string; failure_url?: string }) {
    if (!this.config || !this.config.enabled) {
      throw new Error('MercadoPago não está configurado ou habilitado');
    }

    try {
      const preferenceData = {
        items: [{
          title: paymentData.description,
          quantity: 1,
          unit_price: paymentData.transaction_amount
        }],
        external_reference: paymentData.external_reference,
        payer: paymentData.payer,
        notification_url: this.config.webhookUrl,
        back_urls: {
          success: paymentData.success_url,
          failure: paymentData.failure_url,
          pending: paymentData.success_url
        },
        auto_return: 'approved'
      };

      const response = await fetch('https://api.mercadopago.com/checkout/preferences', {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${this.config.accessToken}`,
          'Content-Type': 'application/json'
        },
        body: JSON.stringify(preferenceData)
      });

      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(`MercadoPago Preference Error: ${JSON.stringify(errorData)}`);
      }

      return await response.json();
    } catch (error) {
      console.error('Error creating MercadoPago preference:', error);
      throw error;
    }
  }

  private async savePaymentRecord(orderId: string, paymentResponse: PaymentResponse) {
    try {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) return;

      await supabase
        .from('mercadopago_payments')
        .insert({
          user_id: user.id,
          order_id: orderId,
          mp_payment_id: paymentResponse.id,
          mp_external_reference: orderId,
          status: paymentResponse.status,
          amount: 0, // Will be updated by webhook
          currency: 'BRL'
        });
    } catch (error) {
      console.error('Error saving payment record:', error);
    }
  }

  async getPayment(paymentId: string): Promise<any> {
    if (!this.config || !this.config.enabled) {
      throw new Error('MercadoPago não está configurado ou habilitado');
    }

    try {
      const response = await fetch(`https://api.mercadopago.com/v1/payments/${paymentId}`, {
        headers: {
          'Authorization': `Bearer ${this.config.accessToken}`,
          'Content-Type': 'application/json'
        }
      });

      if (!response.ok) {
        throw new Error(`Error fetching payment: ${response.status}`);
      }

      return await response.json();
    } catch (error) {
      console.error('Error getting MercadoPago payment:', error);
      throw error;
    }
  }
}

export const mercadoPagoService = new MercadoPagoService();