// Security headers configuration for enhanced protection

const isDevelopment = import.meta.env.DEV;
const isProduction = import.meta.env.PROD;

// Development CSP (more permissive for dev tools)
const developmentCSP = [
  "default-src 'self'",
  "script-src 'self' 'unsafe-inline' 'unsafe-eval'", // Required for Vite dev and chart libraries
  "style-src 'self' 'unsafe-inline'", // Required for Tailwind and component styles
  "img-src 'self' data: https:", // Allow images from HTTPS sources and data URLs
  "font-src 'self' data:", // Allow fonts
  "connect-src 'self' https://mzhyxympbmjjergvbwfa.supabase.co https://api.openai.com https://wa.me ws: wss:", // API endpoints + WebSocket for dev
  "frame-ancestors 'none'", // Prevent embedding in iframes
  "base-uri 'self'", // Restrict base tag URLs
  "form-action 'self'" // Restrict form submissions
].join('; ');

// Production CSP (stricter, nonce-based)
const productionCSP = [
  "default-src 'self'",
  "script-src 'self'", // No unsafe-inline in production
  "style-src 'self' 'unsafe-inline'", // Still needed for Tailwind
  "img-src 'self' data: https:", // Allow images from HTTPS sources and data URLs
  "font-src 'self' data:", // Allow fonts
  "connect-src 'self' https://mzhyxympbmjjergvbwfa.supabase.co https://api.openai.com https://wa.me", // API endpoints only
  "frame-ancestors 'none'", // Prevent embedding in iframes
  "base-uri 'self'", // Restrict base tag URLs
  "form-action 'self'", // Restrict form submissions
  "upgrade-insecure-requests", // Upgrade HTTP to HTTPS
  "block-all-mixed-content" // Block mixed content
].join('; ');

export const securityHeaders = {
  // Content Security Policy (environment-specific)
  'Content-Security-Policy': isProduction ? productionCSP : developmentCSP,

  // Prevent MIME type sniffing
  'X-Content-Type-Options': 'nosniff',

  // Prevent clickjacking
  'X-Frame-Options': 'DENY',

  // Enable XSS protection
  'X-XSS-Protection': '1; mode=block',

  // Control referrer information
  'Referrer-Policy': 'strict-origin-when-cross-origin',

  // Feature policy restrictions
  'Permissions-Policy': 'camera=(), microphone=(), geolocation=(), payment=()',

  // HTTPS enforcement (production only)
  ...(isProduction && {
    'Strict-Transport-Security': 'max-age=31536000; includeSubDomains; preload'
  }),

  // Additional production security headers
  ...(isProduction && {
    'X-Permitted-Cross-Domain-Policies': 'none',
    'Cross-Origin-Embedder-Policy': 'require-corp',
    'Cross-Origin-Opener-Policy': 'same-origin',
    'Cross-Origin-Resource-Policy': 'same-origin'
  })
};

// Function to apply headers in development
export const applySecurityHeaders = () => {
  if (typeof document !== 'undefined') {
    // Create meta tags for security headers in development
    Object.entries(securityHeaders).forEach(([name, value]) => {
      const existing = document.querySelector(`meta[http-equiv="${name}"]`);
      if (!existing) {
        const meta = document.createElement('meta');
        meta.setAttribute('http-equiv', name);
        meta.setAttribute('content', value);
        document.head.appendChild(meta);
      }
    });
  }
};

// CSP nonce generator for inline scripts (if needed)
export const generateNonce = (): string => {
  const array = new Uint8Array(16);
  crypto.getRandomValues(array);
  return Array.from(array, byte => byte.toString(16).padStart(2, '0')).join('');
};